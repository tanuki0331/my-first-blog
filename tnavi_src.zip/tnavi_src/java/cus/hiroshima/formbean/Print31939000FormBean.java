/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/

package jp.co.systemd.tnavi.cus.hiroshima.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.entity.UserHistoryEntity;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.DataEvalCount31939000Entity;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.DataItemName31939000Entity;

/**
 *
 * �y��ʁz�]�蕪�z�\FormBean�N���X.
 *
 * <B>Create</B> 2017.02.02 BY yamazaki<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print31939000FormBean {

	/** �����l */
	private static final String DEFALUT_VALUE = null;

	/** �����R�[�h */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �N�x(����) */
	private String nendoSeireki = DEFALUT_VALUE;

	/** �w�N */
	private String grade;

	/** �w�Z��� */
	private UserHistoryEntity userhistory;

	/** �]��i�K�� */
	private Integer evalStages;

	/** �敪2 */
	private String usekind2;

	/** �w�Z��� */
	private String useSchoolkind;

	/** ���Ȗ� */
	private List<DataItemName31939000Entity> itemNameList;

	/**	 �Ώ۔N�x�E�w�N�̃}�b�v */
	private Map<String,String> searchInfoMap;

	/** �w�N�S�̐l���̃}�b�v */
	private Map<String,String> totalCountMap;

	/** �]��l�����z�̃}�b�v */
	private Map<String,List<DataEvalCount31939000Entity>> evalCountMap;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getNendoSeireki() {
		return nendoSeireki;
	}

	public void setNendoSeireki(String nendoSeireki) {
		this.nendoSeireki = nendoSeireki;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public UserHistoryEntity getUserhistory() {
		return userhistory;
	}

	public void setUserhistory(UserHistoryEntity userhistory) {
		this.userhistory = userhistory;
	}

	public Integer getEvalStages() {
		return evalStages;
	}

	public void setEvalStages(Integer evalStages) {
		this.evalStages = evalStages;
	}

	public String getUsekind2() {
		return usekind2;
	}

	public void setUsekind2(String usekind2) {
		this.usekind2 = usekind2;
	}

	public String getUseSchoolkind() {
		return useSchoolkind;
	}

	public void setUseSchoolkind(String useSchoolkind) {
		this.useSchoolkind = useSchoolkind;
	}

	public List<DataItemName31939000Entity> getItemNameList() {
		return itemNameList;
	}

	public void setItemNameList(List<DataItemName31939000Entity> itemNameList) {
		this.itemNameList = itemNameList;
	}

	public Map<String, String> getSearchInfoMap() {
		return searchInfoMap;
	}

	public void setSearchInfoMap(Map<String, String> searchInfoMap) {
		this.searchInfoMap = searchInfoMap;
	}

	public Map<String, String> getTotalCountMap() {
		return totalCountMap;
	}

	public void setTotalCountMap(Map<String, String> totalCountMap) {
		this.totalCountMap = totalCountMap;
	}

	public Map<String, List<DataEvalCount31939000Entity>> getEvalCountMap() {
		return evalCountMap;
	}

	public void setEvalCountMap(Map<String, List<DataEvalCount31939000Entity>> evalCountMap) {
		this.evalCountMap = evalCountMap;
	}

}
