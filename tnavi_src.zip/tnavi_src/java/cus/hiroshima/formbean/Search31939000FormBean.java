/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/

package jp.co.systemd.tnavi.cus.hiroshima.formbean;

/**
 *
 * �w���v�^���(�l��3)����FormBean�N���X.
 *
 * <B>Create</B> 2019.02.17 BY SD fukuda<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Search31939000FormBean {

	/** �N�x */
	private String nendo;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

}
