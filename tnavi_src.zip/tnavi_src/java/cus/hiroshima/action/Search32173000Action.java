/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2019 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.hiroshima.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.hiroshima.db.service.Search32173000Service;
import jp.co.systemd.tnavi.cus.hiroshima.formbean.Search32173000FormBean;


/**
 * <PRE>
 *  �o�ȕ��� (�L���������ʎx���w�Z) ���� Action.
 * </PRE>
 *
 * <B>Create</B> 2019.02.18 BY AIVICK hara<BR>
 * <B>remark</B><BR>
 *
 * @author
 * @since 1.0.
 */
public class Search32173000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Search32173000Action.class);
	
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return false;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request, HttpServletResponse response,
			SystemInfoBean sessionBean) {
		
		log.info("�y��ʁz�o�ȕ��� (�L���������ʎx���w�Z) START");
		
		Search32173000FormBean searchFormBean = new Search32173000FormBean();
		copyRequestParamToFormBean(request, searchFormBean);

		Search32173000Service searchService = new Search32173000Service(request, sessionBean, searchFormBean);
		searchService.execute();

		//Request��FormBean���Z�b�g����
		request.setAttribute("FORM_BEAN", searchFormBean);

		log.info("�y��ʁz�o�ȕ��� (�L���������ʎx���w�Z) END");
		
		return null;
	}

}
