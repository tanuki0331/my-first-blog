/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2019 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.hiroshima.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.hiroshima.db.service.Print32173000Service;
import jp.co.systemd.tnavi.cus.hiroshima.formbean.Search32173000FormBean;
import jp.co.systemd.tnavi.cus.hiroshima.print.Print32173000;

/**
 * <PRE>
 *  �o�ȕ��� (�L���������ʎx���w�Z) ��� Action.
 * </PRE>
 *
 * <B>Create</B> 2019.02.18 BY AIVICK hara<BR>
 * <B>remark</B><BR>
 *
 * @author
 * @since 1.0.
 */
public class Print32173000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32173000Action.class);

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request, HttpServletResponse response,
			SystemInfoBean sessionBean) {

		log.info("�y��ʁz�o�ȕ��� �i����jSTART");

		//���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("�o�ȕ�", false);

		Search32173000FormBean searchFormBean = (Search32173000FormBean)copyRequestParamToFormBean(request, new Search32173000FormBean());

		//���[�t�H�[���t�@�C��
		//String formFileName = "cus/hiroshima/form32173000.cfx";
		String formFileName = this.getCrForm(request, sessionBean, null, "cus/hiroshima/form32173000.cfx");

		try{
			// ------------------------------------------------------------------------------------------
			// �������
			// ------------------------------------------------------------------------------------------
			Print32173000Service printService = new Print32173000Service(request, sessionBean, searchFormBean);
			printService.execute();

			Print32173000 print = new Print32173000(sessionBean, printService.getPrintFormBean());
			print.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print.execute(formFileName);

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("�y��ʁz�o�ȕ��� �i����j�@END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return log;
	}



}
