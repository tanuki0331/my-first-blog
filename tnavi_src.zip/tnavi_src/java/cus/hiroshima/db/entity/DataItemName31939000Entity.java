package jp.co.systemd.tnavi.cus.hiroshima.db.entity;

import jp.co.systemd.tnavi.db.constants.CommonConstantsUseable;

/**
 * ���Ȗ�Entity.
 *
 * <B>Create</B> 2017.02.02 BY yamazaki<BR>
 */
public class DataItemName31939000Entity implements CommonConstantsUseable {

	/**
	 * ���ȃR�[�h
	 */
	private String cod_code;

	/**
	 * ���Ȗ�
	 */
	private String cod_name1;

	public String getCod_code() {
		return cod_code;
	}

	public void setCod_code(String cod_code) {
		this.cod_code = cod_code;
	}

	public String getCod_name1() {
		return cod_name1;
	}

	public void setCod_name1(String cod_name1) {
		this.cod_name1 = cod_name1;
	}


}
