package jp.co.systemd.tnavi.cus.hiroshima.db.entity;

import jp.co.systemd.tnavi.db.constants.CommonConstantsUseable;

/**
 * �]�蕪�z�\�l��Entity.
 *
 * <B>Create</B> 2017.02.02 BY yamazaki<BR>
 */
public class DataEvalCount31939000Entity implements CommonConstantsUseable {

	/**
	 * �N�x
	 */
	private String nendo;

	/**
	 * �w�N
	 */
	private String grade;
	/**
	 * ���ȃR�[�h
	 */
	private String itemCode;

	/**
	 * �]��R�[�h
	 */
	private String gevl_gevlcode;

	/**
	 * �]��
	 */
	private String gevl_display;

	/**
	 * �]��ʕ��z�l��
	 */
	private String evalcnt;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getGevl_gevlcode() {
		return gevl_gevlcode;
	}

	public void setGevl_gevlcode(String gevl_gevlcode) {
		this.gevl_gevlcode = gevl_gevlcode;
	}

	public String getGevl_display() {
		return gevl_display;
	}

	public void setGevl_display(String gevl_display) {
		this.gevl_display = gevl_display;
	}

	public String getEvalcnt() {
		return evalcnt;
	}

	public void setEvalcnt(String evalcnt) {
		this.evalcnt = evalcnt;
	}




}
