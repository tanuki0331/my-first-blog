/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2017 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.hiroshima.db.service;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.att.formbean.AttPrintDayFormBean;
import jp.co.systemd.tnavi.att.formbean.AttPrintSearchFormBeanImpl;
import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.HRoomEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.BeanUtilManager;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.common.utility.Holiday;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.Data32173000AttendSummaryDailyEntity;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.Data32173000ClassGroupEntity;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.Data32173000StudentAttendEntity;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.Data32173000StudentAttendSummaryEntity;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.Data32173000StudentEntity;
import jp.co.systemd.tnavi.cus.hiroshima.formbean.Print32173000FormBean;
import jp.co.systemd.tnavi.cus.hiroshima.formbean.Print32173000StudentFormBean;
import jp.co.systemd.tnavi.cus.hiroshima.formbean.Search32173000FormBean;
import jp.co.systemd.tnavi.junior.att.db.entity.MonthDataListEntity;


/**
 * <PRE>
 *  �o�ȕ��� (�L���������ʎx���w�Z) ��� Service.
 * </PRE>
 *
 * <B>Create</B> 2019.02.18 BY AIVICK hara<BR>
 * <B>remark</B><BR>
 *
 * @author
 * @since 1.0.
 */
public class Print32173000Service extends AbstractExecuteQuery{

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32173000Service.class);

	/** �V�X�e����� */
	private SystemInfoBean sessionBean;

	/** ����FormBean */
	private Search32173000FormBean searchFormBean;

	/** ���FormBean */
	private Print32173000FormBean printFormBean;

	/**
	 * �R���X�g���N�^
	 * @param request
	 * @param sessionBean
	 * @param searchFormBean
	 * @param printFormBean
	 */
	public Print32173000Service(HttpServletRequest request, SystemInfoBean sessionBean, Search32173000FormBean searchFormBean) {

		this.sessionBean = sessionBean;
		this.searchFormBean = searchFormBean;
		this.printFormBean = new Print32173000FormBean();
		this.printFormBean.setNendo(searchFormBean.getNendo());

	}

	@Override
	public void execute(){
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		try{
			// �I�������N���X�E�O���[�v�̏����擾����
			getGroupInfo();

			// �w��w�N�̌��f�[�^���擾����
			getMonthData();

			// �Ώې��k�����擾
			getStudents();

			// �o�������擾
			getAttendList();

			// �o���W�v���擾(���k)
			getStudentAttendSummary();

			// �o���W�v���擾(��)
			getAttendSummaryDaily();

			// �o���W�v���擾(��)
			printFormBean.setCntEnforce(getCntEnforce());
			printFormBean.setCntEnter(getCount("cus/hiroshima/getData32173000CntEnter.sql"));
			printFormBean.setCntLeave(getCount("cus/hiroshima/getData32173000CntLeave.sql"));
			printFormBean.setCntEnrolledLastMonthEnd(getCount("cus/hiroshima/getData32173000CntEnrolledLastMonthEnd.sql"));
			printFormBean.setCntEnrolledThisMonthEnd(getCount("cus/hiroshima/getData32173000CntEnrolledThisMonthEnd.sql"));
		}catch (Exception e) {
			log.error("�o�ȕ��� (�L���������ʎx���w�Z) ��� DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviDbException(e);
		}

	}

	/**
	 * �I�������N���X�E�O���[�v�̏����擾����
	 */
	private void getGroupInfo() {

		if(StringUtils.isNotBlank(searchFormBean.getClsno())){
			// �ʏ�w��
			searchFormBean.setGroupType(Print32173000FormBean.GROUP_TYPE_CLS);
			searchFormBean.setGroupcode(searchFormBean.getClsno());
			printFormBean.setGroupType(Print32173000FormBean.GROUP_TYPE_CLS);
			printFormBean.setGroupcode(searchFormBean.getClsno());

			QueryManager qm = new QueryManager("common/getHroomByUserAndYear.sql", new Object[]{sessionBean.getUserCode(), printFormBean.getNendo()}, HRoomEntity.class);
			@SuppressWarnings("unchecked")
			List<HRoomEntity> entityList = (List<HRoomEntity>)this.executeQuery(qm);

			for (HRoomEntity entity : entityList) {
				if(StringUtils.equals(entity.getHmr_clsno(), searchFormBean.getClsno())){
					printFormBean.setHolidayGrade(entity.getHmr_glade());
					printFormBean.setGrade(entity.getHmr_glade());
					printFormBean.setHmrclass(entity.getHmr_class());
					printFormBean.setHmrname(entity.getHmr_name());
					break;
				}
			}

		}else{
			// ���ʎx���w��
			printFormBean.setGroupType(Print32173000FormBean.GROUP_TYPE_SPG);

			QueryManager qm = new QueryManager("cus/hiroshima/getData32173000Spclass.sql", new Object[]{sessionBean.getUserCode(), printFormBean.getNendo()}, Data32173000ClassGroupEntity.class);
			@SuppressWarnings("unchecked")
			List<Data32173000ClassGroupEntity> entityList = (List<Data32173000ClassGroupEntity>)this.executeQuery(qm);

			for (Data32173000ClassGroupEntity entity : entityList) {
				if(StringUtils.equals(entity.getSpg_code(), searchFormBean.getGroupcode())){
					printFormBean.setHolidayGrade(searchFormBean.getHolidayGrade());
					printFormBean.setGroupcode(searchFormBean.getGroupcode());
					printFormBean.setGroupname(entity.getSpg_name());
					break;
				}
			}
		}
	}


	/**
	 * �w��w�N�̌��f�[�^���擾����
	 */
	private void getMonthData(){

		Integer nendoStartMonth = Integer.parseInt(sessionBean.getSystemNendoStartDate().trim().substring(0, 2));
		Integer month = Integer.parseInt(searchFormBean.getMonth());
		Integer year  = month >= nendoStartMonth ?  Integer.parseInt(printFormBean.getNendo()) : Integer.parseInt(printFormBean.getNendo()) + 1;

		printFormBean.setYear(String.format("%04d", year));
		printFormBean.setMonth(String.format("%02d", month));

		Calendar firstDayOfMonth = Calendar.getInstance();
		firstDayOfMonth.setTime(DateUtility.getStringToDate(String.format("%04d%02d%02d", year, month, 1)));
		AttPrintDayFormBean[] days = new AttPrintDayFormBean[firstDayOfMonth.getActualMaximum(Calendar.DATE)];

		QueryManager queryManager = null;

		if(!StringUtils.isBlank(searchFormBean.getClsno())){
			// �ʏ�w��
			Object[] param = new Object[]{sessionBean.getUserCode(), printFormBean.getNendo(), printFormBean.getHolidayGrade(), printFormBean.getHmrclass(), printFormBean.getMonth() };
			queryManager = new QueryManager("att/getAttPrintMonthData.sql", param, MonthDataListEntity.class);
		}
		else if(!StringUtils.isBlank(searchFormBean.getGroupcode())){
			// ���ʎx���w��
			Object[] param = new Object[]{sessionBean.getUserCode(), printFormBean.getNendo(), printFormBean.getHolidayGrade(), printFormBean.getGroupcode(), AttPrintSearchFormBeanImpl.CLASS_TYPE_SPCLASS, printFormBean.getMonth() };
			queryManager = new QueryManager("att/getAttPrintMonthDataByGroup.sql", param, MonthDataListEntity.class);
		}

		@SuppressWarnings("unchecked")
		List<MonthDataListEntity> monthDataList = (List<MonthDataListEntity>)this.executeQuery(queryManager);

		for (MonthDataListEntity monthData : monthDataList) {

			int day = Integer.parseInt(monthData.getEnf_day());
			int dayIndex = day - 1;

			if(days[dayIndex] == null){

				AttPrintDayFormBean dayFormBean = new AttPrintDayFormBean();
				dayFormBean.setDay(day);
				dayFormBean.setEnfoce(Integer.parseInt(monthData.getEnf_enforce()));
				dayFormBean.setWeekday(monthData.getEnf_weekday());


				dayFormBean.setWeekDayColor(AttPrintSearchFormBeanImpl.WEEKDAY_BLACK);

				String holidayName = Holiday.queryHoliday(LocalDate.of(year, month, day));

				if(holidayName != null ||  "�y".equals(dayFormBean.getWeekday()) || "��".equals(dayFormBean.getWeekday())){
					dayFormBean.setWeekDayColor(AttPrintSearchFormBeanImpl.WEEKDAY_RED);
				}

				dayFormBean.setText(new StringBuilder());
				if(!StringUtils.isEmpty(monthData.getClo_printword())){
					// �w�����󎚕���
					dayFormBean.setClo_printword(monthData.getClo_printword());
					dayFormBean.getText().append(monthData.getClo_printword());
					// �w�����̏ꍇ�A����Ɠ��ɐݒ肷��B
					dayFormBean.setEnfoce(0);
				} 
				else if(!StringUtils.isEmpty(monthData.getHol_name())){
					// �x�Ɠ�����
					dayFormBean.getText().append(monthData.getHol_name());
				}

				days[dayIndex] = dayFormBean;
			}else if(days[dayIndex].getText().toString().length() > 0){
				// ������t�ɕ����̋x�Ɠ����ݒ肳��Ă���ꍇ
				// ����̋x�Ɠ��Ɗ��Ԃ̋x�Ɠ����d�����Đݒ肳��Ă�����́A���Ԃ̋x�Ɠ������o�͂��邽�߁A
				// ���ԋx�Ɠ��̏ꍇ�̂ݒǋL����
				// �������A�w��������������ꍇ�́A�w����������D�悷�邽�ߒǋL���Ȃ�
				if(!StringUtils.isEmpty(monthData.getHol_name()) && StringUtils.equals(monthData.getHol_kind(), "2") && StringUtils.isEmpty(monthData.getClo_printword())){
					// �x�Ɠ�����
					days[dayIndex].getText().append("�@");
					days[dayIndex].setEnfoce(Integer.parseInt(monthData.getEnf_enforce()));
					days[dayIndex].getText().append(monthData.getHol_name());
				}
			}
		}

		printFormBean.setDays(days);

	}


	/**
	 * �ΏۂƂȂ鐶�k��Map���쐬����
	 */
	protected void getStudents(){

		BeanUtilsBean beanUtil = BeanUtilManager.getDBToPresentationUtil();

		Object[] param = new Object[]{
				 sessionBean.getUserCode()
				,printFormBean.getNendo()
				,printFormBean.getMonth()
				,printFormBean.getGroupType()
				,printFormBean.getGroupcode()
				} ;

		QueryManager qm = new QueryManager("cus/hiroshima/getData32173000Students.sql", param, Data32173000StudentEntity.class);

		@SuppressWarnings("unchecked")
		List<Data32173000StudentEntity> entityList = (List<Data32173000StudentEntity>) this.executeQuery(qm);

		try {
			for(Data32173000StudentEntity entity : entityList){

				Print32173000StudentFormBean studentFormBean = new Print32173000StudentFormBean();
				beanUtil.copyProperties(studentFormBean, entity);
				studentFormBean.setAttendSummary(new Data32173000StudentAttendSummaryEntity());
				printFormBean.getStudentMap().put(entity.getCls_stucode(), studentFormBean);

			}
		} catch (Exception e) {
			//�v���p�e�B�ϊ��G���[
			log.error("BeanUtils�ϊ��G���[:Data32173000StudentEntity To Print32173000StudentFormBean");
			throw new TnaviException(e);
		}

	}

	/**
	 * �o�������擾
	 */
	protected void getAttendList(){

		Object[] param = new Object[]{
				  sessionBean.getUserCode()
				, printFormBean.getNendo()
				, printFormBean.getMonth()
				, printFormBean.getGroupType()
				, printFormBean.getGroupcode()
				} ;

		QueryManager qm = new QueryManager("cus/hiroshima/getData32173000StudentAttend.sql", param, Data32173000StudentAttendEntity.class);

		@SuppressWarnings("unchecked")
		List<Data32173000StudentAttendEntity> entityList = (List<Data32173000StudentAttendEntity>) this.executeQuery(qm);

		// �o�����𐶓k���ɃZ�b�g
		for(Data32173000StudentAttendEntity entity : entityList){
			printFormBean.getStudentMap().get(entity.getCls_stucode()).getAttendList().add(entity);
		}
	}


	/**
	 * �o���W�v���擾(���j
	 */
	protected void getAttendSummaryDaily(){

		Object[] param = new Object[]{
				  sessionBean.getUserCode()
				, printFormBean.getNendo()
				, printFormBean.getMonth()
				, printFormBean.getGroupType()
				, printFormBean.getGroupcode()
				} ;

		QueryManager qm = new QueryManager("cus/hiroshima/getData32173000AttendSummaryDaily.sql", param, Data32173000AttendSummaryDailyEntity.class);

		@SuppressWarnings("unchecked")
		List<Data32173000AttendSummaryDailyEntity> entityList = (List<Data32173000AttendSummaryDailyEntity>) this.executeQuery(qm);

		for(Data32173000AttendSummaryDailyEntity entity : entityList){
			printFormBean.getAttendSummaryDailyList().add(entity);
		}
	}

	/**
	 * �o���W�v���擾(���k)
	 */
	protected void getStudentAttendSummary(){

		Object[] param = new Object[]{
				sessionBean.getUserCode()
				, printFormBean.getNendo()
				, printFormBean.getMonth()
				, printFormBean.getGroupType()
				, printFormBean.getGroupcode()
		} ;

		QueryManager qm = new QueryManager("cus/hiroshima/getData32173000StudentAttendSummary.sql", param, Data32173000StudentAttendSummaryEntity.class);

		@SuppressWarnings("unchecked")
		List<Data32173000StudentAttendSummaryEntity> entityList = (List<Data32173000StudentAttendSummaryEntity>) this.executeQuery(qm);

		for(Data32173000StudentAttendSummaryEntity entity : entityList){
			// �ΏۂƂȂ鐶�k�ɏW�v���ʂ��Z�b�g
			printFormBean.getStudentMap().get(entity.getStucode()).setAttendSummary(entity);
		}
	}


	/**
	 * ���Ɠ����擾
	 */
	private int getCntEnforce(){

		Object[] params = new Object[]{
				  sessionBean.getUserCode()
				, printFormBean.getNendo()
				, printFormBean.getMonth()
				, Print32173000FormBean.GROUP_TYPE_CLS.equals(printFormBean.getGroupType()) ? printFormBean.getGrade() : printFormBean.getHolidayGrade() };
		QueryManager qm = new QueryManager("cus/hiroshima/getData32173000CntEnfoce.sql", params, Integer.class);

		return (int)this.executeQuery(qm);

	}


	/**
	 * �W�v�����擾����
	 * @param sqlFile ���sSQL
	 * @return �W�v���ʐ�
	 */
	private int getCount(String sqlFile){

		Object[] params = new Object[]{
				  sessionBean.getUserCode()
				, printFormBean.getNendo()
				, printFormBean.getMonth()
				, printFormBean.getGroupType()
				, printFormBean.getGroupcode() };
		QueryManager qm = new QueryManager(sqlFile, params, Integer.class);

		return (int)this.executeQuery(qm);


	}

	public Print32173000FormBean getPrintFormBean() {
		return printFormBean;
	}




}
