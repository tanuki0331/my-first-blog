/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2017 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.hiroshima.db.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.HRoomEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import lombok.Getter;

/**
 * <PRE>
 *  �o�ȕ��� (�L���������ʎx���w�Z) ���� Ajax Service.
 * </PRE>
 *
 * <B>Create</B> 2019.02.18 BY AIVICK hara<BR>
 * <B>remark</B><BR>
 *
 * @author
 * @since 1.0.
 */
public class Search32173000AjaxService extends AbstractExecuteQuery{

	/** log4j */
	private static final Log log = LogFactory.getLog(Search32173000Service.class);
	
	/**
	 * �V�X�e�����
	 */
	private SystemInfoBean sessionBean;

	/**
	 * �N�x
	 */
	private String nendo;

	/**
	 * �����w��(���ʎx���w��)�O���[�v
	 */
	private String groupcode;
	
	/**
	 * �w�N���X�g
	 */
	@Getter
	private List<HRoomEntity> hroomList;
	
	public Search32173000AjaxService(HttpServletRequest request, SystemInfoBean sessionBean) {
		
		this.sessionBean = sessionBean;
		this.nendo    = request.getParameter("nendo");
		this.groupcode = request.getParameter("groupcode");
	}
	
	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}


	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {
		
		try{
			Object[] params = new Object[]{sessionBean.getUserCode(),  this.nendo, this.groupcode};
			QueryManager qm = new QueryManager("cus/hiroshima/getData32173000SpclassGrade.sql", params, HRoomEntity.class);
			
			hroomList = (List<HRoomEntity>)this.executeQuery(qm);
			
		} catch (Exception e) {
			log.error("�o�ȕ��� �x�Ɠ���w�N DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviDbException(e);
		}
	}
	

}
