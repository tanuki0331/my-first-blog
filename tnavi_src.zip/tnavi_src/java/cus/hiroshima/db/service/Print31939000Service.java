/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.hiroshima.db.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.UserHistoryEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.DataEvalCount31939000Entity;
import jp.co.systemd.tnavi.cus.hiroshima.db.entity.DataItemName31939000Entity;
import jp.co.systemd.tnavi.cus.hiroshima.formbean.Print31939000FormBean;

/**
 *
 * �y��ʁz�w���v�^���(�l��3) Service�N���X
 * <B>Create</B> 2017.02.02 BY yamazaki<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print31939000Service extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(Print31939000Service.class);

	/** �����R�[�h */
	private String userCode;

	/** �N�x */
	private String nendo;

	/** �N�x�I���N���� */
	private String nendoEndYmd;

	/** �w�N */
	private String grade;

	/** 1����������Ȃ�  */
	private Boolean isNoData = false;

	/** ���FormBean */
	private Print31939000FormBean printFormBean;

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	public Print31939000Service(SystemInfoBean sessionBean,String nendo) {

		this.nendo = nendo;
		// �N�x�I���N�����̎擾
		this.nendoEndYmd
			= DateUtility.getNendoEndDate(nendo, sessionBean.getSystemNendoStartDate(), sessionBean.getSystemNendoEndDate());
	}


	@Override
	protected void doQuery() throws TnaviDbException {

		try {

			// �����R�[�h
			String userCode = this.userCode;
			printFormBean.setUserCode(userCode);

			// �N�x
			String nendoSeireki = this.nendo;
			DateFormatUtility dfu = new DateFormatUtility(userCode);
			dfu.setZeroToSpace(true);

			/** �v�^�f�[�^�o�͊J�n�N�x */
			String startYear;

			//�N�x(�a��)
			printFormBean.setNendo(dfu.formatDate("YYYY�N", 1, nendoSeireki));

			//�N�x(����)
			printFormBean.setNendoSeireki(nendoSeireki);

			// �w�N
			String grade = this.grade;
			printFormBean.setGrade(grade);

			// �w�Z���
			UserHistoryEntity  schoolInfo = getUserhistory(nendoSeireki);
			printFormBean.setUserhistory(schoolInfo);

			// �v�^�f�[�^�o�͊J�n�N�x���擾
			startYear = getStartYear(userCode, nendoSeireki, grade);

			//���Ȗ���Map�𐶐�
			 List<DataItemName31939000Entity>  itemNameList = getItemName(userCode, nendoSeireki, grade);
			printFormBean.setItemNameList(itemNameList);

			// �Ώۊw�N�A�N�x��Map�𐶐�
			Map<String, String>  searchInfoMap = getSearchInfoMap(nendoSeireki, grade, startYear);
			printFormBean.setSearchInfoMap(searchInfoMap);

			// �e�w�N�E�N�x�̐l����Map�𐶐�
			Map<String,String>  totalCountMap = getTotalCounutMap(userCode, nendoEndYmd,searchInfoMap);
			printFormBean.setTotalCountMap(totalCountMap);

			// �e�w�N�E�N�x�̕]�蕪�z�\��Map�𐶐�
			Map<String, List<DataEvalCount31939000Entity>>  evalCountMap = getEvalCountMap(userCode, nendoEndYmd,searchInfoMap);
			printFormBean.setEvalCountMap(evalCountMap);


		} catch (Exception e) {
			log.error("�w���v�^���(�l��3) DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}

	}

	/**
	 * �w�Z�����擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private UserHistoryEntity getUserhistory( String nendoSeireki) {

		Object[] params = {userCode, nendoSeireki};
		QueryManager qm = new QueryManager("common/getUserhistoryByUserAndYear.sql", params, UserHistoryEntity.class);

		List<UserHistoryEntity> userhistoryList = (List<UserHistoryEntity>) this.executeQuery(qm);

		if(userhistoryList.size() > 0){
			return userhistoryList.get(0);
		}

		return null;
	}

	/**
	 * �v�^�f�[�^�o�͊J�n�N�x���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String getStartYear(String useCode, String nendoSeireki, String grade) {

		Object[] params = {userCode, nendoSeireki, grade};
		QueryManager qm = new QueryManager("cus/hiroshima/getDataStartYear31939000.sql", params, String.class);

		String gvst_startYear = (String) this.executeQuery(qm);

		if(gvst_startYear == null || gvst_startYear == ""){
			return "0000";
		}else {
			return gvst_startYear;
		}
	}

	/**
	 *  ���Ȗ����擾����
	 */
	@SuppressWarnings("unchecked")
	private List<DataItemName31939000Entity> getItemName(String userCode, String nendoSeireki,String grade) {
		// ���Ȗ����擾
		Object[] params = {userCode, nendoSeireki, grade};
		QueryManager qm =  new QueryManager("cus/hiroshima/getItemName31939000.sql", params, DataItemName31939000Entity.class);
		if("1".equals(printFormBean.getUseSchoolkind())) {
			// ���ʊw�Z�F�K�C���ȁE�w�Z�ݒ苳��
			qm.setPlusSQL(" AND cod_value1 IN ('0', '1')");
		}else if("3".equals(printFormBean.getUseSchoolkind())) {
			// ���ʎx���w�Z�F�K�C���Ȃ̂�
			qm.setPlusSQL(" AND cod_value1 = '0'");
		}
		qm.setPlusSQL("ORDER BY cod_value2");

		List<DataItemName31939000Entity> itemNameList = (List<DataItemName31939000Entity>) this.executeQuery(qm);

		return itemNameList;

	}

	/**
	 * �Ώ۔N�x�E�w�N���擾����
	 * @return
	 */

	private Map<String,String> getSearchInfoMap(String nendoSeireki, String grade, String startYear){
		// ����������Map[key:�w�N�Avalue:�N�x]����
		Map<String, String> searchInfoMap = new HashMap<String,String>();
		int intNendoSeireki = Integer.parseInt(nendoSeireki);
		int intStartYear = Integer.parseInt(startYear);

		// �o�͑ΏۍŒ�w�N
		int lowerLimit = 1;
		if("1".equals(printFormBean.getUsekind2())) {
			// ���w�Z
			lowerLimit = 3;
		}

		for(int intGrade = Integer.parseInt(grade); intGrade >= lowerLimit; intGrade--) {
			if(intStartYear <= intNendoSeireki) {
				searchInfoMap.put(String.valueOf(intGrade), String.valueOf(intNendoSeireki));
			}
			intNendoSeireki--;
		}

		return searchInfoMap;
	}

	/**
	 * �w�Z�S�̐l�����擾����
	 * @return
	 */

	private Map<String,String> getTotalCounutMap(String userCode, String endNendoDate,Map<String, String> searchInfoMap) {

		// �擾���ʂ̃f�[�^Map�l��[key:�w�N�Avalue:�]�蕪�z�擾���ʂ�list]����
		Map<String, String> totalCountMap = new HashMap<String,String>();

		for (Map.Entry<String, String> map : searchInfoMap.entrySet()) {
			String grade = map.getKey();
			String nendoSeireki= map.getValue();
			String sql = "";
			if("1".equals(printFormBean.getUseSchoolkind())) {
				// ���ʊw�Z
				sql = "cus/hiroshima/getDataTotalCount31939000.sql";
			}else if("3".equals(printFormBean.getUseSchoolkind())) {
				// ���ʎx���w�Z
				sql = "cus/hiroshima/getDataTotalCount31939000_sp.sql";
			}

			// �w�N�S�̐l���f�[�^�擾
			Object[] paramas = {userCode, nendoSeireki ,grade,endNendoDate,endNendoDate};
			QueryManager qm =  new QueryManager(sql, paramas, String.class);

			String TotalCount = (String) this.executeQuery(qm);

			totalCountMap.put(grade, TotalCount);
		}
		return totalCountMap;

	}

	/**
	 * �]��l�����z���擾
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, List<DataEvalCount31939000Entity>> getEvalCountMap(String userCode, String endNendoDate,Map<String, String> searchInfoMap) {
		// �擾����no�f�[�^Map�]��[key:�w�N�Avalue:�]�蕪�z�擾���ʂ�list]����
		Map<String, List<DataEvalCount31939000Entity>> evalCountMap = new HashMap<String, List<DataEvalCount31939000Entity>>();
		for (Map.Entry<String, String> map : searchInfoMap.entrySet()) {
			String grade = map.getKey();
			String nendoSeireki= map.getValue();
			String sql = "";
			// �]�蕪�z�l���f�[�^�擾
			Object[] params = {userCode, nendoSeireki, grade, endNendoDate};

			if("1".equals(printFormBean.getUseSchoolkind())) {
				// ���ʊw�Z
				sql = "cus/hiroshima/getDataEvalCount31939000.sql";
			}else if("3".equals(printFormBean.getUseSchoolkind())) {
				// ���ʎx���w�Z
				sql = "cus/hiroshima/getDataEvalCount31939000_sp.sql";
			}
			QueryManager qm =  new QueryManager(sql, params, DataEvalCount31939000Entity.class);

			List<DataEvalCount31939000Entity> evalCountList = (List<DataEvalCount31939000Entity>) this.executeQuery(qm);
			evalCountMap.put(grade, evalCountList);
		}
		return evalCountMap;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public Boolean getIsNoData() {
		return isNoData;
	}

	public void setIsNoData(Boolean isNoData) {
		this.isNoData = isNoData;
	}

	public Print31939000FormBean getPrintFormBean() {
		return printFormBean;
	}

	public void setPrintFormBean(Print31939000FormBean printFormBean) {
		this.printFormBean = printFormBean;
	}
}
