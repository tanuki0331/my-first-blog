/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.ehime.constants.HealthConstantsUseable;
import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data10105001Entity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Print10105000Entity;

/**
 *
 * �y����z���f���ʂ̒ʒm�Ɗ����� �o�� �T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 *
 * <B>Create</B> 2012.01.05 BY yammaoto<BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print10105000Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print10105000Service.class);

	private String user = HelConstants.DEFALUT_VALUE;

	private String year = HelConstants.DEFALUT_VALUE;

	private String[] stucode = null;

	private String outputKbn = HelConstants.DEFALUT_VALUE;

	private List<Print10105000Entity> result = new ArrayList<Print10105000Entity>();

	public void setUser(String user) {
		this.user = user;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public void setStucode(String[] stucode) {
		this.stucode = stucode;
	}

	public void setOutputKbn(String outputKbn) {
		this.outputKbn = outputKbn;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {
		StringBuilder builder = new StringBuilder();

		// �w�����ꗗ�擾
		List<Print10105000Entity> studentList;

		try{
			QueryManager qm = getStudentList(builder);
			studentList = (List<Print10105000Entity>)this.executeQuery(qm);
		}catch(Exception e){
			log.error("���f���ʂ̒ʒm�Ɗ������̌����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}

		if (!studentList.isEmpty()) {
			// 1���ȏ�̏ꍇ�A�f�[�^�����擾���ăZ�b�g����

			// �f�[�^���擾
			QueryManager qm = getDataList(builder);
			List<Data10105001Entity> dataList = (List<Data10105001Entity>)this.executeQuery(qm);

			// �f�[�^�A��
			if(HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(this.outputKbn)
					|| HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(this.outputKbn)){
				// �A�E���͂̏ꍇ�̂݁A���ꂼ��̍��ڂŘA��
				makeResultEach(studentList, dataList, builder);

			} else {
				// �A�ȊO�A�܂Ƃ߂ĘA��
				makeResultAdd(studentList, dataList, builder);
			}
		}
	}


	/**
	 * �w���f�[�^���X�g�̎擾SQL���쐬
	 * @return QueryManager
	 */
	private QueryManager getStudentList(StringBuilder addSql){
		QueryManager qm = null;
		addSql.setLength(0);

		// �����ݒ�
		Object[] param = {this.user, this.year};

		if(HealthConstantsUseable.HEL_NOTICE_CODE_MEDICINE.equals(this.outputKbn)){ // ����
			qm = new QueryManager("cus/ehime/getPrint10105001.sql", param, Print10105000Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_DENTISTRY.equals(this.outputKbn)){ // ����
			qm = new QueryManager("cus/ehime/getPrint10105002.sql", param, Print10105000Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_EYESIGHT.equals(this.outputKbn)){ // ����
			qm = new QueryManager("cus/ehime/getPrint10105003.sql", param, Print10105000Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(this.outputKbn)){ // �A(�`���A���A�����A�t������)
			qm = new QueryManager("cus/ehime/getPrint10105004.sql", param, Print10105000Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(this.outputKbn)){ // ����
			qm = new QueryManager("cus/ehime/getPrint10105005.sql", param, Print10105000Entity.class);

		}

		// �w�Дԍ��������Ɏw��
		addSql.append(" AND STUDENT.stu_stucode IN (");
		for (String code : this.stucode) {
			addSql.append("'");
			addSql.append(code);
			addSql.append("',");
		}
		addSql.setLength(addSql.length()-1);
		addSql.append(")");

		// ���ѕς�
		addSql.append(" ORDER BY DEP.dep_order, CLS.cls_glade, RIGHT('   '+HROOM.hmr_class, 3)," +
				" CLS.cls_number, RIGHT('          '+STUDENT.stu_stucode, 10) ");

		// SQL�ɒǉ�
		qm.setPlusSQL(addSql.toString());

		return qm;

	}

	/**
	 * �ڍ׃f�[�^���X�g�̎擾SQL���쐬
	 * @return QueryManager
	 */
	private QueryManager getDataList(StringBuilder addSql){
		QueryManager qm = null;
		addSql.setLength(0);

		// �����ݒ�
		Object[] param = {this.user, this.year};

		if(HealthConstantsUseable.HEL_NOTICE_CODE_MEDICINE.equals(this.outputKbn)){ // ����
			qm = new QueryManager("hel/getPrint10105011.sql", param, Data10105001Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_DENTISTRY.equals(this.outputKbn)){ // ����
			qm = new QueryManager("hel/getPrint10105012.sql", param, Data10105001Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_EYESIGHT.equals(this.outputKbn)){ // ����
			qm = new QueryManager("hel/getPrint10105013.sql", param, Data10105001Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(this.outputKbn)){ // �A(�`���A���A�����A�t������)
			qm = new QueryManager("hel/getPrint10105014.sql", param, Data10105001Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(this.outputKbn)){ // ����
			qm = new QueryManager("hel/getPrint10105015.sql", param, Data10105001Entity.class);

		}

		// �w�Дԍ��������Ɏw��
		addSql.append(" AND STUDENT.stu_stucode IN (");
		for (String code : this.stucode) {
			addSql.append("'");
			addSql.append(code);
			addSql.append("',");
		}
		addSql.setLength(addSql.length()-1);
		addSql.append(")");

		// �����ȍ~��SQL�ƕ��ѕς�
		addSql.append(" ) DATA ) DATA2 GROUP BY DATA2.data_stucode ,DATA2.data_kbn ,DATA2.data_mdname, DATA2.data_smname " +
				"ORDER BY DATA2.data_stucode ,DATA2.data_kbn ,DATA2.data_smname");

		// SQL�ɒǉ�
		qm.setPlusSQL(addSql.toString());

		return qm;
	}

	/**
	 * �f�[�^��A�����Đݒ�
	 * @param studentList
	 * @param dataList
	 * @param builder
	 */
	private void makeResultAdd(List<Print10105000Entity> studentList, List<Data10105001Entity> dataList, StringBuilder builder) {
		Map<String, String> dataMap = new HashMap<String, String>();
		String preStucode = null;
		builder.setLength(0);

		for (Data10105001Entity entity : dataList) {
			String stucode = entity.getData_stucode();
			if (!stucode.equals(preStucode)) {
				// �O�f�[�^�Ɗw�Дԍ����قȂ�ꍇ

				// �O�f�[�^��Map�Ɋi�[
				if (preStucode != null) {
					dataMap.put(preStucode, builder.toString());
				}
				// ������
				builder.setLength(0);
				preStucode = stucode;
			} else {

				// ��؂蕶����A��
				builder.append(",");
			}

			// �������ʂ�A��
			builder.append(entity.getData_smname());
		}
		// �Ō�̃f�[�^��Map�Ɋi�[
		if (preStucode != null) {
			dataMap.put(preStucode, builder.toString());
		}

		// �ԋp�p�f�[�^���`
		for (Print10105000Entity entity : studentList) {

			// �A�������f�[�^���Z�b�g
			String data = dataMap.get(entity.getStucode());

			if(HealthConstantsUseable.HEL_NOTICE_CODE_MEDICINE.equals(this.outputKbn)){ // ����
				entity.setMedicineItem(data);

			}else if(HealthConstantsUseable.HEL_NOTICE_CODE_DENTISTRY.equals(this.outputKbn)){ // ����
				entity.setDentistryItem(data);

			}else if(HealthConstantsUseable.HEL_NOTICE_CODE_EYESIGHT.equals(this.outputKbn)){ // ����
				entity.setEyesightItem(data);

			}

			result.add(entity);
		}
	}

	/**
	 * �f�[�^�����ꂼ��A�����Đݒ�
	 * @param studentList
	 * @param dataList
	 * @param builder
	 */
	private void makeResultEach(List<Print10105000Entity> studentList, List<Data10105001Entity> dataList, StringBuilder builder) {
		Map<String, Map<Integer, String>> dataMap = new HashMap<String, Map<Integer, String>>();
		String preStucode = null;
		Integer preKbn = null;
		builder.setLength(0);

		for (Data10105001Entity entity : dataList) {
			String stucode = entity.getData_stucode();
			if (!stucode.equals(preStucode)) {
				// �O�f�[�^�Ɗw�Дԍ����قȂ�ꍇ

				// �O�f�[�^��Map�Ɋi�[
				if (preStucode != null) {
					Map<Integer, String> data = dataMap.get(preStucode);
					if (data == null) {
						data = new HashMap<Integer, String>();
						dataMap.put(preStucode, data);
					}
					data.put(preKbn, builder.toString());
				}
				// ������
				builder.setLength(0);
				preStucode = stucode;
				preKbn = null;
			}

			Integer kbn = entity.getData_kbn();
			if (!kbn.equals(preKbn)) {
				// �O�f�[�^�Ƌ敪���قȂ�ꍇ

				// �O�敪�f�[�^��Map�Ɋi�[
				if (preKbn != null) {
					Map<Integer, String> data = dataMap.get(preStucode);
					if (data == null) {
						data = new HashMap<Integer, String>();
						dataMap.put(preStucode, data);
					}
					data.put(preKbn, builder.toString());
				}
				// �敪��ݒ�
				builder.setLength(0);
				preKbn = kbn;
			} else {
				// �O�f�[�^�Ƌ敪���������ꍇ

				// ��؂蕶����A��
				builder.append(",");
			}

			// �������ʂ�A��
			builder.append(entity.getData_smname());
		}
		// �Ō�̃f�[�^��Map�Ɋi�[
		if (preKbn != null) {
			Map<Integer, String> data = dataMap.get(preStucode);
			if (data == null) {
				data = new HashMap<Integer, String>();
				dataMap.put(preStucode, data);
			}
			data.put(preKbn, builder.toString());
		}

		// �ԋp�p�f�[�^���`
		for (Print10105000Entity entity : studentList) {

			// �A�������f�[�^���Z�b�g
			Map<Integer, String> data = dataMap.get(entity.getStucode());
			if (data != null) {
				for (Entry<Integer, String> value : data.entrySet()) {
					Integer key = value.getKey();

					if (HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(this.outputKbn)) {
						if (key == 1) {
							entity.setUrineItem1(value.getValue());
						} else if (key == 2) {
							entity.setUrineItem2(value.getValue());
						} else if (key == 3) {
							entity.setUrineItem3(value.getValue());
						} else if (key == 4) {
							entity.setUrineItem4(value.getValue());
						}
					} else if (HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(this.outputKbn)) {
						if (key == 1) {
							entity.setHearingRight1(value.getValue());
						} else if (key == 2) {
							entity.setHearingLeft1(value.getValue());
						}
					}
				}
			}

			// �f�[�^����
			String right_db = entity.getHearingRight2();
			if (right_db != null) {
				entity.setHearingRight2(right_db.concat("dB"));
			}
			String left_db = entity.getHearingLeft2();
			if (left_db != null) {
				entity.setHearingLeft2(left_db.concat("dB"));
			}

			result.add(entity);
		}
	}

	/**
	 * @return result
	 */
	public List<Print10105000Entity> getResult() {
		return result;
	}

}
