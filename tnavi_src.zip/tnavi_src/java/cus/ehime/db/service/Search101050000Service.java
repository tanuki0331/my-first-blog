/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.NoticewordsEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.ehime.db.entity.HelreportstatEntity;

/**
 * <PRE>
 * &lt;B&gt;&lt;FONT SIZE=3 COLOR=BLUE&gt;
 * Search101050000Service.
 * &lt;/FONT&gt;&lt;BR&gt;&lt;/B&gt;
 *
 * �y��ʁz���f���ʂ̒ʒm�Ɗ����� �ʒm���ޕ����Ǘ��e�[�u������.�T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 * </PRE>
 *
 * <B>Create</B> 2012.01.11 BY yamamoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Search101050000Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Search101050000Service.class);

	private NoticewordsEntity noticewordsEntity = null;

	private List<NoticewordsEntity> noteList = new ArrayList<NoticewordsEntity>();

	private String user = "";
	private String kensin = "";
	private String year = "";

	private String helrepsIssuedate = "";

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {

		QueryManager qm = null;
		List<HelreportstatEntity> helreportstatList = new ArrayList<HelreportstatEntity>();

		Object[] param = null;


		try{

			// �����ݒ�
			param = new Object[]{noticewordsEntity.getNtwd_user(), noticewordsEntity.getNtwd_kind(), noticewordsEntity.getNtwd_layout()};

			qm = new QueryManager("hel/search10105000_Noticewords.sql", param, NoticewordsEntity.class);

			noteList = (List<NoticewordsEntity>)this.executeQuery(qm);

			if(!kensin.equals("")){
				// �����ݒ�
				param = new Object[]{user,year,kensin};
				qm = new QueryManager("hel/getHelreportstatByUserAndYearAndCode.sql", param, HelreportstatEntity.class);
				helreportstatList = (List<HelreportstatEntity>)this.executeQuery(qm);

				if(helreportstatList != null && helreportstatList.size() != 0){
					int i = 0;
					for(HelreportstatEntity helreportstat:helreportstatList){
						helrepsIssuedate = helreportstat.getHelreps_issuedate();
					}
				}
			}

		}catch(Exception e){
			log.error("���f���ʂ̒ʒm�Ɗ������̕��͌����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}


	}

	/**
	 * @return noticewordsEntity
	 */
	public NoticewordsEntity getNoticewordsEntity() {
		return noticewordsEntity;
	}

	/**
	 * @param noticewordsEntity �Z�b�g���� noticewordsEntity
	 */
	public void setNoticewordsEntity(NoticewordsEntity noticewordsEntity) {
		this.noticewordsEntity = noticewordsEntity;
	}

	/**
	 * @return noteList
	 */
	public List<NoticewordsEntity> getNoteList() {
		return noteList;
	}

	public String getHelrepsIssuedate() {
		return helrepsIssuedate;
	}

	public void setHelrepsIssuedate(String helrepsIssuedate) {
		this.helrepsIssuedate = helrepsIssuedate;
	}
	public void setParam(String user,String year,String kensin){
		this.user = user;
		this.year = year;
		this.kensin = kensin;
	}

}
