/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.service;


import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CodeEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32171000_02Entity;
import jp.co.systemd.tnavi.cus.ehime.formbean.Print32171000FormBean;

/**
 *
 * �y��ʁz�x���v��Excel�����o�������o���T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 *
 * <B>Create</B> 2019.1.16 BY oe<BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print32171000Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32171000Service.class);


	/** FormBean */
	private Print32171000FormBean print32171000FormBean = null;


	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		try{

			Object[] param = { print32171000FormBean.getUser(),print32171000FormBean.getStucode(),print32171000FormBean.getYear()};
			QueryManager queryManager = new QueryManager("cus/ehime/getData32171000_2.sql", param,Data32171000_02Entity.class);

			List<Data32171000_02Entity> dataEntityList = (List<Data32171000_02Entity>)  this.executeQuery(queryManager);

			if(dataEntityList!=null&&dataEntityList.size()>0){
				print32171000FormBean.setUserName(dataEntityList.get(0).getUseh_name_s());
				print32171000FormBean.setStu_name_r(dataEntityList.get(0).getStu_name_r());
				print32171000FormBean.setStu_kana_r(dataEntityList.get(0).getStu_kana_r());
				print32171000FormBean.setStu_sex(dataEntityList.get(0).getStu_sex());
				print32171000FormBean.setStu_birth(dataEntityList.get(0).getStu_birth());
				print32171000FormBean.setSt2_parent_r(dataEntityList.get(0).getSt2_parent_r());
				print32171000FormBean.setSt2_p_kana_r(dataEntityList.get(0).getSt2_p_kana_r());
				print32171000FormBean.setSt2_zip(dataEntityList.get(0).getSt2_zip());
				print32171000FormBean.setSt2_adress(dataEntityList.get(0).getSt2_adress());
				print32171000FormBean.setSt2_num1(dataEntityList.get(0).getSt2_num1());
				print32171000FormBean.setSt2_num2(dataEntityList.get(0).getSt2_num2());
				print32171000FormBean.setSt2_p_tel(dataEntityList.get(0).getSt2_p_tel());
				print32171000FormBean.setSt2_mobilephone(dataEntityList.get(0).getSt2_mobilephone());
				print32171000FormBean.setSt2_e_tel(dataEntityList.get(0).getSt2_e_tel());
				print32171000FormBean.setCls_glade(dataEntityList.get(0).getCls_glade());
				print32171000FormBean.setHmr_class(dataEntityList.get(0).getHmr_class());
				print32171000FormBean.setUseh_kind2(dataEntityList.get(0).getUseh_kind2());
				print32171000FormBean.setHltck_height(dataEntityList.get(0).getHltck_height());
				print32171000FormBean.setHltck_weight(dataEntityList.get(0).getHltck_weight());
			}

			// �g�p�J�n�N�����擾(�N��Z�o���g�p)
			Object[] pm = {print32171000FormBean.getUser(),"55","1"};
			QueryManager qmCode55 = new QueryManager("common/getCodeByUserAndKindAndCode.sql", pm, CodeEntity.class);
			List<CodeEntity> code55List = (List<CodeEntity>) this.executeQuery(qmCode55);
			if(code55List!=null&&code55List.size()>0){
				print32171000FormBean.setCod_start(code55List.get(0).getCod_start());
			}

		} catch (Exception e) {
			log.error("��O����",e);
			throw new TnaviException(e);
		}
	}

	public Print32171000FormBean getPrint32171000FormBean() {
	    return print32171000FormBean;
	}

	public void setPrint32171000FormBean(Print32171000FormBean print32171000FormBean) {
	    this.print32171000FormBean = print32171000FormBean;
	}

}
