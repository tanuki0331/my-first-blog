package jp.co.systemd.tnavi.cus.ehime.db.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.db.QueryUpdateManager;
import jp.co.systemd.tnavi.common.db.entity.NoticewordsEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;

/**
 * <PRE>
 * &lt;B&gt;&lt;FONT SIZE=3 COLOR=BLUE&gt;
 * Update101050000Service.
 * &lt;/FONT&gt;&lt;BR&gt;&lt;/B&gt;
 *
 * �y��ʁz���f���ʂ̒ʒm�Ɗ����� �ʒm���ޕ����Ǘ��e�[�u���X�V.�T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 * </PRE>
 *
 * <B>Create</B> 2011.12.20 BY yamamoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Update101050000Service  extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Update101050000Service.class);

	private String resultMessage = HelConstants.DEFALUT_VALUE;

	private NoticewordsEntity noticewordsEntity = null;

	private String user = null;

	private String year = null;

	private String upuser = null;

	private String update = null;

	private String kensin = null;

	private String helreps_issuedate = null;


	/**
	 * @return noticewordsEntity
	 */
	public NoticewordsEntity getNoticewordsEntity() {
		return noticewordsEntity;
	}

	/**
	 * @param noticewordsEntity �Z�b�g���� noticewordsEntity
	 */
	public void setNoticewordsEntity(NoticewordsEntity noticewordsEntity) {
		this.noticewordsEntity = noticewordsEntity;
	}

	/**
	 * @return resultMessage
	 */
	public String getResultMessage() {
		return resultMessage;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		QueryUpdateBatchManager updatePrepar = null;

		// �����ݒ�
		Object[] param = {noticewordsEntity.getNtwd_1st_words(),
						  noticewordsEntity.getNtwd_2nd_words(),
						  noticewordsEntity.getNtwd_update(),
						  noticewordsEntity.getNtwd_upuser(),
						  noticewordsEntity.getNtwd_principal(),
						  noticewordsEntity.getNtwd_user(),
						  noticewordsEntity.getNtwd_kind(),
						  noticewordsEntity.getNtwd_layout()
						  };

		try{

			updatePrepar = new QueryUpdateBatchManager("hel/update10105000_Noticewords.sql");
			updatePrepar.setPrepearedparams(param);
			this.initialBatchUpdate(updatePrepar);


			//## �o�^�����̎��s START##

			//�X�V���s
			this.executeUpdate(updatePrepar);

			//## �o�^�����̎��s END##

			QueryUpdateManager updateManager = null;
			update = DateUtility.getSystemDate();

			param = setDeleteParam();
			updateManager = new QueryUpdateManager("hel/deleteHelreportstatByPK.sql", param);
			this.executeUpdate(updateManager);

			param = setInsertParam();
			updateManager = new QueryUpdateManager("hel/insertHelreportstat.sql", param);
			this.executeUpdate(updateManager);

			resultMessage = "�X�V���������܂����B";

			//�񍐓��e1�����ɃR�~�b�g����B
			this.commit();

		} catch (Exception e) {
			this.rollback();	//���[���o�b�N
			log.error("�e�[�u���X�V���ɃG���[���������܂����B " , e);
			throw new TnaviDbException(e);

		} finally {

			if(updatePrepar != null) {
				this.closeBatchUpdate(updatePrepar);
				updatePrepar = null;
			}
		}

	}
	public Object[] setDeleteParam(){

		Object[] tempParam = new Object[]{
				this.user
				,this.year
				,this.kensin
		};

		return tempParam;
	}

	public Object[] setInsertParam(){

		Object[] tempParam = new Object[]{
				this.user
				,this.year
				,this.kensin
				,this.helreps_issuedate.substring(4, 6)
				,this.helreps_issuedate
				,update
				,null
				,null
				,null
				,update
				,upuser
		};

		return tempParam;
	}

	public void setParam(String user,String year,String upuser,String kensin,String helreps_issuedate) {
		this.user = user;
		this.year = year;
		this.upuser = upuser;
		this.kensin = kensin;
		this.helreps_issuedate = helreps_issuedate;
	}

}
