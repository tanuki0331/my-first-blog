package jp.co.systemd.tnavi.cus.ehime.db.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.BeanUtilManager;
import jp.co.systemd.tnavi.cus.ehime.constants.HealthConstantsUseable;
import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data10105000Entity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data10105001Entity;
import jp.co.systemd.tnavi.cus.ehime.formbean.List10105000FormBean;
import jp.co.systemd.tnavi.cus.ehime.formbean.Search10105000FormBean;

/**
 * <PRE>
 * List10105000Service.
 *
 * �y��ʁz���f���ʂ̒ʒm�Ɗ����� �ꗗ���� �i.�T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 * </PRE>
 *
 * <B>Create</B> 2012.01.05 BY yamamoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List10105000Service extends AbstractExecuteQuery  {
	/** log4j */
	private static final Log log = LogFactory.getLog(List10105000Service.class);

	/** ���� */
	private String user = HelConstants.DEFALUT_VALUE;

	/** ���f���ʂ̒ʒm�Ɗ����� ���ʈꗗ FormBean */
	private Search10105000FormBean formBean = null;

	/** �������� */
	private List<List10105000FormBean> result = new ArrayList<List10105000FormBean>();

	private SystemInfoBean sessionBean = null;

	/**
	 * @param user �Z�b�g���� user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @param formBean �Z�b�g���� formBean
	 */
	public void setFormBean(Search10105000FormBean formBean) {
		this.formBean = formBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		//�R���X�g���N�^�ł͍s�킸�A
		//execute���\�b�h�Ăяo����DB�ڑ��ASQL���s���s���B
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void doQuery() throws TnaviDbException {
		StringBuilder builder = new StringBuilder();
		StringBuilder Urinalysis1 = new StringBuilder(); // �A����1���p
		StringBuilder Urinalysis2 = new StringBuilder(); // �A����2���p

		// �w�����ꗗ�擾
		List<Data10105000Entity> studentList;

		try{
			QueryManager qm = getStudentList(builder);
			studentList = (List<Data10105000Entity>)this.executeQuery(qm);
		}catch(Exception e){
			log.error("���f���ʂ̒ʒm�Ɗ������̌����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
		// �����Ȑ��E�얞�x�Ȑ��̏ꍇ�A�w�����̂�
		if (!studentList.isEmpty() &&
				(HealthConstantsUseable.HEL_NOTICE_CODE_GROWTH_CURVE.equals(formBean.getKensin())) ||
				HealthConstantsUseable.HEL_NOTICE_CODE_OBESITY_CURVE.equals(formBean.getKensin())) {
			// �ԋp�p�f�[�^���`
			BeanUtilsBean beanUtil = BeanUtilManager.getDBToPresentationUtil();
			try {
				// Entity����Bean�ɋl�ߑւ���
				for (Data10105000Entity entity : studentList) {
					List10105000FormBean bean = new List10105000FormBean();
					beanUtil.copyProperties(bean, entity);

					// �A�������f�[�^���Z�b�g
					result.add(bean);
				}

			} catch (Exception e) {
				//�v���p�e�B�ϊ��G���[
				log.error("�ϊ��G���[:data10105000Entity To list10105000FormBean");
				throw new TnaviException(e);
			}
		} else if (!studentList.isEmpty() && !HealthConstantsUseable.HEL_NOTICE_CODE_GROWTH_CURVE.equals(formBean.getKensin()) &&
						!HealthConstantsUseable.HEL_NOTICE_CODE_OBESITY_CURVE.equals(formBean.getKensin())) {
			// 1���ȏ�̏ꍇ�A�f�[�^�����擾���ăZ�b�g����

			// �f�[�^���擾

			QueryManager qm = getDataList(builder);
			List<Data10105001Entity> dataList = (List<Data10105001Entity>)this.executeQuery(qm);

			// �f�[�^�A��
			Map<String, String> dataMap = new HashMap<String, String>();
			String preStucode = null;
			Integer preKbn = null;
			String preMdname = null;
			builder.setLength(0);
			Urinalysis1.setLength(0);
			Urinalysis2.setLength(0);
			for (Data10105001Entity entity : dataList) {
				String stucode = entity.getData_stucode();
				if (!stucode.equals(preStucode)) {
					// �O�f�[�^�Ɗw�Дԍ����قȂ�ꍇ

					// �O�f�[�^��Map�Ɋi�[
					if (preStucode != null) {
						// �A�����F�Ώہu���ׂāv�u�ُ�Ȃ��v�̏ꍇ
						if (HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())
								&& ("0".equals(formBean.getTargetUrinalysis()) || "3".equals(formBean.getTargetUrinalysis()))) {

							if (Urinalysis1.length() != 0 && Urinalysis2.length() != 0) {
								builder.append("1��(" + Urinalysis1.toString() + ") 2��(" + Urinalysis2.toString() + ")");
							} else if (Urinalysis1.length() != 0 && Urinalysis2.length() == 0) {
								builder.append("1��(" + Urinalysis1.toString() + ")" );
							}
						}
						dataMap.put(preStucode, builder.toString());
					}
					// ������
					builder.setLength(0);
					Urinalysis1.setLength(0);
					Urinalysis2.setLength(0);
					preStucode = stucode;
					preKbn = null;
					preMdname = null;
				}

				Integer kbn = entity.getData_kbn();
				String mdname = entity.getData_mdname();
				if (!kbn.equals(preKbn)) {
					// �O�f�[�^�Ƌ敪���قȂ�ꍇ

					// �O�敪������ꍇ�A�󔒂�����
					if (preKbn != null) {
						// �A�����F�Ώہu���ׂāv�u�ُ�Ȃ��v�̏ꍇ
						if (HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())
								&& ("0".equals(formBean.getTargetUrinalysis()) || "3".equals(formBean.getTargetUrinalysis()))) {
							if (kbn != 2 && kbn != 5 && kbn != 8) {
								Urinalysis1.append(" ");
							}
							if (kbn >= 2 && kbn != 4 && kbn != 7 && Urinalysis2.length() != 0) {
								Urinalysis2.append(" ");
							}

						} else {
							builder.append(" ");
						}
					}
					// �敪��ݒ�
					preKbn = kbn;
					preMdname = mdname;
					// ���ޖ���A��
					if(!HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin()) &&
						!HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(formBean.getKensin())){

					// �A�����͒����ނ�A������
					} else {
						// �A�����F�Ώہu���ׂāv�u�ُ�Ȃ��v�̏ꍇ
						if (HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())
								&& ("0".equals(formBean.getTargetUrinalysis()) || "3".equals(formBean.getTargetUrinalysis()))) {
							// �A�����ꎟ�̌�������
							if (preKbn == 1 || preKbn == 4 || preKbn == 7) {
								Urinalysis1.append(entity.getData_mdname());
								Urinalysis1.append(":");
							// �A�����񎟂̌�������
							} else if (preKbn == 2 || preKbn == 5 || preKbn == 8) {
								Urinalysis2.append(entity.getData_mdname());
								Urinalysis2.append(":");
							// �ꎟ�E�񎟌������ʂ������ꍇ
							} else if (preKbn == 3 || preKbn == 6 || preKbn == 9) {
								Urinalysis1.append(entity.getData_mdname());
								Urinalysis1.append(":");
								Urinalysis2.append(entity.getData_mdname());
								Urinalysis2.append(":");
							}

						} else {
							builder.append(entity.getData_mdname());
							builder.append(":");
						}
					}
				} else {
					// �O�f�[�^�Ƌ敪���������ꍇ
					if (!HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())) {
						// ��؂蕶����A��
						builder.append(",");
					}

				}

				// �������ʂ�A��
				if (entity.getData_smname() != null) {
					// �A�����F�Ώہu���ׂāv�u�ُ�Ȃ��v�̏ꍇ
					if (HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())
							&& ("0".equals(formBean.getTargetUrinalysis()) || "3".equals(formBean.getTargetUrinalysis()))) {
						// �A�����ꎟ�̌�������
						if (preKbn == 1 || preKbn == 4 || preKbn == 7) {
							Urinalysis1.append(entity.getData_smname());
						// �A�����񎟂̌�������
						} else if (preKbn == 2 || preKbn == 5 || preKbn == 8) {
							Urinalysis2.append(entity.getData_smname());
						// �ꎟ�E�񎟌������ʂ������ꍇ
						} else if (preKbn == 3 || preKbn == 6 || preKbn == 9) {
							Urinalysis1.append(entity.getData_smname());
							Urinalysis2.append(entity.getData_smname());
						}
					} else {
						builder.append(entity.getData_smname());
					}
				}
			}
			// �Ō�̃f�[�^��Map�Ɋi�[
			if (preStucode != null) {
				// �A�����F�Ώہu���ׂāv�u�ُ�Ȃ��v�̏ꍇ
				if (HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())
						&& ("0".equals(formBean.getTargetUrinalysis()) || "3".equals(formBean.getTargetUrinalysis()))) {

					if (Urinalysis1.length() != 0 && Urinalysis2.length() != 0) {
						builder.append("1��(" + Urinalysis1.toString() + ") 2��(" + Urinalysis2.toString() + ")");
					} else if (Urinalysis1.length() != 0 && Urinalysis2.length() == 0) {
						builder.append("1��(" + Urinalysis1.toString() + ")" );
					}

				}
				dataMap.put(preStucode, builder.toString());
			}

			// �ԋp�p�f�[�^���`
			BeanUtilsBean beanUtil = BeanUtilManager.getDBToPresentationUtil();
			try {
				// Entity����Bean�ɋl�ߑւ���
				for (Data10105000Entity entity : studentList) {
					List10105000FormBean bean = new List10105000FormBean();
					beanUtil.copyProperties(bean, entity);

					// �A�������f�[�^���Z�b�g
					String data = dataMap.get(bean.getStucode());
					bean.setInspection(data);
					result.add(bean);
				}

			} catch (Exception e) {
				//�v���p�e�B�ϊ��G���[
				log.error("�ϊ��G���[:data10105000Entity To list10105000FormBean");
				throw new TnaviException(e);
			}
		}
	}


	/**
	 * �w���f�[�^���X�g�̎擾SQL���쐬
	 * @return QueryManager
	 */
	private QueryManager getStudentList(StringBuilder addSql){
		QueryManager qm = null;
		addSql.setLength(0);

		// �����ݒ�
		Object[] param = {this.user, this.formBean.getNendo()};

		if(HealthConstantsUseable.HEL_NOTICE_CODE_MEDICINE.equals(formBean.getKensin())){ // ����

			// �h�{��ԁE�S���E�畆�E���̑����a�Ɉُ킪�������
			if("0".equals(formBean.getTargetInternal1())){
				// ���ׂ�
				if("0".equals(formBean.getTargetInternal2())) {
					qm = new QueryManager("cus/ehime/getList10105001_00.sql", param, Data10105000Entity.class);
				// �ُ킠��
				} else if ("1".equals(formBean.getTargetInternal2())) {
					qm = new QueryManager("cus/ehime/getList10105001_01.sql", param, Data10105000Entity.class);
				// �ُ�Ȃ�
				} else {
					qm = new QueryManager("cus/ehime/getList10105001_02.sql", param, Data10105000Entity.class);
				}
			// ���@�����Ɉُ킪�������
			} else if("1".equals(formBean.getTargetInternal1())){
				// ���ׂ�
				if ("0".equals(formBean.getTargetInternal2())) {
					qm = new QueryManager("cus/ehime/getList10105001_10.sql", param, Data10105000Entity.class);
				// �ُ킠��
				} else if ("1".equals(formBean.getTargetInternal2())) {
					qm = new QueryManager("cus/ehime/getList10105001_11.sql", param, Data10105000Entity.class);
				// �ُ�Ȃ�
				} else {
					qm = new QueryManager("cus/ehime/getList10105001_12.sql", param, Data10105000Entity.class);
				}
			// �S�d�}�Ɉُ킪�������
			}else{
				// ���ׂ�
				if ("0".equals(formBean.getTargetInternal2())) {
					qm = new QueryManager("cus/ehime/getList10105001_20.sql", param, Data10105000Entity.class);
				// �ُ킠��
				} else if ("1".equals(formBean.getTargetInternal2())) {
					qm = new QueryManager("cus/ehime/getList10105001_21.sql", param, Data10105000Entity.class);
				// �ُ�Ȃ�
				} else {
					qm = new QueryManager("cus/ehime/getList10105001_22.sql", param, Data10105000Entity.class);
				}
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_DENTISTRY.equals(formBean.getKensin())){ // ����
			qm = new QueryManager("cus/ehime/getList10105002_00.sql", param, Data10105000Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_EYESIGHT.equals(formBean.getKensin())){ // ����

			// ���͂̂�
			if ("0".equals(formBean.getEnableEyesightOnly())){
				// "�����NB(0.7�ȏ�1.0�����̎�)�ȉ�"���I������Ă���ꍇ
				if("0".equals(formBean.getTargetForRankC())){
					qm = new QueryManager("cus/ehime/getList10105003_00.sql", param, Data10105000Entity.class);
				// "�����NC(0.7�����̎�)�ȉ�"���I������Ă���ꍇ
				} else if ("1".equals(formBean.getTargetForRankC())) {
					qm = new QueryManager("cus/ehime/getList10105003_01.sql", param, Data10105000Entity.class);
				// "�����ND(0.3�����̎�)�ȉ�"���I������Ă���ꍇ
				} else {
					qm = new QueryManager("cus/ehime/getList10105003_02.sql", param, Data10105000Entity.class);
				}
			// ��Ȃ̂�
			} else if ("1".equals(formBean.getEnableEyesightOnly())){
				// ���ׂ�
				if ("0".equals(formBean.getTargetOphthalmology())) {
					qm = new QueryManager("cus/ehime/getList10105003_10.sql", param, Data10105000Entity.class);
				// �ُ킠��
				} else if ("1".equals(formBean.getTargetOphthalmology())){
					qm = new QueryManager("cus/ehime/getList10105003_11.sql", param, Data10105000Entity.class);
				// �ُ�Ȃ�
				} else if ("2".equals(formBean.getTargetOphthalmology())){
					qm = new QueryManager("cus/ehime/getList10105003_12.sql", param, Data10105000Entity.class);
				}
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())){ // �A(�`���A���A�����A�t������)
			// ���ׂ�
			if ("0".equals(formBean.getTargetUrinalysis())) {
				qm = new QueryManager("cus/ehime/getList10105004_00.sql", param, Data10105000Entity.class);
			// �ꎟ
			} else if ("1".equals(formBean.getTargetUrinalysis())) {
				qm = new QueryManager("cus/ehime/getList10105004_01.sql", param, Data10105000Entity.class);
			// ��
			} else if ("2".equals(formBean.getTargetUrinalysis())) {
				qm = new QueryManager("cus/ehime/getList10105004_02.sql", param, Data10105000Entity.class);
			// �ُ�Ȃ�
			} else {
				qm = new QueryManager("cus/ehime/getList10105004_03.sql", param, Data10105000Entity.class);
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(formBean.getKensin())){ // ����
			// ���ׂ�
			if ("0".equals(formBean.getTargetHearing())) {
				qm = new QueryManager("cus/ehime/getList10105005_00.sql", param, Data10105000Entity.class);
			// �ُ킠��
			} else if ("1".equals(formBean.getTargetHearing())) {
				qm = new QueryManager("cus/ehime/getList10105005_01.sql", param, Data10105000Entity.class);
			// �ُ�Ȃ�
			} else {
				qm = new QueryManager("cus/ehime/getList10105005_02.sql", param, Data10105000Entity.class);
			}
		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_UNDOUKI.equals(formBean.getKensin())){ // �^����
			// ���ׂ�
			if ("0".equals(formBean.getTargetMusculoskeletal())) {
				qm = new QueryManager("cus/ehime/getList10105006_00.sql", param, Data10105000Entity.class);
			// �ُ킠��
			} else if ("1".equals(formBean.getTargetMusculoskeletal())) {
				qm = new QueryManager("cus/ehime/getList10105006_01.sql", param, Data10105000Entity.class);
			// �ُ�Ȃ�
			} else {
				qm = new QueryManager("cus/ehime/getList10105006_02.sql", param, Data10105000Entity.class);
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_ANEMIA.equals(formBean.getKensin())){ // �n��
			// ���ׂ�
			if ("0".equals(formBean.getTargetAnemia())) {
				qm = new QueryManager("cus/ehime/getList10105007_00.sql", param, Data10105000Entity.class);
			// �ُ킠��
			} else if ("1".equals(formBean.getTargetAnemia())) {
				qm = new QueryManager("cus/ehime/getList10105007_01.sql", param, Data10105000Entity.class);
			// �ُ�Ȃ�
			} else {
				qm = new QueryManager("cus/ehime/getList10105007_02.sql", param, Data10105000Entity.class);
			}

		} else if(HealthConstantsUseable.HEL_NOTICE_CODE_GROWTH_CURVE.equals(formBean.getKensin())){ // �����Ȑ�
			qm = new QueryManager("cus/ehime/getList10105008_00.sql", param, Data10105000Entity.class);

		} else if(HealthConstantsUseable.HEL_NOTICE_CODE_OBESITY_CURVE.equals(formBean.getKensin())){ // �얞�x�Ȑ�
			qm = new QueryManager("cus/ehime/getList10105009_00.sql", param, Data10105000Entity.class);

		}

		// ��ʂŎw�肵������

		// ����[�u
		if (!formBean.getJigo().equals("on") && !HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin()) &&
				!HealthConstantsUseable.HEL_NOTICE_CODE_GROWTH_CURVE.equals(formBean.getKensin()) &&
					!HealthConstantsUseable.HEL_NOTICE_CODE_OBESITY_CURVE.equals(formBean.getKensin())) {
			// �u����[�u�����͂��ꂽ���̂��ΏۂƂ���v��OFF�̏ꍇ
			addSql.append(" AND (DATA.data_brkcnt IS NULL OR DATA.data_brkcnt = 0) ");
		}

		// �w�ȁ`�g
		String fromGlade = formBean.getFromGlade();
		String toGlade = formBean.getToGlade();
		String fromClass = formBean.getFromClass();
		String toClass = formBean.getToClass();
		// �w�N(from)
		if (!fromGlade.isEmpty()) {
			addSql.append(" AND CLS.cls_glade >= '");
			addSql.append(fromGlade);
			addSql.append("' ");
		}
		// �w�N(to)
		if (!toGlade.isEmpty()) {
			addSql.append(" AND CLS.cls_glade <= '");
			addSql.append(toGlade);
			addSql.append("' ");
		}
		// �g(from)
		if (!fromClass.isEmpty()) {
			addSql.append(" AND HROOM.hmr_class >= '");
			addSql.append(fromClass);
			addSql.append("' ");
		}
		// �g(from)
		if (!toClass.isEmpty()) {
			addSql.append(" AND HROOM.hmr_class <= '");
			addSql.append(toClass);
			addSql.append("' ");
		}

		// ���ѕς�
//		addSql.append(" ORDER BY DEP.dep_order, CLS.cls_glade, RIGHT('   '+HROOM.hmr_class, 3)," +
//				" CLS.cls_number, RIGHT('          '+STUDENT.stu_stucode, 10) ");
//		MultiStuSettingFormBean multiStuSettingFormBean = sessionBean.getMultiStuSetting(FunctionId.FUNC_HEL007);
//
//		if( multiStuSettingFormBean.getMss_multi().equals(MultiStuSettingFormBean.EXCLUDE_STUDENT) ){
//			// ���C�����O
//			addSql.append(" AND NOT (stu_audit = '0' AND stu_multi = '1') ");
//		}
//		if( multiStuSettingFormBean.getMss_audit().equals(MultiStuSettingFormBean.EXCLUDE_STUDENT) ){
//			// �Ȗڗ��C�����O
//			addSql.append(" AND NOT (stu_audit = '1' AND stu_multi = '0') ");
//		}

		//���я��ݒ�
		addSql.append(" ORDER BY DEP.dep_order, CLS.cls_glade, RIGHT('   '+HROOM.hmr_class, 3)," +
				" CLS.cls_number, RIGHT('          '+STUDENT.st4_stucode, 10) ");

		// SQL�ɒǉ�
		qm.setPlusSQL(addSql.toString());

		return qm;

	}

	/**
	 * �ڍ׃f�[�^���X�g�̎擾SQL���쐬
	 * @return QueryManager
	 */
	private QueryManager getDataList(StringBuilder addSql){
		QueryManager qm = null;
		addSql.setLength(0);

		// �����ݒ�
		Object[] param;
		String year = this.formBean.getNendo();

		if(HealthConstantsUseable.HEL_NOTICE_CODE_MEDICINE.equals(formBean.getKensin())){ // ����

			// �h�{��ԁE�S���E�畆�E���̑����a�Ɉُ킪�������
			if("0".equals(formBean.getTargetInternal1())){
				// ���ׂ�
				if("0".equals(formBean.getTargetInternal2())) {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_00.sql", param, Data10105001Entity.class);
				// �ُ킠��
				} else if("1".equals(formBean.getTargetInternal2())) {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_01.sql", param, Data10105001Entity.class);
				// �ُ�Ȃ�
				} else {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_02.sql", param, Data10105001Entity.class);
				}
			// ���@�����Ɉُ킪�������
			}else if("1".equals(formBean.getTargetInternal1())){
				// ���ׂ�
				if("0".equals(formBean.getTargetInternal2())) {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_10.sql", param, Data10105001Entity.class);
				// �ُ킠��
				} else if("1".equals(formBean.getTargetInternal2())) {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_11.sql", param, Data10105001Entity.class);
				// �ُ�Ȃ�
				} else {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_12.sql", param, Data10105001Entity.class);
				}
			// �S�d�}�Ɉُ킪�������
			}else{
				// ���ׂ�
				if("0".equals(formBean.getTargetInternal2())) {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_20.sql", param, Data10105001Entity.class);
				// �ُ킠��
				} else if("1".equals(formBean.getTargetInternal2())) {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_21.sql", param, Data10105001Entity.class);
				// �ُ�Ȃ�
				} else {
					param = new Object[]{this.user, year};
					qm = new QueryManager("cus/ehime/getList10105011_22.sql", param, Data10105001Entity.class);
				}
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_DENTISTRY.equals(formBean.getKensin())){ // ����
				param = new Object[]{this.user, year, this.user, year, this.user, year, this.user, year, this.user, year, this.user, year, this.user, year};
				qm = new QueryManager("cus/ehime/getList10105012_00.sql", param, Data10105001Entity.class);

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_EYESIGHT.equals(formBean.getKensin())){ // ���́E���

			// ���݂͂̂̌`��"���I������Ă���ꍇ
			if("0".equals(formBean.getEnableEyesightOnly())){
				// "�����ND(0.3�����̎�)�ȉ�"���I������Ă���ꍇ
				if("0".equals(formBean.getTargetForRankC())){
					param = new Object[]{this.user, year, this.user, year};
					qm = new QueryManager("cus/ehime/getList10105013_00.sql", param, Data10105001Entity.class);
				}else if("1".equals(formBean.getTargetForRankC())){
					param = new Object[]{this.user, year, this.user, year};
					qm = new QueryManager("cus/ehime/getList10105013_01.sql", param, Data10105001Entity.class);
				} else {
					param = new Object[]{this.user, year, this.user, year};
					qm = new QueryManager("cus/ehime/getList10105013_02.sql", param, Data10105001Entity.class);
				}
			// ��Ȃ݂̂̌`��"���I������Ă���ꍇ
			} else if("1".equals(formBean.getEnableEyesightOnly())){
				// ���ׂ�
				if("0".equals(formBean.getTargetOphthalmology())){
					param = new Object[]{this.user, year, this.user, year};
					qm = new QueryManager("cus/ehime/getList10105013_10.sql", param, Data10105001Entity.class);
				// �ُ킠��
				}else if("1".equals(formBean.getTargetOphthalmology())){
					param = new Object[]{this.user, year, this.user, year};
					qm = new QueryManager("cus/ehime/getList10105013_11.sql", param, Data10105001Entity.class);
				// �ُ�Ȃ�
				} else if("2".equals(formBean.getTargetOphthalmology())) {
					param = new Object[]{this.user, year, this.user, year};
					qm = new QueryManager("cus/ehime/getList10105013_12.sql", param, Data10105001Entity.class);
				}
			}
		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(formBean.getKensin())){ // �A(�`���A���A�����A�t������)
			// ���ׂ�
			if("0".equals(formBean.getTargetUrinalysis())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105014_00.sql", param, Data10105001Entity.class);
			// �ꎟ
			}else if("1".equals(formBean.getTargetUrinalysis())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105014_01.sql", param, Data10105001Entity.class);
			// ��
			} else if("2".equals(formBean.getTargetUrinalysis())) {
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105014_02.sql", param, Data10105001Entity.class);
			// �ُ�Ȃ�
			} else if("3".equals(formBean.getTargetUrinalysis())) {
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105014_03.sql", param, Data10105001Entity.class);
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(formBean.getKensin())){ // ����
			// ���ׂ�
			if("0".equals(formBean.getTargetHearing())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105015_00.sql", param, Data10105001Entity.class);
			// �ُ킠��
			}else if("1".equals(formBean.getTargetHearing())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105015_01.sql", param, Data10105001Entity.class);
			// �ُ�Ȃ�
			} else if("2".equals(formBean.getTargetHearing())) {
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105015_02.sql", param, Data10105001Entity.class);
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_UNDOUKI.equals(formBean.getKensin())){ // �^���팟�f
			// ���ׂ�
			if("0".equals(formBean.getTargetMusculoskeletal())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105016_00.sql", param, Data10105001Entity.class);
			// �ُ킠��
			}else if("1".equals(formBean.getTargetMusculoskeletal())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105016_01.sql", param, Data10105001Entity.class);
			// �ُ�Ȃ�
			} else if("2".equals(formBean.getTargetMusculoskeletal())) {
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105016_02.sql", param, Data10105001Entity.class);
			}

		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_ANEMIA.equals(formBean.getKensin())){ // �n��
			// ���ׂ�
			if("0".equals(formBean.getTargetAnemia())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105017_00.sql", param, Data10105001Entity.class);
			// �ُ킠��
			}else if("1".equals(formBean.getTargetAnemia())){
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105017_01.sql", param, Data10105001Entity.class);
			// �ُ�Ȃ�
			} else if("2".equals(formBean.getTargetAnemia())) {
				param = new Object[]{this.user, year};
				qm = new QueryManager("cus/ehime/getList10105017_02.sql", param, Data10105001Entity.class);
			}
		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_GROWTH_CURVE.equals(formBean.getKensin())){
			qm = null;
		}

		// ��ʂŎw�肵������

		// ����[�u�ɂ��i�荞�݂͍s��Ȃ�

		// �w�ȁ`�g
		String department = formBean.getDepartment();
		String fromGlade = formBean.getFromGlade();
		String toGlade = formBean.getToGlade();
		String fromClass = formBean.getFromClass();
		String toClass = formBean.getToClass();
		// �w��
		if (!department.isEmpty()) {
			addSql.append(" AND CLS.cls_department = '");
			addSql.append(department);
			addSql.append("' ");
		}
		// �w�N(from)
		if (!fromGlade.isEmpty()) {
			addSql.append(" AND CLS.cls_glade >= '");
			addSql.append(fromGlade);
			addSql.append("' ");
		}
		// �w�N(to)
		if (!toGlade.isEmpty()) {
			addSql.append(" AND CLS.cls_glade <= '");
			addSql.append(toGlade);
			addSql.append("' ");
		}
		// �g(from)
		if (!fromClass.isEmpty()) {
			addSql.append(" AND HROOM.hmr_class >= '");
			addSql.append(fromClass);
			addSql.append("' ");
		}
		// �g(from)
		if (!toClass.isEmpty()) {
			addSql.append(" AND HROOM.hmr_class <= '");
			addSql.append(toClass);
			addSql.append("' ");
		}

		// �����ȍ~��SQL�ƕ��ѕς�
		addSql.append(" GROUP BY DATA2.data_stucode ,DATA2.data_kbn ,DATA2.data_mdname, DATA2.data_smname " +
				"ORDER BY DATA2.data_stucode ,DATA2.data_kbn ,DATA2.data_smname");

		// SQL�ɒǉ�
		qm.setPlusSQL(addSql.toString());

		return qm;
	}

	/**
	 * @return result
	 */
	public List<List10105000FormBean> getResult() {
		return result;
	}

	public SystemInfoBean getSessionBean() {
		return sessionBean;
	}

	public void setSessionBean(SystemInfoBean sessionBean) {
		this.sessionBean = sessionBean;
	}

}
