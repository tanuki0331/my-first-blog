package jp.co.systemd.tnavi.cus.ehime.db.service;


import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data10104000Entity;
import jp.co.systemd.tnavi.cus.ehime.formbean.Search10104000FormBean;

/**
 * <PRE>
 * &lt;B&gt;&lt;FONT SIZE=3 COLOR=BLUE&gt;
 * List10104000Service.
 * &lt;/FONT&gt;&lt;BR&gt;&lt;/B&gt;
 *
 * �y��ʁz����f�҂ւ̎�f������ �ꗗ���� �i.�T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 * </PRE>
 *
 * <B>Create</B> 2011.10.18 BY yamamoto<BR>
 * <B>Modify</B> 2013.01.11 BY SD inasawa<BR>
 * �������ňڐA�Ή�(�w�Ȃ̍폜��)<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List10104000Service extends AbstractExecuteQuery  {
	/** log4j */
	private static final Log log = LogFactory.getLog(List10104000Service.class);

	/** ���� */
	private String user = HelConstants.DEFALUT_VALUE;

	/** ����f�҂ւ̎�f�������p ���ʈꗗ FormBean */
	private Search10104000FormBean formBean = null;

	/** �������� */
	private List<Data10104000Entity> result = null;


	/**
	 * @return user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user �Z�b�g���� user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	@Override
	public void execute() throws TnaviDbException {
		//�R���X�g���N�^�ł͍s�킸�A
		//execute���\�b�h�Ăяo����DB�ڑ��ASQL���s���s���B
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void doQuery() throws TnaviDbException {

		// ����f�ꗗ�擾
		String year = formBean.getNendo();

		QueryManager qm = null;

		// ����
		if("111".equals(formBean.getKensin())){
			Object[] param = {user, year, user, year, user, year, user, year, user, year, user, year, user, year};
			qm = new QueryManager("cus/ehime/search10104000_Medicine.sql", param, Data10104000Entity.class);
		}
		// ����
		else if("112".equals(formBean.getKensin())){
			Object[] param = {user, year};
			qm = new QueryManager("cus/ehime/search10104000_Dentistry.sql", param, Data10104000Entity.class);
		}
		// ���͂̂�
		else if("113".equals(formBean.getKensin())){
			if ("0".equals(formBean.getEnableEyesightOnly())) {
				Object[] param = {user, year, user, year, user, year};
				qm = new QueryManager("cus/ehime/search10104000_VisionTest.sql", param, Data10104000Entity.class);
			// ��Ȃ̂�
			} else {
				if ("1".equals(formBean.getEnableEyesightOnly())) {
					Object[] param = {user, year, user, year, user, year};
					qm = new QueryManager("cus/ehime/search10104000_Ophthalmology.sql", param, Data10104000Entity.class);
				}
			}
		}
		// �A����
		else if("114".equals(formBean.getKensin())){
			Object[] param = {user, year, user, year, user, year, user, year, user, year};
			qm = new QueryManager("cus/ehime/search10104000_Urine.sql", param, Data10104000Entity.class);
		}
		// ���͌���
		else if("115".equals(formBean.getKensin())){
			Object[] param = {user, year, user, year, user, year, user, year};
			qm = new QueryManager("cus/ehime/search10104000_Hearing.sql", param, Data10104000Entity.class);
		}
		// ���@�Ȍ��f
		else if("116".equals(formBean.getKensin())){
			Object[] param = {user, year, user, year, user, year};
			qm = new QueryManager("cus/ehime/search10104000_Otolaryngology.sql", param, Data10104000Entity.class);
		}
		// �n������
		else if("117".equals(formBean.getKensin())){
			Object[] param = {user, year};
			qm = new QueryManager("cus/ehime/search10104000_Anemia.sql", param, Data10104000Entity.class);
		}

		// �w��
		/**  2013.01.11_inasawa �w�ȕs�v�̈׍폜 ***
		if(formBean.getDepartment().length() > 0){
			qm.setPlusSQL("AND cls_department = '" + formBean.getDepartment() + "' ");
		}
		**  2013.01.11_inasawa �w�ȕs�v�̈׍폜 ***/

		// �w�NFrom
		if(formBean.getFromGlade().length() > 0){
			qm.setPlusSQL("AND cls_glade >= '" + formBean.getFromGlade() + "' ");
		}
		// �w�NTo
		if(formBean.getToGlade().length() > 0){
			qm.setPlusSQL("AND cls_glade <= '" + formBean.getToGlade() + "' ");
		}
		// �gFrom
		if(formBean.getFromClass().length() > 0){
			qm.setPlusSQL("AND hmr_class >= '" + formBean.getFromClass() + "' ");
		}
		// �gTo
		if(formBean.getToClass().length() > 0){
			qm.setPlusSQL("AND hmr_class <= '" + formBean.getToClass() + "' ");
		}

		// 2013.01.11_inasawa �w�ȕs�v�̈� �\�[�g����r��
		//qm.setPlusSQL("ORDER BY cls_user, cls_year, cls_department, cls_glade, hmr_class, cls_number");
		qm.setPlusSQL("ORDER BY cls_user, cls_year, cls_glade, hmr_class, cls_number");


		try{
			result = (List<Data10104000Entity>)this.executeQuery(qm);
		}catch(Exception e){
			log.error("����f�҂ւ̎�f�������̌����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
	}


	/**
	 * @return formBean
	 */
	public Search10104000FormBean getFormBean() {
		return formBean;
	}

	/**
	 * @param formBean �Z�b�g���� formBean
	 */
	public void setFormBean(Search10104000FormBean formBean) {
		this.formBean = formBean;
	}

	/**
	 * @return result
	 */
	public List<Data10104000Entity> getResult() {
		return result;
	}

	/**
	 * @param result �Z�b�g���� result
	 */
	public void setResult(List<Data10104000Entity> result) {
		this.result = result;
	}



}
