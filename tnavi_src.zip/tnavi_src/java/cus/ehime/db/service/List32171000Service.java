/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.service;


import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32171000Entity;
import jp.co.systemd.tnavi.cus.ehime.formbean.Data32171000FormBean;
import jp.co.systemd.tnavi.cus.ehime.formbean.List32171000FormBean;

/**
 *
 * �y��ʁz�x���v��Excel�����o���ꗗ�T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 *
 * <B>Create</B> 2019.1.16 BY oe<BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List32171000Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(List32171000Service.class);

	//** �����敪 */
	/** �S�C�i�����j */
	private static String SEARCH_KIND_TANNIN = "01";
	/** ���ʎx���w���i�����j */
	private static String SEARCH_KIND_SPGD = "02";
	/** �����i�����j */
	private static String SEARCH_KIND_KYOMU = "03";

	/** FormBean */
	private List32171000FormBean list32171000FormBean = null;

	/** DateFormatUtility */
	DateFormatUtility dfu = null;

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		try{
			dfu = new DateFormatUtility(list32171000FormBean.getUserCode());
			dfu.setZeroToSpace(true);

			Object[] param = { list32171000FormBean.getUserCode(),list32171000FormBean.getYear()};
			QueryManager queryManager = new QueryManager("cus/ehime/getData32171000.sql", param,Data32171000Entity.class);

			StringBuffer sql = new StringBuffer();
			if(StringUtils.equals(list32171000FormBean.getSearchKind(), SEARCH_KIND_TANNIN)) {
				if(StringUtils.isNotEmpty(list32171000FormBean.getClsno())){
					sql.append(" AND cls_clsno = '" +list32171000FormBean.getClsno()+ "'");
				}
			}else if(StringUtils.equals(list32171000FormBean.getSearchKind(), SEARCH_KIND_SPGD)) {
				if(StringUtils.isNotEmpty(list32171000FormBean.getSpgdcode())){
					sql.append(" AND spgd_code = '" +list32171000FormBean.getSpgdcode()+ "'");
				}
			}else if(StringUtils.equals(list32171000FormBean.getSearchKind(), SEARCH_KIND_KYOMU)) {
				if(StringUtils.isNotEmpty(list32171000FormBean.getGlade())){
					sql.append(" AND cls_glade = '" + list32171000FormBean.getGlade() + "'");
				}
				if(StringUtils.isNotEmpty(list32171000FormBean.getCls())){
					sql.append(" AND hmr_class = '" + list32171000FormBean.getCls() + "'");
				}
			}
			sql.append("ORDER BY hmr_glade ,hmr_clsno ,hmr_class ,CASE WHEN cls_number IS NULL THEN 1 ELSE 0 END ,cls_number ASC ,RIGHT('          '+tbl_student.stu_stucode, 10) ASC ");

			queryManager.setPlusSQL(sql.toString());

			List<Data32171000Entity> dataEntityList = (List<Data32171000Entity>)  this.executeQuery(queryManager);

			//entity����formbean�֕���
			for(int i=0;i<dataEntityList.size();i++){
				Data32171000FormBean data32171000FormBean = new Data32171000FormBean();

				data32171000FormBean.setCls_glade(dataEntityList.get(i).getCls_glade());
				data32171000FormBean.setHmr_class(dataEntityList.get(i).getHmr_class());
				data32171000FormBean.setCls_number(dataEntityList.get(i).getCls_number());
				data32171000FormBean.setStu_name(dataEntityList.get(i).getStu_name());
				data32171000FormBean.setStu_hkana(dataEntityList.get(i).getStu_hkana());
				data32171000FormBean.setSex(dataEntityList.get(i).getSex());
				data32171000FormBean.setStu_birth(StringUtils.isNotEmpty(dataEntityList.get(i).getStu_birth()) ? dfu.formatDate("YYYY/MM/DD", dataEntityList.get(i).getStu_birth()) : "");
				data32171000FormBean.setStu_stucode(dataEntityList.get(i).getStu_stucode());

				list32171000FormBean.getData32171000FormBeanList().add(data32171000FormBean);
			}

			//�f�[�^�����i�[
			list32171000FormBean.setDataCount(list32171000FormBean.getData32171000FormBeanList().size());
			list32171000FormBean.setTitle(formatTitle());

		} catch (Exception e) {
			log.error("��O����",e);
			throw new TnaviException(e);
		}
	}

	/**
	 * �w�肵��������������w�b�_���𐶐�
	 * @return �^�C�g��
	 */
	private String formatTitle() {
		// �\�����錟�������𐶐�
		String year = dfu.formatDate("YYYY", list32171000FormBean.getYear()) + "�N�x";

		StringBuffer title = new StringBuffer(year);

		if(StringUtils.isNotEmpty(list32171000FormBean.getGlade())){
			title.append("�@");
			title.append(list32171000FormBean.getGlade());
			title.append("�w�N");
		}

		if(StringUtils.isNotEmpty(list32171000FormBean.getCls())){
			title.append("�@");
			title.append(list32171000FormBean.getCls());
			title.append("�g");
		}
		return title.toString();
	}

	public List32171000FormBean getList32171000FormBean() {
	    return list32171000FormBean;
	}

	public void setList32171000FormBean(List32171000FormBean list32171000FormBean) {
	    this.list32171000FormBean = list32171000FormBean;
	}

}
