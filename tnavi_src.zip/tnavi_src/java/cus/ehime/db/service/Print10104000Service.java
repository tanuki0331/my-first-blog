/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Print10104000Entity;

/**
 *
 * �y����z����f�҂ւ̎�f������ �o�� �T�[�r�X�N���X.
 * �r�W�l�X���W�b�N.
 *
 * <B>Create</B> 2011.12.19 BY yammaoto<BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print10104000Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print10104000Service.class);

	private String user = HelConstants.DEFALUT_VALUE;

	private String yaer = HelConstants.DEFALUT_VALUE;

	private String[] stucode = null;

	private List<Print10104000Entity> result = null;

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {

		QueryManager qm = null;
		List<String> paramList = new ArrayList<String>();
		StringBuilder addSql = new  StringBuilder();

		paramList.add(user);
		paramList.add(yaer);

		if(stucode != null){
			for(String val : stucode){
				paramList.add(val);
			}
		}

		// �����ݒ�
		Object[] param = new Object[paramList.size()];

		for(int i = 0; i < paramList.size() ; i++ ){
			param[i] = paramList.get(i);
		}

		qm = new QueryManager("hel/search10104000_Print.sql", param, Print10104000Entity.class);

		if(stucode != null){
			addSql.append(" AND ")
			      .append(" st.stu_stucode ").append(" IN( ")
			      ;
			for(int i = 0; i < stucode.length ; i++ ){
				if(i > 0){
					addSql.append(",");
				}
				addSql.append("?");
			}

			addSql.append(")");
		}
		qm.setPlusSQL(addSql.toString());

		String test1 = addSql.toString();

		addSql.setLength(0);
		addSql.append(" ORDER  BY ")
		      .append(" cls.cls_user ")
		      .append(" ,cls.cls_year ")
		      .append(" ,cls.cls_department ")
		      .append(" ,cls.cls_glade ")
		      .append(" ,hr.hmr_class ")
		      .append(" ,cls.cls_number ")
		      .append(" ,st.stu_stucode ")
		      ;
		qm.setPlusSQL(addSql.toString());

		String test2 = addSql.toString();

		try{
			result = (List<Print10104000Entity>)this.executeQuery(qm);
		}catch(Exception e){
			log.error("����f�҂ւ̎�f�������̌����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}

	}



	/**
	 * @return user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user �Z�b�g���� user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return yaer
	 */
	public String getYaer() {
		return yaer;
	}

	/**
	 * @param yaer �Z�b�g���� yaer
	 */
	public void setYaer(String yaer) {
		this.yaer = yaer;
	}


	/**
	 * @return stucode
	 */
	public String[] getStucode() {
		return stucode;
	}

	/**
	 * @param stucode �Z�b�g���� stucode
	 */
	public void setStucode(String[] stucode) {
		this.stucode = stucode;
	}

	/**
	 * @return result
	 */
	public List<Print10104000Entity> getResult() {
		return result;
	}


}
