package jp.co.systemd.tnavi.cus.ehime.db.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;

public class Check32121000Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Check32121000Service.class);

	/** �����R�[�h */
	private String userCode = null;

	/** ��� */
	private String kijundate = null;

	private Object[] noExistStuList;

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {
		try {

			// ������_�Ŕ�ݐЏ�Ԃł���҂��擾(���Ƃ͏���)
			Object[] param = { userCode, kijundate };
			QueryManager qm = new QueryManager("cus/ehime/check32121000_01.sql", param);
			List<Map<String, String>> mapList = (List<Map<String, String>>) this.executeQuery(qm);

			List<String> tempStuList = new ArrayList<String>();

			for (Map<String, String> map : mapList) {
				tempStuList.add(map.get("stucode"));
			}

			// �z��ɕϊ�
			noExistStuList = tempStuList.toArray();

		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
			throw new TnaviException(e);
		}
	}

	public void setParameters(String userCode, String kijundate) {
		this.userCode = userCode;
		this.kijundate = kijundate;
	}

	public Object[] getNoExistStuList() {
		return noExistStuList;
	}

}
