package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * ���ʊ����̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.04.23 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32056000_SpecialActivityEntity {

    /**
	 * �w�Дԍ�
	 */
	private String rsav_stucode;

	/**
	 * �o�͎���ID
	 */
	private String rsav_term;

	/**
	 * ���ʊ����R�[�h
	 */
	private String rsav_rsatcode;

	/**
	 * �]���lID
	 */
	private String rsav_rsaecode;

	/**
	 * ���ʊ����̋L�^
	 */
	private String rsav_record;

	/**
	 * ���ʊ����̓��e
	 */
	private String rsat_rsatname;

	/**
	 * �]���l(�\���p)
	 */
	private String rsae_display;


	public String getRsav_stucode() {
	    return rsav_stucode;
	}

	public void setRsav_stucode(String rsav_stucode) {
	    this.rsav_stucode = rsav_stucode;
	}

	public String getRsav_term() {
	    return rsav_term;
	}

	public void setRsav_term(String rsav_term) {
	    this.rsav_term = rsav_term;
	}

	public String getRsav_rsatcode() {
	    return rsav_rsatcode;
	}

	public void setRsav_rsatcode(String rsav_rsatcode) {
	    this.rsav_rsatcode = rsav_rsatcode;
	}

	public String getRsav_rsaecode() {
	    return rsav_rsaecode;
	}

	public void setRsav_rsaecode(String rsav_rsaecode) {
	    this.rsav_rsaecode = rsav_rsaecode;
	}

	public String getRsav_record() {
	    return rsav_record;
	}

	public void setRsav_record(String rsav_record) {
	    this.rsav_record = rsav_record;
	}

	public String getRsat_rsatname() {
	    return rsat_rsatname;
	}

	public void setRsat_rsatname(String rsat_rsatname) {
	    this.rsat_rsatname = rsat_rsatname;
	}

	public String getRsae_display() {
	    return rsae_display;
	}

	public void setRsae_display(String rsae_display) {
	    this.rsae_display = rsae_display;
	}

}
