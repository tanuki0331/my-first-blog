package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * �ϓ_���Ƃ̐���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.04.23 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32056000_ViewpointValueEntity {

	/**
	 * �w�Дԍ�
	 */
    private String rvpv_stucode;

    /**
     * ���яo�͎���ID
     */
    private String rvpv_goptcode;

    /**
     * ���ȃR�[�h
     */
    private String rvpv_item;

    /**
     * �ϓ_�R�[�h
     */
    private String rvpv_rivtcode;

    /**
     * �\���p�l
     */
    private String rvpv_manualrevpecode;

    /**
     * �\���p�̋L��
     */
    private String rvpe_reportdisplay;

    /**
     * �ΐ��`��t���O
     */
    private String slashFlg;

	public String getRvpv_stucode() {
		return rvpv_stucode;
	}

	public void setRvpv_stucode(String rvpv_stucode) {
		this.rvpv_stucode = rvpv_stucode;
	}

	public String getRvpv_goptcode() {
		return rvpv_goptcode;
	}

	public void setRvpv_goptcode(String rvpv_goptcode) {
		this.rvpv_goptcode = rvpv_goptcode;
	}

	public String getRvpv_item() {
		return rvpv_item;
	}

	public void setRvpv_item(String rvpv_item) {
		this.rvpv_item = rvpv_item;
	}

	public String getRvpv_rivtcode() {
		return rvpv_rivtcode;
	}

	public void setRvpv_rivtcode(String rvpv_rivtcode) {
		this.rvpv_rivtcode = rvpv_rivtcode;
	}

	public String getRvpv_manualrevpecode() {
		return rvpv_manualrevpecode;
	}

	public void setRvpv_manualrevpecode(String rvpv_manualrevpecode) {
		this.rvpv_manualrevpecode = rvpv_manualrevpecode;
	}

	public String getRvpe_reportdisplay() {
		return rvpe_reportdisplay;
	}

	public void setRvpe_reportdisplay(String rvpe_reportdisplay) {
		this.rvpe_reportdisplay = rvpe_reportdisplay;
	}

	public String getSlashFlg() {
		return slashFlg;
	}

	public void setSlashFlg(String slashFlg) {
		this.slashFlg = slashFlg;
	}

}
