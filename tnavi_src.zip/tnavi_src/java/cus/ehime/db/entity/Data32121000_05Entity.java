/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD INCORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * ����l�����_���z�\ 5���Ȃ̂ݏ��� Entity.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32121000_05Entity {

	/** �w�Дԍ� **/
    private String cls_stucode;

    /** ���k���� **/
    private String st4_name;

    /** 5���Ȃ݂̂̏��� */
    private String Ranking;


	/**
	 * @return the cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode the cls_stucode to set
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return the st4_name
	 */
	public String getSt4_name() {
		return st4_name;
	}

	/**
	 * @param st4_name the st4_name to set
	 */
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public String getRanking() {
		return Ranking;
	}

	public void setRanking(String ranking) {
		Ranking = ranking;
	}

	/**
	 * @return the score
	 */


}
