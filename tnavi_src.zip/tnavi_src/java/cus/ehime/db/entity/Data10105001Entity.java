package jp.co.systemd.tnavi.cus.ehime.db.entity;

import jp.co.systemd.tnavi.cus.ehime.constants.HealthConstantsUseable;

/**
 * <PRE>
 * ���f���ʂ̒ʒm�Ɗ������pEntity(�����ގ擾�p).
 * </PRE>
 *
 * <B>Create</B> 2012.02.20 BY fujita<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Data10105001Entity implements HealthConstantsUseable{

	/** �w�Дԍ� */
	private String data_stucode;

	/** ���ދ敪 */
	private Integer data_kbn;

	/** �����ޖ� */
	private String data_mdname;

	/** �����ޖ� */
	private String data_smname;

	public String getData_stucode() {
		return data_stucode;
	}

	public void setData_stucode(String data_stucode) {
		this.data_stucode = data_stucode;
	}

	public Integer getData_kbn() {
		return data_kbn;
	}

	public void setData_kbn(Integer data_kbn) {
		this.data_kbn = data_kbn;
	}

	public String getData_mdname() {
		return data_mdname;
	}

	public void setData_mdname(String data_mdname) {
		this.data_mdname = data_mdname;
	}

	public String getData_smname() {
		return data_smname;
	}

	public void setData_smname(String data_smname) {
		this.data_smname = data_smname;
	}
}
