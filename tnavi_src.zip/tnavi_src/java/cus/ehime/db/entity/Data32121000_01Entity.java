/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD INCORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * ����l�����_���z�\ ���k Entity.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32121000_01Entity {

	/** �w�Дԍ� **/
	private String cls_stucode;

	/** �w�N */
	private String cls_glade;

	/** �g */
	private String hmr_class;

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String cls_number;

	/** ���k���� **/
	private String st4_name;

	/** ���k�ӂ肪�� **/
	private String st4_hkana;

	/** �𗬊w���Q���҃t���O */
	private String isKoryu;

	/**
	 * @return the cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode the cls_stucode to set
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return the cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade the cls_glade to set
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return the hmr_class
	 */
	public String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class the hmr_class to set
	 */
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return the cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number the cls_number to set
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	/**
	 * @return the st4_name
	 */
	public String getSt4_name() {
		return st4_name;
	}

	/**
	 * @param st4_name the st4_name to set
	 */
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	/**
	 * @return the st4_hkana
	 */
	public String getSt4_hkana() {
		return st4_hkana;
	}

	/**
	 * @param st4_hkana the st4_hkana to set
	 */
	public void setSt4_hkana(String st4_hkana) {
		this.st4_hkana = st4_hkana;
	}

	/**
	 * @return isKoryu
	 */
	public String getIsKoryu() {
		return isKoryu;
	}

	/**
	 * @param isKoryu isKoryu��ݒ肷��
	 */
	public void setIsKoryu(String isKoryu) {
		this.isKoryu = isKoryu;
	}
}
