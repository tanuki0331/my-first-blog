/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD INCORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * ����l�����_���z�\ 5���Ȃ̂ݏ��� Entity.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */

	public class Data32121000_06Entity {

	    /** ���k�R�[�h */
	    private String stucode;

	    /** �g */
	    private String cls_number;

	    /** ���k���� */
	    private String st4_name;

	    /** ���ȃR�[�h */
	    private String cod_code;

	    /** ���Ȗ� */
	    private String item_name;


	    /** ���_ */
	    private String soten;


		public String getStucode() {
			return stucode;
		}


		public void setStucode(String stucode) {
			this.stucode = stucode;
		}


		public String getCls_number() {
			return cls_number;
		}


		public void setCls_number(String cls_number) {
			this.cls_number = cls_number;
		}


		public String getSt4_name() {
			return st4_name;
		}


		public void setSt4_name(String st4_name) {
			this.st4_name = st4_name;
		}


		public String getCod_code() {
			return cod_code;
		}


		public void setCod_code(String cod_code) {
			this.cod_code = cod_code;
		}


		public String getItem_name() {
			return item_name;
		}


		public void setItem_name(String item_name) {
			this.item_name = item_name;
		}


		public String getSoten() {
			return soten;
		}


		public void setSoten(String soten) {
			this.soten = soten;
		}




}
