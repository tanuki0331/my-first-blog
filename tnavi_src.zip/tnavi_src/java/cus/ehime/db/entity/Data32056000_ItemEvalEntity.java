package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * ���ȕ]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.04.23 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32056000_ItemEvalEntity {
	/**
	 * �w�Дԍ�
	 */
	private String rev_stucode;

	/**
	 * ����
	 */
	private String rev_item;

	/**
	 * ���яo�͎���ID
	 */
	private String rev_goptcode;

	/**
	 * �]��
	 */
	private String revl_display;

    /**
     * �E�オ��ΐ��`��t���O
     */
    private String slashFlg;

	public String getRev_stucode() {
		return rev_stucode;
	}

	public void setRev_stucode(String rev_stucode) {
		this.rev_stucode = rev_stucode;
	}

	public String getRev_item() {
		return rev_item;
	}

	public void setRev_item(String rev_item) {
		this.rev_item = rev_item;
	}

	public String getRev_goptcode() {
	    return rev_goptcode;
	}

	public void setRev_goptcode(String rev_goptcode) {
	    this.rev_goptcode = rev_goptcode;
	}

	public String getRevl_display() {
		return revl_display;
	}

	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}

	public String getSlashFlg() {
		return slashFlg;
	}

	public void setSlashFlg(String slashFlg) {
		this.slashFlg = slashFlg;
	}

}
