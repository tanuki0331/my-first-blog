package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * �����̏o��Entity.
 * </PRE>
 *
  * <B>Create</B> 2018.04.23 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32056000_ScorptCommentEntity {

	/**
	 * �w�Дԍ�
	 */
	private String rcom_stucode;

	/**
	 * �]������
	 */
	private String rcom_term;

	/**
	 * ���ʊ��������̋L�^
	 */
	private String rcom_comment;

	public String getRcom_stucode() {
		return rcom_stucode;
	}

	public void setRcom_stucode(String rcom_stucode) {
		this.rcom_stucode = rcom_stucode;
	}

	public String getRcom_term() {
		return rcom_term;
	}

	public void setRcom_term(String rcom_term) {
		this.rcom_term = rcom_term;
	}

	public String getRcom_comment() {
		return rcom_comment;
	}

	public void setRcom_comment(String rcom_comment) {
		this.rcom_comment = rcom_comment;
	}


}
