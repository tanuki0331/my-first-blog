package jp.co.systemd.tnavi.cus.ehime.db.entity;

import jp.co.systemd.tnavi.cus.ehime.constants.HealthConstantsUseable;

/**
 * <PRE>
 * ���f���ʂ̒ʒm�Ɗ������pEntity.
 * </PRE>
 *
 * <B>Create</B> 2012.01.05 BY yamamoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Data10105000Entity implements HealthConstantsUseable{

	/** �w�Ȗ� */
	private String departmentName = null;

	/** �w�N */
	private String glade = null;

	/** �g */
	private String st_class = null;

	/** �o�Ȕԍ� */
	private String number = null;

	/** �w�Дԍ� */
	private String stucode = null;

	/** ���� */
	private String name = null;

	/** ���� */
	private String inspection = null;

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getGlade() {
		return glade;
	}

	public void setGlade(String glade) {
		this.glade = glade;
	}

	public String getSt_class() {
		return st_class;
	}

	public void setSt_class(String st_class) {
		this.st_class = st_class;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getStucode() {
		return stucode;
	}

	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInspection() {
		return inspection;
	}

	public void setInspection(String inspection) {
		this.inspection = inspection;
	}

}
