package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * �s���̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.04.23 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32056000_ActViewpointEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �o�͎���ID
	 */
	private String ravt_term;

	/**
	 * ���ږ�
	 */
	private String ravt_ravtname;

	/**
	 * �ϓ_
	 */
	private String ravt_purpose;

	/**
	 * �]��
	 */
	private String race_reportdisplay;

	/**
	 * ���я�
	 */
	private String ravt_order;

	/**
	 * �ϓ_�R�[�h
	 */
	private String ravt_ravtcode;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getRavt_term() {
		return ravt_term;
	}

	public void setRavt_term(String ravt_term) {
		this.ravt_term = ravt_term;
	}

	public String getRavt_ravtname() {
		return ravt_ravtname;
	}

	public void setRavt_ravtname(String ravt_ravtname) {
		this.ravt_ravtname = ravt_ravtname;
	}

	public String getRavt_purpose() {
		return ravt_purpose;
	}

	public void setRavt_purpose(String ravt_purpose) {
		this.ravt_purpose = ravt_purpose;
	}

	public String getRace_reportdisplay() {
		return race_reportdisplay;
	}

	public void setRace_reportdisplay(String race_reportdisplay) {
		this.race_reportdisplay = race_reportdisplay;
	}

	public String getRavt_order() {
		return ravt_order;
	}

	public void setRavt_order(String ravt_order) {
		this.ravt_order = ravt_order;
	}

	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}

	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}

}
