package jp.co.systemd.tnavi.cus.ehime.db.entity;

import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;

/**
 * <PRE>
 * ����f�҂ւ̎�f������ �pEntity.
 * </PRE>
 *
 * <B>Create</B> 2011.12.19 BY yamamoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print10104000Entity  {

	/** �����R�[�h */
	private String cls_user = HelConstants.DEFALUT_VALUE;

	/** �N�x */
	private String cls_year = HelConstants.DEFALUT_VALUE;

	/** �w�ȃR�[�h */
	private String department = HelConstants.DEFALUT_VALUE;

	/** �w�Ȗ� */
	private String departmentName = HelConstants.DEFALUT_VALUE;

	/** �w�N */
	private String glade = HelConstants.DEFALUT_VALUE;

	/** �g */
	private String st_class = HelConstants.DEFALUT_VALUE;

	/** �o�Ȕԍ� */
	private String number = HelConstants.DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String stucode = HelConstants.DEFALUT_VALUE;

	/** ���k���� */
	private String stucodeName = HelConstants.DEFALUT_VALUE;

	/** �Z�� */
	private String principalName = HelConstants.DEFALUT_VALUE;

	/** �w�Z */
	private String schoolName = HelConstants.DEFALUT_VALUE;

	/**
	 * @return cls_user
	 */
	public String getCls_user() {
		return cls_user;
	}

	/**
	 * @param cls_user �Z�b�g���� cls_user
	 */
	public void setCls_user(String cls_user) {
		this.cls_user = cls_user;
	}

	/**
	 * @return cls_year
	 */
	public String getCls_year() {
		return cls_year;
	}

	/**
	 * @param cls_year �Z�b�g���� cls_year
	 */
	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	/**
	 * @return department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department �Z�b�g���� department
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return departmentName
	 */
	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 * @param departmentName �Z�b�g���� departmentName
	 */
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 * @return glade
	 */
	public String getGlade() {
		return glade;
	}

	/**
	 * @param glade �Z�b�g���� glade
	 */
	public void setGlade(String glade) {
		this.glade = glade;
	}

	/**
	 * @return st_class
	 */
	public String getSt_class() {
		return st_class;
	}

	/**
	 * @param st_class �Z�b�g���� st_class
	 */
	public void setSt_class(String st_class) {
		this.st_class = st_class;
	}

	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number �Z�b�g���� number
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return stucode
	 */
	public String getStucode() {
		return stucode;
	}

	/**
	 * @param stucode �Z�b�g���� stucode
	 */
	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	/**
	 * @return stucodeName
	 */
	public String getStucodeName() {
		return stucodeName;
	}

	/**
	 * @param stucodeName �Z�b�g���� stucodeName
	 */
	public void setStucodeName(String stucodeName) {
		this.stucodeName = stucodeName;
	}


	/**
	 * @return principalName
	 */
	public String getPrincipalName() {
		return principalName;
	}

	/**
	 * @param principalName �Z�b�g���� principalName
	 */
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	/**
	 * @return schoolName
	 */
	public String getSchoolName() {
		return schoolName;
	}

	/**
	 * @param schoolName �Z�b�g���� schoolName
	 */
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

}
