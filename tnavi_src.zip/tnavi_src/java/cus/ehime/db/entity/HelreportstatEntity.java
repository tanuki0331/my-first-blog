/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * �ی��񍐏��Entity.
 *
 * <B>Create</B>   2011.11.22 BY hara<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class HelreportstatEntity {

	public final static String DEFALUT_VALUE = "";

	/**�����R�[�h*/
	private String helreps_user = DEFALUT_VALUE;

	/**�N�x*/
	private String helreps_year = DEFALUT_VALUE;

	/**���[��ʃR�[�h*/
	private String helreps_cd = DEFALUT_VALUE;

	/**��*/
	private String helreps_mt = DEFALUT_VALUE;

	/**�񍐓�*/
	private String helreps_issuedate = DEFALUT_VALUE;

	/**�������*/
	private String helreps_printtime = DEFALUT_VALUE;

	/**�񍐓���*/
	private String helreps_sendtime = DEFALUT_VALUE;

	/**�񍐎҃R�[�h*/
	private String helreps_senduser = DEFALUT_VALUE;

	/**�ŏI�񍐓���*/
	private String helreps_sendlasttime = DEFALUT_VALUE;

	/**�X�V��*/
	private String helreps_update = DEFALUT_VALUE;

	/**�X�V��*/
	private String helreps_upuser = DEFALUT_VALUE;

	/**
	 * @return helreps_user
	 */
	public String getHelreps_user() {
		return helreps_user;
	}

	/**
	 * @param helreps_user �Z�b�g���� helreps_user
	 */
	public void setHelreps_user(String helreps_user) {
		this.helreps_user = helreps_user;
	}

	/**
	 * @return helreps_year
	 */
	public String getHelreps_year() {
		return helreps_year;
	}

	/**
	 * @param helreps_year �Z�b�g���� helreps_year
	 */
	public void setHelreps_year(String helreps_year) {
		this.helreps_year = helreps_year;
	}

	/**
	 * @return helreps_cd
	 */
	public String getHelreps_cd() {
		return helreps_cd;
	}

	/**
	 * @param helreps_cd �Z�b�g���� helreps_cd
	 */
	public void setHelreps_cd(String helreps_cd) {
		this.helreps_cd = helreps_cd;
	}

	/**
	 * @return helreps_mt
	 */
	public String getHelreps_mt() {
		return helreps_mt;
	}

	/**
	 * @param helreps_mt �Z�b�g���� helreps_mt
	 */
	public void setHelreps_mt(String helreps_mt) {
		this.helreps_mt = helreps_mt;
	}

	/**
	 * @return helreps_issuedate
	 */
	public String getHelreps_issuedate() {
		return helreps_issuedate;
	}

	/**
	 * @param helreps_issuedate �Z�b�g���� helreps_issuedate
	 */
	public void setHelreps_issuedate(String helreps_issuedate) {
		this.helreps_issuedate = helreps_issuedate;
	}


	/**
	 * @return helreps_printtime
	 */
	public String getHelreps_printtime() {
		return helreps_printtime;
	}

	/**
	 * @param helreps_printtime �Z�b�g���� helreps_printtime
	 */
	public void setHelreps_printtime(String helreps_printtime) {
		this.helreps_printtime = helreps_printtime;
	}

	/**
	 * @return helreps_sendtime
	 */
	public String getHelreps_sendtime() {
		return helreps_sendtime;
	}

	/**
	 * @param helreps_sendtime �Z�b�g���� helreps_sendtime
	 */
	public void setHelreps_sendtime(String helreps_sendtime) {
		this.helreps_sendtime = helreps_sendtime;
	}

	/**
	 * @return helreps_senduser
	 */
	public String getHelreps_senduser() {
		return helreps_senduser;
	}

	/**
	 * @param helreps_senduser �Z�b�g���� helreps_senduser
	 */
	public void setHelreps_senduser(String helreps_senduser) {
		this.helreps_senduser = helreps_senduser;
	}

	/**
	 * @return helreps_sendlasttime
	 */
	public String getHelreps_sendlasttime() {
		return helreps_sendlasttime;
	}

	/**
	 * @param helreps_sendlasttime �Z�b�g���� helreps_sendlasttime
	 */
	public void setHelreps_sendlasttime(String helreps_sendlasttime) {
		this.helreps_sendlasttime = helreps_sendlasttime;
	}

	/**
	 * @return helreps_update
	 */
	public String getHelreps_update() {
		return helreps_update;
	}

	/**
	 * @param helreps_update �Z�b�g���� helreps_update
	 */
	public void setHelreps_update(String helreps_update) {
		this.helreps_update = helreps_update;
	}

	/**
	 * @return helreps_update
	 */
	public String getHelreps_upuser() {
		return helreps_upuser;
	}

	/**
	 * @param helreps_upuser �Z�b�g���� helreps_upuser
	 */
	public void setHelreps_upuser(String helreps_upuser) {
		this.helreps_upuser = helreps_upuser;
	}


}