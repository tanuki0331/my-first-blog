/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD INCORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * ����l�����_���z�\ ���ȏ��� Entity.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32121000_04Entity {

	/** �w�Дԍ� **/
    private String cls_stucode;

	/** �����ԍ�(�o�Ȕԍ�) **/
    private String cls_number;

    /** ���k���� **/
    private String st4_name;

    /** ���ȃR�[�h */
    private String subject_code;

    /** ���Ȗ� */
    private String subject_name;

    /** ���Ȃ��Ƃ̏��� */
    private String ranking;


	/**
	 * @return the cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode the cls_stucode to set
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return the cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number the cls_number to set
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	/**
	 * @return the st4_name
	 */
	public String getSt4_name() {
		return st4_name;
	}

	/**
	 * @param st4_name the st4_name to set
	 */
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	/**
	 * @return the subject_code
	 */
	public String getSubject_code() {
		return subject_code;
	}

	/**
	 * @param subject_code the subject_code to set
	 */
	public void setSubject_code(String subject_code) {
		this.subject_code = subject_code;
	}

	/**
	 * @return the subject_name
	 */
	public String getSubject_name() {
		return subject_name;
	}

	/**
	 * @param subject_name the subject_name to set
	 */
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}

	public String getRanking() {
		return ranking;
	}

	public void setRanking(String ranking) {
		this.ranking = ranking;
	}

	/**
	 * @return the score
	 */

}
