package jp.co.systemd.tnavi.cus.ehime.db.entity;

import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;

/**
 * <PRE>
 * ���f���ʂ̒ʒm�Ɗ����� �pEntity.
 * </PRE>
 *
 * <B>Create</B> 2012.01.05 BY yamamoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print10105000Entity  {

	/** �w�Ȗ� */
	private String departmentName = HelConstants.DEFALUT_VALUE;

	/** �w�N */
	private String glade = HelConstants.DEFALUT_VALUE;

	/** �g */
	private String st_class = HelConstants.DEFALUT_VALUE;

	/** �o�Ȕԍ� */
	private String number = HelConstants.DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String stucode = HelConstants.DEFALUT_VALUE;

	/** ���k���� */
	private String stucodeName = HelConstants.DEFALUT_VALUE;

	/** �Z�� */
	private String principalName = HelConstants.DEFALUT_VALUE;

	/** �w�Z */
	private String schoolName = HelConstants.DEFALUT_VALUE;

	/** ���Ȍ��f */
	private String medicineItem = HelConstants.DEFALUT_VALUE;

	/** ���Ȍ��f(��f����) */
	private String dentistryResult1 = HelConstants.DEFALUT_VALUE;
	private String dentistryResult2 = HelConstants.DEFALUT_VALUE;
	private String dentistryResult3 = HelConstants.DEFALUT_VALUE;
	private String dentistryResult4 = HelConstants.DEFALUT_VALUE;
	private String dentistryResult5 = HelConstants.DEFALUT_VALUE;
	private String dentistryResult6 = HelConstants.DEFALUT_VALUE;


	/** ���Ȍ��f�i�����u���̑��v�j */
	private String dentistryItem = HelConstants.DEFALUT_VALUE;

	/** ���͌��f(����) */
	private String eyeRight1 = HelConstants.DEFALUT_VALUE;
	private String eyeRight2 = HelConstants.DEFALUT_VALUE;
	private String eyeLeft1 = HelConstants.DEFALUT_VALUE;
	private String eyeLeft2 = HelConstants.DEFALUT_VALUE;

	/** ���͌��f */
	private String eyesightItem = HelConstants.DEFALUT_VALUE;

	/** �A���f */
	private String urineItem1 = HelConstants.DEFALUT_VALUE;
	private String urineItem2 = HelConstants.DEFALUT_VALUE;
	private String urineItem3 = HelConstants.DEFALUT_VALUE;
	private String urineItem4 = HelConstants.DEFALUT_VALUE;

	/** ���͌��f */
	private String hearingRight1 = HelConstants.DEFALUT_VALUE;
	private String hearingRight2 = HelConstants.DEFALUT_VALUE;
	private String hearingLeft1 = HelConstants.DEFALUT_VALUE;
	private String hearingLeft2 = HelConstants.DEFALUT_VALUE;

	/**
	 * @return departmentName
	 */
	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 * @param departmentName �Z�b�g���� departmentName
	 */
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 * @return glade
	 */
	public String getGlade() {
		return glade;
	}

	/**
	 * @param glade �Z�b�g���� glade
	 */
	public void setGlade(String glade) {
		this.glade = glade;
	}

	/**
	 * @return st_class
	 */
	public String getSt_class() {
		return st_class;
	}

	/**
	 * @param st_class �Z�b�g���� st_class
	 */
	public void setSt_class(String st_class) {
		this.st_class = st_class;
	}

	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number �Z�b�g���� number
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return stucode
	 */
	public String getStucode() {
		return stucode;
	}

	/**
	 * @param stucode �Z�b�g���� stucode
	 */
	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	/**
	 * @return stucodeName
	 */
	public String getStucodeName() {
		return stucodeName;
	}

	/**
	 * @param stucodeName �Z�b�g���� stucodeName
	 */
	public void setStucodeName(String stucodeName) {
		this.stucodeName = stucodeName;
	}


	/**
	 * @return principalName
	 */
	public String getPrincipalName() {
		return principalName;
	}

	/**
	 * @param principalName �Z�b�g���� principalName
	 */
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	/**
	 * @return schoolName
	 */
	public String getSchoolName() {
		return schoolName;
	}

	/**
	 * @param schoolName �Z�b�g���� schoolName
	 */
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	/**
	 * @return medicineItem
	 */
	public String getMedicineItem() {
		return medicineItem;
	}

	/**
	 * @param medicineItem �Z�b�g���� medicineItem
	 */
	public void setMedicineItem(String medicineItem) {
		this.medicineItem = medicineItem;
	}

	/**
	 * @return dentistryResult1
	 */
	public String getDentistryResult1() {
		return dentistryResult1;
	}

	/**
	 * @param dentistryResult1 �Z�b�g���� dentistryResult1
	 */
	public void setDentistryResult1(String dentistryResult1) {
		this.dentistryResult1 = dentistryResult1;
	}

	/**
	 * @return dentistryResult2
	 */
	public String getDentistryResult2() {
		return dentistryResult2;
	}

	/**
	 * @param dentistryResult2 �Z�b�g���� dentistryResult2
	 */
	public void setDentistryResult2(String dentistryResult2) {
		this.dentistryResult2 = dentistryResult2;
	}

	/**
	 * @return dentistryResult3
	 */
	public String getDentistryResult3() {
		return dentistryResult3;
	}

	/**
	 * @param dentistryResult3 �Z�b�g���� dentistryResult3
	 */
	public void setDentistryResult3(String dentistryResult3) {
		this.dentistryResult3 = dentistryResult3;
	}

	/**
	 * @return dentistryResult4
	 */
	public String getDentistryResult4() {
		return dentistryResult4;
	}

	/**
	 * @param dentistryResult4 �Z�b�g���� dentistryResult4
	 */
	public void setDentistryResult4(String dentistryResult4) {
		this.dentistryResult4 = dentistryResult4;
	}

	/**
	 * @return dentistryResult5
	 */
	public String getDentistryResult5() {
		return dentistryResult5;
	}

	/**
	 * @param dentistryResult5 �Z�b�g���� dentistryResult5
	 */
	public void setDentistryResult5(String dentistryResult5) {
		this.dentistryResult5 = dentistryResult5;
	}

	/**
	 * @return dentistryResult6
	 */
	public String getDentistryResult6() {
		return dentistryResult6;
	}

	/**
	 * @param dentistryResult6 �Z�b�g���� dentistryResult6
	 */
	public void setDentistryResult6(String dentistryResult6) {
		this.dentistryResult6 = dentistryResult6;
	}

	/**
	 * @return dentistryItem
	 */
	public String getDentistryItem() {
		return dentistryItem;
	}

	/**
	 * @param dentistryItem �Z�b�g���� dentistryItem
	 */
	public void setDentistryItem(String dentistryItem) {
		this.dentistryItem = dentistryItem;
	}

	/**
	 * @return eyeRight1
	 */
	public String getEyeRight1() {
		return eyeRight1;
	}

	/**
	 * @param eyeRight1 �Z�b�g���� eyeRight1
	 */
	public void setEyeRight1(String eyeRight1) {
		this.eyeRight1 = eyeRight1;
	}

	/**
	 * @return eyeRight2
	 */
	public String getEyeRight2() {
		return eyeRight2;
	}

	/**
	 * @param eyeRight2 �Z�b�g���� eyeRight2
	 */
	public void setEyeRight2(String eyeRight2) {
		this.eyeRight2 = eyeRight2;
	}

	/**
	 * @return eyeLeft1
	 */
	public String getEyeLeft1() {
		return eyeLeft1;
	}

	/**
	 * @param eyeLeft1 �Z�b�g���� eyeLeft1
	 */
	public void setEyeLeft1(String eyeLeft1) {
		this.eyeLeft1 = eyeLeft1;
	}

	/**
	 * @return eyeLeft2
	 */
	public String getEyeLeft2() {
		return eyeLeft2;
	}

	/**
	 * @param eyeLeft2 �Z�b�g���� eyeLeft2
	 */
	public void setEyeLeft2(String eyeLeft2) {
		this.eyeLeft2 = eyeLeft2;
	}

	/**
	 * @return eyesightItem
	 */
	public String getEyesightItem() {
		return eyesightItem;
	}

	/**
	 * @param eyesightItem �Z�b�g���� eyesightItem
	 */
	public void setEyesightItem(String eyesightItem) {
		this.eyesightItem = eyesightItem;
	}

	/**
	 * @return urineItem1
	 */
	public String getUrineItem1() {
		return urineItem1;
	}

	/**
	 * @param urineItem1 �Z�b�g���� urineItem1
	 */
	public void setUrineItem1(String urineItem1) {
		this.urineItem1 = urineItem1;
	}

	/**
	 * @return urineItem2
	 */
	public String getUrineItem2() {
		return urineItem2;
	}

	/**
	 * @param urineItem2 �Z�b�g���� urineItem2
	 */
	public void setUrineItem2(String urineItem2) {
		this.urineItem2 = urineItem2;
	}

	/**
	 * @return urineItem3
	 */
	public String getUrineItem3() {
		return urineItem3;
	}

	/**
	 * @param urineItem3 �Z�b�g���� urineItem3
	 */
	public void setUrineItem3(String urineItem3) {
		this.urineItem3 = urineItem3;
	}

	/**
	 * @return urineItem4
	 */
	public String getUrineItem4() {
		return urineItem4;
	}

	/**
	 * @param urineItem4 �Z�b�g���� urineItem4
	 */
	public void setUrineItem4(String urineItem4) {
		this.urineItem4 = urineItem4;
	}

	public String getHearingRight1() {
		return hearingRight1;
	}

	public void setHearingRight1(String hearingRight1) {
		this.hearingRight1 = hearingRight1;
	}

	public String getHearingRight2() {
		return hearingRight2;
	}

	public void setHearingRight2(String hearingRight2) {
		this.hearingRight2 = hearingRight2;
	}

	public String getHearingLeft1() {
		return hearingLeft1;
	}

	public void setHearingLeft1(String hearingLeft1) {
		this.hearingLeft1 = hearingLeft1;
	}

	public String getHearingLeft2() {
		return hearingLeft2;
	}

	public void setHearingLeft2(String hearingLeft2) {
		this.hearingLeft2 = hearingLeft2;
	}


}
