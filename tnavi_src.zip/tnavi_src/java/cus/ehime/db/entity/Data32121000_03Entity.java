/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD INCORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.db.entity;

/**
 * <PRE>
 * ����l�����_���z�\ ���z�f�[�^ Entity.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32121000_03Entity {

	/**
	 * ���_�͈́i�����j
	 */
	private String lowerLimit;

	/**
	 * ���_�͈́i����j
	 */
	private String upperLimit;

	/**
	 * �Ώېl���i�c���j
	 */
	private Integer rangeCount;

	/**
	 * ���ȃR�[�h
	 */
	private String subjectCode;

	/**
	 * �Ȗږ�
	 */
	private String subjectName;

	/**
	 * @return the lowerLimit
	 */
	public String getLowerLimit() {
		return lowerLimit;
	}

	/**
	 * @param lowerLimit the lowerLimit to set
	 */
	public void setLowerLimit(String lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	/**
	 * @return the upperLimit
	 */
	public String getUpperLimit() {
		return upperLimit;
	}

	/**
	 * @param upperLimit the upperLimit to set
	 */
	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}

	/**
	 * @return the rangeCount
	 */
	public Integer getRangeCount() {
		return rangeCount;
	}

	/**
	 * @param rangeCount the rangeCount to set
	 */
	public void setRangeCount(Integer rangeCount) {
		this.rangeCount = rangeCount;
	}

	/**
	 * @return the subjectCode
	 */
	public String getSubjectCode() {
		return subjectCode;
	}

	/**
	 * @param subjectCode the subjectCode to set
	 */
	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}

	/**
	 * @return the subjectName
	 */
	public String getSubjectName() {
		return subjectName;
	}

	/**
	 * @param subjectName the subjectName to set
	 */
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

}
