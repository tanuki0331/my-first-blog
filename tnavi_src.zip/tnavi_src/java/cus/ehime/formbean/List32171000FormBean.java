/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.formbean;

import java.util.ArrayList;
import java.util.List;

/**
 * �x���v��Excel�����o��
 *
 * <B>Create</B>   2019.1.16 BY oe<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List32171000FormBean {

	public final static String DEFALUT_VALUE = "";

	private String userCode = DEFALUT_VALUE;

    /**
     * �N�x
     */
    private String year = DEFALUT_VALUE;
    /**
     * �w��
     */
    private String dcode = DEFALUT_VALUE;
    /**
     * �n��E�R�[�X
     */
    private String course = DEFALUT_VALUE;
    /**
     * �w�N
     */
    private String glade = DEFALUT_VALUE;
    /**
     * �g
     */
    private String cls = DEFALUT_VALUE;

    private List<Data32171000FormBean> data32171000FormBeanList = new ArrayList<Data32171000FormBean>();

	/**
	 * �f�[�^�̌���
	 */
	private int dataCount;

	/** �����敪 */
	private String searchKind = DEFALUT_VALUE;

	/** �w���ԍ� */
	private String clsno = DEFALUT_VALUE;

	/** ���ʊw��No */
    private String spgdcode = DEFALUT_VALUE;

    /** �^�C�g�� */
    private String title = DEFALUT_VALUE;


	public String getUserCode() {
	    return userCode;
	}

	public void setUserCode(String userCode) {
	    this.userCode = userCode;
	}

	public String getYear() {
	    return year;
	}

	public void setYear(String year) {
	    this.year = year;
	}

	public String getDcode() {
	    return dcode;
	}

	public void setDcode(String dcode) {
	    this.dcode = dcode;
	}

	public String getCourse() {
	    return course;
	}

	public void setCourse(String course) {
	    this.course = course;
	}

	public String getGlade() {
	    return glade;
	}

	public void setGlade(String glade) {
	    this.glade = glade;
	}

	public String getCls() {
	    return cls;
	}

	public void setCls(String cls) {
	    this.cls = cls;
	}

	public List<Data32171000FormBean> getData32171000FormBeanList() {
	    return data32171000FormBeanList;
	}

	public void setData32171000FormBeanList(List<Data32171000FormBean> data32171000FormBeanList) {
	    this.data32171000FormBeanList = data32171000FormBeanList;
	}

	public int getDataCount() {
	    return dataCount;
	}

	public void setDataCount(int dataCount) {
	    this.dataCount = dataCount;
	}

	public String getSearchKind() {
	    return searchKind;
	}

	public void setSearchKind(String searchKind) {
	    this.searchKind = searchKind;
	}

	public String getClsno() {
	    return clsno;
	}

	public void setClsno(String clsno) {
	    this.clsno = clsno;
	}

	public String getSpgdcode() {
	    return spgdcode;
	}

	public void setSpgdcode(String spgdcode) {
	    this.spgdcode = spgdcode;
	}

	public String getTitle() {
	    return title;
	}

	public void setTitle(String title) {
	    this.title = title;
	}

}