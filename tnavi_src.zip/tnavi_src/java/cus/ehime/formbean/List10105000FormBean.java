package jp.co.systemd.tnavi.cus.ehime.formbean;


import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;

/**
 * <PRE>
 * ���f���ʂ̒ʒm�Ɗ����� ���ʈꗗ FormBean.
 * </PRE>
 *
 * <B>Create</B> 2012.01.05 BY yammaoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List10105000FormBean {


	/** �w�Ȗ� */
	private String departmentName = HelConstants.DEFALUT_VALUE;

	/** �w�N */
	private String glade = HelConstants.DEFALUT_VALUE;

	/** �g */
	private String st_class = HelConstants.DEFALUT_VALUE;

	/** �o�Ȕԍ� */
	private String number = HelConstants.DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String stucode = HelConstants.DEFALUT_VALUE;

	/** ���� */
	private String name = HelConstants.DEFALUT_VALUE;

	/** ���� */
	private String inspection = HelConstants.DEFALUT_VALUE;


	/**
	 * @return departmentName
	 */
	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 * @param departmentName �Z�b�g���� departmentName
	 */
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 * @return glade
	 */
	public String getGlade() {
		return glade;
	}

	/**
	 * @param glade �Z�b�g���� glade
	 */
	public void setGlade(String glade) {
		this.glade = glade;
	}

	/**
	 * @return st_class
	 */
	public String getSt_class() {
		return st_class;
	}

	/**
	 * @param st_class �Z�b�g���� st_class
	 */
	public void setSt_class(String st_class) {
		this.st_class = st_class;
	}

	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number �Z�b�g���� number
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return stucode
	 */
	public String getStucode() {
		return stucode;
	}

	/**
	 * @param stucode �Z�b�g���� stucode
	 */
	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name �Z�b�g���� name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return inspection
	 */
	public String getInspection() {
		return inspection;
	}

	/**
	 * @param inspection �Z�b�g���� inspection
	 */
	public void setInspection(String inspection) {
		this.inspection = inspection;
	}

}
