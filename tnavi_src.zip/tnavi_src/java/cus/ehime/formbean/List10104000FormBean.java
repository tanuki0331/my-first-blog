package jp.co.systemd.tnavi.cus.ehime.formbean;


import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;

/**
 * <PRE>
 * ����f�҂ւ̎�f������ ���ʈꗗ FormBean.
 * </PRE>
 *
 * <B>Create</B> 2011.12.15 BY yammaoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List10104000FormBean {


	/** �����R�[�h */
	private String cls_user = HelConstants.DEFALUT_VALUE;

	/** �N�x */
	private String cls_year = HelConstants.DEFALUT_VALUE;

	/** �w�ȃR�[�h */
	private String department = HelConstants.DEFALUT_VALUE;

	/** �w�Ȗ� */
	private String departmentName = HelConstants.DEFALUT_VALUE;

	/** �w�N */
	private String glade = HelConstants.DEFALUT_VALUE;

	/** �g */
	private String st_class = HelConstants.DEFALUT_VALUE;

	/** �o�Ȕԍ� */
	private String number = HelConstants.DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String stucode = HelConstants.DEFALUT_VALUE;

	/** ���� */
	private String name = HelConstants.DEFALUT_VALUE;

	/** ���� */
	private String inspection = HelConstants.DEFALUT_VALUE;

	/**
	 * @return cls_user
	 */
	public String getCls_user() {
		return cls_user;
	}

	/**
	 * @param cls_user �Z�b�g���� cls_user
	 */
	public void setCls_user(String cls_user) {
		this.cls_user = cls_user;
	}

	/**
	 * @return cls_year
	 */
	public String getCls_year() {
		return cls_year;
	}

	/**
	 * @param cls_year �Z�b�g���� cls_year
	 */
	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	/**
	 * @return department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department �Z�b�g���� department
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return departmentName
	 */
	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 * @param departmentName �Z�b�g���� departmentName
	 */
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 * @return glade
	 */
	public String getGlade() {
		return glade;
	}

	/**
	 * @param glade �Z�b�g���� glade
	 */
	public void setGlade(String glade) {
		this.glade = glade;
	}

	/**
	 * @return st_class
	 */
	public String getSt_class() {
		return st_class;
	}

	/**
	 * @param st_class �Z�b�g���� st_class
	 */
	public void setSt_class(String st_class) {
		this.st_class = st_class;
	}

	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number �Z�b�g���� number
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return stucode
	 */
	public String getStucode() {
		return stucode;
	}

	/**
	 * @param stucode �Z�b�g���� stucode
	 */
	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name �Z�b�g���� name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return inspection
	 */
	public String getInspection() {
		return inspection;
	}

	/**
	 * @param inspection �Z�b�g���� inspection
	 */
	public void setInspection(String inspection) {
		this.inspection = inspection;
	}

}
