/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD INCORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.formbean;

import java.util.List;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32121000_01Entity;


/**
 * <PRE>
 * ����l�����_���z�\ ���k�ꗗ FormBean.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List32121000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�� **/
	private String goptCode = DEFALUT_VALUE;

	/** �w���i�\���p�j**/
	private String goptCodeStr = DEFALUT_VALUE;

	/** �w�N **/
	private String hmrGlade = DEFALUT_VALUE;

	/** �w�N�i�\���p�j**/
	private String hmrGladeStr = DEFALUT_VALUE;

	/** �g **/
	private String hmrClass = DEFALUT_VALUE;

	/** �g�i�\���p�j**/
	private String hmrClassStr = DEFALUT_VALUE;

	/** ���k�ꗗ **/
	private List<Data32121000_01Entity> studentList;

	/** �ꗗ����(���k���)���� **/
	private int cntListDetail = 0;

	/** �N���X�ԍ� **/
	private  String clsno = DEFALUT_VALUE;

	/** �]���Ώۃ��X�g(����l��) */
	private List<SimpleTagFormBean> testplanTypeList;

	/** �]���Ώۃ��X�g(���̓e�X�g) */
	private List<SimpleTagFormBean> abilitytestplanTypeList;

	/**
	 * �V�X�e���N����
	 * 2015.10.02_ootani
	 */
	private String outputDate;

	/**
	 * CoReports���C�A�E�g
	 */
	private String crlayout = DEFALUT_VALUE;

	/**
	 * ���ʎx���w������p
	 */
	private boolean isSpSupportCls = false;

	/**
	 * @return the nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo the nendo to set
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return the goptCode
	 */
	public String getGoptCode() {
		return goptCode;
	}

	/**
	 * @param goptCode the goptCode to set
	 */
	public void setGoptCode(String goptCode) {
		this.goptCode = goptCode;
	}

	/**
	 * @return the goptCodeStr
	 */
	public String getGoptCodeStr() {
		return goptCodeStr;
	}

	/**
	 * @param goptCodeStr the goptCodeStr to set
	 */
	public void setGoptCodeStr(String goptCodeStr) {
		this.goptCodeStr = goptCodeStr;
	}

	/**
	 * @return the hmrGlade
	 */
	public String getHmrGlade() {
		return hmrGlade;
	}

	/**
	 * @param hmrGlade the hmrGlade to set
	 */
	public void setHmrGlade(String hmrGlade) {
		this.hmrGlade = hmrGlade;
	}

	/**
	 * @return the hmrGladeStr
	 */
	public String getHmrGladeStr() {
		return hmrGladeStr;
	}

	/**
	 * @param hmrGladeStr the hmrGladeStr to set
	 */
	public void setHmrGladeStr(String hmrGladeStr) {
		this.hmrGladeStr = hmrGladeStr;
	}

	/**
	 * @return the hmrClass
	 */
	public String getHmrClass() {
		return hmrClass;
	}

	/**
	 * @param hmrClass the hmrClass to set
	 */
	public void setHmrClass(String hmrClass) {
		this.hmrClass = hmrClass;
	}

	/**
	 * @return the hmrClassStr
	 */
	public String getHmrClassStr() {
		return hmrClassStr;
	}

	/**
	 * @param hmrClassStr the hmrClassStr to set
	 */
	public void setHmrClassStr(String hmrClassStr) {
		this.hmrClassStr = hmrClassStr;
	}

	/**
	 * @return the studentList
	 */
	public List<Data32121000_01Entity> getStudentList() {
		return studentList;
	}

	/**
	 * @param studentList the studentList to set
	 */
	public void setStudentList(List<Data32121000_01Entity> studentList) {
		this.studentList = studentList;
	}

	/**
	 * @return the cntListDetail
	 */
	public int getCntListDetail() {
		return cntListDetail;
	}

	/**
	 * @param cntListDetail the cntListDetail to set
	 */
	public void setCntListDetail(int cntListDetail) {
		this.cntListDetail = cntListDetail;
	}

	/**
	 * @return the clsno
	 */
	public String getClsno() {
		return clsno;
	}

	/**
	 * @param clsno the clsno to set
	 */
	public void setClsno(String clsno) {
		this.clsno = clsno;
	}

	/**
	 * @return the testplanTypeList
	 */
	public List<SimpleTagFormBean> getTestplanTypeList() {
		return testplanTypeList;
	}

	/**
	 * @param testplanTypeList the testplanTypeList to set
	 */
	public void setTestplanTypeList(List<SimpleTagFormBean> testplanTypeList) {
		this.testplanTypeList = testplanTypeList;
	}

	public List<SimpleTagFormBean> getAbilitytestplanTypeList() {
		return abilitytestplanTypeList;
	}

	public void setAbilitytestplanTypeList(List<SimpleTagFormBean> abilitytestplanTypeList) {
		this.abilitytestplanTypeList = abilitytestplanTypeList;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public String getCrlayout() {
		return crlayout;
	}

	public void setCrlayout(String crlayout) {
		this.crlayout = crlayout;
	}

	/**
	 * @return isSpSupportCls
	 */
	public boolean isSpSupportCls() {
		return isSpSupportCls;
	}

	/**
	 * @param isSpSupportCls isSpSupportCls��ݒ肷��
	 */
	public void setSpSupportCls(boolean isSpSupportCls) {
		this.isSpSupportCls = isSpSupportCls;
	}

}