package jp.co.systemd.tnavi.cus.ehime.formbean;

/**
 * <PRE>
 * ���ђʒm�\���(���Q��)(���w�Z) ��� ���k��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.04.23 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32056000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String stuGrade = DEFALUT_VALUE;

	/** �g **/
	private String stuClass = DEFALUT_VALUE;

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String stuNumber = DEFALUT_VALUE;

	/** �w�Дԍ� **/
	private String stuStucode = DEFALUT_VALUE;

	/** ���k�E��������(�ʏ�) **/
	private String stuStuname = DEFALUT_VALUE;

	/** ���k�E��������(�ː�) **/
	private String stuStuname_r = DEFALUT_VALUE;

	/** �C�����̐��k�E��������(�ʏ�) **/
	private String stuStuname_Deed = DEFALUT_VALUE;

	/** �C�����̐��k�E��������(�ː�) **/
	private String stuStuname_r_Deed = DEFALUT_VALUE;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getStuGrade() {
		return stuGrade;
	}

	public void setStuGrade(String stuGrade) {
		this.stuGrade = stuGrade;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getStuNumber() {
		return stuNumber;
	}

	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getStuStucode() {
		return stuStucode;
	}

	public void setStuStucode(String stuStucode) {
		this.stuStucode = stuStucode;
	}

	public String getStuStuname() {
		return stuStuname;
	}

	public void setStuStuname(String stuStuname) {
		this.stuStuname = stuStuname;
	}

	public String getStuStuname_r() {
		return stuStuname_r;
	}

	public void setStuStuname_r(String stuStuname_r) {
		this.stuStuname_r = stuStuname_r;
	}

	public String getStuStuname_Deed() {
		return stuStuname_Deed;
	}

	public void setStuStuname_Deed(String stuStuname_Deed) {
		this.stuStuname_Deed = stuStuname_Deed;
	}

	public String getStuStuname_r_Deed() {
		return stuStuname_r_Deed;
	}

	public void setStuStuname_r_Deed(String stuStuname_r_Deed) {
		this.stuStuname_r_Deed = stuStuname_r_Deed;
	}

	public static String getDefalutValue() {
		return DEFALUT_VALUE;
	}

}
