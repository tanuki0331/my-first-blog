package jp.co.systemd.tnavi.cus.ehime.formbean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32121000_03Entity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32121000_06Entity;
import jp.co.systemd.tnavi.mst.formbean.CodeFormBean;


/**
 * <PRE>
 * ����l�����_���z�\ ��� FormBean.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print32121000FormBean {
	/**
	 * �����l
	 */
	public final static String DEFALUT_VALUE = "";

	/**
	 * CoReports�t�H�[���t�@�C����
	 */
	private String formFileName = DEFALUT_VALUE;

	/**
	 * �w�N
	 */
	private String grade;

	/**
	 * ���яo�͎���
	 */
	private String outputtermCode;

	/**
	 * ���яo�͎�������
	 */
	private String outputtermName;

	/**
	 * �]���ΏۃR�[�h
	 */
	private String testplanTypeCode;

	/**
	 * �]���Ώۖ���
	 */
	private String testplanTypeName;

	/**
	 * ���Ȑ�
	 */
	private String outputSubjects;

	/**
	 * �e�X�g�o�͑Ώ�
	 */
	private String outputType;

	/**
	 * ���ϓ_�̈󎚗L��
	 */
	private boolean outputAverage;

	/**
	 * ���ʂ̈󎚗L��
	 */
	private boolean outputRank;

	/**
	 * �\������O���t�̋��ȃ��X�g
	 */
	private List<CodeFormBean> graphSubjectList;

	/**
	 * �O���tY����������
	 */
	private int memoryWidth;

	/**
	 * ���_�\�e�[�u���w�b�_
	 */
	private String[] scoreTableHeader;

	/**
	 * ���_�\�e�[�u�����ϒl
	 */
	private String[] scoreTableAvg;
	/**
	 *����
	 */
	private HashMap<String, String[]> scoreTableRankMap;

	private List<Data32121000FormBean> dataFormBeanList;

	/**
	 * ���z�f�[�^
	 */
	private List<Data32121000_03Entity> graphDataList;

	/**
	 *�`���[�g�p�̓��_Map
	 */
	private Map<String, List<Data32121000_06Entity>> chartScoreMap;

	/**
	 *����l���`���[�g�p�̓��_Map
	 */
	private Map<String, byte[]> graphDataMap;

	/**
	 *���̓e�X�g�̃`���[�g�p�̓��_Map
	 */
	private Map<String, byte[]> abilityGraphDataMap;


	public String getFormFileName() {
		return formFileName;
	}

	public void setFormFileName(String formFileName) {
		this.formFileName = formFileName;
	}

	/**
	 * @return the grade
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}

	/**
	 * @return the outputtermCode
	 */
	public String getOutputtermCode() {
		return outputtermCode;
	}

	/**
	 * @param outputtermCode the outputtermCode to set
	 */
	public void setOutputtermCode(String outputtermCode) {
		this.outputtermCode = outputtermCode;
	}

	/**
	 * @return the outputtermName
	 */
	public String getOutputtermName() {
		return outputtermName;
	}

	/**
	 * @param outputtermName the outputtermName to set
	 */
	public void setOutputtermName(String outputtermName) {
		this.outputtermName = outputtermName;
	}

	/**
	 * @return the testplanTypeCode
	 */
	public String getTestplanTypeCode() {
		return testplanTypeCode;
	}

	/**
	 * @param testplanTypeCode the testplanTypeCode to set
	 */
	public void setTestplanTypeCode(String testplanTypeCode) {
		this.testplanTypeCode = testplanTypeCode;
	}

	/**
	 * @return the testplanTypeName
	 */
	public String getTestplanTypeName() {
		return testplanTypeName;
	}

	/**
	 * @param testplanTypeName the testplanTypeName to set
	 */
	public void setTestplanTypeName(String testplanTypeName) {
		this.testplanTypeName = testplanTypeName;
	}

	/**
	 * @return the outputSubjects
	 */
	public String getOutputSubjects() {
		return outputSubjects;
	}

	/**
	 * @param outputSubjects the outputSubjects to set
	 */
	public void setOutputSubjects(String outputSubjects) {
		this.outputSubjects = outputSubjects;
	}

	public String getOutputType() {
		return outputType;
	}

	public void setOutputType(String outputType) {
		this.outputType = outputType;
	}

	/**
	 * @return outputAverage
	 */
	public boolean isOutputAverage() {
		return outputAverage;
	}

	/**
	 * @param outputAverage �Z�b�g���� outputAverage
	 */
	public void setOutputAverage(boolean outputAverage) {
		this.outputAverage = outputAverage;
	}

	public boolean isOutputRank() {
		return outputRank;
	}

	public void setOutputRank(boolean outputRank) {
		this.outputRank = outputRank;
	}

	/**
	 * @return the graphSubjectList
	 */
	public List<CodeFormBean> getGraphSubjectList() {
		return graphSubjectList;
	}

	/**
	 * @param graphSubjectList the graphSubjectList to set
	 */
	public void setGraphSubjectList(List<CodeFormBean> graphSubjectList) {
		this.graphSubjectList = graphSubjectList;
	}

	/**
	 * @return the memoryWidth
	 */
	public int getMemoryWidth() {
		return memoryWidth;
	}

	/**
	 * @param memoryWidth the memoryWidth to set
	 */
	public void setMemoryWidth(int memoryWidth) {
		this.memoryWidth = memoryWidth;
	}

	/**
	 * @return the scoreTableHeader
	 */
	public String[] getScoreTableHeader() {
		return scoreTableHeader;
	}

	/**
	 * @param scoreTableHeader the scoreTableHeader to set
	 */
	public void setScoreTableHeader(String[] scoreTableHeader) {
		this.scoreTableHeader = scoreTableHeader;
	}

	/**
	 * @return the scoreTableAvg
	 */
	public String[] getScoreTableAvg() {
		return scoreTableAvg;
	}

	/**
	 * @param scoreTableAvg the scoreTableAvg to set
	 */
	public void setScoreTableAvg(String[] scoreTableAvg) {
		this.scoreTableAvg = scoreTableAvg;
	}



	/**
	 * @return the dataFormBeanList
	 */
	public List<Data32121000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	/**
	 * @param dataFormBeanList the dataFormBeanList to set
	 */
	public void setDataFormBeanList(List<Data32121000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	/**
	 * @return the graphDataList
	 */
	public List<Data32121000_03Entity> getGraphDataList() {
		return graphDataList;
	}

	/**
	 * @param graphDataList the graphDataList to set
	 */
	public void setGraphDataList(List<Data32121000_03Entity> graphDataList) {
		this.graphDataList = graphDataList;
	}

	/**
	 *
	 * @return the scoreTableRankMap
	 */
	public HashMap<String, String[]> getScoreTableRankMap() {
		return scoreTableRankMap;
	}

	/**
	 *
	 * @param scoreTableRankMap the scoreTableRankMap to set
	 */
	public void setScoreTableRankMap(HashMap<String, String[]> scoreTableRankMap) {
		this.scoreTableRankMap = scoreTableRankMap;
	}

	/**
	 *
	 * @return the chartScoreMap
	 */
	public Map<String, List<Data32121000_06Entity>> getChartScoreMap() {
		return chartScoreMap;
	}

	/**
	 *
	 * @param chartScoreMap the chartScoreMap to set
	 */
	public void setChartScoreMap(Map<String, List<Data32121000_06Entity>> chartScoreMap) {
		this.chartScoreMap = chartScoreMap;
	}

	/**
	 *
	 * @return the graphDataMap
	 */
	public Map<String, byte[]> getGraphDataMap() {
		return graphDataMap;
	}

	/**
	 *
	 * @param graphDataMap the graphDataMap to set
	 */
	public void setGraphDataMap(Map<String, byte[]> graphDataMap) {
		this.graphDataMap = graphDataMap;
	}

	/**
	 *
	 * @return the abilityGraphDataMap
	 */
	public Map<String, byte[]> getAbilityGraphDataMap() {
		return abilityGraphDataMap;
	}

	/**
	 *
	 * @param abilityGraphDataMap the abilityGraphDataMap to set
	 */
	public void setAbilityGraphDataMap(Map<String, byte[]> abilityGraphDataMap) {
		this.abilityGraphDataMap = abilityGraphDataMap;
	}

}
