package jp.co.systemd.tnavi.cus.ehime.formbean;


/**
 * <PRE>
 * �x���v��Excel�����o��FormBean.
 * </PRE>
 *
 * <B>Create</B> 2019.1.16 BY oe<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print32171000FormBean{

	/**
	 * �N�x
	 */
	private String year = "";

	/**
	 * �����R�[�h
	 */
	private String user = "";

	/**
	 * �o�̓e���v���[�g
	 */
	private String selectTemplate = "";

	/**
	 * �w�Z��
	 */
	private String userName = "";

	/**
	 * ���O�C�����[�U�[
	 */
	private String staffName = "";

	/**
	 * ������鐶�k�̊w�Дԍ�
	 */
	private String stucode = "";

	/**
    * ���k����(�ː�)
    */
	private String stu_name_r = "";

    /**
     * ���k����(�U�艼��)(�ː�)
    */
	private String stu_kana_r = "";

	/**
	 * ����
	 */
	private String stu_sex = "";

	/**
	 * ���N����
	 */
	private String stu_birth = "";

	/**
	 * �ی�Ҏ���(�ː�)
	 */
	private String st2_parent_r = "";

	/**
	 * �ی�҂ӂ肪��(�ː�)
	 */
	private String st2_p_kana_r = "";

	/**
	 * �X�֔ԍ�
	 */
	private String st2_zip = "";

	/**
	 * �Z��
	 */
	private String st2_adress = "";

	/**
	 * �Ԓn
	 */
	private String st2_num1 = "";

	/**
	 * �}���V������
	 */
	private String st2_num2 = "";

	/**
	 * �ی�ғd�b�ԍ�
	 */
	private String st2_p_tel = "";

	/**
	 * �ی�Ҍg�ѓd�b
	 */
	private String st2_mobilephone = "";

	/**
	 * �ً}�d�b�ԍ�
	 */
	private String st2_e_tel = "";

	private String cls_glade = "";

	private String hmr_class = "";

	/**
	 * �g�p�J�n�N����
	 */
	private String cod_start = "";

	private String useh_kind2 = "";

	/**
	 * �g��
	 */
	private String hltck_height = "";

	/**
	 * �̏d
	 */
	private String hltck_weight = "";


	public String getYear() {
	    return year;
	}

	public void setYear(String year) {
	    this.year = year;
	}

	public String getUser() {
	    return user;
	}

	public void setUser(String user) {
	    this.user = user;
	}

	public String getSelectTemplate() {
	    return selectTemplate;
	}

	public void setSelectTemplate(String selectTemplate) {
	    this.selectTemplate = selectTemplate;
	}

	public String getUserName() {
	    return userName;
	}

	public void setUserName(String userName) {
	    this.userName = userName;
	}

	public String getStaffName() {
	    return staffName;
	}

	public void setStaffName(String staffName) {
	    this.staffName = staffName;
	}

	public String getStucode() {
	    return stucode;
	}

	public void setStucode(String stucode) {
	    this.stucode = stucode;
	}

	public String getStu_name_r() {
	    return stu_name_r;
	}

	public void setStu_name_r(String stu_name_r) {
	    this.stu_name_r = stu_name_r;
	}

	public String getStu_kana_r() {
	    return stu_kana_r;
	}

	public void setStu_kana_r(String stu_kana_r) {
	    this.stu_kana_r = stu_kana_r;
	}

	public String getStu_sex() {
	    return stu_sex;
	}

	public void setStu_sex(String stu_sex) {
	    this.stu_sex = stu_sex;
	}

	public String getStu_birth() {
	    return stu_birth;
	}

	public void setStu_birth(String stu_birth) {
	    this.stu_birth = stu_birth;
	}

	public String getSt2_parent_r() {
	    return st2_parent_r;
	}

	public void setSt2_parent_r(String st2_parent_r) {
	    this.st2_parent_r = st2_parent_r;
	}

	public String getSt2_p_kana_r() {
	    return st2_p_kana_r;
	}

	public void setSt2_p_kana_r(String st2_p_kana_r) {
	    this.st2_p_kana_r = st2_p_kana_r;
	}

	public String getSt2_zip() {
	    return st2_zip;
	}

	public void setSt2_zip(String st2_zip) {
	    this.st2_zip = st2_zip;
	}

	public String getSt2_adress() {
	    return st2_adress;
	}

	public void setSt2_adress(String st2_adress) {
	    this.st2_adress = st2_adress;
	}

	public String getSt2_num1() {
	    return st2_num1;
	}

	public void setSt2_num1(String st2_num1) {
	    this.st2_num1 = st2_num1;
	}

	public String getSt2_num2() {
	    return st2_num2;
	}

	public void setSt2_num2(String st2_num2) {
	    this.st2_num2 = st2_num2;
	}

	public String getSt2_p_tel() {
	    return st2_p_tel;
	}

	public void setSt2_p_tel(String st2_p_tel) {
	    this.st2_p_tel = st2_p_tel;
	}

	public String getSt2_mobilephone() {
	    return st2_mobilephone;
	}

	public void setSt2_mobilephone(String st2_mobilephone) {
	    this.st2_mobilephone = st2_mobilephone;
	}

	public String getSt2_e_tel() {
	    return st2_e_tel;
	}

	public void setSt2_e_tel(String st2_e_tel) {
	    this.st2_e_tel = st2_e_tel;
	}

	public String getCls_glade() {
	    return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
	    this.cls_glade = cls_glade;
	}

	public String getHmr_class() {
	    return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
	    this.hmr_class = hmr_class;
	}

	public String getCod_start() {
	    return cod_start;
	}

	public void setCod_start(String cod_start) {
	    this.cod_start = cod_start;
	}

	public String getUseh_kind2() {
	    return useh_kind2;
	}

	public void setUseh_kind2(String useh_kind2) {
	    this.useh_kind2 = useh_kind2;
	}

	public String getHltck_height() {
	    return hltck_height;
	}

	public void setHltck_height(String hltck_height) {
	    this.hltck_height = hltck_height;
	}

	public String getHltck_weight() {
	    return hltck_weight;
	}

	public void setHltck_weight(String hltck_weight) {
	    this.hltck_weight = hltck_weight;
	}
}
