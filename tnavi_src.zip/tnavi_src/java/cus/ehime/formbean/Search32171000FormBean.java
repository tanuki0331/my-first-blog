package jp.co.systemd.tnavi.cus.ehime.formbean;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

public class Search32171000FormBean implements CommonConstantsUseable {

/**
 * Search08050000FormBean.
 *
 * �x���v��Excel�����o��FormBean.
 *
 * <B>Create</B> 2019.1.16 BY oe<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */

	/**
	 * �N�x
	 */
	private String nendo ;

	/**
	 * �w��
	 */
	private String department ;

	/**
	 * �n��E�R�[�X
	 */
	private String course ;

	/**
	 * �N
	 */
	private String glade ;

	/**
	 * �g
	 */
	private String cls ;

	/** �J�ڌ���ʏ�� */
	private String fromScreen;


	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getGlade() {
		return glade;
	}

	public void setGlade(String glade) {
		this.glade = glade;
	}

	public String getCls() {
		return cls;
	}

	public void setCls(String cls) {
		this.cls = cls;
	}

	public String getFromScreen() {
	    return fromScreen;
	}

	public void setFromScreen(String fromScreen) {
	    this.fromScreen = fromScreen;
	}

}