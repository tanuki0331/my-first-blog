package jp.co.systemd.tnavi.cus.ehime.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;

/**
 * <PRE>
 * ����f�҂ւ̎�f�������pFormBean.
 * </PRE>
 *
 * <B>Create</B> 2011.12.15 BY yammaoto<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Search10104000FormBean {

	/** �N�x */
	private String nendo = HelConstants.DEFALUT_VALUE;

	/** �w�ȃR�[�h */
	private String department = HelConstants.DEFALUT_VALUE;

	/** �w�Ȗ��� */
	private String departmentName = HelConstants.DEFALUT_VALUE;

	/** �w�NFrom */
	private String fromGlade = HelConstants.DEFALUT_VALUE;

	/** �w�NTo */
	private String toGlade = HelConstants.DEFALUT_VALUE;

	/** �gFrom */
	private String fromClass = HelConstants.DEFALUT_VALUE;

	/** �gTo */
	private String toClass = HelConstants.DEFALUT_VALUE;

	/** �o�͑Ώ� */
	private String kensin  = HelConstants.DEFALUT_VALUE;

	/** �o�͑Ώ�(�������̓��e) */
	private String init_kensin  = HelConstants.DEFALUT_VALUE;

	/** �������� */
	private List<List10104000FormBean> searchResult = new ArrayList<List10104000FormBean>();

	/** ����1 */
	private String note1 = HelConstants.DEFALUT_VALUE;

	/** ����2 */
	private String note2 = HelConstants.DEFALUT_VALUE;

	/** ���s�� **/
	private String helreps_issuedate = HelConstants.DEFALUT_VALUE;

	/** �Z�������󎚁@(0:���Ȃ��A1:����) */
	private String principalOutput = HelConstants.DEFALUT_VALUE;

	/** ���͌��f�̌`�� (0:�����Ȃ��A1:���݂͂̂̌`���A2:��Ȃ݂̂̌`�� */
	private String enableEyesightOnly = HelConstants.DEFALUT_VALUE;

	/**
	 * ���t�z��(0:�����A1�F�N�A2�F�N�̋�؂蕶���A3�F���A4�F���̋�؂蕶���A5�F���A6�F���̋�؂蕶��)
	 */
    private String[] formatDateArray = {"","","","","","",""};

	/** �I�𐶓k */
	private String[] select = null;

	/**
	 * @return nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo �Z�b�g���� nendo
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department �Z�b�g���� department
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return departmentName
	 */
	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 * @param departmentName �Z�b�g���� departmentName
	 */
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 * @return fromGlade
	 */
	public String getFromGlade() {
		return fromGlade;
	}

	/**
	 * @param fromGlade �Z�b�g���� fromGlade
	 */
	public void setFromGlade(String fromGlade) {
		this.fromGlade = fromGlade;
	}

	/**
	 * @return toGlade
	 */
	public String getToGlade() {
		return toGlade;
	}

	/**
	 * @param toGlade �Z�b�g���� toGlade
	 */
	public void setToGlade(String toGlade) {
		this.toGlade = toGlade;
	}

	/**
	 * @return fromClass
	 */
	public String getFromClass() {
		return fromClass;
	}

	/**
	 * @param fromClass �Z�b�g���� fromClass
	 */
	public void setFromClass(String fromClass) {
		this.fromClass = fromClass;
	}

	/**
	 * @return toClass
	 */
	public String getToClass() {
		return toClass;
	}

	/**
	 * @param toClass �Z�b�g���� toClass
	 */
	public void setToClass(String toClass) {
		this.toClass = toClass;
	}

	/**
	 * @return kensin
	 */
	public String getKensin() {
		return kensin;
	}

	/**
	 * @param kensin �Z�b�g���� kensin
	 */
	public void setKensin(String kensin) {
		this.kensin = kensin;
	}


	/**
	 * @return init_kensin
	 */
	public String getInit_kensin() {
		return init_kensin;
	}

	/**
	 * @param init_kensin �Z�b�g���� init_kensin
	 */
	public void setInit_kensin(String init_kensin) {
		this.init_kensin = init_kensin;
	}

	/**
	 * @return searchResult
	 */
	public List<List10104000FormBean> getSearchResult() {
		return searchResult;
	}

	/**
	 * @param searchResult �Z�b�g���� searchResult
	 */
	public void setSearchResult(List<List10104000FormBean> searchResult) {
		this.searchResult = searchResult;
	}

	/**
	 * @return note1
	 */
	public String getNote1() {
		return note1;
	}

	/**
	 * @param note1 �Z�b�g���� note1
	 */
	public void setNote1(String note1) {
		this.note1 = note1;
	}

	/**
	 * @return note2
	 */
	public String getNote2() {
		return note2;
	}

	/**
	 * @param note2 �Z�b�g���� note2
	 */
	public void setNote2(String note2) {
		this.note2 = note2;
	}


	public int getSearchResultCount(){
		return searchResult.size();
	}

	/**
	 * @return select
	 */
	public String[] getSelect() {
		return select;
	}

	/**
	 * @param select �Z�b�g���� select
	 */
	public void setSelect(String[] select) {
		this.select = select;
	}

	public String getHelreps_issuedate() {
		return helreps_issuedate;
	}

	public void setHelreps_issuedate(String helreps_issuedate) {
		this.helreps_issuedate = helreps_issuedate;
	}

	public String[] getFormatDateArray() {
		return formatDateArray;
	}

	public void setFormatDateArray(String[] formatDateArray) {
		this.formatDateArray = formatDateArray;
	}

	public String getPrincipalOutput() {
		return principalOutput;
	}

	public void setPrincipalOutput(String principalOutput) {
		this.principalOutput = principalOutput;
	}

	public String getEnableEyesightOnly() {
		return enableEyesightOnly;
	}

	public void setEnableEyesightOnly(String enableEyesightOnly) {
		this.enableEyesightOnly = enableEyesightOnly;
	}



}
