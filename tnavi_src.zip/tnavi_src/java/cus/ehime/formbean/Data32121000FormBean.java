package jp.co.systemd.tnavi.cus.ehime.formbean;



/**
 * <PRE>
 * ����l�����_���z�\ ����f�[�^ FormBean.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32121000FormBean {

	/** �w�Дԍ� **/
	private String cls_stucode;

	/** �N���X��� */
	private String cls_grade;

	/** �g */
	private String hmr_class;

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String cls_number;

	/** ���k���� **/
	private String st4_name;

	/** ���k�ӂ肪�� **/
	private String st4_hkana;

	/** ���_ �u9���ȁv�{�u5���Ȍv�v�{�u9���Ȍv�v */
	private String[] score = {"", "", "", "", "", "", "", "", "", "", ""};

	/** �󌟃t���O �u9���ȁv�{�u5���Ȍv�v�{�u9���Ȍv�v */
	private String[] scoreflg = {"", "", "", "", "", "", "", "", "", "", ""};


	/**
	 * @return the cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode the cls_stucode to set
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return the cls_grade
	 */
	public String getCls_grade() {
		return cls_grade;
	}

	/**
	 * @param cls_grade the cls_grade to set
	 */
	public void setCls_grade(String cls_grade) {
		this.cls_grade = cls_grade;
	}

	/**
	 * @return the hmr_class
	 */
	public String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class the hmr_class to set
	 */
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return the cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number the cls_number to set
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	/**
	 * @return the st4_name
	 */
	public String getSt4_name() {
		return st4_name;
	}

	/**
	 * @param st4_name the st4_name to set
	 */
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	/**
	 * @return the st4_hkana
	 */
	public String getSt4_hkana() {
		return st4_hkana;
	}

	/**
	 * @param st4_hkana the st4_hkana to set
	 */
	public void setSt4_hkana(String st4_hkana) {
		this.st4_hkana = st4_hkana;
	}

	/**
	 * @return the score
	 */
	public String[] getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(String[] score) {
		this.score = score;
	}

	public String[] getScoreflg() {
	    return scoreflg;
	}

	public void setScoreflg(String[] scoreflg) {
	    this.scoreflg = scoreflg;
	}

}
