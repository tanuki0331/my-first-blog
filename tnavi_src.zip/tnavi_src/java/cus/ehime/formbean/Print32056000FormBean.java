package jp.co.systemd.tnavi.cus.ehime.formbean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.db.entity.ScorptspeacttitleEntity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32056000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32056000_AttendEntity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32056000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32056000_ScorptCommentEntity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32056000_SpecialActivityEntity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32056000_TotalactEntity;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Data32056000_ViewpointValueEntity;

/**
 * <PRE>
 * ���ђʒm�\���(���Q��)(���w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.04.23 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print32056000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** 20170620 nagaoka
	 * �o�͂���o�Ȕԍ��̎�� */
	public final static String OUTPUT_NUMBER_KOUBO  = "0"; 	// cls_reference_number���o��
	public final static String OUTPUT_NUMBER_NORMAL = "1"; 	// cls_number���o��

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C�����t */
	private String endDate = DEFALUT_VALUE;

	/** �Z�̓C���[�W */
	byte[] stampImage;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �S�C���� */
	private String teacherName = DEFALUT_VALUE;

	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;

	/** ���ȕʊϓ_�̃��X�g */
	List<List<Data32056000_ItemViewpointEntity>> itemViewpointListList;

	/** �ϓ_�̃��X�g */
	List<Data32056000_ItemViewpointEntity> itemViewpointList;

	/** ���k���̃f�[�^ */
	private List<Data32056000FormBean> dataFormBeanList;

	/** �ϓ_�ʕ]���̃��X�g */
	private Map<String,List<Data32056000_ViewpointValueEntity>> viewpointValueEntityMap;

	/** ���ȕʕ]��̃n�b�V�� �L�[�F�w�Дԍ�_���ȃR�[�h�@�l�F�]�� */
	private HashMap<String,String> itemEvalHash;

	/** �����I�Ȋw�K�̎��Ԃ̃��X�g  */
	private Map<String,List<Data32056000_TotalactEntity>> totalactEntityListMap;

	/** ���퐶���̋L�^�̃��X�g  */
	private Map<String,List<List<Data32056000_ActViewpointEntity>>> actViewpointEntityListListMap;

	/** ���ʊ����̋L�^���e���X�g */
	private List<ScorptspeacttitleEntity> speacttitleList;

	/** ���ʊ����̋L�^�]��MAP */
	private Map<String, Map<String, Data32056000_SpecialActivityEntity>> specialactMapMap;

	/** �����̃��X�g */
	private List<Data32056000_ScorptCommentEntity> scorptCommentEntityList;

	/** �o���̋L�^�̃��X�g(�����Ƃ̏W�v) */
	private Map<String,List<Data32056000_AttendEntity>> stuAttendDataListHash;

	/** �o�͎������X�g */
	private List<CmlguideoutputtermEntity> outputTermEntityList;

	/** ����y�[�W�\�� */
	private boolean output_page1;

	/** ����y�[�W���� */
	private boolean output_page2;

	/** ����y�[�W�C���� */
	private boolean output_page3;


	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public List<List<Data32056000_ItemViewpointEntity>> getItemViewpointListList() {
		return itemViewpointListList;
	}

	public void setItemViewpointListList(
			List<List<Data32056000_ItemViewpointEntity>> itemViewpointListList) {
		this.itemViewpointListList = itemViewpointListList;
	}

	public List<Data32056000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	public void setDataFormBeanList(List<Data32056000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	public Map<String, List<Data32056000_ViewpointValueEntity>> getViewpointValueEntityMap() {
		return viewpointValueEntityMap;
	}

	public void setViewpointValueEntityMap(Map<String, List<Data32056000_ViewpointValueEntity>> viewpointValueEntityMap) {
		this.viewpointValueEntityMap = viewpointValueEntityMap;
	}

	public List<CmlguideoutputtermEntity> getOutputTermEntityList() {
	    return outputTermEntityList;
	}

	public void setOutputTermEntityList(List<CmlguideoutputtermEntity> outputTermEntityList) {
	    this.outputTermEntityList = outputTermEntityList;
	}

	public boolean isOutput_page1() {
		return output_page1;
	}

	public void setOutput_page1(boolean output_page1) {
		this.output_page1 = output_page1;
	}

	public boolean isOutput_page2() {
		return output_page2;
	}

	public void setOutput_page2(boolean output_page2) {
		this.output_page2 = output_page2;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public Map<String,List<Data32056000_TotalactEntity>> getTotalactEntityListMap() {
	    return totalactEntityListMap;
	}

	public void setTotalactEntityListMap(Map<String,List<Data32056000_TotalactEntity>> totalactEntityListMap) {
	    this.totalactEntityListMap = totalactEntityListMap;
	}

	public Map<String,List<List<Data32056000_ActViewpointEntity>>> getActViewpointEntityListListMap() {
	    return actViewpointEntityListListMap;
	}

	public void setActViewpointEntityListListMap(Map<String,List<List<Data32056000_ActViewpointEntity>>> actViewpointEntityListListMap) {
	    this.actViewpointEntityListListMap = actViewpointEntityListListMap;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public boolean isOutput_page3() {
		return output_page3;
	}

	public void setOutput_page3(boolean output_page3) {
		this.output_page3 = output_page3;
	}

	public byte[] getStampImage() {
		return stampImage;
	}

	public void setStampImage(byte[] stampImage) {
		this.stampImage = stampImage;
	}

	public HashMap<String,String> getItemEvalHash() {
		return itemEvalHash;
	}

	public void setItemEvalHash(HashMap<String,String> itemEvalHash) {
		this.itemEvalHash = itemEvalHash;
	}

	public List<ScorptspeacttitleEntity> getSpeacttitleList() {
	    return speacttitleList;
	}

	public void setSpeacttitleList(List<ScorptspeacttitleEntity> speacttitleList) {
	    this.speacttitleList = speacttitleList;
	}

	public Map<String,Map<String,Data32056000_SpecialActivityEntity>> getSpecialactMapMap() {
	    return specialactMapMap;
	}

	public void setSpecialactMapMap(Map<String,Map<String,Data32056000_SpecialActivityEntity>> specialactMapMap) {
	    this.specialactMapMap = specialactMapMap;
	}

	public List<Data32056000_ScorptCommentEntity> getScorptCommentEntityList() {
		return scorptCommentEntityList;
	}

	public void setScorptCommentEntityList(List<Data32056000_ScorptCommentEntity> scorptCommentEntityList) {
		this.scorptCommentEntityList = scorptCommentEntityList;
	}

	public Map<String,List<Data32056000_AttendEntity>> getStuAttendDataListHash() {
		return stuAttendDataListHash;
	}

	public void setStuAttendDataListHash(Map<String,List<Data32056000_AttendEntity>> stuAttendDataListHash) {
		this.stuAttendDataListHash = stuAttendDataListHash;
	}

}
