/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD INCORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ehime.db.service.List32121000Service;
import jp.co.systemd.tnavi.cus.ehime.formbean.List32121000FormBean;

/**
 * <PRE>
 * ����l�����_���z�\ ���k�ꗗAction.
 * </PRE>
 *
 * <B>Create</B>2018.06.22 BY nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List32121000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List32121000Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz����l�����_���z�\ START");

		// ------------------------------------------------------------------------------------------
		// FormBean����
		// ------------------------------------------------------------------------------------------
		List32121000FormBean formBean = new List32121000FormBean();

		// ------------------------------------------------------------------------------------------
		// �����ݒ� - FormBean�ɒl���Z�b�g
		// ------------------------------------------------------------------------------------------
		// �T�[�r�X�N���X�̐���
		List32121000Service service = new List32121000Service();

		// Request(�ʏ�J�ڂ̏ꍇ) ���� Session(��߂飃{�^�������̏ꍇ)�ɐݒ肳��Ă���l����FormBean���쐬����
		service.execute(request, sessionBean);

		// �쐬����FormBean���擾
		formBean = service.getStuListFormBean();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", formBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz����l�����_���z�\ END");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}
}
