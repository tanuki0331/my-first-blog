/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.action;

import java.io.UnsupportedEncodingException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractExcelPrintAction;
import jp.co.systemd.tnavi.common.print.ExcelPrintResult;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ehime.db.service.Print32171000Service;
import jp.co.systemd.tnavi.cus.ehime.formbean.Print32171000FormBean;
import jp.co.systemd.tnavi.cus.ehime.print.Print32171000;

/**
 * <PRE>
 * �x���v��Excel�����o�� �����o��Action.
 * </PRE>
 *
 * <B>Create</B> 2019.1.16 BY OE<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print32171000Action extends AbstractExcelPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32171000Action.class);

	@Override
	protected ExcelPrintResult doPrint(ServletContext sc,
			HttpServletRequest request, SystemInfoBean sessionBean) {

		log.info("�y��ʁz�x���v��Excel�����o�� START");

		Print32171000FormBean formbean = new Print32171000FormBean();

		String userCode = sessionBean.getUserCode();//�����R�[�h
		String year = request.getParameter("year");//�N�x
		String stucode = request.getParameter("print_stucode");//������鐶�k
		String selectTemplate = request.getParameter("selectTemplate");//�o�̓e���v���[�g
		String staffName = sessionBean.getStaffName();

		formbean.setSelectTemplate(selectTemplate);
		formbean.setStaffName(staffName);
		formbean.setStucode(stucode);
		formbean.setYear(year);
		formbean.setUser(userCode);
		//-----�Ɩ�����
		Print32171000Service service = new Print32171000Service();
		service.setPrint32171000FormBean(formbean);

		//���s
		service.execute();

		//���s���ʂ��擾
		formbean = service.getPrint32171000FormBean();

		//�e���v���[�g�t�@�C����
		String templateFileName;
		if(selectTemplate.equals("01")){
			templateFileName = sc.getInitParameter("templateldir") + "cus\\ehime\\�ʂ̋���x���v��(������).xlsx";
		}else{
			templateFileName = sc.getInitParameter("templateldir") + "cus\\ehime\\�ʂ̋���x���v��(�m�I).xlsx";
		}

		// ����v���O����
		Print32171000 print = new Print32171000();
		print.setFormBean(formbean);

		print.setTemplateWorkbookName(templateFileName);

		ExcelPrintResult result = print.execute();

		log.info("�y��ʁz�x���v��Excel�����o�� END");

		return result;
	}

	@Override
	protected String getDownloadFileName(ServletContext sc,
			HttpServletRequest request, SystemInfoBean sessionBean) {

		String fileName = "shingaku_syusyoku_list.xls";
		try {
			fileName = java.net.URLEncoder.encode("�ʂ̋���x���v��.xlsx", "UTF-8");
		} catch (UnsupportedEncodingException e) {
		}
		return fileName;
	}
}
