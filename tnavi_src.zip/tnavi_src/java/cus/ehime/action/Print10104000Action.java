package jp.co.systemd.tnavi.cus.ehime.action;


import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.db.entity.NoticewordsEntity;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.CPlanUtility;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.common.ws.CPFileBean;
import jp.co.systemd.tnavi.cus.ehime.db.service.Insert101040000Service;
import jp.co.systemd.tnavi.cus.ehime.db.service.Search101040000Service;
import jp.co.systemd.tnavi.cus.ehime.db.service.Update101040000Service;


/**
 * �����������
 * �y��ʁz����f�҂ւ̎�f������ �o�� Action�N���X.
 *
 * <B>Create</B> 2012.01.16 BY onishi<BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print10104000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog( Print10104000Action.class );

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y���[�z����f�҂ւ̎�f������ �o�� START");

		// ------------------------------------------------------------------------------------------
		// �L�����p�X�v����Bean����
		// ------------------------------------------------------------------------------------------
		CPFileBean cpBean = new CPFileBean();

		// ------------------------------------------------------------------------------------------
		// �o�͏���
		// ------------------------------------------------------------------------------------------
		try {
			// ------------------------------------------------------------------------------------------
			// �p�����[�^�̎擾
			// ------------------------------------------------------------------------------------------
			// CPlan
			String req_kinoId 		= request.getParameter(CPFileBean.KINO_ID_FORM_NAME);			// �@�\ID�̎擾

			String req_layoutCodeName = request.getParameter(CPFileBean.LAYOUT_CODE_FORM_NAME);		// ���C�A�E�g�R�[�h�̎擾
			String[] values = CPlanUtility.separateKmksetKeyValue(req_layoutCodeName);
			String req_layoutCode 	= values[CPlanUtility.IDX_LEYOUT_CODE];									//���C�A�E�g�R�[�h
			String req_layoutName   = "����f�҂ւ̎�f�������@" + values[CPlanUtility.IDX_LEYOUT_NAME];	//���C�A�E�g����



			String req_fileType 	= request.getParameter(CPFileBean.FILE_TYPE_FORM_NAME);			// PDF��
			String sys_UserCode 	= sessionBean.getStaffId();										// ���[�U�[�R�[�h

			// ���
			String sys_SchId		= sessionBean.getUserCode();						// �����R�[�h
			String nendo			= request.getParameter("nendo");					// �N�x
			String department		= request.getParameter("department");				// �w�ȃR�[�h
			String departmentName	= request.getParameter("departmentName");			// �w�Ȗ���
			String fromGlade		= request.getParameter("fromGlade");				// �w�NFrom
			String toGlade			= request.getParameter("toGlade");					// �w�NTo
			String fromClass		= request.getParameter("fromClass");				// �gFrom
			String toClass			= request.getParameter("toClass");					// �gTo
			String kensin			= request.getParameter("kensin");					// �o�͑Ώ�
			String note1			= request.getParameter("note1");					// ����1
			String note2			= request.getParameter("note2");					// ����2
			String principalOutput	= request.getParameter("principalOutput");			// �Z�������󎚁@(0:���Ȃ��A1:����)
			String enableEyesightOnly			= request.getParameter("enableEyesightOnly");	// ���͌����E��Ȍ��f�̃��C�A�E�g
			String[] select 		= request.getParameterValues("select");				//

			if (req_kinoId == null) 		{ req_kinoId = ""; }
			if (req_layoutCode == null) 	{ req_layoutCode = ""; }
			if (req_layoutName == null) 	{ req_layoutName = ""; }
			if (req_fileType == null) 		{ req_fileType = ""; }
			if (sys_UserCode == null) 		{ sys_UserCode = ""; }
			if (sys_SchId == null) 			{ sys_SchId = ""; }
			if (nendo == null) 				{ nendo = ""; }
			if (department == null)			{ department = ""; }
			if (departmentName == null)		{ departmentName = ""; }
			if (fromGlade == null) 			{ fromGlade = ""; }
			if (toGlade == null) 			{ toGlade = ""; }
			if (fromClass == null) 			{ fromClass = ""; }
			if (toClass == null) 			{ toClass = ""; }
			if (kensin == null) 			{ kensin = ""; }
			if (note1 == null) 				{ note1 = ""; }
			if (note2 == null) 				{ note2 = ""; }
			if (principalOutput == null)	{ principalOutput = ""; }
			if (enableEyesightOnly == null)	{ enableEyesightOnly = ""; }

			DateFormatUtility dfu = sessionBean.getDateFormatUtility();

			// �\���Ώۓ�
			String targetDate = "";

			// �\���Ώۓ�������
			// ���t�v���_�E���ύX��
			// �N
			if (0 != dfu.getYearview()) {
				targetDate = dfu.convertWarekiYearToSeirekiYear(request.getParameter("hldry_date_gengo"), request.getParameter("helreps_issuedate_year"));
			} else {
				targetDate = request.getParameter("helreps_issuedate_year");
			}
			// ��
			targetDate += request.getParameter("helreps_issuedate_month");
			// ��
			targetDate += request.getParameter("helreps_issuedate_day");


			// �ʒm���ޕ����Ǘ������p�����[�^�쐬
			NoticewordsEntity ent = new NoticewordsEntity();
			ent.setNtwd_1st_words(note1);
			ent.setNtwd_2nd_words(note2);
			ent.setNtwd_kind(kensin);
			ent.setNtwd_upuser(sessionBean.getStaffId());
			ent.setNtwd_update(DateUtility.getSystemDate("yyyyMMdd"));
			ent.setNtwd_user(sessionBean.getUserCode());
			ent.setNtwd_principal(principalOutput);

			// �ʒm���ޕ����Ǘ��e�[�u�������T�[�r�X
			Search101040000Service searchService = new Search101040000Service();
			searchService.setNoticewordsEntity(ent);
			searchService.execute();

			// �f�[�^�̗L�����m�F
			if(searchService.getNoteList().size() > 0){
				// �ʒm���ޕ����Ǘ��e�[�u���X�V�T�[�r�X
				Update101040000Service upService = new Update101040000Service();
				upService.setParam(sys_SchId, nendo, sessionBean.getStaffId(), kensin, targetDate);
				upService.setNoticewordsEntity(ent);
				upService.execute();
			}else{
				// �ʒm���ޕ����Ǘ��e�[�u���ǉ��T�[�r�X
				Insert101040000Service insService = new Insert101040000Service();
				insService.setParam(sys_SchId, nendo, sessionBean.getStaffId(), kensin, targetDate);
				insService.setNoticewordsEntity(ent);
				insService.execute();
			}

			// ------------------------------------------------------------------------------------------
			// �t�@�C���o�̓N���X�Ƀp�����[�^�Z�b�g
			// ------------------------------------------------------------------------------------------
			cpBean.setShozokuCode(sys_SchId);
			cpBean.setUserCode(sys_UserCode);
			cpBean.setKinoId(req_kinoId);
			cpBean.setLayoutCode(req_layoutCode);
			cpBean.setParameter("nendo", nendo);
			cpBean.setParameter("department", department);
			cpBean.setParameter("departmentName", departmentName);
			cpBean.setParameter("fromGlade", fromGlade);
			cpBean.setParameter("toGlade", toGlade);
			cpBean.setParameter("fromClass", fromClass);
			cpBean.setParameter("toClass", toClass);
			cpBean.setParameter("kensin", kensin);
			cpBean.setParameter("note1", note1);
			cpBean.setParameter("note2", note2);
			cpBean.setParameter("stucodeList", StringUtils.join(select, ','));
			cpBean.setParameter("helrepsIssuedate", targetDate);
			cpBean.setParameter("enableEyesightOnly", enableEyesightOnly);
			cpBean.setParameter("principalOutput", principalOutput);

			// ------------------------------------------------------------------------------------------
			// �o��
			// ------------------------------------------------------------------------------------------
			Boolean isPDF = true;
			int fileSize = cpBean.sendFileDataToClient(response, isPDF);
			if (fileSize == 0) {
				// �Y���f�[�^���Ȃ��ꍇ
				gotoNoDataPage(request, sessionBean);
				return null;
			}
		} catch(TnaviException tex) {
			throw new TnaviException(tex);
		} catch(Exception e) {
			log.error("��O����",e);
			throw new TnaviException(e);
		}

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y���[�z����f�҂ւ̎�f������ �o�� END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return log;
	}

}
