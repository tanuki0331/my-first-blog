package jp.co.systemd.tnavi.cus.ehime.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.ehime.db.service.Print32121000Service;
import jp.co.systemd.tnavi.cus.ehime.formbean.List32121000FormBean;
import jp.co.systemd.tnavi.cus.ehime.formbean.Print32121000FormBean;
import jp.co.systemd.tnavi.cus.ehime.print.Print32121000;

/**
 * ����l�����_���z�\ ��� Action.
 *
 * <B>Create</B> 2018.06.22 BY nishizawa<BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print32121000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32121000Action.class);

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("����l�����_���z�\ ��� START");

		//-----���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("���ђʒm�\");

		List32121000FormBean listFormBean = (List32121000FormBean)copyRequestParamToFormBean(request, new List32121000FormBean());


		try{

			// 2015.10.02_ootani �o�͊��
			String outputDate = "";
			if(request.getParameter("output_y") != null
					&& request.getParameter("output_m") != null
					&& request.getParameter("output_d") != null){
				StringBuffer sb = new StringBuffer();
				sb.append(request.getParameter("output_y"));
				sb.append(request.getParameter("output_m"));
				sb.append(request.getParameter("output_d"));
				outputDate = sb.toString();
			}else{
				// ���蓾�Ȃ����A�o�͊�����擾�ł��Ȃ���΃V�X�e�����t���Z�b�g
				outputDate = DateUtility.getSystemDate();
			}

			Print32121000Service service = new Print32121000Service(sessionBean, listFormBean );
			service.setOutputDate(outputDate);
			service.execute(request, sessionBean);
			Print32121000FormBean printFormBean = service.getPrintFormBean();

			Print32121000 print32121000 = new Print32121000();
			print32121000.setPrintFormBean(service.getPrintFormBean());
			print32121000.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print32121000.execute(printFormBean.getFormFileName());

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("����l�����_���z�\ ��� END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return null;
	}

}
