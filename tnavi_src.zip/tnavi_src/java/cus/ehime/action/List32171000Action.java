/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ehime.action;


import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.common.formbean.SpClassKeyFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ehime.db.service.List32171000Service;
import jp.co.systemd.tnavi.cus.ehime.formbean.List32171000FormBean;


/**
 * <PRE>
 *�x���v��Excel�����o���i�ꗗ�jAction.
 * </PRE>
 *
 * <B>Create</B> 2019.1.16 BY oe<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List32171000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List32171000Action.class);

	//** �����敪 */
	/** �S�C�i�����j */
	private static String SEARCH_KIND_TANNIN = "01";
	/** ���ʎx���w���i�����j */
	private static String SEARCH_KIND_SPGD = "02";
	/** �����i�����j */
	private static String SEARCH_KIND_KYOMU = "03";

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {
		log.info("�y��ʁz�x���v��Excel�����o�� START");

		String userCode = sessionBean.getUserCode();//�����R�[�h
		String year = "";
		String glade="";
		String cls="";

		String searchKind = null;	// �����敪
		String clsno = null;		// �w��No
		String spgdcode = null;	// ���ʊw��No

		HroomKeyFormBean hrBean = sessionBean.getSelectHroomKey();					// �w���S�C���j���[����J�ڎ��p
		SpClassKeyFormBean spClassKeyFormBean = sessionBean.getSelectSpClassKey();	// ���ʎx���w��Key�̎擾

		String fromScreen = request.getParameter("fromScreen");; // �J�ڌ���ʏ��
		if(fromScreen == null) {
			year = sessionBean.getSystemNendoSeireki();
			if(hrBean != null) {
				// �w���S�C
				clsno = hrBean.getClsno();
				searchKind = SEARCH_KIND_TANNIN;
			}else if(spClassKeyFormBean != null) {
				// ���ʎx���w��
				spgdcode = spClassKeyFormBean.getSpgcode();
				searchKind = SEARCH_KIND_SPGD;
			}
		}else{
			// ����
			year = request.getParameter("nendo");
			glade =  request.getParameter("glade");//�w�N
			cls =  request.getParameter("cls");//�g
			searchKind = SEARCH_KIND_KYOMU;
		}

		List32171000FormBean list32171000FormBean = new List32171000FormBean();

		list32171000FormBean.setUserCode(userCode);
		list32171000FormBean.setYear(year);
		list32171000FormBean.setGlade(glade);
		list32171000FormBean.setCls(cls);
		list32171000FormBean.setSearchKind(searchKind);
		list32171000FormBean.setClsno(clsno);
		list32171000FormBean.setSpgdcode(spgdcode);

		//-----�Ɩ�����
		List32171000Service service = new List32171000Service();
		service.setList32171000FormBean(list32171000FormBean);

		//���s
		service.execute();

		//���s���ʂ��擾
		list32171000FormBean = service.getList32171000FormBean();

		sessionBean.getStudentSessionBean().setTargetYear(year);
		sessionBean.getStudentSessionBean().setGlade(glade);
		sessionBean.getStudentSessionBean().setCls(cls);

		//-----Request��FormBean���Z�b�g����B
		request.setAttribute("FORM_BEAN", list32171000FormBean);

		log.info("�y��ʁz�x���v��Excel�����o���ꗗEND");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}


}
