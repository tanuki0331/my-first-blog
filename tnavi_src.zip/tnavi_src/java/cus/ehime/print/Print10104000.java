package jp.co.systemd.tnavi.cus.ehime.print;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lowagie.text.Cell;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Table;

import jp.co.systemd.tnavi.common.exception.TnaviPrintException;
import jp.co.systemd.tnavi.common.print.AbstractPdfManager;
import jp.co.systemd.tnavi.common.print.PrintConstantsUseable;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.common.utility.PDFFontSizeUtility;
import jp.co.systemd.tnavi.cus.ehime.constants.HealthConstantsUseable;
import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Print10104000Entity;

/**
 * �����������
 * �y��ʁz����f�҂ւ̎�f������Action�N���X.
 *
 * <B>Create</B> 2011.12.16 BY yamamoto<BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print10104000 extends AbstractPdfManager  implements PrintConstantsUseable {

	/**log4j*/
	private final Log log = LogFactory.getLog(Print10104000.class);

	/**����f�f�[�^���X�g*/
	private List<Print10104000Entity> printList = new ArrayList<Print10104000Entity>();

	/** ����1 */
	private String note1 = HelConstants.DEFALUT_VALUE;

	/** ����2 */
	private String note2 = HelConstants.DEFALUT_VALUE;

	/** ���f�敪 */
	private String kensin = HelConstants.DEFALUT_VALUE;

	@Override
	protected void doPrint() throws TnaviPrintException {

        try {

        	for(Print10104000Entity ent : printList){

            	Table headerTable = null;
        		headerTable = new Table(37);
              	headerTable.setWidth(100);
              	Cell[] tdCell = null;

              	// �N���X�A�o�Ȕԍ���null���̓X�y�[�X�ɕϊ�
              	if(ent.getSt_class() == null) ent.setSt_class("�@");
              	if(ent.getNumber() == null) ent.setNumber("�@");

        		// �w�b�_�o��
        		if(HealthConstantsUseable.HEL_CODE_MEDICINE.equals(kensin)){ // ����
        			tdCell = outputMedicineTable(headerTable, ent, "���Ȍ��f�̎�f�ɂ���");

        		}else if(HealthConstantsUseable.HEL_CODE_DENTISTRY.equals(kensin)){ // ���ȉ�
        			tdCell = outputDentistryTable(headerTable, ent, "���Ȍ��f�̎�f�ɂ���");

        		}else if(HealthConstantsUseable.HEL_CODE_EYESIGHT.equals(kensin)){ // ���͉�
        			tdCell = outputEyesightTable(headerTable, ent, "���́E��Ȍ��f�̎�f�ɂ���");

        		}else if(HealthConstantsUseable.HEL_CODE_URINE.equals(kensin)){ // �A��
        			tdCell = outputUrineTable(headerTable, ent, "�A���f�̎�f�ɂ���");

        		}else if(HealthConstantsUseable.HEL_CODE_HEARING.equals(kensin)){ // ���͉�
        			tdCell = outputHearingTable(headerTable, ent, "���͌��f�̎�f�ɂ���");

        		}

           		for(int i = 0; i < tdCell.length; i++){
           			if(tdCell[i] == null){
           				break;
           			}

           			try{
           	   			headerTable.addCell(tdCell[i]);
           			}catch(Exception e){
           				System.out.println(i);
           				e.printStackTrace();
           			}
           		}

               	document.add(headerTable);

            	document.newPage();

        	}


        } catch (Exception e) {
			log.error("��O����",e);
			throw new TnaviPrintException(e);
        }
	}

	/**
	 * �󔒃Z�����쐬����
	 * @param colspan
	 * @param rowspan
	 * @param fontData
	 * @return
	 * @throws DocumentException
	 */
	private Cell createSpaceColumn(int colspan, int rowspan, Font fontData)  throws DocumentException{

   		// �󔒍s
		Cell cell = setCellValue(" ", fontData);
		cell = setBorderWidth(cell, 0f, 0f, 0f, 0f);
		cell.setColspan(colspan);
		cell.setRowspan(rowspan);

		return cell;

	}

	/**
	 * �󔒃Z�����쐬����
	 * @param colspan
	 * @param fontData
	 * @return
	 * @throws DocumentException
	 */
	private Cell createSpaceColumn(int colspan,  Font fontData)  throws DocumentException{
		return createSpaceColumn(colspan, 1, fontData);
	}


	/**
	 * �Z���ɒl�ݒ肷��B
	 * @param val
	 * @param fontData
	 * @param colspan
	 * @param rowspan
	 * @param horizontal
	 * @param vertical
	 * @return
	 * @throws DocumentException
	 */
	private Cell setValue(String val, Font fontData, int colspan, int rowspan, int horizontal, int vertical)  throws DocumentException{
		Cell cell = setCellValue(val, fontData);
		cell = setBorderWidth(cell, 0f, 0f, 0f, 0f);
		cell.setColspan(colspan);
		cell.setRowspan(rowspan);

		if(horizontal >= 0){
			cell.setHorizontalAlignment(horizontal);
		}

		if(vertical >= 0){
			cell.setVerticalAlignment(vertical);
		}
		return cell;

	}

	/**
	 * �Z���ɒl�ݒ肷��B
	 * @param val
	 * @param fontData
	 * @param colspan
	 * @return
	 * @throws DocumentException
	 */
	private Cell setValue(String val,  Font fontData, int colspan)  throws DocumentException{
		return setValue(val, fontData, colspan, 1, -1, -1);
	}

	/**
	 * �Z���ɒl�ݒ肷��B
	 * @param val
	 * @param fontData
	 * @param colspan
	 * @param horizontal
	 * @param vertical
	 * @return
	 * @throws DocumentException
	 */
	private Cell setValue(String val, Font fontData, int colspan, int horizontal, int vertical)  throws DocumentException{
		return setValue(val, fontData, colspan, 1, horizontal, vertical);
	}



	/**
	 * ���ʃw�b�_�[���쐬
	 * @param headerTable
	 * @param tdCell
	 * @param ent
	 * @param title
	 * @return
	 * @throws DocumentException
	 */
	private int outputCommonHeaderTable(Table headerTable, Cell[] tdCell, Print10104000Entity ent, String title) throws DocumentException{

		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

       	//�e�[�u�����ݒ�
       	float tableWidth[] = {3f,3f,3f,3f,3f,3f,3f,3f,3f,3f,
       			               3f,3f,3f,3f,3f,3f,3f,3f,3f,3f,
       			               3f,3f,3f,3f,3f,3f,3f,3f,3f,3f,
       			               3f,3f,3f,3f,3f,3f,3f};
       	headerTable.setWidths(tableWidth);

       	//�e�[�u���̃f�t�H���g�̕\���ʒu�i���j�ݒ�
       	headerTable.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
       	//�e�[�u���̃f�t�H���g�̕\���ʒu�i�c�j�ݒ�
       	headerTable.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);
       	//�e�[�u���̗]���ݒ�
       	headerTable.setPadding(1.5f);
       	//�e�[�u���̃Z���Ԃ̊Ԋu�ݒ�
       	headerTable.setSpacing(0);
       	//�e�[�u���̐��̐F�ݒ�
//       	headerTable.setBorderColor(new Color(255, 255, 255));
       	headerTable.setBorderColor(new Color(0, 0, 0));
       	// �e�[�u���I�t�Z�b�g
       	headerTable.setOffset(150f);
       	//�e�[�u���r���̑���
       	headerTable.setBorderWidth(0);

       	int idx = 0;
       	StringBuilder value = new StringBuilder();

       	for(int i = 0; i < 1 ;i++){
       		// �󔒍s
       		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
       		idx++;
       	}


   		// ���s��
        DateFormatUtility dateFormatUtility = new DateFormatUtility(ent.getCls_user());
        dateFormatUtility.setZeroToSpace(true);
   		value.setLength(0);
   		value.append(dateFormatUtility.formatDate("YYYY�NMM��DD��", 1, DateUtility.getSystemDate()));
   		tdCell[idx] = setValue(value.toString() , d_font_msm12, 37, Element.ALIGN_RIGHT, Element.ALIGN_MIDDLE);
   		idx++;


   		// �ی��
   		tdCell[idx] = setValue("�ی��", d_font_msm12, 3);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("�l", d_font_msm12, 9, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;


   		// �w�N�A�g�A�ԍ�
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;


   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int celSpanNum = 8;
   		int addCelSpanNum = 0;
   		if(value.length() > 10){
   			if((value.length()-10) <= 4){
   				addCelSpanNum = (value.length()-10);
   			}else{
   				addCelSpanNum = 4;
   			}
   		}
   		celSpanNum +=  addCelSpanNum;
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(21, d_font_msm12);
   		idx++;

   		// �Z�����^�C�g��
   		tdCell[idx] = setValue("�Z����", d_font_msm12, 3);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getPrincipalName());
   		depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 13, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = setValue(title, d_font_msm18, 37, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

       	return idx;
	}

	/**
	 * �w�Z����ݒ肷��B
	 * @param schoolName
	 * @param tdCell
	 * @param index
	 * @return
	 * @throws DocumentException
	 */
	private int addSchoolInfo(String schoolName, Cell[] tdCell, int index) throws DocumentException{

		int idx = index;
		StringBuilder value = new StringBuilder();
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

   		// �w�Z���^�C�g��
   		tdCell[idx] = setValue("�w�Z��", d_font_msm12, 3);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �w�Z��
   		value.setLength(0);
   		value.append(schoolName);
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 13, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

		return idx;
	}


	/**
	 *
	 * ���Ȍ��f�o��.
	 *
	 * @param print04111000FormBean Print04111000FormBean
	 * @throws DocumentException
	 * @since 1.0
	 */
	private Cell[] outputMedicineTable(Table headerTable, Print10104000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

      	StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 34){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 8 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("�@����f", d_font_msm12, 4, Element.ALIGN_CENTER, Element.ALIGN_LEFT);
   		idx++;

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 28, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// ����f
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�f �f �� ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = setValue("�E�ُ�Ȃ�", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		tdCell[idx] = setValue("�E�v�ώ@", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		tdCell[idx] = setValue("�E�v���", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(6, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�N�@�@���@�@��", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;

   		return tdCell;

	}



	/**
	 *
	 * ���ȉȌ��f�o��.
	 *
	 * @param print04111000FormBean Print04111000FormBean
	 * @throws DocumentException
	 * @since 1.0
	 */
	private Cell[] outputDentistryTable(Table headerTable, Print10104000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

      	StringBuilder value = new StringBuilder();

       	int maxCells = 300;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 34){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 5 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("�@����f", d_font_msm12, 4, Element.ALIGN_CENTER, Element.ALIGN_LEFT);
   		idx++;

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 28, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// ����f
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12 );
   		idx++;

   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�{", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("���@��", d_font_msm12, 12 ,Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("���@��:", d_font_msm12, 4,Element. ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(13, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue(" ", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�C", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�E���ݎ�", d_font_msm12, 6);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("(��@�_�@)", d_font_msm12, 5);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(13, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�E", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(" �E�����@�����u��", d_font_msm12, 8);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("C", d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(13, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�@", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(" �@�@�@�@���u��", d_font_msm12, 8);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(13, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(" �E�r����(�i�v��)", d_font_msm12, 8);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(13, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		for(int i = 0 ;i < 4; i++){
   	   		tdCell[idx] = setValue("1", d_font_msm12, 1);
   			if(i == 0){
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   			}else{
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}
   	   		idx++;
   		}
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(" �E�v���ӓ���", d_font_msm12, 8);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�~", d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(13, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		for(int i = 0 ;i < 4; i++){
   	   		tdCell[idx] = setValue("2", d_font_msm12, 1);
   			if(i == 0){
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   			}else{
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}
   	   		idx++;
   		}
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(" �E�v�ώ@��", d_font_msm12, 8);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("CO", d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(13, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		for(int i = 0 ;i < 4; i++){
   	   		tdCell[idx] = setValue("3", d_font_msm12, 1);
   			if(i == 0){
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   			}else{
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}
   	   		idx++;
   		}
   		tdCell[idx] = createSpaceColumn(12, d_font_msm12);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(20, d_font_msm12);
   		idx++;


   		String[] numval = {"8","7","6","5","4","3","2","1","1","2","3","4","5","6","7","8"};

   		String[] spelval = {"E","D","C","B","A","A","B","C","D","E"};

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		for(int i = 0 ;i < 16; i++){
   	   		tdCell[idx] = setValue(numval[i], d_font_msm12, 1, Element.ALIGN_CENTER, Element.ALIGN_TOP);
   	   		tdCell[idx].setRowspan(2);
   			if(i == 0){
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   			}else{
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}
   	   		idx++;
   		}
   		tdCell[idx] = createSpaceColumn(20, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�@", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.0f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.0f, 0.0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�E", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.0f, 0f);
   		tdCell[idx].setRowspan(4);
   		idx++;
   		for(int i = 0 ;i < 10; i++){
   	   		tdCell[idx] = setValue(spelval[i], d_font_msm12, 1, Element.ALIGN_CENTER, Element.ALIGN_TOP);
   	   		tdCell[idx].setRowspan(2);
   			if(i == 0){
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}else{
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}
   	   		idx++;
   		}
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0f, 0f, 0f);
   		tdCell[idx].setRowspan(4);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�@", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;

   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		idx++;
   		tdCell[idx] = createSpaceColumn(4, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�N", d_font_msm12, 4, Element.ALIGN_LEFT, Element.ALIGN_BOTTOM);
		tdCell[idx].setBorderWidthBottom(1f);
		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 2, Element.ALIGN_LEFT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 3, Element.ALIGN_RIGHT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�@", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		idx++;
   		for(int i = 0 ;i < 10; i++){
   	   		tdCell[idx] = setValue(spelval[i], d_font_msm12, 1, Element.ALIGN_CENTER, Element.ALIGN_TOP);
   	   		tdCell[idx].setRowspan(2);
   			if(i == 0){
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}else{
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   			}
   	   		idx++;
   		}
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		idx++;
   		tdCell[idx] = setValue(" ", d_font_msm12, 1);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 5, Element.ALIGN_LEFT, Element.ALIGN_MIDDLE);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(12, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		for(int i = 0 ;i < 16; i++){
   	   		tdCell[idx] = setValue(numval[i], d_font_msm12, 1, Element.ALIGN_CENTER, Element.ALIGN_TOP);
   	   		tdCell[idx].setRowspan(2);
   			if(i == 0){
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0.5f);
   			}else{
   	   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   			}
   	   		idx++;
   		}

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 5, Element.ALIGN_LEFT, Element.ALIGN_MIDDLE);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(11, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1, Element.ALIGN_CENTER, Element.ALIGN_MIDDLE);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		tdCell[idx].setRowspan(2);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;

       	return tdCell;
	}

	/**
	 * ���́E��Ȍ��f
	 * @param ent
	 * @param title
	 * @throws DocumentException
	 */
	private Cell[] outputEyesightTable(Table headerTable, Print10104000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

		StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 34){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 8 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("�@����f", d_font_msm12, 4, Element.ALIGN_CENTER, Element.ALIGN_LEFT);
   		idx++;

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 28, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// ����f
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("���@��", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("���F", d_font_msm12, 5, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(�@�@)", d_font_msm12, 5, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("�E�F", d_font_msm12, 5, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(�@�@)", d_font_msm12, 5, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�f �f �� ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = setValue("�E�ُ�Ȃ�", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		tdCell[idx] = setValue("�E�v�ώ@", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		tdCell[idx] = setValue("�E�v���", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;

		return tdCell;
	}

	/**
	 * �A���f�o��
	 * @param ent
	 * @param title
	 * @throws DocumentException
	 */
	private Cell[] outputUrineTable(Table headerTable, Print10104000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

      	StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 34){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 8 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("�@����f", d_font_msm12, 4, Element.ALIGN_CENTER, Element.ALIGN_LEFT);
   		idx++;

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 28, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// ����f
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�`�@��", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthLeft(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		tdCell[idx].setBorderWidthTop(1f);
   		idx++;

   		tdCell[idx] = setValue("��", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		tdCell[idx].setBorderWidthTop(1f);
   		idx++;

   		tdCell[idx] = setValue("���@��", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		tdCell[idx].setBorderWidthTop(1f);
   		idx++;

   		tdCell[idx] = setValue("���̑�", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		tdCell[idx].setBorderWidthTop(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;

   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = createSpaceColumn(8, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthLeft(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(8, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(8, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(8, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		tdCell[idx].setBorderWidthRight(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;

		return tdCell;

	}

	/**
	 * ���͌��f
	 * @param ent
	 * @param title
	 * @throws DocumentException
	 */
	private Cell[] outputHearingTable(Table headerTable, Print10104000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

		StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 34){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 8 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("�@����f", d_font_msm12, 4, Element.ALIGN_CENTER, Element.ALIGN_LEFT);
   		idx++;

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 28, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// ����f
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("����", d_font_msm12, 6, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("���F", d_font_msm12, 6, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(�@ �@)", d_font_msm12, 6, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("�E�F", d_font_msm12, 6, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(�@ �@)", d_font_msm12, 6, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�f �f �� ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = setValue("�E�ُ�Ȃ�", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		tdCell[idx] = setValue("�E�v�ώ@", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		tdCell[idx] = setValue("�E�v���", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 35, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;

		return tdCell;
	}

	/**
	 * @return printList
	 */
	public List<Print10104000Entity> getPrintList() {
		return printList;
	}


	/**
	 * @param printList �Z�b�g���� printList
	 */
	public void setPrintList(List<Print10104000Entity> printList) {
		this.printList = printList;
	}


	/**
	 * @return note1
	 */
	public String getNote1() {
		return note1;
	}


	/**
	 * @param note1 �Z�b�g���� note1
	 */
	public void setNote1(String note1) {
		this.note1 = note1;
	}


	/**
	 * @return note2
	 */
	public String getNote2() {
		return note2;
	}


	/**
	 * @param note2 �Z�b�g���� note2
	 */
	public void setNote2(String note2) {
		this.note2 = note2;
	}


	/**
	 * @return kensin
	 */
	public String getKensin() {
		return kensin;
	}


	/**
	 * @param kensin �Z�b�g���� kensin
	 */
	public void setKensin(String kensin) {
		this.kensin = kensin;
	}




}
