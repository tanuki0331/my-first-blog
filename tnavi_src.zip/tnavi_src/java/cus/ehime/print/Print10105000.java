package jp.co.systemd.tnavi.cus.ehime.print;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lowagie.text.Cell;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Table;

import jp.co.systemd.tnavi.common.exception.TnaviPrintException;
import jp.co.systemd.tnavi.common.print.AbstractPdfManager;
import jp.co.systemd.tnavi.common.print.PrintConstantsUseable;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.common.utility.PDFFontSizeUtility;
import jp.co.systemd.tnavi.cus.ehime.constants.HealthConstantsUseable;
import jp.co.systemd.tnavi.cus.ehime.constants.HelConstants;
import jp.co.systemd.tnavi.cus.ehime.db.entity.Print10105000Entity;

/**
 * �����������
 * �y��ʁz���f���ʂ̒ʒm�Ɗ�����Action�N���X.
 *
 * <B>Create</B> 2011.12.16 BY yamamoto<BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print10105000 extends AbstractPdfManager implements PrintConstantsUseable {

	/**log4j*/
	private final Log log = LogFactory.getLog(Print10105000.class);

	/**�����R�[�h*/
	private String user = HelConstants.DEFALUT_VALUE;

	/**����f�f�[�^���X�g*/
	private List<Print10105000Entity> printList = new ArrayList<Print10105000Entity>();

	/** ����1 */
	private String note1 = HelConstants.DEFALUT_VALUE;

	/** ����2 */
	private String note2 = HelConstants.DEFALUT_VALUE;

	/** ���f�敪 */
	private String kensin = HelConstants.DEFALUT_VALUE;

	public void setUser(String user) {
		this.user = user;
	}
	public void setPrintList(List<Print10105000Entity> printList) {
		this.printList = printList;
	}

	public void setNote1(String note1) {
		this.note1 = note1;
	}

	public void setNote2(String note2) {
		this.note2 = note2;
	}

	public void setKensin(String kensin) {
		this.kensin = kensin;
	}

	@Override
	protected void doPrint() throws TnaviPrintException {

        try {

        	for(Print10105000Entity ent : printList){

            	Table headerTable = null;
        		headerTable = new Table(37);
              	headerTable.setWidth(100);
              	Cell[] tdCell = null;

        		// �w�b�_�o��
        		if(HealthConstantsUseable.HEL_NOTICE_CODE_MEDICINE.equals(kensin)){ // ����
        			tdCell = outputMedicineTable(headerTable, ent, "���Ȍ��f���ʂ̂��m�点�y�ю�f�̂�������");

        		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_DENTISTRY.equals(kensin)){ // ���ȉ�
        			tdCell = outputDentistryTable(headerTable, ent, "���Ȍ��f���ʂ̂��m�点�y�ю�f�̂�������");

        		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_EYESIGHT.equals(kensin)){ // ���͉�
        			tdCell = outputEyesightTable(headerTable, ent, "���́E��Ȍ��f���ʂ̂��m�点�y�ю�f�̂�������");

        		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_URINE.equals(kensin)){ // �A��
        			tdCell = outputUrineTable(headerTable, ent, "�A�������ʂ̂��m�点�y�ю�f�̂�������");

        		}else if(HealthConstantsUseable.HEL_NOTICE_CODE_HEARING.equals(kensin)){ // ����
        			tdCell = outputHearingTable(headerTable, ent, "���͌��f���ʂ̂��m�点�y�ю�f�̂�������");
        		}

           		for(int i = 0; i < tdCell.length; i++){
           			if(tdCell[i] == null){
           				break;
           			}

           			try{
           	   			headerTable.addCell(tdCell[i]);
           			}catch(Exception e){
           				System.out.println(i);
           				e.printStackTrace();
           			}
           		}

               	document.add(headerTable);

            	document.newPage();

        	}


        } catch (Exception e) {
			log.error("��O����",e);
			throw new TnaviPrintException(e);
        }
	}

	/**
	 * �󔒃Z�����쐬����
	 * @param colspan
	 * @param rowspan
	 * @param fontData
	 * @return
	 * @throws DocumentException
	 */
	private Cell createSpaceColumn(int colspan, int rowspan, Font fontData)  throws DocumentException{

   		// �󔒍s
		Cell cell = setCellValue(" ", fontData);
		cell = setBorderWidth(cell, 0f, 0f, 0f, 0f);
		cell.setColspan(colspan);
		cell.setRowspan(rowspan);

		return cell;

	}

	/**
	 * �󔒃Z�����쐬����
	 * @param colspan
	 * @param fontData
	 * @return
	 * @throws DocumentException
	 */
	private Cell createSpaceColumn(int colspan,  Font fontData)  throws DocumentException{
		return createSpaceColumn(colspan, 1, fontData);
	}


	/**
	 * �Z���ɒl�ݒ肷��B
	 * @param val
	 * @param fontData
	 * @param colspan
	 * @param rowspan
	 * @param horizontal
	 * @param vertical
	 * @return
	 * @throws DocumentException
	 */
	private Cell setValue(String val, Font fontData, int colspan, int rowspan, int horizontal, int vertical)  throws DocumentException{
		Cell cell = setCellValue(val, fontData);
		cell = setBorderWidth(cell, 0f, 0f, 0f, 0f);
		cell.setColspan(colspan);
		cell.setRowspan(rowspan);

		if(horizontal >= 0){
			cell.setHorizontalAlignment(horizontal);
		}

		if(vertical >= 0){
			cell.setVerticalAlignment(vertical);
		}
		return cell;

	}

	/**
	 * �Z���ɒl�ݒ肷��B
	 * @param val
	 * @param fontData
	 * @param colspan
	 * @return
	 * @throws DocumentException
	 */
	private Cell setValue(String val,  Font fontData, int colspan)  throws DocumentException{
		return setValue(val, fontData, colspan, 1, -1, -1);
	}

	/**
	 * �Z���ɒl�ݒ肷��B
	 * @param val
	 * @param fontData
	 * @param colspan
	 * @param horizontal
	 * @param vertical
	 * @return
	 * @throws DocumentException
	 */
	private Cell setValue(String val, Font fontData, int colspan, int horizontal, int vertical)  throws DocumentException{
		return setValue(val, fontData, colspan, 1, horizontal, vertical);
	}



	/**
	 * ���ʃw�b�_�[���쐬
	 * @param headerTable
	 * @param tdCell
	 * @param ent
	 * @param title
	 * @return
	 * @throws DocumentException
	 */
	private int outputCommonHeaderTable(Table headerTable, Cell[] tdCell, Print10105000Entity ent, String title) throws DocumentException{

		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

       	//�e�[�u�����ݒ�
       	float tableWidth[] = {3f,3f,3f,3f,3f,3f,3f,3f,3f,3f,
       			               3f,3f,3f,3f,3f,3f,3f,3f,3f,3f,
       			               3f,3f,3f,3f,3f,3f,3f,3f,3f,3f,
       			               3f,3f,3f,3f,3f,3f,3f};
       	headerTable.setWidths(tableWidth);

       	//�e�[�u���̃f�t�H���g�̕\���ʒu�i���j�ݒ�
       	headerTable.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
       	//�e�[�u���̃f�t�H���g�̕\���ʒu�i�c�j�ݒ�
       	headerTable.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);
       	//�e�[�u���̗]���ݒ�
       	headerTable.setPadding(1.5f);
       	//�e�[�u���̃Z���Ԃ̊Ԋu�ݒ�
       	headerTable.setSpacing(0);
       	//�e�[�u���̐��̐F�ݒ�
//       	headerTable.setBorderColor(new Color(255, 255, 255));
       	headerTable.setBorderColor(new Color(0, 0, 0));
       	// �e�[�u���I�t�Z�b�g
       	headerTable.setOffset(150f);
       	//�e�[�u���r���̑���
       	headerTable.setBorderWidth(0);

       	int idx = 0;
       	StringBuilder value = new StringBuilder();

       	for(int i = 0; i < 1 ;i++){
       		// �󔒍s
       		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
       		idx++;
       	}


   		// ���s��
        DateFormatUtility dateFormatUtility = new DateFormatUtility(user);
        dateFormatUtility.setZeroToSpace(true);
   		value.setLength(0);
   		value.append(dateFormatUtility.formatDate("YYYY�NMM��DD��", 1, DateUtility.getSystemDate()));
   		tdCell[idx] = setValue(value.toString() , d_font_msm12, 37, Element.ALIGN_RIGHT, Element.ALIGN_MIDDLE);
   		idx++;


   		// �ی��
   		tdCell[idx] = setValue("�ی��", d_font_msm12, 3);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("�l", d_font_msm12, 9, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;


   		// �w�N�A�g�A�ԍ�
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;


   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int celSpanNum = 8;
   		int addCelSpanNum = 0;
   		if(value.length() > 10){
   			if((value.length()-10) <= 4){
   				addCelSpanNum = (value.length()-10);
   			}else{
   				addCelSpanNum = 4;
   			}
   		}
   		celSpanNum +=  addCelSpanNum;
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(21, d_font_msm12);
   		idx++;

   		// �Z�����^�C�g��
   		tdCell[idx] = setValue("�Z����", d_font_msm12, 3);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getPrincipalName());
   		depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 13, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = setValue(title, d_font_msm18, 37, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


       	return idx;
	}

	/**
	 * �w�Z����ݒ肷��B
	 * @param schoolName
	 * @param tdCell
	 * @param index
	 * @return
	 * @throws DocumentException
	 */
	private int addSchoolInfo(String schoolName, Cell[] tdCell, int index) throws DocumentException{

		int idx = index;
		StringBuilder value = new StringBuilder();
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

   		// �w�Z���^�C�g��
   		tdCell[idx] = setValue("�w�Z��", d_font_msm12, 3);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �w�Z��
   		value.setLength(0);
   		value.append(schoolName);
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 13, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

		return idx;
	}


	/**
	 *
	 * ���Ȍ��f�o��.
	 *
	 * @param print04111000FormBean Print04111000FormBean
	 * @throws DocumentException
	 * @since 1.0
	 */
	private Cell[] outputMedicineTable(Table headerTable, Print10105000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

      	StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 37, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 38){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 6 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����f���ʁ�", d_font_msm12, 6, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(29, 1, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(ent.getMedicineItem(), d_font_msm16, 33, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, 1, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(10, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�@�f�@�@��@�@���@�@��", d_font_msm18, 17, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(10, 1, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�f �f �� ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(24, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 31, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		return tdCell;

	}



	/**
	 *
	 * ���ȉȌ��f�o��.
	 *
	 * @param print04111000FormBean Print04111000FormBean
	 * @throws DocumentException
	 * @since 1.0
	 */
	private Cell[] outputDentistryTable(Table headerTable, Print10105000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

      	StringBuilder value = new StringBuilder();

       	int maxCells = 300;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 37, 5, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 38){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 5 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(1, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����f���ʁ�", d_font_msm12, 6, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(30, 1, d_font_msm12);
   		idx++;


   		tdCell[idx] = setValue("���@���@���@�e", d_font_msm12, 9, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("���@�@�@�@�@�@��", d_font_msm12, 23, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�� �f �� ��", d_font_msm12, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;

   		tdCell[idx] = setValue("�����̗L��", d_font_msm11, 9);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�ނ����͕a�C�ł��B���R�Ɏ��邱�ƂȂ��i�s���܂��B", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue(ent.getDentistryResult1(), d_font_msm11, 4, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�{", d_font_msm11, 1);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;

   		tdCell[idx] = setValue("�����сE���ݍ��킹", d_font_msm11, 9);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�����Ⴍ�E�ېH�E�������ɖ�肪�N���鎖������܂��B", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue(ent.getDentistryResult2(), d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;


   		tdCell[idx] = setValue("�{�֐߂̏��", d_font_msm11, 9);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("�����̊֐߂��ɂ��Ă����Â炢�B�������͒ɂ��͂Ȃ����O������", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue(ent.getDentistryResult3(), d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setRowspan(2);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;


   		tdCell[idx] = setValue("�w�Q�{���x���������Ȃ����̏Ǐ�ł��B", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;


   		tdCell[idx] = setValue("���C�̕t��", d_font_msm11, 9);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("���C���t�����A�ނ����⎕�����̌����ɂȂ�܂��B", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue(ent.getDentistryResult4(), d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;


   		tdCell[idx] = setValue("�����̏��", d_font_msm11, 9);
   		tdCell[idx].setRowspan(3);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0f);
   		idx++;
   		tdCell[idx] = setValue("����(������)�����ǂ��N�����a�C�B���������Ēɂ݁A�o����", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;
   		tdCell[idx] = setValue(ent.getDentistryResult5(), d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setRowspan(3);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0f);
   		idx++;


   		tdCell[idx] = setValue("�N������������܂��B�����Ă����Ǝ������ɂȂ�A���^���Ĕ^��", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;


   		tdCell[idx] = setValue("�o�đS�g�Ɉ����e����^���܂��B", d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0f, 0.5f, 0f, 0f);
   		idx++;


   		tdCell[idx] = setValue("���̑��̎����a�y�шُ�", d_font_msm11, 9);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0.5f);
   		idx++;
   		String item = ent.getDentistryItem();

   		tdCell[idx] = setValue(item, d_font_msm11, 23);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		if(item != null){
   			item = "�v����";
   		}else{
   			item = "";
   		}
   		tdCell[idx] = setValue(item, d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;


   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 37, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		String[] rrowTitles = {"�����̗L��","�����сE���ݍ��킹","�{�֐߂̏��","���C�̕t��","�����̏��","���̑��̎����a�y�шُ�"};
   		float bottom = 0f;
   		for(int i = 0 ; i < rrowTitles.length ; i++){

   			if(i >= (rrowTitles.length-1)){
   				bottom = 0.5f;
   			}

   	   		tdCell[idx] = setValue(rrowTitles[i], d_font_msm11, 9);
   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, bottom);
   	   		idx++;
   	   		tdCell[idx] = setValue("1�D���Í�", d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, bottom);
   	   		idx++;
   	   		tdCell[idx] = setValue("2�D�o�ߊώ@", d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, bottom);
   	   		idx++;
   	   		tdCell[idx] = setValue("3�D�o�ߊώ@�i�@�@�@�@�@�@�@�@�@�@�@�@�j", d_font_msm11, 18, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   	   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, bottom);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(1, 1, d_font_msm11);
   		idx++;
   		tdCell[idx] = setValue("���@�@��", d_font_msm12, 5, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(30, 1, d_font_msm11);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, 1, d_font_msm11);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 22, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(15, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 21, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 31, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

       	return tdCell;
	}

	/**
	 * ���́E��Ȍ��f
	 * @param ent
	 * @param title
	 * @throws DocumentException
	 */
	private Cell[] outputEyesightTable(Table headerTable, Print10105000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

		StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 37, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;


   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 38){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 6 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END



   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����f���ʁ�", d_font_msm12, 6, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(29, 1, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("���@��", d_font_msm12, 8, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("���F", d_font_msm12, 2, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getEyeLeft1(), d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getEyeLeft2(), d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(")", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("�E�F", d_font_msm12, 2, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getEyeRight1(), d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getEyeRight2(), d_font_msm12, 3, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(")", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(ent.getEyesightItem(), d_font_msm16, 31, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, 1, d_font_msm12);
   		idx++;



   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 37, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�f�f����", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = setValue("", d_font_msm12, 24, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 31, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

		return tdCell;
	}

	/**
	 * �A���f�o��
	 * @param ent
	 * @param title
	 * @throws DocumentException
	 */
	private Cell[] outputUrineTable(Table headerTable, Print10105000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

      	StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = createSpaceColumn(1, 5, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 36, 5, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 38){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 6 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����f���ʁ�", d_font_msm12, 6, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(28, 1, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�`�@��", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0.5f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		tdCell[idx] = setValue("���@��", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		tdCell[idx] = setValue("���̑�", d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;

   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue(ent.getUrineItem1(), d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0.5f, 0.5f);
   		idx++;
   		tdCell[idx] = setValue(ent.getUrineItem2(), d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		tdCell[idx] = setValue(ent.getUrineItem3(), d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		tdCell[idx] = setValue(ent.getUrineItem4(), d_font_msm12, 8, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		tdCell[idx] = setBorderWidth(tdCell[idx], 0.5f, 0.5f, 0f, 0.5f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;




   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 37, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;





   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�f�f����", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = setValue("", d_font_msm12, 24, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 31, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

		return tdCell;

	}
	/**
	 * ���͌��f
	 * @param ent
	 * @param title
	 * @throws DocumentException
	 */
	private Cell[] outputHearingTable(Table headerTable, Print10105000Entity ent, String title) throws DocumentException{
		PDFFontSizeUtility PDFFontSizeUtility = new PDFFontSizeUtility();

		StringBuilder value = new StringBuilder();

       	int maxCells = 200;
       	int idx = 0;
       	Cell[] tdCell = new Cell[maxCells];

       	// ���ʃw�b�_�[�쐬
       	idx = outputCommonHeaderTable(headerTable, tdCell, ent, title);


   		// ����1 34����
   		StringBuilder comment = new StringBuilder();
   		comment.setLength(0);
   		comment.append(note1);


   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 37, 20, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;


   		String tmp = note1;
        int rowCnt = 0;
        int nowRowCnt = 1;
        while (tmp.length() > 0) {
        	tmp = tmp.substring(1, tmp.length());
        	rowCnt++;
        	if(rowCnt >= 38){
        		nowRowCnt++;
        		rowCnt = 0;
        	}
        }

        nowRowCnt = 6 - nowRowCnt;

   		for(int len = 0 ; len < nowRowCnt; len++){
   	   		// �󔒍s
   	   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   	   		idx++;
   		}
   		// ����1 34���� END



   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, 1, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����f���ʁ�", d_font_msm12, 6, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(29, 1, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("���@��", d_font_msm12, 6, Element.ALIGN_LEFT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("���F", d_font_msm12, 2, Element.ALIGN_LEFT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getHearingLeft1(), d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getHearingLeft2(), d_font_msm12, 3, Element.ALIGN_RIGHT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(")", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = createSpaceColumn(1, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("�E�F", d_font_msm12, 2, Element.ALIGN_LEFT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getHearingRight1(), d_font_msm11, 5, Element.ALIGN_CENTER, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("(", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(ent.getHearingRight2(), d_font_msm12, 3, Element.ALIGN_RIGHT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue(")", d_font_msm12, 1, Element.ALIGN_RIGHT, Element.ALIGN_BOTTOM);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 1, d_font_msm12);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, 5, d_font_msm12);
   		idx++;

   		// �؎��
   		Font font = new Font(mainFont, 12);
   		font.setColor(COLOR_GRAY25);
   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;

   		tdCell[idx] = setValue("���@��@�Ɓ@��@���@��", d_font_msm12, 13, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		tdCell[idx] = setValue("----------------------------", font, 12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		/***************************************
   		 * �ڍ�
   		 ***************************************/

   		// ����f
   		tdCell[idx] = setValue("��@�f�@��@���@��", d_font_msm18, 37, Element.ALIGN_CENTER, Element.ALIGN_CENTER);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;

   		// �w�Z
   		idx = addSchoolInfo(ent.getSchoolName(), tdCell, idx);
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(9, d_font_msm12);
   		idx++;

   		// �w�N�A�g�A��
   		value.setLength(0);
   		value.append(ent.getGlade())
   		     .append("�N")
   		     .append("").append(ent.getSt_class()).append("�g")
   		     .append("").append(ent.getNumber()).append("��")
   		     ;
   		tdCell[idx] = setValue(value.toString(), d_font_msm12, 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(25, d_font_msm12);
   		idx++;

   		// ����
   		value.setLength(0);
   		value.append(ent.getStucodeName());
   		int depFontSize = PDFFontSizeUtility.fontSizeAjust(value.toString(), 12, new int[]{31,26,23,21,19,17,16,15}, new int[]{5,6,7,8,9,10,11,12});
   		tdCell[idx] = setValue(value.toString(), new Font(mainFont,depFontSize), 12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�f�f����", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = setValue("", d_font_msm12, 24, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(5, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

   		tdCell[idx] = setValue("�� �@ �@ ��", d_font_msm12, 5);
   		idx++;

   		tdCell[idx] = createSpaceColumn(27, d_font_msm12);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(2, d_font_msm12);
   		idx++;



   		// �����̃��C���쐬
   		for(int i = 0 ; i < 4 ; i++){

   	   		tdCell[idx] = createSpaceColumn(8, 2 , d_font_msm12);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(27, 2, d_font_msm12);
   	   		tdCell[idx].setBorderWidthBottom(1f);
   	   		idx++;

   	   		tdCell[idx] = createSpaceColumn(2, 2, d_font_msm12);
   	   		idx++;
   		}

   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("�����@�@�N�@�@���@�@��", d_font_msm12, 11, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		idx++;
   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��Ë@�֖�", d_font_msm12, 20, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		tdCell[idx] = createSpaceColumn(17, d_font_msm12);
   		idx++;
   		tdCell[idx] = setValue("��@�t�@��", d_font_msm12, 19, Element.ALIGN_LEFT, Element.ALIGN_CENTER);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;
   		tdCell[idx] = setValue("��", d_font_msm12, 1);
   		tdCell[idx].setBorderWidthBottom(1f);
   		idx++;


   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(37, d_font_msm12);
   		idx++;


   		// ����2 34����
   		// �󔒍s
   		tdCell[idx] = createSpaceColumn(3, 20, d_font_msm12);
   		idx++;

   		comment.setLength(0);
   		comment.append(note2);

   		tdCell[idx] = setValue(comment.toString(), d_font_msm14, 31, 2, Element.ALIGN_TOP, Element.ALIGN_LEFT);
   		idx++;

   		tdCell[idx] = createSpaceColumn(3, d_font_msm12);
   		idx++;

		return tdCell;
	}
}
