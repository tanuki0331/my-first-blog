package jp.co.systemd.tnavi.cus.kannami.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kannami.db.service.Detail31960000Service;
import jp.co.systemd.tnavi.cus.kannami.db.service.List31960000Service;
import jp.co.systemd.tnavi.cus.kannami.formbean.Detail31960000FormBean;
import jp.co.systemd.tnavi.cus.kannami.formbean.List31960000FormBean;


/**
 * <PRE>
 *  ���ђʒm�\����(���쒬 ���w�Z���ʎx���w��) ���� Action.
 * </PRE>
 *
 * <B>Create</B> 2017.07.05 BY yamazaki <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Detail31960000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Detail31960000Action.class);

	/** ���O�ɏo�͂��邽�߂̖��O */
	private static final String actionName = "�y��ʁz���ђʒm�\����(���쒬 ���w�Z���ʎx���w��) ����";

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return false;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request, HttpServletResponse response,
							SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info(actionName + " START");

		// ------------------------------------------------------------------------------------------
		// ���N�G�X�g��formbean�ɃR�s�[����`��FormBean���쐬
		// ------------------------------------------------------------------------------------------
		List31960000FormBean listFormBean = (List31960000FormBean)copyRequestParamToFormBean(request, new List31960000FormBean());

		// ------------------------------------------------------------------------------------------
		// �ꗗ�T�[�r�X�N���X�̐���
		// ------------------------------------------------------------------------------------------
		List31960000Service listService = new List31960000Service();
		listService.execute(request, sessionBean, listFormBean);

		sessionBean.getKannamiSessionBean().setList31960000FormBean(listService.getListFormBean());

		// ------------------------------------------------------------------------------------------
		// ���N�G�X�g��formbean�ɃR�s�[����`��FormBean���쐬
		// ------------------------------------------------------------------------------------------
		Detail31960000FormBean detailFormBean = (Detail31960000FormBean)copyRequestParamToFormBean(request, new Detail31960000FormBean());

		// ------------------------------------------------------------------------------------------
		// �T�[�r�X�N���X�̐���
		// ------------------------------------------------------------------------------------------
		Detail31960000Service service = new Detail31960000Service(request, sessionBean, detailFormBean, listFormBean);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g����B
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", service.getDetailFormBean());

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info(actionName + " END");

		return null;
	}

}
