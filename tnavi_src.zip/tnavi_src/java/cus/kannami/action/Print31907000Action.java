package jp.co.systemd.tnavi.cus.kannami.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kannami.db.service.Print31907000Service;
import jp.co.systemd.tnavi.cus.kannami.print.Print31907000;

/**
 * ���ђʒm�\���(���쒬 ���w�Z) ��� Action.
 *
 * <B>Create</B> 2016.07.25 BY AIVICK <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31907000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print31907000Action.class);

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("���ђʒm�\���(���쒬 ���w�Z) START");

		//-----���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("���ђʒm�\");

		try{

			//���[�t�H�[���t�@�C��
			String formFileName = "cus/kannami/form31907000.cfx";

			Print31907000Service service = new Print31907000Service();
			service.execute(request, sessionBean);

			Print31907000 print31907000 = new Print31907000();
			print31907000.setPrintFormBean(service.getPrintFormBean());
			print31907000.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print31907000.execute(formFileName);

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("���ђʒm�\���(���쒬 ���w�Z) END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return null;
	}

}
