/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD.Inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kannami.db.entity.Data31929000_RecordEntity;
import jp.co.systemd.tnavi.cus.kannami.db.service.List31929000Service;
import jp.co.systemd.tnavi.cus.kannami.db.service.Regist31929000Service;
import jp.co.systemd.tnavi.cus.kannami.formbean.List31929000FormBean;
import jp.co.systemd.tnavi.cus.kannami.formbean.Regist31929000FormBean;


/**
 * <PRE>
 * �i�H�\��� �X�VAction.
 * </PRE>
 *
 * <B>Create</B> 2016.11.08 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Regist31929000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist31929000Action.class);

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("�y��ʁz�i�H�\��� �X�V START");

		Regist31929000FormBean regist31929000FormBean = new Regist31929000FormBean();

		setRequestParameters(sessionBean, request, regist31929000FormBean);

		// �X�V�T�[�r�X�̎��s
		Regist31929000Service regist31929000Service = new Regist31929000Service();
		regist31929000Service.setRegistFormBean(regist31929000FormBean);
		regist31929000Service.execute(request, sessionBean);

		regist31929000FormBean = regist31929000Service.getRegistFormBean();

		String resultMassage = regist31929000FormBean.getMessage();

		// ------------------------------------------------------------------------------------------
		// �ĕ`�揈��
		// ------------------------------------------------------------------------------------------
		List31929000FormBean list31929000FormBean = new List31929000FormBean();
		list31929000FormBean.setNendo(request.getParameter("nendo"));
		list31929000FormBean.setGrade(request.getParameter("grade"));
		list31929000FormBean.setHmrclass(request.getParameter("hmrclass"));
		list31929000FormBean.setHmrname(request.getParameter("hmrname"));
		list31929000FormBean.setActiveTabIndex(request.getParameter("activeTabIndex"));

		List31929000Service list31929000Service = new List31929000Service( request, sessionBean );
		list31929000Service.setListFormBean(list31929000FormBean);
		list31929000Service.execute();

		//���s���ʂ��擾
		list31929000FormBean = list31929000Service.getListFormBean();
		list31929000FormBean.setMessage(resultMassage);

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", list31929000FormBean);

		log.info("�y��ʁz�i�H�\��� �X�V END");
		return null;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return false;
	}

	private Regist31929000FormBean setRequestParameters(SystemInfoBean  sessionBean, HttpServletRequest request, Regist31929000FormBean regist31929000FormBean){

		//�f�[�^����
		Integer recordCount = Integer.parseInt(request.getParameter("recordCount"));

		//���lList
		List<Data31929000_RecordEntity> recordList = new ArrayList<Data31929000_RecordEntity>();

		//List�ɔ��l�����Z�b�g
		for(int i=0; i<recordCount; i++) {
			Data31929000_RecordEntity recordEntity = new Data31929000_RecordEntity();
			String stucode = request.getParameter("stucode2_" + i);
			String record = request.getParameter("record_" + i);
			//�w�Дԍ����擾���ꂽ�ꍇ�̂ݍX�V
			if(stucode != null && !"".equals(stucode)) {
				recordEntity.setAcr_stucode(stucode);	//�w�Дԍ�
				recordEntity.setAcr_kind("3");			//�敪 3:�Q�l����(���i)
				recordEntity.setAcr_record(record);		//�L�^
				recordList.add(recordEntity);
			}
		}

		//FormBean�ɃZ�b�g
		regist31929000FormBean.setRecordList(recordList);

		return regist31929000FormBean;
	}



}
