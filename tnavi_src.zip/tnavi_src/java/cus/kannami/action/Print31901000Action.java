/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import jp.co.systemd.tnavi.common.action.AbstractExcelPrintAction;
import jp.co.systemd.tnavi.common.print.ExcelPrintResult;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kannami.db.service.List31901000Service;
import jp.co.systemd.tnavi.cus.kannami.db.service.Regist31901000Service;
import jp.co.systemd.tnavi.cus.kannami.formbean.Search31901000FormBean;
import jp.co.systemd.tnavi.cus.kannami.print.Print31901000;
import jp.co.systemd.tnavi.junior.common.utility.DownLoadFileUtility;
import jp.co.systemd.tnavi.stu.action.Print30002000Action;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * �s�o�Z�����p�f�[�^�o�� ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.20 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31901000Action extends AbstractExcelPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print30002000Action.class);

	/** �e���v���[�g�t�@�C���� */
	private static final String fileName = "�s�o�Z�����p�f�[�^�o��.xlsx";

	/**
	 * {@inheritDoc}
	 */
	protected ExcelPrintResult doPrint(ServletContext sc,
			HttpServletRequest request, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz�s�o�Z�����p�f�[�^�o��START");

		// ------------------------------------------------------------------------------------------
		// ����FormBean����
		// ------------------------------------------------------------------------------------------
		Search31901000FormBean searchFormBean = (Search31901000FormBean)copyRequestParamToFormBean(request, new Search31901000FormBean());

		// ------------------------------------------------------------------------------------------
		// �f�[�^�̍X�V����
		// ------------------------------------------------------------------------------------------
		Regist31901000Service registService = new Regist31901000Service(request, sessionBean);
		registService.execute();
		
		// ------------------------------------------------------------------------------------------
		// �f�[�^�̍Ď擾����
		// ------------------------------------------------------------------------------------------
		List31901000Service service = new List31901000Service(sessionBean, searchFormBean);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Excel�o�̓v���O�����̎��s
		// ------------------------------------------------------------------------------------------
		// �e���v���[�g�t�@�C����
		String templateFileName = sc.getInitParameter("templateldir") + fileName;
		// PrintService����
		Print31901000 print = new Print31901000(searchFormBean, templateFileName);

		// ������s
		ExcelPrintResult result = print.execute();

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz�s�o�Z�����p�f�[�^�o��END");

		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getDownloadFileName(ServletContext sc,
			HttpServletRequest request, SystemInfoBean sessionBean) {
		return DownLoadFileUtility.encodeDownloadFileName( "�s�o�Z�����p�f�[�^�o��.xlsx" );
		
	}

}
