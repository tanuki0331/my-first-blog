package jp.co.systemd.tnavi.cus.kannami.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import jp.co.systemd.tnavi.common.action.AbstractExcelPrintAction;
import jp.co.systemd.tnavi.common.print.ExcelPrintResult;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kannami.db.service.Print30994000Service;
import jp.co.systemd.tnavi.cus.kannami.print.Print30994000;
import jp.co.systemd.tnavi.junior.common.utility.DownLoadFileUtility;

/**
 * �w��������(���쒬) Action.
 *
 * <B>Create</B> 2016.03.28 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print30994000Action extends AbstractExcelPrintAction {

	private static final String TEMPLATE_FILE   = "�w������(���쒬).xls";
	private static final String DOWNLOAD_FILE_0 = "�w������.xls";
	private static final String DOWNLOAD_FILE_1 = "�n�於��.xls";
	private static final String DOWNLOAD_FILE_2 = "�w���`�F�b�N�\.xls";
	
	@Override
	protected ExcelPrintResult doPrint(ServletContext sc,
			HttpServletRequest request, SystemInfoBean sessionBean) {
		
		//�e���v���[�g�t�@�C����
		String templateFileName = sc.getInitParameter("templateldir") + TEMPLATE_FILE;
		
		Print30994000Service service = new Print30994000Service(request, sessionBean);
		service.execute();
				
		Print30994000 print = new Print30994000();
		print.setParameter(service.getPrintFormBean(), templateFileName);
		
		ExcelPrintResult result = print.execute();
		
		return result;
	}

	@Override
	protected String getDownloadFileName(ServletContext sc,
			HttpServletRequest request, SystemInfoBean sessionBean) {
		
		return DownLoadFileUtility.encodeDownloadFileName(getOutputTargetFilename(request));
	}

	/**
	 * ��ʂőI�������o�͓��e����o�͑Ώۂ̃t�@�C������Ԃ�
	 * @param request
	 * @return �o�͑Ώۃt�@�C����
	 */
	private String getOutputTargetFilename(HttpServletRequest request) {
		String output_target = request.getParameter("output_target");
		String download_file = null;
		if("0".equals(output_target)){
			download_file = DOWNLOAD_FILE_0;
		}else if("1".equals(output_target)){
			download_file = DOWNLOAD_FILE_1;
		}else if("2".equals(output_target)){
			download_file = DOWNLOAD_FILE_2;
		}
		return download_file;
	}

}
