/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD.Inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.db.entity.CourseAbilityuseEntity;
import jp.co.systemd.tnavi.common.db.entity.CourseStandardevalEntity;
import jp.co.systemd.tnavi.common.db.entity.CourseStandardscoreEntity;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kannami.db.service.List31927000Service;
import jp.co.systemd.tnavi.cus.kannami.db.service.Regist31927000Service;
import jp.co.systemd.tnavi.cus.kannami.formbean.List31927000FormBean;
import jp.co.systemd.tnavi.cus.kannami.formbean.Regist31927000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * <PRE>
 * �i�H��]���������́i�X�V�jAction.
 * </PRE>
 * 
 * <B>Create</B> 2016.10.31 BY aivick<BR>
 * <B>remark</B><BR>
 * 
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Regist31927000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist31927000Action.class);

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("�y��ʁz�i�H��]���������� �o�^ START");

		Regist31927000FormBean regist31927000FormBean = new Regist31927000FormBean();

		this.copyRequestParamToFormBean(request, regist31927000FormBean);

		String school_kind = request.getParameter("school_kind");
		if(school_kind == null || school_kind.equals("")){
			school_kind ="1"; // ���E����
		}
		regist31927000FormBean.setSchool_kind(school_kind);
		
		
		setRequestParameters(sessionBean, request, regist31927000FormBean);
		
		// �X�V�T�[�r�X�̎��s
		Regist31927000Service regist31927000Service = new Regist31927000Service();
		regist31927000Service.setRegistFormBean(regist31927000FormBean);
		regist31927000Service.execute(request, sessionBean);
		
		regist31927000FormBean = regist31927000Service.getRegistFormBean();
		
		String resultMassage = regist31927000FormBean.getMessage();

		// ------------------------------------------------------------------------------------------
		// �ĕ`�揈��
		// ------------------------------------------------------------------------------------------

		List31927000FormBean list31927000FormBean = new List31927000FormBean();
		list31927000FormBean.setNendo(regist31927000FormBean.getNendo());
		list31927000FormBean.setSchool_kind(regist31927000FormBean.getSchool_kind());
		
		List31927000Service list31927000Service = new List31927000Service( request, sessionBean );
		list31927000Service.setListFormBean(list31927000FormBean);
		list31927000Service.execute();

		//���s���ʂ��擾
		list31927000FormBean = list31927000Service.getListFormBean();
		list31927000FormBean.setMessage(resultMassage);
		list31927000FormBean.setTransition_radio(regist31927000FormBean.getTransition_radio());
		
		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", list31927000FormBean);

		log.info("�y��ʁz�i�H��]���������� �o�^ END");
		return null;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return false;
	}
	
	private Regist31927000FormBean setRequestParameters(SystemInfoBean  sessionBean, HttpServletRequest request, Regist31927000FormBean regist31927000FormBean){

		// �]���̐ݒ���擾���AEntity�ɕێ�����B	

		String school_code_seq = regist31927000FormBean.getSchool_code_seq();
		String[] school_code_array = school_code_seq.split(",");

		
		List<CourseStandardevalEntity> courseStandardevalEntityList = new ArrayList<CourseStandardevalEntity>(); 

		if( school_code_array != null ){

			for ( int i=0 ; i < school_code_array.length ; i++ ){
				
				String school_code = school_code_array[i];
				
				String[] split_scholl_code = new String[2];
					
				split_scholl_code = school_code.split("_",-1);

				if( split_scholl_code[0] == null ) continue;

				String course_code ="";
				if( split_scholl_code[1] == null ){
					course_code = "";
				}else{
					course_code = split_scholl_code[1];
				}	

				CourseStandardevalEntity courseStandardevalEntity = new CourseStandardevalEntity();
				courseStandardevalEntity.setCse_sclcd(split_scholl_code[0]); 
				courseStandardevalEntity.setCse_sclccd(course_code); 
				courseStandardevalEntity.setCse_year(regist31927000FormBean.getNendo()); 				

				String str_check      = request.getParameter(split_scholl_code[0] + "_"+course_code + "_check");
				if( str_check == null ) {
					courseStandardevalEntity.setCse_outputflg("0");
				}else{
					courseStandardevalEntity.setCse_outputflg("1");
				}
				
				if( regist31927000FormBean.getSchool_kind().equals("1")){
					

					
					String str_public9sum = request.getParameter(split_scholl_code[0]+"_"+course_code +"_public9sum");
					String str_public5sum = request.getParameter(split_scholl_code[0]+"_"+course_code +"_public5sum");
					String str_public3sum = request.getParameter(split_scholl_code[0]+"_"+course_code +"_public3sum");
	
					if( str_public9sum != null && !str_public9sum.trim().equals("")){
						courseStandardevalEntity.setCse_public_9sum(Integer.parseInt(str_public9sum)); 				
					}else{
						courseStandardevalEntity.setCse_public_9sum(null); 				
					}  
					
					if( str_public5sum != null && !str_public5sum.trim().equals("")){
						courseStandardevalEntity.setCse_public_5sum(Integer.parseInt(str_public5sum)); 				
					}else{
						courseStandardevalEntity.setCse_public_5sum(null); 				
					}  
	
					if( str_public3sum != null && !str_public3sum.trim().equals("")){
						courseStandardevalEntity.setCse_public_3sum(Integer.parseInt(str_public3sum)); 				
					}else{
						courseStandardevalEntity.setCse_public_3sum(null); 				
					}  

					courseStandardevalEntity.setCse_private_tan_5sum(null); 				
					courseStandardevalEntity.setCse_private_tan_9sum(null); 				
					courseStandardevalEntity.setCse_private_hei_5sum(null); 				
					courseStandardevalEntity.setCse_private_hei_9sum(null); 				

					courseStandardevalEntity.setCse_memo(null); 				
	
				}else{
					
					courseStandardevalEntity.setCse_public_9sum(null); 				
					courseStandardevalEntity.setCse_public_5sum(null); 				
					courseStandardevalEntity.setCse_public_3sum(null); 				
					
					String str_tan5sum = request.getParameter(split_scholl_code[0]+"_"+course_code +"_tan5sum");
					String str_tan9sum = request.getParameter(split_scholl_code[0]+"_"+course_code +"_tan9sum");
					String str_hei5sum = request.getParameter(split_scholl_code[0]+"_"+course_code +"_hei5sum");
					String str_hei9sum = request.getParameter(split_scholl_code[0]+"_"+course_code +"_hei9sum");
					
					if( str_tan5sum != null && !str_tan5sum.trim().equals("")){
						courseStandardevalEntity.setCse_private_tan_5sum(Integer.parseInt(str_tan5sum)); 				
					}else{
						courseStandardevalEntity.setCse_private_tan_5sum(null); 				
					}  
					
					if( str_tan9sum != null && !str_tan9sum.trim().equals("")){
						courseStandardevalEntity.setCse_private_tan_9sum(Integer.parseInt(str_tan9sum)); 				
					}else{
						courseStandardevalEntity.setCse_private_tan_9sum(null); 				
					}  
	
					if( str_hei5sum != null && !str_hei5sum.trim().equals("")){
						courseStandardevalEntity.setCse_private_hei_5sum(Integer.parseInt(str_hei5sum)); 				
					}else{
						courseStandardevalEntity.setCse_private_hei_5sum(null); 				
					}  
	
					if( str_hei9sum != null && !str_hei9sum.trim().equals("")){
						courseStandardevalEntity.setCse_private_hei_9sum(Integer.parseInt(str_hei9sum)); 				
					}else{
						courseStandardevalEntity.setCse_private_hei_9sum(null); 				
					}  

					String str_memo = request.getParameter(split_scholl_code[0]+"_"+course_code+"_memo");
					courseStandardevalEntity.setCse_memo(str_memo); 				
				}
				courseStandardevalEntityList.add(courseStandardevalEntity);
			}
		}
		regist31927000FormBean.setCourseStandardevalEntityList(courseStandardevalEntityList);

		
		
		List<CourseStandardscoreEntity> courseStandardscoreEntityList = new ArrayList<CourseStandardscoreEntity>(); 

		String test_code_seq = regist31927000FormBean.getTest_code_seq();
		String[] test_code_array = test_code_seq.split(",");
		
		if( regist31927000FormBean.getSchool_kind().equals("1")){

			// ���̓e�X�g�̍��v�_�̐ݒ���擾���AEntity�ɕێ�����B	
			if( school_code_array != null && test_code_array != null  ){
	
				for ( int i=0 ; i < school_code_array.length ; i++ ){

					for ( int j=0 ; j < test_code_array.length ; j++ ){ 
					
						String school_code = school_code_array[i];
						String test_code   = test_code_array[j];
				
						String[] split_scholl_code = new String[2];
						split_scholl_code =school_code.split("_", -1);
						
						if( split_scholl_code[0] == null )	break;
		
						String course_code ="";
						if( split_scholl_code[1] == null ){
							course_code = "";
						}else{
							course_code = split_scholl_code[1];
						}	
						
						CourseStandardscoreEntity courseStandardscoreEntity = new CourseStandardscoreEntity();
						courseStandardscoreEntity.setCss_sclcd(split_scholl_code[0]); 
						courseStandardscoreEntity.setCss_sclccd(course_code); 
						
						courseStandardscoreEntity.setCss_abttcode(test_code); 				
						courseStandardscoreEntity.setCss_year(regist31927000FormBean.getNendo()); 				

						String str_scoresum = request.getParameter(split_scholl_code[0]+"_"+course_code+"_score_"+ test_code );
						if( str_scoresum != null && !str_scoresum.equals("") ){
							courseStandardscoreEntity.setCss_scoresum(Integer.parseInt(str_scoresum));
						}else{
							courseStandardscoreEntity.setCss_scoresum(null);
						}
						courseStandardscoreEntityList.add(courseStandardscoreEntity);
					}
				}
			}	
			regist31927000FormBean.setCourseStandardscoreEntityList(courseStandardscoreEntityList);
		}		

		List<CourseAbilityuseEntity> courseAbilityuseEntityList = new ArrayList<CourseAbilityuseEntity>(); 

		
		// ���̓e�X�g�̍��v�_�̐ݒ���擾���AEntity�ɕێ�����B	
		if( test_code_array != null  ){

			for ( int j=0 ; j < test_code_array.length ; j++ ){ 
			
				String test_code   = test_code_array[j];
					
				CourseAbilityuseEntity courseAbilityuseEntity = new CourseAbilityuseEntity();

				String str_abbttcode = request.getParameter( "testTiming_"+ test_code );

				if( str_abbttcode == null || str_abbttcode.equals("") ) continue;

				courseAbilityuseEntity.setCau_abttcode( test_code );
				courseAbilityuseEntityList.add(courseAbilityuseEntity);
			}
		}	
		regist31927000FormBean.setCourseAbilityuseEntityList(courseAbilityuseEntityList);
		
		return regist31927000FormBean;
	}
	
	

}
