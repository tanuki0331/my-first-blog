/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.kannami.db.service.List31901000Service;
import jp.co.systemd.tnavi.cus.kannami.formbean.Search31901000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * �s�o�Z�����p�f�[�^�o�� ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.20 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Search31901000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Search31901000Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz�s�o�Z�����p�f�[�^�o�� START");

		// ------------------------------------------------------------------------------------------
		// FormBean����
		// ------------------------------------------------------------------------------------------
		Search31901000FormBean searchFormBean = (Search31901000FormBean)copyRequestParamToFormBean(request, new Search31901000FormBean());

		// ------------------------------------------------------------------------------------------
		// �����ݒ�
		// ------------------------------------------------------------------------------------------
		if(searchFormBean.getNendo() == null || searchFormBean.getNendo().length() == 0){
			searchFormBean.setNendo(sessionBean.getSystemNendoSeireki());
			searchFormBean.setInitNendo("");
			searchFormBean.setMonth(DateUtility.getSystemDate().substring(4, 6));
			searchFormBean.setInitMonth("");
			
			searchFormBean.setDays1("7");
			searchFormBean.setDays2("15");
			searchFormBean.setDays3("15");
			
			searchFormBean.setOutput1("1");
			searchFormBean.setOutput2("1");
			searchFormBean.setOutput3("1");
			searchFormBean.setOutput4("1");
			
		}

		// ------------------------------------------------------------------------------------------
		// �f�[�^�̎擾����
		// ------------------------------------------------------------------------------------------
		List31901000Service service = new List31901000Service(sessionBean, searchFormBean);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", searchFormBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz�s�o�Z�����p�f�[�^�o�� END");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}

}
