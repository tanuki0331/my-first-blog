/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2012 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.kannami.db.service.List30933000Service;
import jp.co.systemd.tnavi.cus.kannami.formbean.List30933000FormBean;

/**
 * <PRE>
 * ���������(�É���) �ꗗ Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.12.14 BY SD nishizawa.<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List30933000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List30933000Action.class);

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("�y��ʁz���������(�É���) �ꗗ START");

        List30933000FormBean list30933000FormBean = new List30933000FormBean();

		// �N���X�I���őI�������N���X���Z�b�V��������擾
		HroomKeyFormBean hroomKeyFormBean = new HroomKeyFormBean();
		hroomKeyFormBean = sessionBean.getSelectHroomKey();

        // -------------------------------------------------------------
        // �p�����[�^�擾
        // -------------------------------------------------------------
		String nendo = sessionBean.getSystemNendo();			// �N�x
		list30933000FormBean.setNendo(nendo);

		String grade = "";		// �w�N
		String clsno = "";		// �N���X�ԍ�

		//�w���S�C�̂݃N���X�����擾����
		if(hroomKeyFormBean != null) {
			grade = hroomKeyFormBean.getGlade();
			clsno = hroomKeyFormBean.getClsno();
			if(hroomKeyFormBean.getGlade() != null && "3".equals(hroomKeyFormBean.getGlade())) {
				list30933000FormBean.setLastgradeflg("1");
			}else{
				list30933000FormBean.setLastgradeflg("0");
			}
		}
		list30933000FormBean.setGrade(grade);
		list30933000FormBean.setClsno(clsno);

		//�I���̑I����Ԃ��擾����
		String[] selkindArray = null;
		if(request.getParameter("selkindArray") != null){
			selkindArray  = request.getParameter("selkindArray").split(",");
		}
		list30933000FormBean.setSelkindArray(selkindArray);

		//�o�͓��t���擾����
		String outputYear = request.getParameter("outputYear");
		String outputMonth = request.getParameter("outputMonth");
		String outputDay = request.getParameter("outputDay");
		if(outputYear == null || outputMonth == null || outputDay == null) {
			//�o�͓��t�ɃV�X�e�����t���Z�b�g(�����l)
			String date = DateUtility.getSystemDate();
			outputYear = date.substring(0,4);
			outputMonth = date.substring(4,6);
			outputDay = date.substring(6,8);
		}
		list30933000FormBean.setOutputYear(outputYear);
		list30933000FormBean.setOutputMonth(outputMonth);
		list30933000FormBean.setOutputDay(outputDay);

		//[�w�Ȗ��𗪏̂ŏo�͂���]�`�F�b�N��Ԃ��擾����
		String checkdepsname = request.getParameter("checkdepsname");
		list30933000FormBean.setCheckdepsname(checkdepsname);

        // -------------------------------------------------------------
        // ���k���擾����
        // -------------------------------------------------------------
        // ���k���擾
        List30933000Service list30933000Service = new List30933000Service(request, sessionBean);
        list30933000Service.setListFormBean(list30933000FormBean);
        list30933000Service.execute();

        // �ꗗFormBean�擾
        list30933000FormBean = list30933000Service.getListFormBean();
        // FormBean�Ƀp�����[�^�Z�b�g
        list30933000FormBean.setNendo(nendo);

		//Request��FormBean���Z�b�g����
		request.setAttribute("FORM_BEAN", list30933000FormBean);

		log.info("�y��ʁz���������(�É���) �ꗗ END");

		return null;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return false;
	}

}
