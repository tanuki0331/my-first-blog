/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD Inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.action;


import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kannami.formbean.List31927000FormBean;
import jp.co.systemd.tnavi.cus.kannami.db.service.List31927000Service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * �i�H�ψ���p�����i���́jAction.
 * </PRE>
 * 
 * <B>Create</B> 2016.10.31 BY terai<BR>
 * <B>remark</B><BR>
 * 
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List31927000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List31927000Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {
		log.info("�y��ʁz�i�H�ψ���p�����i���́jSTART");

		List31927000FormBean list31927000FormBean = new List31927000FormBean();
			
		String transition_radio = request.getParameter("TRANSITION_ID");
		list31927000FormBean.setTransition_radio(transition_radio);
		
		String nendo = request.getParameter("nendo");
		list31927000FormBean.setNendo(nendo);

		String school_kind = request.getParameter("school_kind");
		if(school_kind == null || school_kind.equals("")){
			school_kind ="1"; // ���E����
		}
		list31927000FormBean.setSchool_kind(school_kind);
		
		List31927000Service service = new List31927000Service( request, sessionBean );
		service.setListFormBean(list31927000FormBean);
		service.execute();

		//���s���ʂ��擾
		list31927000FormBean = service.getListFormBean();

		//-----Request��FormBean���Z�b�g����B
		request.setAttribute("FORM_BEAN", list31927000FormBean);
				
		log.info("�y��ʁz�i�H�ψ���p�����i���́jEND");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}
	
}
