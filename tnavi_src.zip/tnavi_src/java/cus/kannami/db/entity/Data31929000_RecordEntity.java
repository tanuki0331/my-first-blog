/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� ���lEntity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.08 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31929000_RecordEntity {

	/** �����R�[�h */
	private String acr_user;

	/** �w�Дԍ� */
	private String acr_stucode;

	/** �敪 */
	private String acr_kind;

	/** �L�^ */
	private String acr_record;

	/** �X�V�� */
	private String acr_update;

	/** �X�V�� */
	private String acr_upuser;


	public String getAcr_user() {
	    return acr_user;
	}

	public void setAcr_user(String acr_user) {
	    this.acr_user = acr_user;
	}

	public String getAcr_stucode() {
	    return acr_stucode;
	}

	public void setAcr_stucode(String acr_stucode) {
	    this.acr_stucode = acr_stucode;
	}

	public String getAcr_kind() {
	    return acr_kind;
	}

	public void setAcr_kind(String acr_kind) {
	    this.acr_kind = acr_kind;
	}

	public String getAcr_record() {
	    return acr_record;
	}

	public void setAcr_record(String acr_record) {
	    this.acr_record = acr_record;
	}

	public String getAcr_update() {
	    return acr_update;
	}

	public void setAcr_update(String acr_update) {
	    this.acr_update = acr_update;
	}

	public String getAcr_upuser() {
	    return acr_upuser;
	}

	public void setAcr_upuser(String acr_upuser) {
	    this.acr_upuser = acr_upuser;
	}

}
