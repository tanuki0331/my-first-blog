package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * ����Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.07.26 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31907000_CommentEntity {
	/** �w�Дԍ� */
	private String rcom_stucode;

	/** �������e */
	private String rcom_comment;

	/**
	 * rcom_stucode ���擾����B
	 * @return rcom_stucode
	 */
	public final String getRcom_stucode() {
		return rcom_stucode;
	}

	/**
	 * rcom_stucode ��ݒ肷��B
	 * @param rcom_stucode �Z�b�g���� rcom_stucode
	 */
	public final void setRcom_stucode(String rcom_stucode) {
		this.rcom_stucode = rcom_stucode;
	}

	/**
	 * rcom_comment ���擾����B
	 * @return rcom_comment
	 */
	public final String getRcom_comment() {
		return rcom_comment;
	}

	/**
	 * rcom_comment ��ݒ肷��B
	 * @param rcom_comment �Z�b�g���� rcom_comment
	 */
	public final void setRcom_comment(String rcom_comment) {
		this.rcom_comment = rcom_comment;
	}

}
