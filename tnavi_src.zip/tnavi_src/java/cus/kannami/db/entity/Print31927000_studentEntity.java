/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  ���k�ꗗ�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_studentEntity {

	private String rsch_course;
	private String school_kind;
	private String scl_cd ;
	private String scl_name;
	private String hmr_class;	
	private String cls_number;	
	private String stu_stucode;	
	private String st4_name;	
	private String sex;	
	private String selection_shubetu;

	public String getRsch_course() {
		return rsch_course;
	}
	public void setRsch_course(String rsch_course) {
		this.rsch_course = rsch_course;
	}
	public String getSchool_kind() {
		return school_kind;
	}
	public void setSchool_kind(String school_kind) {
		this.school_kind = school_kind;
	}
	public String getScl_cd() {
		return scl_cd;
	}
	public void setScl_cd(String scl_cd) {
		this.scl_cd = scl_cd;
	}
	public String getScl_name() {
		return scl_name;
	}
	public void setScl_name(String scl_name) {
		this.scl_name = scl_name;
	}
	public String getHmr_class() {
		return hmr_class;
	}
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}
	public String getCls_number() {
		return cls_number;
	}
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	public String getStu_stucode() {
		return stu_stucode;
	}
	public void setStu_stucode(String stu_stucode) {
		this.stu_stucode = stu_stucode;
	}
	public String getSt4_name() {
		return st4_name;
	}
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSelection_shubetu() {
		return selection_shubetu;
	}
	public void setSelection_shubetu(String selection_shubetu) {
		this.selection_shubetu = selection_shubetu;
	}	
	
	
}
