package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * ���ђʒm�\����(���쒬 ���w�Z���ʎx���w��) �s���̂����� Entity.
 * </PRE>
 * <B>Create</B> 2017.07.05 BY yamazaki <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31960000SpScorptactviewpointvalueEntity {

	/**
	 * �\���p ���ڃR�[�h
	 */
	private Integer disp_sravtcode;

	/**
	 * ���ڃR�[�h
	 */
	private String sravt_sravtcode;

	/**
	 * �ʊϓ_
	 */
	private String sravv_indivivp;

	/**
	 * �]���R�[�h
	 */
	private String sravv_sracecode;


	public Integer getDisp_sravtcode() {
		return disp_sravtcode;
	}

	public void setDisp_sravtcode(Integer disp_sravtcode) {
		this.disp_sravtcode = disp_sravtcode;
	}

	public String getSravt_sravtcode() {
		return sravt_sravtcode;
	}

	public void setSravt_sravtcode(String sravt_sravtcode) {
		this.sravt_sravtcode = sravt_sravtcode;
	}

	public String getSravv_indivivp() {
		return sravv_indivivp;
	}

	public void setSravv_indivivp(String sravv_indivivp) {
		this.sravv_indivivp = sravv_indivivp;
	}

	public String getSravv_sracecode() {
		return sravv_sracecode;
	}

	public void setSravv_sracecode(String sravv_sracecode) {
		this.sravv_sracecode = sravv_sracecode;
	}

}