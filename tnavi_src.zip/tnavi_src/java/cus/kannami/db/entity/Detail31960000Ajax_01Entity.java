/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2014 SystemD, inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * �����ꗗ�\�@���ʊ���(�ψ���A�W�A�N���u�Ȃ�)�ݐЏ��  Entity.
 *
 * <B>Create</B> 2014.06.18 BY SD nagaoka<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD, Inc.
 * @since 1.0.
 */
public class Detail31960000Ajax_01Entity implements CommonConstantsUseable{

	/** ����*/
	private String cls_user = "";
	/** �N�x*/
	private String 	cls_year = "";
	/** �w�N*/
	private String cls_glade = "";
	/** �N���X�ԍ�*/
	private String cls_clsno = "";
	/** �o�Ȕԍ�*/
	private String cls_number = "";
	/** �w�Дԍ�*/
	private String cls_stucode = "";
	/** ��� 1�F�ψ���@5:�W�A�w���@6:�N���u*/
	private String ext_kind = "";
	/** �ۊO������*/
	private String ext_name = "";
	/** �ۊO������ ��*/
	private String ext_name2 = "";
	/** ��E*/
	private String pst_name = "";
	/** �C��*/
	private String cod_name1 = "";

	/**
	 * @param cls_user �Z�b�g���� cls_user
	 */
	public void setCls_user(String cls_user) {
		this.cls_user = cls_user;
	}
	/**
	 * @return cls_user
	 */
	public String getCls_user() {
		return cls_user;
	}
	/**
	 * @param cls_year �Z�b�g���� cls_year
	 */
	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}
	/**
	 * @return cls_year
	 */
	public String getCls_year() {
		return cls_year;
	}
	/**
	 * @param cls_glade �Z�b�g���� cls_glade
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}
	/**
	 * @return cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}
	/**
	 * @param cls_clsno �Z�b�g���� cls_clsno
	 */
	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}
	/**
	 * @return cls_clsno
	 */
	public String getCls_clsno() {
		return cls_clsno;
	}
	/**
	 * @param cls_number �Z�b�g���� cls_number
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	/**
	 * @return cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}
	/**
	 * @param ext_kind �Z�b�g���� ext_kind
	 */
	public void setExt_kind(String ext_kind) {
		this.ext_kind = ext_kind;
	}
	/**
	 * @return ext_kind
	 */
	public String getExt_kind() {
		return ext_kind;
	}
	/**
	 * @param ext_name �Z�b�g���� ext_name
	 */
	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}
	/**
	 * @return ext_name
	 */
	public String getExt_name() {
		return ext_name;
	}
	/**
	 * @param ext_name2 �Z�b�g���� ext_name2
	 */
	public void setExt_name2(String ext_name2) {
		this.ext_name2 = ext_name2;
	}
	/**
	 * @return ext_name2
	 */
	public String getExt_name2() {
		return ext_name2;
	}
	/**
	 * @param pst_name �Z�b�g���� pst_name
	 */
	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}
	/**
	 * @return pst_name
	 */
	public String getPst_name() {
		return pst_name;
	}
	/**
	 * @param cod_name1 �Z�b�g���� cod_name1
	 */
	public void setCod_name1(String cod_name1) {
		this.cod_name1 = cod_name1;
	}
	/**
	 * @return cod_name1
	 */
	public String getCod_name1() {
		return cod_name1;
	}
	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}
}
