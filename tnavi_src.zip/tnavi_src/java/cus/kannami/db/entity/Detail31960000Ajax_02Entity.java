/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2014 SystemD, inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ���ʊ����̋L�^����(���쒬 ���ʎx���w��)�@�������@�ݐЏ��  Entity.
 *
 * <B>Create</B> 2017.07.10 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD, Inc.
 * @since 1.0.
 */
public class Detail31960000Ajax_02Entity implements CommonConstantsUseable{

	/** ����*/
	private String cls_user = "";
	/** �N�x*/
	private String cls_year = "";
	/** �w�N*/
	private String cls_glade = "";
	/** �N���X�ԍ�*/
	private String cls_clsno = "";
	/** �o�Ȕԍ�*/
	private String cls_number = "";
	/** �w�Дԍ�*/
	private String cls_stucode = "";
	/** �����R�[�h*/
	private String clb_code = "";
	/** �����N����*/
	private String clb_start = "";
	/** �ޕ��N����*/
	private String clb_stop = "";
	/** �������l*/
	private String clb_memo = "";
	/** ��E�R�[�h*/
	private String clb_post = "";
	/** ������*/
	private String ext_name = "";
	/** ��������*/
	private String ext_name2 = "";
	/** ��E��*/
	private String pst_name = "";
	/**
	 * @param cls_user �Z�b�g���� cls_user
	 */
	public void setCls_user(String cls_user) {
		this.cls_user = cls_user;
	}
	/**
	 * @return cls_user
	 */
	public String getCls_user() {
		return cls_user;
	}
	/**
	 * @param cls_year �Z�b�g���� cls_year
	 */
	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}
	/**
	 * @return cls_year
	 */
	public String getCls_year() {
		return cls_year;
	}
	/**
	 * @param cls_glade �Z�b�g���� cls_glade
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}
	/**
	 * @return cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}
	/**
	 * @param cls_clsno �Z�b�g���� cls_clsno
	 */
	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}
	/**
	 * @return cls_clsno
	 */
	public String getCls_clsno() {
		return cls_clsno;
	}
	/**
	 * @param cls_number �Z�b�g���� cls_number
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	/**
	 * @return cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}
	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}
	/**
	 * @param clb_code �Z�b�g���� clb_code
	 */
	public void setClb_code(String clb_code) {
		this.clb_code = clb_code;
	}
	/**
	 * @return clb_code
	 */
	public String getClb_code() {
		return clb_code;
	}
	/**
	 * @param clb_start �Z�b�g���� clb_start
	 */
	public void setClb_start(String clb_start) {
		this.clb_start = clb_start;
	}
	/**
	 * @return clb_start
	 */
	public String getClb_start() {
		return clb_start;
	}
	/**
	 * @param clb_stop �Z�b�g���� clb_stop
	 */
	public void setClb_stop(String clb_stop) {
		this.clb_stop = clb_stop;
	}
	/**
	 * @return clb_stop
	 */
	public String getClb_stop() {
		return clb_stop;
	}
	/**
	 * @param clb_memo �Z�b�g���� clb_memo
	 */
	public void setClb_memo(String clb_memo) {
		this.clb_memo = clb_memo;
	}
	/**
	 * @return clb_memo
	 */
	public String getClb_memo() {
		return clb_memo;
	}
	/**
	 * @param clb_post �Z�b�g���� clb_post
	 */
	public void setClb_post(String clb_post) {
		this.clb_post = clb_post;
	}
	/**
	 * @return clb_post
	 */
	public String getClb_post() {
		return clb_post;
	}
	/**
	 * @param ext_name �Z�b�g���� ext_name
	 */
	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}
	/**
	 * @return ext_name
	 */
	public String getExt_name() {
		return ext_name;
	}
	/**
	 * @param ext_name2 �Z�b�g���� ext_name2
	 */
	public void setExt_name2(String ext_name2) {
		this.ext_name2 = ext_name2;
	}
	/**
	 * @return ext_name2
	 */
	public String getExt_name2() {
		return ext_name2;
	}
	/**
	 * @param pst_name �Z�b�g���� pst_name
	 */
	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}
	/**
	 * @return pst_name
	 */
	public String getPst_name() {
		return pst_name;
	}
}
