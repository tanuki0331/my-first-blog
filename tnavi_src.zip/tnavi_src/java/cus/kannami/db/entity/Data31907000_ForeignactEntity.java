package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �O���ꊈ��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.07.26 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31907000_ForeignactEntity {

	/** �w�Дԍ� */
	private String rfla_stucode;

	/** �]�� */
    private String rfla_eval;

	/**
	 * rfla_stucode ���擾����B
	 * @return rfla_stucode
	 */
	public final String getRfla_stucode() {
		return rfla_stucode;
	}

	/**
	 * rfla_stucode ��ݒ肷��B
	 * @param rfla_stucode �Z�b�g���� rfla_stucode
	 */
	public final void setRfla_stucode(String rfla_stucode) {
		this.rfla_stucode = rfla_stucode;
	}

	/**
	 * rfla_eval ���擾����B
	 * @return rfla_eval
	 */
	public final String getRfla_eval() {
		return rfla_eval;
	}

	/**
	 * rfla_eval ��ݒ肷��B
	 * @param rfla_eval �Z�b�g���� rfla_eval
	 */
	public final void setRfla_eval(String rfla_eval) {
		this.rfla_eval = rfla_eval;
	}
}
