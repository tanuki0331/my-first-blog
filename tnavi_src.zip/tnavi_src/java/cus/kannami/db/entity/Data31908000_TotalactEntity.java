package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �����I�Ȋw�K�̎��Ԃ̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31908000_TotalactEntity {
	
	/**
	 * �w�Дԍ�
	 */
	private String rtav_stucode;
	
	/**
	 * �w�K����
	 */
	private String rtav_contents;
	
	/**
	 * �ϓ_
	 */
    private String rtav_viewpoint;
    
    /**
     * �]��
     */
    private String rtav_value;

	/**
	 * @return the rtav_stucode
	 */
	public String getRtav_stucode() {
		return rtav_stucode;
	}

	/**
	 * @param rtav_stucode the rtav_stucode to set
	 */
	public void setRtav_stucode(String rtav_stucode) {
		this.rtav_stucode = rtav_stucode;
	}

	public String getRtav_contents() {
		return rtav_contents;
	}

	public void setRtav_contents(String rtav_contents) {
		this.rtav_contents = rtav_contents;
	}

	public String getRtav_viewpoint() {
		return rtav_viewpoint;
	}

	public void setRtav_viewpoint(String rtav_viewpoint) {
		this.rtav_viewpoint = rtav_viewpoint;
	}

	/**
	 * @return the rtav_value
	 */
	public String getRtav_value() {
		return rtav_value;
	}

	/**
	 * @param rtav_value the rtav_value to set
	 */
	public void setRtav_value(String rtav_value) {
		this.rtav_value = rtav_value;
	}
	
	
}
