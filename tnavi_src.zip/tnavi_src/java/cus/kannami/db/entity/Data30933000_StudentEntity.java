/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  ���������(�É���) ���k�ꗗEntity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.14 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data30933000_StudentEntity {

	/** �w�Дԍ� */
	private String exrs_stucode;

	/** �A�� */
	private String exrs_seq;

	/** �g */
	private String hmr_class;

	/** �o�Ȕԍ� */
	private String cls_number;

	/** ���k���� */
	private String st4_name;

	/** ���Z������ */
	private String scl_name;

	/** �ے����� */
	private String coursename;

	/** �w�Ȗ��� */
	private String scld_depname;

	/** �I������ */
	private String selname;

	/** �]�ފw�t���O */
	private String regflg;

	/** �ٓ��� */
	private String regdate;

	/** �ٓ��敪 */
	private String regtxt;


	public String getExrs_stucode() {
	    return exrs_stucode;
	}

	public void setExrs_stucode(String exrs_stucode) {
	    this.exrs_stucode = exrs_stucode;
	}

	public String getExrs_seq() {
	    return exrs_seq;
	}

	public void setExrs_seq(String exrs_seq) {
	    this.exrs_seq = exrs_seq;
	}

	public String getHmr_class() {
	    return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
	    this.hmr_class = hmr_class;
	}

	public String getCls_number() {
	    return cls_number;
	}

	public void setCls_number(String cls_number) {
	    this.cls_number = cls_number;
	}

	public String getSt4_name() {
	    return st4_name;
	}

	public void setSt4_name(String st4_name) {
	    this.st4_name = st4_name;
	}

	public String getScl_name() {
	    return scl_name;
	}

	public void setScl_name(String scl_name) {
	    this.scl_name = scl_name;
	}

	public String getCoursename() {
	    return coursename;
	}

	public void setCoursename(String coursename) {
	    this.coursename = coursename;
	}

	public String getScld_depname() {
	    return scld_depname;
	}

	public void setScld_depname(String scld_depname) {
	    this.scld_depname = scld_depname;
	}

	public String getSelname() {
	    return selname;
	}

	public void setSelname(String selname) {
	    this.selname = selname;
	}

	public String getRegflg() {
	    return regflg;
	}

	public void setRegflg(String regflg) {
	    this.regflg = regflg;
	}

	public String getRegdate() {
	    return regdate;
	}

	public void setRegdate(String regdate) {
	    this.regdate = regdate;
	}

	public String getRegtxt() {
	    return regtxt;
	}

	public void setRegtxt(String regtxt) {
	    this.regtxt = regtxt;
	}

}
