/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� ���lEntity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.09 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31929000_MemoEntity {

	/** �w�Дԍ� */
	private String cls_stucode;

	/** ���l */
	private String acr_record;


	public String getCls_stucode() {
	    return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
	    this.cls_stucode = cls_stucode;
	}

	public String getAcr_record() {
	    return acr_record;
	}

	public void setAcr_record(String acr_record) {
	    this.acr_record = acr_record;
	}

}
