/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  ���ȕ\�����p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_itemOrderEntity {

	private String item_name;
	private String item_code;
	private String item5_sum_flg;
	
	
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getItem_code() {
		return item_code;
	}
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}
	public String getItem5_sum_flg() {
		return item5_sum_flg;
	}
	public void setItem5_sum_flg(String item5_sum_flg) {
		this.item5_sum_flg = item5_sum_flg;
	}


	
	

}
