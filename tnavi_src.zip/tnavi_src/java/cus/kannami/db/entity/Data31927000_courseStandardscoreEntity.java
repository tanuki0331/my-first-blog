/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 System D Inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 *  tbl_course_standardscore
 * </PRE>
 * 
 * <B>Create</B> 2016.10.19 BY aivick<BR>
 * <B>remark</B><BR>
 * 
 * @author System D Inc.
 * @since 1.0.
 */
public class Data31927000_courseStandardscoreEntity implements CommonConstantsUseable {		

    /** 
     * �����R�[�h
     */
    private String css_user;
    /** 
     * �N�x
     */
    private String css_year;
    /** 
     * ���Z���R�[�h
     */
    private String css_sclcd;
    /** 
     * ���Z���R�[�h
     */
    private String css_sclccd;
	/** 
     * ���{�����R�[�h
     */
    private String css_abttcode;
    /** 
     * �������_
     */
    private Integer css_scoresum;
    
    /** 
     * ���{������
     */
    private String abtt_name;
    /** 
     * ���{�������Q
     */
    private String abtt_name2;
    /** 
     * ���{��
     */
    private String abtt_date;
    
    /** 
     * �I�����ꂽ���{�����R�[�h(tbl_course_abilityuse)
     */
    private String cau_abttcode;
    
    
	public String getCss_user() {
		return css_user;
	}
	public void setCss_user(String css_user) {
		this.css_user = css_user;
	}
	public String getCss_year() {
		return css_year;
	}
	public void setCss_year(String css_year) {
		this.css_year = css_year;
	}
	public String getCss_sclcd() {
		return css_sclcd;
	}
	public void setCss_sclcd(String css_sclcd) {
		this.css_sclcd = css_sclcd;
	}
    public String getCss_sclccd() {
		return css_sclccd;
	}
	public void setCss_sclccd(String css_sclccd) {
		this.css_sclccd = css_sclccd;
	}
	public String getCss_abttcode() {
		return css_abttcode;
	}
	public void setCss_abttcode(String css_abttcode) {
		this.css_abttcode = css_abttcode;
	}
	public Integer getCss_scoresum() {
		return css_scoresum;
	}
	public void setCss_scoresum(Integer css_scoresum) {
		this.css_scoresum = css_scoresum;
	}
	public String getAbtt_name() {
		return abtt_name;
	}
	public void setAbtt_name(String abtt_name) {
		this.abtt_name = abtt_name;
	}
	public String getAbtt_name2() {
		return abtt_name2;
	}
	public void setAbtt_name2(String abtt_name2) {
		this.abtt_name2 = abtt_name2;
	}
	public String getAbtt_date() {
		return abtt_date;
	}
	public void setAbtt_date(String abtt_date) {
		this.abtt_date = abtt_date;
	}
	public String getCau_abttcode() {
		return cau_abttcode;
	}
	public void setCau_abttcode(String cau_abttcode) {
		this.cau_abttcode = cau_abttcode;
	}

}
