/**------------------------------------------------------------**
 * Te@cherNavi
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �ٓ����Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.12 nagaoka<BR>
 * �@��Data30026000_05Entity�@��藬�p
 * <B>remark</B><BR>
 *
 * @author SystemD.Inc
 * @since 1.0.
 */
public class Print30999000_05Entity{

	public final static String DEFALUT_VALUE = "";

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;
	/**
	 * �J�n�N����
	 */
	private String reg_start;
	/**
	 * �I���N����
	 */
	private String reg_end;
	/**
	 * �ٓ��R�[�h
	 */
	private String reg_mcode;
	/**
	 * ����
	 */
	private String reg_permitdate;
	/**
	 * �w�Јٓ��敪����(�ʏ�)
	 */
	private String cod_name2;
	/**
	 * �]����w�Z��
	 */
	private String st4_anotherschname;

	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getReg_start() {
		return reg_start;
	}
	public void setReg_start(String reg_start) {
		this.reg_start = reg_start;
	}
	public String getReg_end() {
		return reg_end;
	}
	public void setReg_end(String reg_end) {
		this.reg_end = reg_end;
	}
	public String getReg_mcode() {
		return reg_mcode;
	}
	public void setReg_mcode(String reg_mcode) {
		this.reg_mcode = reg_mcode;
	}
	public String getReg_permitdate() {
		return reg_permitdate;
	}
	public void setReg_permitdate(String reg_permitdate) {
		this.reg_permitdate = reg_permitdate;
	}
	public String getCod_name2() {
		return cod_name2;
	}
	public void setCod_name2(String cod_name2) {
		this.cod_name2 = cod_name2;
	}
	public String getSt4_anotherschname() {
		return st4_anotherschname;
	}
	public void setSt4_anotherschname(String st4_anotherschname) {
		this.st4_anotherschname = st4_anotherschname;
	}

}
