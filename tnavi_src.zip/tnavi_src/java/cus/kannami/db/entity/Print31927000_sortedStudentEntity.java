/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  ���k�ꗗ�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_sortedStudentEntity {

	private String cls_user;
	private String cls_year;
	private String cls_glade; 
	private String cls_clsno; 
	private String hmr_class; 
	private String cls_number;
	private String cls_stucode;
	private String st4_name;
	private String sex;
	private String sum_9;
	private String sum_5;
	private String sum_3;
	private String school_kind;
	private String scld_seq;
	private String rsch_time;
	private String rsch_course;
	private String rsch_schtype;
	private String rsch_emphow;
	private String rsch_system;
	private String rsch_faculty;
	private String rsch_hopearea;
	private String rsch_1choiceed;
	private String rsch_2choiceed;
	private String rsch_3choiceed;
	private String rsch_4choiceed;
	private String rsch_5choiceed;
	private String rsch_6choiceed;
	private String rsch_1coursecd;
	private String rsch_2coursecd;
	private String rsch_3coursecd;
	private String rsch_4coursecd;
	private String rsch_5coursecd;
	private String rsch_6coursecd;
	private String rsch_selection1;
	private String rsch_selection2;
	private String rsch_selection3;
	private String rsch_selection4;
	private String rsch_selection5;
	private String rsch_selection6;
	private String rsch_1choiceco;
	private String rsch_2choiceco;
	private String rsch_3choiceco;
	private String rsch_memo;
	
	private String selection_shubetu;
	private String selection2_336;
	private String selection3_336;
	private String selection4_336;
	private String selection5_336;
	private String selection6_336;
	
	private String cse_outputflg;
	
	public String getCls_user() {
		return cls_user;
	}
	public void setCls_user(String cls_user) {
		this.cls_user = cls_user;
	}
	public String getCls_year() {
		return cls_year;
	}
	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}
	public String getCls_glade() {
		return cls_glade;
	}
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}
	public String getCls_clsno() {
		return cls_clsno;
	}
	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}
	public String getHmr_class() {
		return hmr_class;
	}
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}
	public String getCls_number() {
		return cls_number;
	}
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getSt4_name() {
		return st4_name;
	}
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSum_9() {
		return sum_9;
	}
	public void setSum_9(String sum_9) {
		this.sum_9 = sum_9;
	}
	public String getSum_5() {
		return sum_5;
	}
	public void setSum_5(String sum_5) {
		this.sum_5 = sum_5;
	}
	public String getSum_3() {
		return sum_3;
	}
	public void setSum_3(String sum_3) {
		this.sum_3 = sum_3;
	}
	public String getSchool_kind() {
		return school_kind;
	}
	public void setSchool_kind(String school_kind) {
		this.school_kind = school_kind;
	}
	public String getScld_seq() {
		return scld_seq;
	}
	public void setScld_seq(String scld_seq) {
		this.scld_seq = scld_seq;
	}
	public String getRsch_time() {
		return rsch_time;
	}
	public void setRsch_time(String rsch_time) {
		this.rsch_time = rsch_time;
	}
	public String getRsch_course() {
		return rsch_course;
	}
	public void setRsch_course(String rsch_course) {
		this.rsch_course = rsch_course;
	}
	public String getRsch_schtype() {
		return rsch_schtype;
	}
	public void setRsch_schtype(String rsch_schtype) {
		this.rsch_schtype = rsch_schtype;
	}
	public String getRsch_emphow() {
		return rsch_emphow;
	}
	public void setRsch_emphow(String rsch_emphow) {
		this.rsch_emphow = rsch_emphow;
	}
	public String getRsch_system() {
		return rsch_system;
	}
	public void setRsch_system(String rsch_system) {
		this.rsch_system = rsch_system;
	}
	public String getRsch_faculty() {
		return rsch_faculty;
	}
	public void setRsch_faculty(String rsch_faculty) {
		this.rsch_faculty = rsch_faculty;
	}
	public String getRsch_hopearea() {
		return rsch_hopearea;
	}
	public void setRsch_hopearea(String rsch_hopearea) {
		this.rsch_hopearea = rsch_hopearea;
	}
	public String getRsch_1choiceed() {
		return rsch_1choiceed;
	}
	public void setRsch_1choiceed(String rsch_1choiceed) {
		this.rsch_1choiceed = rsch_1choiceed;
	}
	public String getRsch_2choiceed() {
		return rsch_2choiceed;
	}
	public void setRsch_2choiceed(String rsch_2choiceed) {
		this.rsch_2choiceed = rsch_2choiceed;
	}
	public String getRsch_3choiceed() {
		return rsch_3choiceed;
	}
	public void setRsch_3choiceed(String rsch_3choiceed) {
		this.rsch_3choiceed = rsch_3choiceed;
	}
	public String getRsch_4choiceed() {
		return rsch_4choiceed;
	}
	public void setRsch_4choiceed(String rsch_4choiceed) {
		this.rsch_4choiceed = rsch_4choiceed;
	}
	public String getRsch_5choiceed() {
		return rsch_5choiceed;
	}
	public void setRsch_5choiceed(String rsch_5choiceed) {
		this.rsch_5choiceed = rsch_5choiceed;
	}
	public String getRsch_6choiceed() {
		return rsch_6choiceed;
	}
	public void setRsch_6choiceed(String rsch_6choiceed) {
		this.rsch_6choiceed = rsch_6choiceed;
	}
	public String getRsch_1coursecd() {
		return rsch_1coursecd;
	}
	public void setRsch_1coursecd(String rsch_1coursecd) {
		this.rsch_1coursecd = rsch_1coursecd;
	}
	public String getRsch_2coursecd() {
		return rsch_2coursecd;
	}
	public void setRsch_2coursecd(String rsch_2coursecd) {
		this.rsch_2coursecd = rsch_2coursecd;
	}
	public String getRsch_3coursecd() {
		return rsch_3coursecd;
	}
	public void setRsch_3coursecd(String rsch_3coursecd) {
		this.rsch_3coursecd = rsch_3coursecd;
	}
	public String getRsch_4coursecd() {
		return rsch_4coursecd;
	}
	public void setRsch_4coursecd(String rsch_4coursecd) {
		this.rsch_4coursecd = rsch_4coursecd;
	}
	public String getRsch_5coursecd() {
		return rsch_5coursecd;
	}
	public void setRsch_5coursecd(String rsch_5coursecd) {
		this.rsch_5coursecd = rsch_5coursecd;
	}
	public String getRsch_6coursecd() {
		return rsch_6coursecd;
	}
	public void setRsch_6coursecd(String rsch_6coursecd) {
		this.rsch_6coursecd = rsch_6coursecd;
	}
	public String getRsch_selection1() {
		return rsch_selection1;
	}
	public void setRsch_selection1(String rsch_selection1) {
		this.rsch_selection1 = rsch_selection1;
	}
	public String getRsch_selection2() {
		return rsch_selection2;
	}
	public void setRsch_selection2(String rsch_selection2) {
		this.rsch_selection2 = rsch_selection2;
	}
	public String getRsch_selection3() {
		return rsch_selection3;
	}
	public void setRsch_selection3(String rsch_selection3) {
		this.rsch_selection3 = rsch_selection3;
	}
	public String getRsch_selection4() {
		return rsch_selection4;
	}
	public void setRsch_selection4(String rsch_selection4) {
		this.rsch_selection4 = rsch_selection4;
	}
	public String getRsch_selection5() {
		return rsch_selection5;
	}
	public void setRsch_selection5(String rsch_selection5) {
		this.rsch_selection5 = rsch_selection5;
	}
	public String getRsch_selection6() {
		return rsch_selection6;
	}
	public void setRsch_selection6(String rsch_selection6) {
		this.rsch_selection6 = rsch_selection6;
	}
	public String getRsch_1choiceco() {
		return rsch_1choiceco;
	}
	public void setRsch_1choiceco(String rsch_1choiceco) {
		this.rsch_1choiceco = rsch_1choiceco;
	}
	public String getRsch_2choiceco() {
		return rsch_2choiceco;
	}
	public void setRsch_2choiceco(String rsch_2choiceco) {
		this.rsch_2choiceco = rsch_2choiceco;
	}
	public String getRsch_3choiceco() {
		return rsch_3choiceco;
	}
	public void setRsch_3choiceco(String rsch_3choiceco) {
		this.rsch_3choiceco = rsch_3choiceco;
	}
	public String getRsch_memo() {
		return rsch_memo;
	}
	public void setRsch_memo(String rsch_memo) {
		this.rsch_memo = rsch_memo;
	}
	
	public String getCse_outputflg() {
		return cse_outputflg;
	}
	public void setCse_outputflg(String cse_outputflg) {
		this.cse_outputflg = cse_outputflg;
	}
	
	public String getSelection_shubetu() {
		return selection_shubetu;
	}
	public void setSelection_shubetu(String selection_shubetu) {
		this.selection_shubetu = selection_shubetu;
	}
	public String getSelection2_336() {
		return selection2_336;
	}
	public void setSelection2_336(String selection2_336) {
		this.selection2_336 = selection2_336;
	}
	public String getSelection3_336() {
		return selection3_336;
	}
	public void setSelection3_336(String selection3_336) {
		this.selection3_336 = selection3_336;
	}
	public String getSelection4_336() {
		return selection4_336;
	}
	public void setSelection4_336(String selection4_336) {
		this.selection4_336 = selection4_336;
	}
	public String getSelection5_336() {
		return selection5_336;
	}
	public void setSelection5_336(String selection5_336) {
		this.selection5_336 = selection5_336;
	}
	public String getSelection6_336() {
		return selection6_336;
	}
	public void setSelection6_336(String selection6_336) {
		this.selection6_336 = selection6_336;
	}
	
}
