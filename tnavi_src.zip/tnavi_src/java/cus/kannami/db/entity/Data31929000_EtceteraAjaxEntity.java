/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� ���̑�����Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.07 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31929000_EtceteraAjaxEntity {

	/** �N�x */
	private String nendo;

	/** �w�N */
	private String grade;

	/** �w�Дԍ� */
	private String cls_stucode;

	/** ���̑����� */
	private String retc_value;


	public String getNendo() {
	    return nendo;
	}

	public void setNendo(String nendo) {
	    this.nendo = nendo;
	}

	public String getGrade() {
	    return grade;
	}

	public void setGrade(String grade) {
	    this.grade = grade;
	}

	public String getCls_stucode() {
	    return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
	    this.cls_stucode = cls_stucode;
	}

	public String getRetc_value() {
	    return retc_value;
	}

	public void setRetc_value(String retc_value) {
	    this.retc_value = retc_value;
	}

}
