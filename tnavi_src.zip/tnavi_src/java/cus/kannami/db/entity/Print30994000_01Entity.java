package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * �w��������(���쒬) �N���X���Entity.
 *
 * <B>Create</B> 2016.03.28 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print30994000_01Entity {

	/**
	 * �N���X�R�[�h
	 */
	private String hmr_clsno;
	 
	/**
	 * �N���X����
	 */
	private String hmr_name;
	
	/**
	 * �S�C����
	 */
	private String stf_name;

	public String getHmr_clsno() {
		return hmr_clsno;
	}

	public void setHmr_clsno(String hmr_clsno) {
		this.hmr_clsno = hmr_clsno;
	}

	public String getHmr_name() {
		return hmr_name;
	}

	public void setHmr_name(String hmr_name) {
		this.hmr_name = hmr_name;
	}

	public String getStf_name() {
		return stf_name;
	}

	public void setStf_name(String stf_name) {
		this.stf_name = stf_name;
	}
	
}
