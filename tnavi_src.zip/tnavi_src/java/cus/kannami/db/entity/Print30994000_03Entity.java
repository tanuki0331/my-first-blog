package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * �w��������(���쒬) �ƒ됔�����(�Z��o�����)�@Entity.
 *
 * <B>Create</B> 2016.03.28 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print30994000_03Entity {

	/**
	 * �����R�[�h
	 */
	private String bro_user;
	
	/**
	 * �����ԍ�
	 */
	private String cls_number;
	
	/**
	 * �w�Дԍ�
	 */
	private String bro_stucode;
	
	/**
	 * �Z��o���@�w�N
	 */
	private String rel_glade;
	
	/**
	 * �Z��o���@�g
	 */
	private String rel_class;
	
	/**
	 * �Z��o���@�����ԍ�
	 */
	private String rel_number;
	
	/**
	 * �Z��o���@�w�Дԍ�
	 */
	private String bro_bro_stucode;
	
	/**
	 * �Z��o���@����
	 */
	private String rel_stuname;

	public String getBro_user() {
		return bro_user;
	}

	public void setBro_user(String bro_user) {
		this.bro_user = bro_user;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getBro_stucode() {
		return bro_stucode;
	}

	public void setBro_stucode(String bro_stucode) {
		this.bro_stucode = bro_stucode;
	}

	public String getRel_glade() {
		return rel_glade;
	}

	public void setRel_glade(String rel_glade) {
		this.rel_glade = rel_glade;
	}

	public String getRel_class() {
		return rel_class;
	}

	public void setRel_class(String rel_class) {
		this.rel_class = rel_class;
	}

	public String getRel_number() {
		return rel_number;
	}

	public void setRel_number(String rel_number) {
		this.rel_number = rel_number;
	}

	public String getBro_bro_stucode() {
		return bro_bro_stucode;
	}

	public void setBro_bro_stucode(String bro_bro_stucode) {
		this.bro_bro_stucode = bro_bro_stucode;
	}

	public String getRel_stuname() {
		return rel_stuname;
	}

	public void setRel_stuname(String rel_stuname) {
		this.rel_stuname = rel_stuname;
	}
	
}
