package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) ���k��� Entity.
 * </PRE>
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31967000StudentEntity {

	/** 
	 * �w�Дԍ�
	 */
	private String cls_stucode;
	
	/**
	 * �w�N
	 */
	private String cls_glade;
	
	/**
	 * �g
	 */
	private String hmr_class;
	
	/**
	 * ��
	 */
	private String cls_number;
	
	/**
	 * ����
	 */
	private String st4_name;
	
	/**
	 * �]�����@
	 */
	private String srem_em;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_glade() {
		return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public String getHmr_class() {
		return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getSt4_name() {
		return st4_name;
	}

	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public String getSrem_em() {
		return srem_em;
	}

	public void setSrem_em(String srem_em) {
		this.srem_em = srem_em;
	}

}