/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 * �s�o�Z�����p�f�[�^�o�� ���k���Entity �N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31901000_01Entity {

	/** �o�͏� */
	private String srr_order;
	
	/** ���k���� */
	private String st4_name;

	/** �w�Дԍ� **/
	private String	cls_stucode;

	/** �w�N **/
	private String	cls_glade;

	/** ���� */
	private String sex;

	/** ���� */
	private String srr_kind;

	/** �p�����R�E���A�E�]�Z */
	private String srr_reason;
	
	/** ���ȓ����݌v */
	private String absenceSum;
	
	/** ���� + �ی������o�Z + (�x�����ށ�2) �݌v */
	private String etcSum;
	
	/** SC�ESSW�t���O */
	private String srr_scssw_flg; 
	
	/** �a�@�t���O */
	private String srr_hospital_flg;
	
	/** �������k���t���O */
	private String srr_consultation_flg;
	
	/** �K���w�������t���O */
	private String srr_spclassroom_flg;
	
	/** �t���[�t���O */
	private String srr_free_flg;
	
	/** ���̑��t���O */
	private String srr_others_flg;

    /* �ȉ��AExcel�o�͎��ɂ̂ݕK�v�ƂȂ鍀�� */
	/** �s�o�Z�����݌v */
	private String futoukoCnt;
	
	/** �a�������݌v */
	private String sickCnt;
	
	/** ���̑������݌v */
	private String otherCnt;
	
	/** �x�����ޓ����݌v */
	private String lateLeaveCnt;
	
	/** �ی����������݌v */
	private String hokenCnt;
	
	/** �K�w�����݌v */
	private String tekioCnt;

	
	public String getSrr_order() {
		return srr_order;
	}

	public void setSrr_order(String srr_order) {
		this.srr_order = srr_order;
	}

	public String getSt4_name() {
		return st4_name;
	}

	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_glade() {
		return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getSrr_kind() {
		return srr_kind;
	}

	public void setSrr_kind(String srr_kind) {
		this.srr_kind = srr_kind;
	}

	public String getSrr_reason() {
		return srr_reason;
	}

	public void setSrr_reason(String srr_reason) {
		this.srr_reason = srr_reason;
	}

	public String getAbsenceSum() {
		return absenceSum;
	}

	public void setAbsenceSum(String absenceSum) {
		this.absenceSum = absenceSum;
	}

	public String getEtcSum() {
		return etcSum;
	}

	public void setEtcSum(String etcSum) {
		this.etcSum = etcSum;
	}

	public String getSrr_scssw_flg() {
		return srr_scssw_flg;
	}

	public void setSrr_scssw_flg(String srr_scssw_flg) {
		this.srr_scssw_flg = srr_scssw_flg;
	}

	public String getSrr_hospital_flg() {
		return srr_hospital_flg;
	}

	public void setSrr_hospital_flg(String srr_hospital_flg) {
		this.srr_hospital_flg = srr_hospital_flg;
	}

	public String getSrr_consultation_flg() {
		return srr_consultation_flg;
	}

	public void setSrr_consultation_flg(String srr_consultation_flg) {
		this.srr_consultation_flg = srr_consultation_flg;
	}

	public String getSrr_spclassroom_flg() {
		return srr_spclassroom_flg;
	}

	public void setSrr_spclassroom_flg(String srr_spclassroom_flg) {
		this.srr_spclassroom_flg = srr_spclassroom_flg;
	}

	public String getSrr_free_flg() {
		return srr_free_flg;
	}

	public void setSrr_free_flg(String srr_free_flg) {
		this.srr_free_flg = srr_free_flg;
	}

	public String getSrr_others_flg() {
		return srr_others_flg;
	}

	public void setSrr_others_flg(String srr_others_flg) {
		this.srr_others_flg = srr_others_flg;
	}

	public String getFutoukoCnt() {
		return futoukoCnt;
	}

	public void setFutoukoCnt(String futoukoCnt) {
		this.futoukoCnt = futoukoCnt;
	}

	public String getSickCnt() {
		return sickCnt;
	}

	public void setSickCnt(String sickCnt) {
		this.sickCnt = sickCnt;
	}

	public String getOtherCnt() {
		return otherCnt;
	}

	public void setOtherCnt(String otherCnt) {
		this.otherCnt = otherCnt;
	}

	public String getLateLeaveCnt() {
		return lateLeaveCnt;
	}

	public void setLateLeaveCnt(String lateLeaveCnt) {
		this.lateLeaveCnt = lateLeaveCnt;
	}

	public String getHokenCnt() {
		return hokenCnt;
	}

	public void setHokenCnt(String hokenCnt) {
		this.hokenCnt = hokenCnt;
	}

	public String getTekioCnt() {
		return tekioCnt;
	}

	public void setTekioCnt(String tekioCnt) {
		this.tekioCnt = tekioCnt;
	}
	
}
