/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� ���Ȑ���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.07 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31929000_OutputtermEntity {


	/** �Ώ۔N�x */
	private String nendo;

	/** �Ώۊw�N */
	private String grade;

	/** �o�͎����R�[�h */
	private String gopt_goptcode;

	/** �\���� */
	private String gopt_order;

	/** �o�͖��� */
	private String dispname;


	public String getNendo() {
	    return nendo;
	}

	public void setNendo(String nendo) {
	    this.nendo = nendo;
	}

	public String getGrade() {
	    return grade;
	}

	public void setGrade(String grade) {
	    this.grade = grade;
	}

	public String getGopt_goptcode() {
	    return gopt_goptcode;
	}

	public void setGopt_goptcode(String gopt_goptcode) {
	    this.gopt_goptcode = gopt_goptcode;
	}

	public String getGopt_order() {
	    return gopt_order;
	}

	public void setGopt_order(String gopt_order) {
	    this.gopt_order = gopt_order;
	}

	public String getDispname() {
	    return dispname;
	}

	public void setDispname(String dispname) {
	    this.dispname = dispname;
	}

}
