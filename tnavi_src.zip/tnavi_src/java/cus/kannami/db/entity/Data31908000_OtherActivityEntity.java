package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �������̋L�^�̏o��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31908000_OtherActivityEntity {

	/**
	 * �w�Дԍ�
	 */
	private String retc_stucode;
		
	/**
	 * ����ID
	 */
	private String retc_rtasitem;

	/**
	 * �]��
	 */
	private String retc_value;

	public String getRetc_stucode() {
		return retc_stucode;
	}

	public void setRetc_stucode(String retc_stucode) {
		this.retc_stucode = retc_stucode;
	}

	public String getRetc_rtasitem() {
		return retc_rtasitem;
	}

	public void setRetc_rtasitem(String retc_rtasitem) {
		this.retc_rtasitem = retc_rtasitem;
	}

	public String getRetc_value() {
		return retc_value;
	}

	public void setRetc_value(String retc_value) {
		this.retc_value = retc_value;
	}

	

}
