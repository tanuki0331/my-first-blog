package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.07.11 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31961000_ItemViewpointEntity {

	/** �ʒm�\�p���Ȗ� */
	private String si_reportname;

	/** ���ȃR�[�h */
	private String si_item;

	/** �ϓ_�R�[�h */
	private String srivt_srivtcode;

	/** �ʊϓ_ */
	private String srvpv_indivivp;

	public String getSi_reportname() {
		return si_reportname;
	}
	public void setSi_reportname(String si_reportname) {
		this.si_reportname = si_reportname;
	}
	public String getSi_item() {
		return si_item;
	}
	public void setSi_item(String si_item) {
		this.si_item = si_item;
	}
	public String getSrivt_srivtcode() {
		return srivt_srivtcode;
	}
	public void setSrivt_srivtcode(String srivt_srivtcode) {
		this.srivt_srivtcode = srivt_srivtcode;
	}
	public String getSrvpv_indivivp() {
		return srvpv_indivivp;
	}
	public void setSrvpv_indivivp(String srvpv_indivivp) {
		this.srvpv_indivivp = srvpv_indivivp;
	}


}
