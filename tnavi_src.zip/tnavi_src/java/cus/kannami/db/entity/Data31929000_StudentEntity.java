/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� ���k�ꗗEntity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.04 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31929000_StudentEntity {


	/** �o�Ȕԍ� */
	private String cls_number;

	/** �w�Дԍ� */
	private String cls_stucode;

	/** ���k���� */
	private String st4_name;

	/** ���l */
	private String acr_record;


	public String getCls_number() {
	    return cls_number;
	}

	public void setCls_number(String cls_number) {
	    this.cls_number = cls_number;
	}

	public String getCls_stucode() {
	    return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
	    this.cls_stucode = cls_stucode;
	}

	public String getSt4_name() {
	    return st4_name;
	}

	public void setSt4_name(String st4_name) {
	    this.st4_name = st4_name;
	}

	public String getAcr_record() {
	    return acr_record;
	}

	public void setAcr_record(String acr_record) {
	    this.acr_record = acr_record;
	}

}
