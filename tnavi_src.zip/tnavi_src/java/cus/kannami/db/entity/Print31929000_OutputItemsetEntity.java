/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� �o�͑Ώۋ���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.08 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31929000_OutputItemsetEntity {

	/** ���ȃR�[�h */
	private String cod_code;

	/** ���Ȗ��� */
	private String cod_name3;

	/** �\���� */
	private String itd_order;


	public String getCod_code() {
	    return cod_code;
	}

	public void setCod_code(String cod_code) {
	    this.cod_code = cod_code;
	}

	public String getCod_name3() {
	    return cod_name3;
	}

	public void setCod_name3(String cod_name3) {
	    this.cod_name3 = cod_name3;
	}

	public String getItd_order() {
	    return itd_order;
	}

	public void setItd_order(String itd_order) {
	    this.itd_order = itd_order;
	}

}
