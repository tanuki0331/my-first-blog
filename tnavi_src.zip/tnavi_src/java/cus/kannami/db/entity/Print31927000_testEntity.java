/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 *  �e�X�g���� �\���p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_testEntity {

	private String cls_stucode ;
	private String cls_number;
	private String item_code;
	private String item_name;
	private String score;
	private String abtt_date;
	private String abtt_code;
	private String abtt_name2;

	
	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getCls_number() {
		return cls_number;
	}
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	public String getItem_code() {
		return item_code;
	}
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getAbtt_date() {
		return abtt_date;
	}
	public void setAbtt_date(String abtt_date) {
		this.abtt_date = abtt_date;
	}
	public String getAbtt_code() {
		return abtt_code;
	}
	public void setAbtt_code(String abtt_code) {
		this.abtt_code = abtt_code;
	}
	public String getAbtt_name2() {
		return abtt_name2;
	}
	public void setAbtt_name2(String abtt_name2) {
		this.abtt_name2 = abtt_name2;
	}
	
	
	
}
