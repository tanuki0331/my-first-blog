package jp.co.systemd.tnavi.cus.kannami.db.entity;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.common.print.ExcelSimpleListPrintable;

/**
 * �w��������(���쒬) �w�N������Entity.
 *
 * <B>Create</B> 2016.03.29 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print30994000_06Entity implements ExcelSimpleListPrintable {

	/**
	 * �o�͑Ώہ@0�F�w������A1�F�����n������A2�F�w���`�F�b�N�\�A3�F�w���`�F�b�N�\(�w�N)
	 */
	private int output_target;

	/** �敪�@1:���w�Z,2:���w�Z */
	private String useKind2;

	/** �s�ԍ� */
	private int row;

	/**
	 * �w�Дԍ�(1���)
	 */
	private String cls_stucode_01;

	/**
	 * �g(1���)
	 */
    private String hmr_class_01;

	/**
	 * �����ԍ�(1���)
	 */
    private String cls_number_01;

    /**
     * ���k����(1���)
     */
    private String st4_name_01;

    /**
     * ����(1���)
     */
    private String stu_sex_01;

    /**
     * �_�~�[1(1���)
     */
    private String dummy1_01;

    /**
     * �_�~�[2(1���)
     */
    private String dummy2_01;

    /**
     * �_�~�[3(1���)
     */
    private String dummy3_01;

    /**
     * �_�~�[4(1���)
     */
    private String dummy4_01;

    /**
     * �_�~�[5(1���)
     */
    private String dummy5_01;

	/**
	 * �w�Дԍ�(2���)
	 */
	private String cls_stucode_02;

	/**
	 * �g(2���)
	 */
    private String hmr_class_02;

	/**
	 * �����ԍ�(2���)
	 */
    private String cls_number_02;

    /**
     * ���k����(2���)
     */
    private String st4_name_02;

    /**
     * ����(2���)
     */
    private String stu_sex_02;

    /**
     * �_�~�[1(2���)
     */
    private String dummy1_02;

    /**
     * �_�~�[2(2���)
     */
    private String dummy2_02;

    /**
     * �_�~�[3(2���)
     */
    private String dummy3_02;

    /**
     * �_�~�[4(2���)
     */
    private String dummy4_02;

    /**
     * �_�~�[5(2���)
     */
    private String dummy5_02;

	/**
	 * �w�Дԍ�(3���)
	 */
	private String cls_stucode_03;

	/**
	 * �g(3���)
	 */
    private String hmr_class_03;

	/**
	 * �����ԍ�(3���)
	 */
    private String cls_number_03;

    /**
     * ���k����(3���)
     */
    private String st4_name_03;

    /**
     * ����(3���)
     */
    private String stu_sex_03;

    /**
     * �_�~�[1(3���)
     */
    private String dummy1_03;

    /**
     * �_�~�[2(3���)
     */
    private String dummy2_03;

    /**
     * �_�~�[3(3���)
     */
    private String dummy3_03;

    /**
     * �_�~�[4(3���)
     */
    private String dummy4_03;

    /**
     * �_�~�[5(3���)
     */
    private String dummy5_03;

	/**
	 * �w�Дԍ�(4���)
	 */
	private String cls_stucode_04;

	/**
	 * �g(4���)
	 */
    private String hmr_class_04;

	/**
	 * �����ԍ�(4���)
	 */
    private String cls_number_04;

    /**
     * ���k����(4���)
     */
    private String st4_name_04;

    /**
     * ����(4���)
     */
    private String stu_sex_04;

    /**
     * �_�~�[1(4���)
     */
    private String dummy1_04;

    /**
     * �_�~�[2(4���)
     */
    private String dummy2_04;

    /**
     * �_�~�[3(4���)
     */
    private String dummy3_04;

    /**
     * �_�~�[4(4���)
     */
    private String dummy4_04;

    /**
     * �_�~�[5(4���)
     */
    private String dummy5_04;

	/**
	 * �w�Дԍ�(X���)
	 */
	private String cls_stucode_05;

	/**
	 * �g(X���)
	 */
    private String hmr_class_05;

	/**
	 * �����ԍ�(X���)
	 */
    private String cls_number_05;

    /**
     * ���k����(X���)
     */
    private String st4_name_05;

    /**
     * ����(X���)
     */
    private String stu_sex_05;

    /**
     * �_�~�[1(X���)
     */
    private String dummy1_05;

    /**
     * �_�~�[2(X���)
     */
    private String dummy2_05;

    /**
     * �_�~�[3(X���)
     */
    private String dummy3_05;

    /**
     * �_�~�[4(X���)
     */
    private String dummy4_05;

    /**
     * �_�~�[5(X���)
     */
    private String dummy5_05;

    /**
     * ���ʃR�[�h
     */
    private String sexName;

	/**
	 * @return output_target
	 */
	public int getOutput_target() {
		return output_target;
	}

	/**
	 * @param output_target the output_target to set
	 */
	public void setOutput_target(int output_target) {
		this.output_target = output_target;
	}

	/**
	 * @return useKind2
	 */
	public String getUseKind2() {
		return useKind2;
	}

	/**
	 * @param useKind2 the useKind2 to set
	 */
	public void setUseKind2(String useKind2) {
		this.useKind2 = useKind2;
	}

	/**
	 * @return row
	 */
	public int getRow() {
		return row;
	}

	/**
	 * @param row the row to set
	 */
	public void setRow(int row) {
		this.row = row;
	}

	/**
	 * @return cls_stucode_01
	 */
	public String getCls_stucode_01() {
		return cls_stucode_01;
	}

	/**
	 * @param cls_stucode_01 the cls_stucode_01 to set
	 */
	public void setCls_stucode_01(String cls_stucode_01) {
		this.cls_stucode_01 = cls_stucode_01;
	}

	/**
	 * @return hmr_class_01
	 */
	public String getHmr_class_01() {
		return hmr_class_01;
	}

	/**
	 * @param hmr_class_01 the hmr_class_01 to set
	 */
	public void setHmr_class_01(String hmr_class_01) {
		this.hmr_class_01 = hmr_class_01;
	}

	/**
	 * @return cls_number_01
	 */
	public String getCls_number_01() {
		return cls_number_01;
	}

	/**
	 * @param cls_number_01 the cls_number_01 to set
	 */
	public void setCls_number_01(String cls_number_01) {
		this.cls_number_01 = cls_number_01;
	}

	/**
	 * @return st4_name_01
	 */
	public String getSt4_name_01() {
		return st4_name_01;
	}

	/**
	 * @param st4_name_01 the st4_name_01 to set
	 */
	public void setSt4_name_01(String st4_name_01) {
		this.st4_name_01 = st4_name_01;
	}

	/**
	 * @return stu_sex_01
	 */
	public String getStu_sex_01() {
		return stu_sex_01;
	}

	/**
	 * @param stu_sex_01 the stu_sex_01 to set
	 */
	public void setStu_sex_01(String stu_sex_01) {
		this.stu_sex_01 = stu_sex_01;
	}

	/**
	 * @return dummy1_01
	 */
	public String getDummy1_01() {
		return dummy1_01;
	}

	/**
	 * @param dummy1_01 the dummy1_01 to set
	 */
	public void setDummy1_01(String dummy1_01) {
		this.dummy1_01 = dummy1_01;
	}

	/**
	 * @return dummy2_01
	 */
	public String getDummy2_01() {
		return dummy2_01;
	}

	/**
	 * @param dummy2_01 the dummy2_01 to set
	 */
	public void setDummy2_01(String dummy2_01) {
		this.dummy2_01 = dummy2_01;
	}

	/**
	 * @return dummy3_01
	 */
	public String getDummy3_01() {
		return dummy3_01;
	}

	/**
	 * @param dummy3_01 the dummy3_01 to set
	 */
	public void setDummy3_01(String dummy3_01) {
		this.dummy3_01 = dummy3_01;
	}

	/**
	 * @return dummy4_01
	 */
	public String getDummy4_01() {
		return dummy4_01;
	}

	/**
	 * @param dummy4_01 the dummy4_01 to set
	 */
	public void setDummy4_01(String dummy4_01) {
		this.dummy4_01 = dummy4_01;
	}

	/**
	 * @return dummy5_01
	 */
	public String getDummy5_01() {
		return dummy5_01;
	}

	/**
	 * @param dummy5_01 the dummy5_01 to set
	 */
	public void setDummy5_01(String dummy5_01) {
		this.dummy5_01 = dummy5_01;
	}

	/**
	 * @return cls_stucode_02
	 */
	public String getCls_stucode_02() {
		return cls_stucode_02;
	}

	/**
	 * @param cls_stucode_02 the cls_stucode_02 to set
	 */
	public void setCls_stucode_02(String cls_stucode_02) {
		this.cls_stucode_02 = cls_stucode_02;
	}

	/**
	 * @return hmr_class_02
	 */
	public String getHmr_class_02() {
		return hmr_class_02;
	}

	/**
	 * @param hmr_class_02 the hmr_class_02 to set
	 */
	public void setHmr_class_02(String hmr_class_02) {
		this.hmr_class_02 = hmr_class_02;
	}

	/**
	 * @return cls_number_02
	 */
	public String getCls_number_02() {
		return cls_number_02;
	}

	/**
	 * @param cls_number_02 the cls_number_02 to set
	 */
	public void setCls_number_02(String cls_number_02) {
		this.cls_number_02 = cls_number_02;
	}

	/**
	 * @return st4_name_02
	 */
	public String getSt4_name_02() {
		return st4_name_02;
	}

	/**
	 * @param st4_name_02 the st4_name_02 to set
	 */
	public void setSt4_name_02(String st4_name_02) {
		this.st4_name_02 = st4_name_02;
	}

	/**
	 * @return stu_sex_02
	 */
	public String getStu_sex_02() {
		return stu_sex_02;
	}

	/**
	 * @param stu_sex_02 the stu_sex_02 to set
	 */
	public void setStu_sex_02(String stu_sex_02) {
		this.stu_sex_02 = stu_sex_02;
	}

	/**
	 * @return dummy1_02
	 */
	public String getDummy1_02() {
		return dummy1_02;
	}

	/**
	 * @param dummy1_02 the dummy1_02 to set
	 */
	public void setDummy1_02(String dummy1_02) {
		this.dummy1_02 = dummy1_02;
	}

	/**
	 * @return dummy2_02
	 */
	public String getDummy2_02() {
		return dummy2_02;
	}

	/**
	 * @param dummy2_02 the dummy2_02 to set
	 */
	public void setDummy2_02(String dummy2_02) {
		this.dummy2_02 = dummy2_02;
	}

	/**
	 * @return dummy3_02
	 */
	public String getDummy3_02() {
		return dummy3_02;
	}

	/**
	 * @param dummy3_02 the dummy3_02 to set
	 */
	public void setDummy3_02(String dummy3_02) {
		this.dummy3_02 = dummy3_02;
	}

	/**
	 * @return dummy4_02
	 */
	public String getDummy4_02() {
		return dummy4_02;
	}

	/**
	 * @param dummy4_02 the dummy4_02 to set
	 */
	public void setDummy4_02(String dummy4_02) {
		this.dummy4_02 = dummy4_02;
	}

	/**
	 * @return dummy5_02
	 */
	public String getDummy5_02() {
		return dummy5_02;
	}

	/**
	 * @param dummy5_02 the dummy5_02 to set
	 */
	public void setDummy5_02(String dummy5_02) {
		this.dummy5_02 = dummy5_02;
	}

	/**
	 * @return cls_stucode_03
	 */
	public String getCls_stucode_03() {
		return cls_stucode_03;
	}

	/**
	 * @param cls_stucode_03 the cls_stucode_03 to set
	 */
	public void setCls_stucode_03(String cls_stucode_03) {
		this.cls_stucode_03 = cls_stucode_03;
	}

	/**
	 * @return hmr_class_03
	 */
	public String getHmr_class_03() {
		return hmr_class_03;
	}

	/**
	 * @param hmr_class_03 the hmr_class_03 to set
	 */
	public void setHmr_class_03(String hmr_class_03) {
		this.hmr_class_03 = hmr_class_03;
	}

	/**
	 * @return cls_number_03
	 */
	public String getCls_number_03() {
		return cls_number_03;
	}

	/**
	 * @param cls_number_03 the cls_number_03 to set
	 */
	public void setCls_number_03(String cls_number_03) {
		this.cls_number_03 = cls_number_03;
	}

	/**
	 * @return st4_name_03
	 */
	public String getSt4_name_03() {
		return st4_name_03;
	}

	/**
	 * @param st4_name_03 the st4_name_03 to set
	 */
	public void setSt4_name_03(String st4_name_03) {
		this.st4_name_03 = st4_name_03;
	}

	/**
	 * @return stu_sex_03
	 */
	public String getStu_sex_03() {
		return stu_sex_03;
	}

	/**
	 * @param stu_sex_03 the stu_sex_03 to set
	 */
	public void setStu_sex_03(String stu_sex_03) {
		this.stu_sex_03 = stu_sex_03;
	}

	/**
	 * @return dummy1_03
	 */
	public String getDummy1_03() {
		return dummy1_03;
	}

	/**
	 * @param dummy1_03 the dummy1_03 to set
	 */
	public void setDummy1_03(String dummy1_03) {
		this.dummy1_03 = dummy1_03;
	}

	/**
	 * @return dummy2_03
	 */
	public String getDummy2_03() {
		return dummy2_03;
	}

	/**
	 * @param dummy2_03 the dummy2_03 to set
	 */
	public void setDummy2_03(String dummy2_03) {
		this.dummy2_03 = dummy2_03;
	}

	/**
	 * @return dummy3_03
	 */
	public String getDummy3_03() {
		return dummy3_03;
	}

	/**
	 * @param dummy3_03 the dummy3_03 to set
	 */
	public void setDummy3_03(String dummy3_03) {
		this.dummy3_03 = dummy3_03;
	}

	/**
	 * @return dummy4_03
	 */
	public String getDummy4_03() {
		return dummy4_03;
	}

	/**
	 * @param dummy4_03 the dummy4_03 to set
	 */
	public void setDummy4_03(String dummy4_03) {
		this.dummy4_03 = dummy4_03;
	}

	/**
	 * @return dummy5_03
	 */
	public String getDummy5_03() {
		return dummy5_03;
	}

	/**
	 * @param dummy5_03 the dummy5_03 to set
	 */
	public void setDummy5_03(String dummy5_03) {
		this.dummy5_03 = dummy5_03;
	}

	/**
	 * @return cls_stucode_04
	 */
	public String getCls_stucode_04() {
		return cls_stucode_04;
	}

	/**
	 * @param cls_stucode_04 the cls_stucode_04 to set
	 */
	public void setCls_stucode_04(String cls_stucode_04) {
		this.cls_stucode_04 = cls_stucode_04;
	}

	/**
	 * @return hmr_class_04
	 */
	public String getHmr_class_04() {
		return hmr_class_04;
	}

	/**
	 * @param hmr_class_04 the hmr_class_04 to set
	 */
	public void setHmr_class_04(String hmr_class_04) {
		this.hmr_class_04 = hmr_class_04;
	}

	/**
	 * @return cls_number_04
	 */
	public String getCls_number_04() {
		return cls_number_04;
	}

	/**
	 * @param cls_number_04 the cls_number_04 to set
	 */
	public void setCls_number_04(String cls_number_04) {
		this.cls_number_04 = cls_number_04;
	}

	/**
	 * @return st4_name_04
	 */
	public String getSt4_name_04() {
		return st4_name_04;
	}

	/**
	 * @param st4_name_04 the st4_name_04 to set
	 */
	public void setSt4_name_04(String st4_name_04) {
		this.st4_name_04 = st4_name_04;
	}

	/**
	 * @return stu_sex_04
	 */
	public String getStu_sex_04() {
		return stu_sex_04;
	}

	/**
	 * @param stu_sex_04 the stu_sex_04 to set
	 */
	public void setStu_sex_04(String stu_sex_04) {
		this.stu_sex_04 = stu_sex_04;
	}

	/**
	 * @return dummy1_04
	 */
	public String getDummy1_04() {
		return dummy1_04;
	}

	/**
	 * @param dummy1_04 the dummy1_04 to set
	 */
	public void setDummy1_04(String dummy1_04) {
		this.dummy1_04 = dummy1_04;
	}

	/**
	 * @return dummy2_04
	 */
	public String getDummy2_04() {
		return dummy2_04;
	}

	/**
	 * @param dummy2_04 the dummy2_04 to set
	 */
	public void setDummy2_04(String dummy2_04) {
		this.dummy2_04 = dummy2_04;
	}

	/**
	 * @return dummy3_04
	 */
	public String getDummy3_04() {
		return dummy3_04;
	}

	/**
	 * @param dummy3_04 the dummy3_04 to set
	 */
	public void setDummy3_04(String dummy3_04) {
		this.dummy3_04 = dummy3_04;
	}

	/**
	 * @return dummy4_04
	 */
	public String getDummy4_04() {
		return dummy4_04;
	}

	/**
	 * @param dummy4_04 the dummy4_04 to set
	 */
	public void setDummy4_04(String dummy4_04) {
		this.dummy4_04 = dummy4_04;
	}

	/**
	 * @return dummy5_04
	 */
	public String getDummy5_04() {
		return dummy5_04;
	}

	/**
	 * @param dummy5_04 the dummy5_04 to set
	 */
	public void setDummy5_04(String dummy5_04) {
		this.dummy5_04 = dummy5_04;
	}

	/**
	 * @return cls_stucode_05
	 */
	public String getCls_stucode_05() {
		return cls_stucode_05;
	}

	/**
	 * @param cls_stucode_05 the cls_stucode_05 to set
	 */
	public void setCls_stucode_05(String cls_stucode_05) {
		this.cls_stucode_05 = cls_stucode_05;
	}

	/**
	 * @return hmr_class_05
	 */
	public String getHmr_class_05() {
		return hmr_class_05;
	}

	/**
	 * @param hmr_class_05 the hmr_class_05 to set
	 */
	public void setHmr_class_05(String hmr_class_05) {
		this.hmr_class_05 = hmr_class_05;
	}

	/**
	 * @return cls_number_05
	 */
	public String getCls_number_05() {
		return cls_number_05;
	}

	/**
	 * @param cls_number_05 the cls_number_05 to set
	 */
	public void setCls_number_05(String cls_number_05) {
		this.cls_number_05 = cls_number_05;
	}

	/**
	 * @return st4_name_05
	 */
	public String getSt4_name_05() {
		return st4_name_05;
	}

	/**
	 * @param st4_name_05 the st4_name_05 to set
	 */
	public void setSt4_name_05(String st4_name_05) {
		this.st4_name_05 = st4_name_05;
	}

	/**
	 * @return stu_sex_05
	 */
	public String getStu_sex_05() {
		return stu_sex_05;
	}

	/**
	 * @param stu_sex_05 the stu_sex_05 to set
	 */
	public void setStu_sex_05(String stu_sex_05) {
		this.stu_sex_05 = stu_sex_05;
	}

	/**
	 * @return dummy1_05
	 */
	public String getDummy1_05() {
		return dummy1_05;
	}

	/**
	 * @param dummy1_05 the dummy1_05 to set
	 */
	public void setDummy1_05(String dummy1_05) {
		this.dummy1_05 = dummy1_05;
	}

	/**
	 * @return dummy2_05
	 */
	public String getDummy2_05() {
		return dummy2_05;
	}

	/**
	 * @param dummy2_05 the dummy2_05 to set
	 */
	public void setDummy2_05(String dummy2_05) {
		this.dummy2_05 = dummy2_05;
	}

	/**
	 * @return dummy3_05
	 */
	public String getDummy3_05() {
		return dummy3_05;
	}

	/**
	 * @param dummy3_05 the dummy3_05 to set
	 */
	public void setDummy3_05(String dummy3_05) {
		this.dummy3_05 = dummy3_05;
	}

	/**
	 * @return dummy4_05
	 */
	public String getDummy4_05() {
		return dummy4_05;
	}

	/**
	 * @param dummy4_05 the dummy4_05 to set
	 */
	public void setDummy4_05(String dummy4_05) {
		this.dummy4_05 = dummy4_05;
	}

	/**
	 * @return dummy5_05
	 */
	public String getDummy5_05() {
		return dummy5_05;
	}

	/**
	 * @param dummy5_05 the dummy5_05 to set
	 */
	public void setDummy5_05(String dummy5_05) {
		this.dummy5_05 = dummy5_05;
	}

	public String getSexName() {
		return sexName;
	}

	public void setSexName(String sexName) {
		this.sexName = sexName;
	}

	@Override
	public List<Object> getRowDataSameKeys() {
		return getDataList();
	}

	@Override
	public List<Object> getRowDataAnotherKeys() {
		return getDataList();
	}

	@Override
	public boolean isKeyBreak(ExcelSimpleListPrintable breakKey) {

		int breakRow = 5;
		if(row % breakRow == 0){
			return true;
		}

		return false;
	}

	/**
	 * Excel�o�͗p��DataList���쐬����
	 * @return DataList
	 */
	private List<Object> getDataList() {
		List<Object> dataList = new ArrayList<Object>();

		// --- 1���
		dataList.add(hmr_class_01);		// �g
		dataList.add(cls_number_01);	// ��
		dataList.add(st4_name_01);		// ����
		dataList.add(stu_sex_01);		// ����
		dataList.add(dummy1_01);		// �_�~�[1�`5
		dataList.add(dummy2_01);
		dataList.add(dummy3_01);
		dataList.add(dummy4_01);
		dataList.add(dummy5_01);
		// --- 2���
		dataList.add(hmr_class_02);		// �g
		dataList.add(cls_number_02);	// ��
		dataList.add(st4_name_02);		// ����
		dataList.add(stu_sex_02);		// ����
		dataList.add(dummy1_02);		// �_�~�[1�`5
		dataList.add(dummy2_02);
		dataList.add(dummy3_02);
		dataList.add(dummy4_02);
		dataList.add(dummy5_02);
		// --- 3���
		dataList.add(hmr_class_03);		// �g
		dataList.add(cls_number_03);	// ��
		dataList.add(st4_name_03);		// ����
		dataList.add(stu_sex_03);		// ����
		dataList.add(dummy1_03);		// �_�~�[1�`5
		dataList.add(dummy2_03);
		dataList.add(dummy3_03);
		dataList.add(dummy4_03);
		dataList.add(dummy5_03);
		// --- 4���
		dataList.add(hmr_class_04);		// �g
		dataList.add(cls_number_04);	// ��
		dataList.add(st4_name_04);		// ����
		dataList.add(stu_sex_04);		// ����
		dataList.add(dummy1_04);		// �_�~�[1�`5
		dataList.add(dummy2_04);
		dataList.add(dummy3_04);
		dataList.add(dummy4_04);
		dataList.add(dummy5_04);
		// --- 5���
		dataList.add(hmr_class_05);		// �g
		dataList.add(cls_number_05);	// ��
		dataList.add(st4_name_05);		// ����
		dataList.add(stu_sex_05);		// ����
		dataList.add(dummy1_05);		// �_�~�[1�`5
		dataList.add(dummy2_05);
		dataList.add(dummy3_05);
		dataList.add(dummy4_05);
		dataList.add(dummy5_05);

		return dataList;
	}
}
