/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INC, All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 *  ���� �\���p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_attendEntity {

	private String gar_user ;
	private String gar_year ;
	private String gar_stucode; 
 	private String gar_grade ;
	private String gar_count ;
	private String gar_stop ;
	private String gar_must ;
	private String gar_absence ;
	private String gar_attend ;
	private String gar_late ;
	private String gar_leave ;
	private String gar_memo ;
	private String gar_update; 
	private String gar_upuser;
	public String getGar_user() {
		return gar_user;
	}
	public void setGar_user(String gar_user) {
		this.gar_user = gar_user;
	}
	public String getGar_year() {
		return gar_year;
	}
	public void setGar_year(String gar_year) {
		this.gar_year = gar_year;
	}
	public String getGar_stucode() {
		return gar_stucode;
	}
	public void setGar_stucode(String gar_stucode) {
		this.gar_stucode = gar_stucode;
	}
	public String getGar_grade() {
		return gar_grade;
	}
	public void setGar_grade(String gar_grade) {
		this.gar_grade = gar_grade;
	}
	public String getGar_count() {
		return gar_count;
	}
	public void setGar_count(String gar_count) {
		this.gar_count = gar_count;
	}
	public String getGar_stop() {
		return gar_stop;
	}
	public void setGar_stop(String gar_stop) {
		this.gar_stop = gar_stop;
	}
	public String getGar_must() {
		return gar_must;
	}
	public void setGar_must(String gar_must) {
		this.gar_must = gar_must;
	}
	public String getGar_absence() {
		return gar_absence;
	}
	public void setGar_absence(String gar_absence) {
		this.gar_absence = gar_absence;
	}
	public String getGar_attend() {
		return gar_attend;
	}
	public void setGar_attend(String gar_attend) {
		this.gar_attend = gar_attend;
	}
	public String getGar_late() {
		return gar_late;
	}
	public void setGar_late(String gar_late) {
		this.gar_late = gar_late;
	}
	public String getGar_leave() {
		return gar_leave;
	}
	public void setGar_leave(String gar_leave) {
		this.gar_leave = gar_leave;
	}
	public String getGar_memo() {
		return gar_memo;
	}
	public void setGar_memo(String gar_memo) {
		this.gar_memo = gar_memo;
	}
	public String getGar_update() {
		return gar_update;
	}
	public void setGar_update(String gar_update) {
		this.gar_update = gar_update;
	}
	public String getGar_upuser() {
		return gar_upuser;
	}
	public void setGar_upuser(String gar_upuser) {
		this.gar_upuser = gar_upuser;
	}
	
 
	
	
}
