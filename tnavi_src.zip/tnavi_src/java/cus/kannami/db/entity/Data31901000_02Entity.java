/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 * �s�o�Z�����p�f�[�^�o�� ���k���i���ʁjEntity �N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31901000_02Entity {

	/**
	 * �����l
	 */
	public final static String DEFALUT_VALUE = "";
	
	/** �w�Дԍ� */
	private String att_stucode = DEFALUT_VALUE;
	
	/** �� */
	private String att_month = DEFALUT_VALUE;
	
	/** ���ȓ��� */
	private String absenceCnt = DEFALUT_VALUE;
	
	/** �x���E���ޓ��� */
	private String lateLeaveCnt = DEFALUT_VALUE;
	
	/** �ی��������� */
	private String hokenCnt = DEFALUT_VALUE;
	
	/** �K���w���������� */
	private String tekioCnt = DEFALUT_VALUE;

	public String getAtt_stucode() {
		return att_stucode;
	}

	public void setAtt_stucode(String att_stucode) {
		this.att_stucode = att_stucode;
	}

	public String getAtt_month() {
		return att_month;
	}

	public void setAtt_month(String att_month) {
		this.att_month = att_month;
	}

	public String getAbsenceCnt() {
		return absenceCnt;
	}

	public void setAbsenceCnt(String absenceCnt) {
		this.absenceCnt = absenceCnt;
	}

	public String getLateLeaveCnt() {
		return lateLeaveCnt;
	}

	public void setLateLeaveCnt(String lateLeaveCnt) {
		this.lateLeaveCnt = lateLeaveCnt;
	}

	public String getHokenCnt() {
		return hokenCnt;
	}

	public void setHokenCnt(String hokenCnt) {
		this.hokenCnt = hokenCnt;
	}

	public String getTekioCnt() {
		return tekioCnt;
	}

	public void setTekioCnt(String tekioCnt) {
		this.tekioCnt = tekioCnt;
	}

}
