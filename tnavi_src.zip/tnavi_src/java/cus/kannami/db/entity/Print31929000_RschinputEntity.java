/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� �i�H��]Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.09 BY SD nishizawa<BR>
 * <B>Create</B> 2017.06.19 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31929000_RschinputEntity {

	/** �w�Дԍ� */
	private String cls_stucode;

	/** ������ */
	private String rsch_time;

	/** �u�]�Z�R�[�h */
	private String rsch_choiceed;

	/** �u�]�Z�� */
	private String scl_sname;

	/** �w�ȓ����� */
	private String scld_depsname;

	/** �I����ʃR�[�h */
	private String rsch_selection;

	/** �I���敪(1:��ʁA���E�A���̑� 2:����) */
	private String sel_kind;

	/** �u�]�� */
	private String sel_order;


	public String getCls_stucode() {
	    return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
	    this.cls_stucode = cls_stucode;
	}

	public String getRsch_time() {
	    return rsch_time;
	}

	public void setRsch_time(String rsch_time) {
	    this.rsch_time = rsch_time;
	}

	public String getRsch_choiceed() {
	    return rsch_choiceed;
	}

	public void setRsch_choiceed(String rsch_choiceed) {
	    this.rsch_choiceed = rsch_choiceed;
	}

	public String getScl_sname() {
	    return scl_sname;
	}

	public void setScl_sname(String scl_sname) {
	    this.scl_sname = scl_sname;
	}

	/**
	 * @return scld_depsname
	 */
	public String getScld_depsname() {
		return scld_depsname;
	}

	/**
	 * @param scld_depsname scld_depsname��ݒ肷��
	 */
	public void setScld_depsname(String scld_depsname) {
		this.scld_depsname = scld_depsname;
	}

	public String getRsch_selection() {
	    return rsch_selection;
	}

	public void setRsch_selection(String rsch_selection) {
	    this.rsch_selection = rsch_selection;
	}

	public String getSel_kind() {
	    return sel_kind;
	}

	public void setSel_kind(String sel_kind) {
	    this.sel_kind = sel_kind;
	}

	public String getSel_order() {
	    return sel_order;
	}

	public void setSel_order(String sel_order) {
	    this.sel_order = sel_order;
	}

}
