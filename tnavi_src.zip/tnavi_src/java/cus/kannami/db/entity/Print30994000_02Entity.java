package jp.co.systemd.tnavi.cus.kannami.db.entity;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.common.print.ExcelSimpleListPrintable;

/**
 * �w��������(���쒬) �N���X���Entity.
 *
 * <B>Create</B> 2016.03.28 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print30994000_02Entity implements ExcelSimpleListPrintable {

	/**
	 * �o�͑Ώہ@0�F�w������A1�F�����n������A2�F�w���`�F�b�N�\
	 */
	private int output_target;

	/** �敪�@1:���w�Z,2:���w�Z */
	private String useKind2;

	/** �s�ԍ� */
	private int row;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �w�N
	 */
	private String hmr_glade;

	/**
	 * �g
	 */
	private String hmr_class;

	/**
	 * �N���X��
	 */
	private String hmr_name;

	/**
	 * �����ԍ�
	 */
    private String cls_number;

    /**
     * ���k����
     */
    private String st4_name;

    /**
     * ���k����
     */
    private String st4_hkana;

    /**
     * ����
     */
    private String stu_sex;

    /**
     * ���ʃR�[�h
     */
    private String stu_sexCode;

    /**
     * ���N����
     */
    private String stu_birth;

    /**
     * �ی�Ҏ���
     */
    private String st4_parent;

    /**
     * �Z��
     */
    private String  stu_adress;

    /**
     * ����ԍ�
     */
    private String st2_p_tel;

    /**
     * �ً}�A����1
     */
    private String  st2_e_tel;

    /**
     * �ً}�A����2
     */
    private String  st4_e_tel2;

    /**
     * �n��
     */
    private String  adg_name;

    /**
     * �ƒ됔��
     */
    private String brotherInfo;

    /**
     * ������
     */
    private String clubInfo;

    /**
     * �ی��2����(�ʏ�)
     */
    private String st4_p2_parent;

    /**
     * �ی��1�g�ѓd�b
     */
    private String st2_mobilephone;

    /**
     * �ی��2�g�ѓd�b
     */
    private String st4_p2_mobilephone;

    /**
     * �ً}�A����
     */
    private String st2_emrgncy;

    /**
     * �ی��2�ً}�A����
     */
    private String st4_p2_emergency;

    /**
     * �ی��2�ً}�d�b�ԍ�
     */
    private String st4_p2_e_tel;

    /**
     * �o�Z�ǃR�[�h
     */
    private String adg_code;

	public int getOutput_target() {
		return output_target;
	}

	public void setOutput_target(int output_target) {
		this.output_target = output_target;
	}

	public String getUseKind2() {
		return useKind2;
	}

	public void setUseKind2(String useKind2) {
		this.useKind2 = useKind2;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return hmr_glade
	 */
	public String getHmr_glade() {
		return hmr_glade;
	}

	/**
	 * @param hmr_glade the hmr_glade to set
	 */
	public void setHmr_glade(String hmr_glade) {
		this.hmr_glade = hmr_glade;
	}

	/**
	 * @return hmr_class
	 */
	public String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class the hmr_class to set
	 */
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return hmr_name
	 */
	public String getHmr_name() {
		return hmr_name;
	}

	/**
	 * @param hmr_name the hmr_name to set
	 */
	public void setHmr_name(String hmr_name) {
		this.hmr_name = hmr_name;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getSt4_name() {
		return st4_name;
	}

	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public String getSt4_hkana() {
		return st4_hkana;
	}

	public void setSt4_hkana(String st4_hkana) {
		this.st4_hkana = st4_hkana;
	}

	public String getStu_sex() {
		return stu_sex;
	}

	public void setStu_sex(String stu_sex) {
		this.stu_sex = stu_sex;
	}

	public String getStu_sexCode() {
		return stu_sexCode;
	}

	public void setStu_sexCode(String stu_sexCode) {
		this.stu_sexCode = stu_sexCode;
	}

	public String getStu_birth() {
		return stu_birth;
	}

	public void setStu_birth(String stu_birth) {
		this.stu_birth = stu_birth;
	}

	public String getSt4_parent() {
		return st4_parent;
	}

	public void setSt4_parent(String st4_parent) {
		this.st4_parent = st4_parent;
	}

	public String getStu_adress() {
		return stu_adress;
	}

	public void setStu_adress(String stu_adress) {
		this.stu_adress = stu_adress;
	}

	public String getSt2_p_tel() {
		return st2_p_tel;
	}

	public void setSt2_p_tel(String st2_p_tel) {
		this.st2_p_tel = st2_p_tel;
	}

	public String getSt2_e_tel() {
		return st2_e_tel;
	}

	public void setSt2_e_tel(String st2_e_tel) {
		this.st2_e_tel = st2_e_tel;
	}

	public String getSt4_e_tel2() {
		return st4_e_tel2;
	}

	public void setSt4_e_tel2(String st4_e_tel2) {
		this.st4_e_tel2 = st4_e_tel2;
	}

	public String getAdg_name() {
		return adg_name;
	}

	public void setAdg_name(String adg_name) {
		this.adg_name = adg_name;
	}

	public String getBrotherInfo() {
		return brotherInfo;
	}

	public void setBrotherInfo(String brotherInfo) {
		this.brotherInfo = brotherInfo;
	}

	public String getClubInfo() {
		return clubInfo;
	}

	public void setClubInfo(String clubInfo) {
		this.clubInfo = clubInfo;
	}

	public String getSt4_p2_parent() {
		return st4_p2_parent;
	}

	public void setSt4_p2_parent(String st4_p2_parent) {
		this.st4_p2_parent = st4_p2_parent;
	}

	public String getSt2_mobilephone() {
		return st2_mobilephone;
	}

	public void setSt2_mobilephone(String st2_mobilephone) {
		this.st2_mobilephone = st2_mobilephone;
	}

	public String getSt4_p2_mobilephone() {
		return st4_p2_mobilephone;
	}

	public void setSt4_p2_mobilephone(String st4_p2_mobilephone) {
		this.st4_p2_mobilephone = st4_p2_mobilephone;
	}

	public String getSt2_emrgncy() {
		return st2_emrgncy;
	}

	public void setSt2_emrgncy(String st2_emrgncy) {
		this.st2_emrgncy = st2_emrgncy;
	}

	public String getSt4_p2_emergency() {
		return st4_p2_emergency;
	}

	public void setSt4_p2_emergency(String st4_p2_emergency) {
		this.st4_p2_emergency = st4_p2_emergency;
	}

	public String getSt4_p2_e_tel() {
		return st4_p2_e_tel;
	}

	public void setSt4_p2_e_tel(String st4_p2_e_tel) {
		this.st4_p2_e_tel = st4_p2_e_tel;
	}

	/**
	 * @return adg_code
	 */
	public String getAdg_code() {
		return adg_code;
	}

	/**
	 * @param adg_code the adg_code to set
	 */
	public void setAdg_code(String adg_code) {
		this.adg_code = adg_code;
	}

	@Override
	public List<Object> getRowDataSameKeys() {
		return getDataList();
	}

	@Override
	public List<Object> getRowDataAnotherKeys() {
		return getDataList();
	}

	@Override
	public boolean isKeyBreak(ExcelSimpleListPrintable breakKey) {

		int breakRow = 45;
		if(output_target == 0 || output_target == 1){
			// 45�s��keyBreak
			breakRow = 45;
		}else if(output_target == 2){
			// 5�s���Ƃ�keyBreak
			breakRow = 5;
		}
		if(row % breakRow == 0){
			return true;
		}

		return false;
	}

	/**
	 * Excel�o�͗p��DataList���쐬����
	 * @return DataList
	 */
	private List<Object> getDataList() {
		List<Object> dataList = new ArrayList<Object>();

		// �w������
		if(output_target == 0){

			dataList.add(cls_number);	// ��
			dataList.add(st4_name);		// ����
			dataList.add(st4_hkana);	// �ӂ肪��
			dataList.add(stu_sex);		// ����
			dataList.add(stu_birth);	// ���N����
			dataList.add(st4_parent);	// �ی�Ҏ���
			dataList.add(stu_adress);	// �Z��
			dataList.add(st2_p_tel);	// ����ԍ�
			dataList.add(st2_e_tel);	// �ً}�A����P
			dataList.add(st4_e_tel2);	// �ً}�A����Q
			dataList.add(brotherInfo);	// �ƒ됔��
			if("1".equals(useKind2)){
				dataList.add(adg_name);	// ���w�Z�F�n��
			}else if("2".equals(useKind2)){
				dataList.add(clubInfo);	// ���w�Z�F������
			}
		}
		// �����n������
		else if(output_target == 1){
			dataList.add(cls_number);	// ��
			dataList.add(st4_name);		// ����
			dataList.add(stu_sex);		// ����
			dataList.add(st4_parent);	// �ی�Ҏ���
			dataList.add(stu_adress);	// �Z��
			dataList.add(st2_e_tel);	// �ً}�A����P
			dataList.add(st4_e_tel2);	// �ً}�A����Q
			dataList.add(brotherInfo);	// �ƒ됔��
			dataList.add(adg_name);		// ���w�Z�F�n��
		}
		// �w���`�F�b�N�\
		else if(output_target == 2){
			dataList.add(cls_number);	// ��
			dataList.add(st4_name);		// ����
			dataList.add(stu_sex);		// ����
		}
		// �����n������(�n���)
		else if(output_target == 4){
			dataList.add(hmr_glade);	// �w�N
			dataList.add(hmr_class);	// �g
			dataList.add(cls_number);	// ��
			dataList.add(st4_name);		// ����
			dataList.add(stu_sex);		// ����
			dataList.add(st4_parent);	// �ی�Ҏ���
			dataList.add(stu_adress);	// �Z��
			dataList.add(st2_e_tel);	// �ً}�A����P
			dataList.add(st4_e_tel2);	// �ً}�A����Q
			dataList.add(brotherInfo);	// �ƒ됔��
			dataList.add(adg_name);		// ���w�Z�F�n��

		}
		return dataList;
	}
}
