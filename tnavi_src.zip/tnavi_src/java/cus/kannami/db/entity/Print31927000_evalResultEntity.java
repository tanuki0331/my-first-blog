/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �]�茋�ʎ擾�p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_evalResultEntity {

	private String item_name;
	private String item_code;

	private String revl_display;
	
	private String item5_sum_flg;
	private String item3_sum_flg;

	private String rev_stucode;

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getItem_code() {
		return item_code;
	}
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getRevl_display() {
		return revl_display;
	}

	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}

	public String getItem5_sum_flg() {
		return item5_sum_flg;
	}

	public void setItem5_sum_flg(String item5_sum_flg) {
		this.item5_sum_flg = item5_sum_flg;
	}

	public String getItem3_sum_flg() {
		return item3_sum_flg;
	}

	public void setItem3_sum_flg(String item3_sum_flg) {
		this.item3_sum_flg = item3_sum_flg;
	}

	public String getRev_stucode() {
		return rev_stucode;
	}

	public void setRev_stucode(String rev_stucode) {
		this.rev_stucode = rev_stucode;
	}
	
	

}
