/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

import java.math.BigDecimal;

/**
 * <PRE>
 *  �i�H�\��� ���ϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.08 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31929000_ScoreAverageEntity {

	/** ���ȃR�[�h */
	private String itemcode;

	/** ���ϓ_ */
	private BigDecimal scoreAvg;


	public String getItemcode() {
	    return itemcode;
	}

	public void setItemcode(String itemcode) {
	    this.itemcode = itemcode;
	}

	public BigDecimal getScoreAvg() {
	    return scoreAvg;
	}

	public void setScoreAvg(BigDecimal scoreAvg) {
	    this.scoreAvg = scoreAvg;
	}

}
