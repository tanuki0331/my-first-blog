/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

import java.util.LinkedHashMap;
import java.util.List;


/**
 * <PRE>
 *  ����(���̓e�X�g) �w�b�_�[ �e�X�g���� �\���p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31927000_detailEntity {


    /** 
     * ���Z���R�[�h
     */
	private String scl_cd ;

	/** 
     * �n��E�R�[�X�R�[�h
     */
	private String sclc_cd ;

	/** 
     * ���Z����
     */
	private String scl_name;

	/** 
     * ���Z����
     */
	private String scl_sname;

	/** 
     * ���Z��
     */
	private String scl_name_org;
	/** 
     * �w�Ȗ�
     */
	private String scl_depname;
	/** 
     * �n��R�[�X��
     */
	private String sclc_name;


	/** 
     * �N�x
     */
	private String scl_year;

	/** 
     * �����R�[�h
     */
	private String scl_user;
	
    /** 
     * �w�Z���
     */
	private String cod_name2;
	
    /** 
     * �w�Z���
     */
	private String scl_type;
    /** 
     * �w�ȕ\����
     */
	private String scl_order;
    /** 
     * �w�ȃR�[�h
     */
	private String scld_seq;
    /** 
     * �n��R�[�X�@�\����
     */
	private String sclc_order;
		

	/** 
     * �����R�[�h
     */
    private String cse_user;
    /** 
     * �N�x
     */
    private String cse_year;
    /** 
     * ���Z���R�[�h
     */
    private String cse_sclcd;
    /** 
     * �n��R�[�X�R�[�h
     */
    private String cse_sclccd;
    /** 
     * ����(�]��) 9�v
     */
    private Integer cse_public_9sum;
    /** 
     * ����(�]��) 5�v
     */
    private Integer cse_public_5sum;
    /** 
     * ����(�]��) 3�v
     */
    private Integer cse_public_3sum;
    /** 
     * ����(�P) 5�v
     */
    private Integer cse_private_tan_5sum;
    /** 
     * ����(�P) 9�v
     */
    private Integer cse_private_tan_9sum;
    /** 
     * ����(��) 5�v
     */
    private Integer cse_private_hei_5sum;
    /** 
     * ����(��) 9�v
     */
    private Integer cse_private_hei_9sum;
    /** 
     * �ꗗ�\���Ώۃt���O
     */
    private String cse_outputflg;
    /** 
     * ���l
     */
    private String cse_memo;
    /** 
     * �X�V��
     */
    private String cse_update;
    /** 
     * �X�V��
     */
    private String cse_upuser;

	public String getScl_type() {
		return scl_type;
	}


	public void setScl_type(String scl_type) {
		this.scl_type = scl_type;
	}


	public String getScl_order() {
		return scl_order;
	}


	public void setScl_order(String scl_order) {
		this.scl_order = scl_order;
	}


	public String getScld_seq() {
		return scld_seq;
	}


	public void setScld_seq(String scld_seq) {
		this.scld_seq = scld_seq;
	}


	public String getSclc_order() {
		return sclc_order;
	}


	public void setSclc_order(String sclc_order) {
		this.sclc_order = sclc_order;
	}

	
	List<Data31927000_detailscoreEntity> data31927000_detailscoreEntityList;
	
	
	LinkedHashMap<String, Print31927000_sortedStudentEntity> print31927000_sortedStudentEntityMap;




	public String getScl_cd() {
		return scl_cd;
	}


	public void setScl_cd(String scl_cd) {
		this.scl_cd = scl_cd;
	}


	public String getSclc_cd() {
		return sclc_cd;
	}


	public void setSclc_cd(String sclc_cd) {
		this.sclc_cd = sclc_cd;
	}


	public String getScl_name() {
		return scl_name;
	}


	public void setScl_name(String scl_name) {
		this.scl_name = scl_name;
	}


	public String getScl_sname() {
		return scl_sname;
	}


	public void setScl_sname(String scl_sname) {
		this.scl_sname = scl_sname;
	}


	public String getScl_name_org() {
		return scl_name_org;
	}


	public void setScl_name_org(String scl_name_org) {
		this.scl_name_org = scl_name_org;
	}


	public String getScl_depname() {
		return scl_depname;
	}


	public void setScl_depname(String scl_depname) {
		this.scl_depname = scl_depname;
	}


	public String getSclc_name() {
		return sclc_name;
	}


	public void setSclc_name(String sclc_name) {
		this.sclc_name = sclc_name;
	}


	public String getScl_year() {
		return scl_year;
	}


	public void setScl_year(String scl_year) {
		this.scl_year = scl_year;
	}


	public String getScl_user() {
		return scl_user;
	}


	public void setScl_user(String scl_user) {
		this.scl_user = scl_user;
	}

	
    public String getCod_name2() {
		return cod_name2;
	}


	public void setCod_name2(String cod_name2) {
		this.cod_name2 = cod_name2;
	}


	public String getCse_user() {
		return cse_user;
	}


	public void setCse_user(String cse_user) {
		this.cse_user = cse_user;
	}


	public String getCse_year() {
		return cse_year;
	}


	public void setCse_year(String cse_year) {
		this.cse_year = cse_year;
	}


	public String getCse_sclcd() {
		return cse_sclcd;
	}


	public void setCse_sclcd(String cse_sclcd) {
		this.cse_sclcd = cse_sclcd;
	}


	public String getCse_sclccd() {
		return cse_sclccd;
	}


	public void setCse_sclccd(String cse_sclccd) {
		this.cse_sclccd = cse_sclccd;
	}


	public Integer getCse_public_9sum() {
		return cse_public_9sum;
	}


	public void setCse_public_9sum(Integer cse_public_9sum) {
		this.cse_public_9sum = cse_public_9sum;
	}


	public Integer getCse_public_5sum() {
		return cse_public_5sum;
	}


	public void setCse_public_5sum(Integer cse_public_5sum) {
		this.cse_public_5sum = cse_public_5sum;
	}


	public Integer getCse_public_3sum() {
		return cse_public_3sum;
	}


	public void setCse_public_3sum(Integer cse_public_3sum) {
		this.cse_public_3sum = cse_public_3sum;
	}


	public Integer getCse_private_tan_5sum() {
		return cse_private_tan_5sum;
	}


	public void setCse_private_tan_5sum(Integer cse_private_tan_5sum) {
		this.cse_private_tan_5sum = cse_private_tan_5sum;
	}


	public Integer getCse_private_tan_9sum() {
		return cse_private_tan_9sum;
	}


	public void setCse_private_tan_9sum(Integer cse_private_tan_9sum) {
		this.cse_private_tan_9sum = cse_private_tan_9sum;
	}


	public Integer getCse_private_hei_5sum() {
		return cse_private_hei_5sum;
	}


	public void setCse_private_hei_5sum(Integer cse_private_hei_5sum) {
		this.cse_private_hei_5sum = cse_private_hei_5sum;
	}


	public Integer getCse_private_hei_9sum() {
		return cse_private_hei_9sum;
	}


	public void setCse_private_hei_9sum(Integer cse_private_hei_9sum) {
		this.cse_private_hei_9sum = cse_private_hei_9sum;
	}


	public String getCse_outputflg() {
		return cse_outputflg;
	}


	public void setCse_outputflg(String cse_outputflg) {
		this.cse_outputflg = cse_outputflg;
	}


	public String getCse_memo() {
		return cse_memo;
	}


	public void setCse_memo(String cse_memo) {
		this.cse_memo = cse_memo;
	}


	public String getCse_update() {
		return cse_update;
	}


	public void setCse_update(String cse_update) {
		this.cse_update = cse_update;
	}


	public String getCse_upuser() {
		return cse_upuser;
	}


	public void setCse_upuser(String cse_upuser) {
		this.cse_upuser = cse_upuser;
	}


	public List<Data31927000_detailscoreEntity> getData31927000_detailscoreEntityList() {
		return data31927000_detailscoreEntityList;
	}


	public void setData31927000_detailscoreEntityList(
			List<Data31927000_detailscoreEntity> data31927000_detailscoreEntityList) {
		this.data31927000_detailscoreEntityList = data31927000_detailscoreEntityList;
	}

	public LinkedHashMap<String, Print31927000_sortedStudentEntity> getPrint31927000_sortedStudentEntityMap() {
		return print31927000_sortedStudentEntityMap;
	}


	public void setPrint31927000_sortedStudentEntityMap(
			LinkedHashMap<String, Print31927000_sortedStudentEntity> print31927000_sortedStudentEntityMap) {
		this.print31927000_sortedStudentEntityMap = print31927000_sortedStudentEntityMap;
	}

	
}
