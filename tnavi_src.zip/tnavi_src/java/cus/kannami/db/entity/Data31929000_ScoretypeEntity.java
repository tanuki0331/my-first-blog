/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �i�H�\��� �f�_�o��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.11.07 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31929000_ScoretypeEntity {

	/** �敪(1:����e�X�g 2:���̓e�X�g) */
	private String kind;

	/** �N�x */
	private String nendo;

	/** �w�N */
	private String grade;

	/** �o�͎����R�[�h */
	private String gopt_goptcode;

	/** �]����ʃR�[�h */
	private String tpt_serial;

	/** ���̓e�X�g�R�[�h */
	private String abtt_code;

	/** �\����1(�w�N) */
	private String order1;

	/** �\����2(�o�͎���) */
	private String order2;

	/** �\����3(�]�����) */
	private String order3;

	/** �\������ */
	private String dispname;


	public String getKind() {
	    return kind;
	}

	public void setKind(String kind) {
	    this.kind = kind;
	}

	public String getNendo() {
	    return nendo;
	}

	public void setNendo(String nendo) {
	    this.nendo = nendo;
	}

	public String getGrade() {
	    return grade;
	}

	public void setGrade(String grade) {
	    this.grade = grade;
	}

	public String getGopt_goptcode() {
	    return gopt_goptcode;
	}

	public void setGopt_goptcode(String gopt_goptcode) {
	    this.gopt_goptcode = gopt_goptcode;
	}

	public String getTpt_serial() {
	    return tpt_serial;
	}

	public void setTpt_serial(String tpt_serial) {
	    this.tpt_serial = tpt_serial;
	}

	public String getAbtt_code() {
	    return abtt_code;
	}

	public void setAbtt_code(String abtt_code) {
	    this.abtt_code = abtt_code;
	}

	public String getOrder1() {
	    return order1;
	}

	public void setOrder1(String order1) {
	    this.order1 = order1;
	}

	public String getOrder2() {
	    return order2;
	}

	public void setOrder2(String order2) {
	    this.order2 = order2;
	}

	public String getOrder3() {
	    return order3;
	}

	public void setOrder3(String order3) {
	    this.order3 = order3;
	}

	public String getDispname() {
	    return dispname;
	}

	public void setDispname(String dispname) {
	    this.dispname = dispname;
	}

}
