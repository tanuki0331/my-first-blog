/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  ����(���̓e�X�g) �w�b�_�[ �e�X�g���� �\���p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.31 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31927000_abilityuseEntity {


	/** �R�[�h */
	private String abtt_code;
	/** ���� */
	private String abtt_name2;
	/** �g�p�t���O */
	private String chkflg;
	
	
	public String getAbtt_code() {
		return abtt_code;
	}
	public void setAbtt_code(String abtt_code) {
		this.abtt_code = abtt_code;
	}
	public String getAbtt_name2() {
		return abtt_name2;
	}
	public void setAbtt_name2(String abtt_name2) {
		this.abtt_name2 = abtt_name2;
	}
	public String getChkflg() {
		return chkflg;
	}
	public void setChkflg(String chkflg) {
		this.chkflg = chkflg;
	} 
	
	
	
}
