/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INC, All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 * ���� �\���p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_absentEntity {

	private String gopt_name;
	private String gopt_goptcode;
	private String gopt_order;
	private String cls_glade;
	private String cls_stucode;
 	private String cls_number;
 	private String absencecount;
 	
 	
	public String getGopt_name() {
		return gopt_name;
	}
	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}
	public String getGopt_goptcode() {
		return gopt_goptcode;
	}
	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}
	public String getGopt_order() {
		return gopt_order;
	}
	public void setGopt_order(String gopt_order) {
		this.gopt_order = gopt_order;
	}
	public String getCls_glade() {
		return cls_glade;
	}
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}
	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getCls_number() {
		return cls_number;
	}
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	public String getAbsencecount() {
		return absencecount;
	}
	public void setAbsencecount(String absencecount) {
		this.absencecount = absencecount;
	} 

	
}
