package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �]���E�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31908000_ScoreEntity {
	
	/**
	 * ���ȃR�[�h
	 */
	private String rvpv_item;
	
	/**
	 * ���ȃR�[�h
	 */
	private String rvpv_rivtcode;

	/**
	 * �w�Дԍ�
	 */
	private String rvpv_stucode;

	/**
	 * �o�͎���
	 */
	private String rvpv_goptcode;

	/**
	 * �]��
	 */
	private String rvpe_reportdisplay;

	/**
	 * �]��
	 */
	private String revl_display;


	public String getRvpv_item() {
		return rvpv_item;
	}

	public void setRvpv_item(String rvpv_item) {
		this.rvpv_item = rvpv_item;
	}

	public String getRvpv_rivtcode() {
		return rvpv_rivtcode;
	}

	public void setRvpv_rivtcode(String rvpv_rivtcode) {
		this.rvpv_rivtcode = rvpv_rivtcode;
	}

	public String getRvpv_stucode() {
		return rvpv_stucode;
	}

	public void setRvpv_stucode(String rvpv_stucode) {
		this.rvpv_stucode = rvpv_stucode;
	}

	public String getRvpv_goptcode() {
		return rvpv_goptcode;
	}

	public void setRvpv_goptcode(String rvpv_goptcode) {
		this.rvpv_goptcode = rvpv_goptcode;
	}

	public String getRvpe_reportdisplay() {
		return rvpe_reportdisplay;
	}

	public void setRvpe_reportdisplay(String rvpe_reportdisplay) {
		this.rvpe_reportdisplay = rvpe_reportdisplay;
	}

	public String getRevl_display() {
		return revl_display;
	}

	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}

	
	
}
