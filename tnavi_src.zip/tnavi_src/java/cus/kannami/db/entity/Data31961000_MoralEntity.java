package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �w�Z����̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.07.11 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31961000_MoralEntity {

	/**
	 * �w�Дԍ�
	 */
	private String srcom_stucode;

	/**
	 * ����
	 */
	private String srcom_item;

	/**
	 * �������e
	 */
    private String srcom_comment;

	public String getSrcom_stucode() {
		return srcom_stucode;
	}

	public void setSrcom_stucode(String srcom_stucode) {
		this.srcom_stucode = srcom_stucode;
	}

	public String getSrcom_item() {
		return srcom_item;
	}

	public void setSrcom_item(String srcom_item) {
		this.srcom_item = srcom_item;
	}

	public String getSrcom_comment() {
		return srcom_comment;
	}

	public void setSrcom_comment(String srcom_comment) {
		this.srcom_comment = srcom_comment;
	}


}
