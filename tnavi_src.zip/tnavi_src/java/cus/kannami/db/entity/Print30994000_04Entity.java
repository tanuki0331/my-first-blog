package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * �w��������(���쒬) �������@Entity.
 *
 * <B>Create</B> 2016.03.28 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print30994000_04Entity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;
	
	/**
	 * �N���X�R�[�h
	 */
	private String cls_clsno;
	
	/**
	 * �����ԍ�
	 */
	private String cls_number;
	
	/**
	 * �ݐЊJ�n��
	 */
	private String clb_start;
	
	/**
	 * �ݐЏI����
	 */
	private String clb_stop;
	
	/**
	 * ��������
	 */
	private String ext_name;
	
	/**
	 * ��E��
	 */
	private String pst_name;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_clsno() {
		return cls_clsno;
	}

	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getClb_start() {
		return clb_start;
	}

	public void setClb_start(String clb_start) {
		this.clb_start = clb_start;
	}

	public String getClb_stop() {
		return clb_stop;
	}

	public void setClb_stop(String clb_stop) {
		this.clb_stop = clb_stop;
	}

	public String getExt_name() {
		return ext_name;
	}

	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}

	public String getPst_name() {
		return pst_name;
	}

	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}
	
}
