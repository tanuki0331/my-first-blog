/**------------------------------------------------------------**
 * Te@cherNavi
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 * �o�����R���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.12 nagaoka<BR>
 * ��getData30026000_08Entity ��藬�p
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class Print30998000_08Entity{

	public final static String DEFALUT_VALUE = "";

    /**
     * �w�Дԍ�
     */
    private String cls_stucode;
    /**
     * �N����
     */
    private String att_date;
    /**
     * �o���敪
     */
    private String att_attendkind;
    /**
     * �o���敪����
     */
    private String akj_name;
    /**
     * ���Ȉ���
     */
    private Integer akj_absenceflg;
    /**
     * �x������
     */
    private Integer akj_lateflg;
    /**
     * ���ވ���
     */
    private Integer akj_leaveflg;
    /**
     * �o�����������
     */
    private Integer akj_schoolkind;
    /**
     * ���ꓮ��t���O
     */
    private String akj_special;
    /**
     * �A��
     */
    private String arj_serial;
    /**
     * ���R
     */
    private String arj_reason;
    /**
     * �W�v�O���[�v�R�[�h
     */
    private String atrg_grpcode;
    /**
     * �W�v�O���[�v����
     */
    private String arg_grpname;

    /**
     * �l��
     */
    private int count;

	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getAtt_date() {
		return att_date;
	}
	public void setAtt_date(String att_date) {
		this.att_date = att_date;
	}
	public String getAtt_attendkind() {
		return att_attendkind;
	}
	public void setAtt_attendkind(String att_attendkind) {
		this.att_attendkind = att_attendkind;
	}
	public String getAkj_name() {
		return akj_name;
	}
	public void setAkj_name(String akj_name) {
		this.akj_name = akj_name;
	}
	public Integer getAkj_absenceflg() {
		return akj_absenceflg;
	}
	public void setAkj_absenceflg(Integer akj_absenceflg) {
		this.akj_absenceflg = akj_absenceflg;
	}
	public Integer getAkj_lateflg() {
		return akj_lateflg;
	}
	public void setAkj_lateflg(Integer akj_lateflg) {
		this.akj_lateflg = akj_lateflg;
	}
	public Integer getAkj_leaveflg() {
		return akj_leaveflg;
	}
	public void setAkj_leaveflg(Integer akj_leaveflg) {
		this.akj_leaveflg = akj_leaveflg;
	}
	public Integer getAkj_schoolkind() {
		return akj_schoolkind;
	}
	public void setAkj_schoolkind(Integer akj_schoolkind) {
		this.akj_schoolkind = akj_schoolkind;
	}
	public String getAkj_special() {
		return akj_special;
	}
	public void setAkj_special(String akj_special) {
		this.akj_special = akj_special;
	}
	public String getArj_serial() {
		return arj_serial;
	}
	public void setArj_serial(String arj_serial) {
		this.arj_serial = arj_serial;
	}
	public String getArj_reason() {
		return arj_reason;
	}
	public void setArj_reason(String arj_reason) {
		this.arj_reason = arj_reason;
	}
	public String getAtrg_grpcode() {
		return atrg_grpcode;
	}
	public void setAtrg_grpcode(String atrg_grpcode) {
		this.atrg_grpcode = atrg_grpcode;
	}
	public String getArg_grpname() {
		return arg_grpname;
	}
	public void setArg_grpname(String arg_grpname) {
		this.arg_grpname = arg_grpname;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
