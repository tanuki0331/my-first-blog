package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �]���E�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.07.11 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31961000_ScorptevalEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * ���ȃR�[�h
	 */
	private String sriu_item;

	/**
	 * �m��]��
	 */
	private String srevl_display;

	/**
	 * �L�q�]��
	 */
	private String srev_descript;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getSriu_item() {
		return sriu_item;
	}

	public void setSriu_item(String sriu_item) {
		this.sriu_item = sriu_item;
	}

	public String getSrevl_display() {
		return srevl_display;
	}

	public void setSrevl_display(String srevl_display) {
		this.srevl_display = srevl_display;
	}

	public String getSrev_descript() {
		return srev_descript;
	}

	public void setSrev_descript(String srev_descript) {
		this.srev_descript = srev_descript;
	}
}
