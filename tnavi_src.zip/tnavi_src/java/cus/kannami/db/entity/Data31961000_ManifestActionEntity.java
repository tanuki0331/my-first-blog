package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �]���E�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.07.11 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31961000_ManifestActionEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �o�͎����R�[�h
	 */
	private String gopt_goptcode;

	/**
	 * ���ڃR�[�h
	 */
	private String sravt_sravtcode;

	/**
	 * ���ږ�
	 */
	private String sravt_name;

	/**
	 * �ʍ���
	 */
	private String sravv_indivivp;

	/**
	 * �ʒm�\�\���l
	 */
	private String srace_display;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getGopt_goptcode() {
		return gopt_goptcode;
	}

	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}

	public String getSravt_sravtcode() {
		return sravt_sravtcode;
	}

	public void setSravt_sravtcode(String sravt_sravtcode) {
		this.sravt_sravtcode = sravt_sravtcode;
	}

	public String getSravt_name() {
		return sravt_name;
	}

	public void setSravt_name(String sravt_name) {
		this.sravt_name = sravt_name;
	}

	public String getSravv_indivivp() {
		return sravv_indivivp;
	}

	public void setSravv_indivivp(String sravv_indivivp) {
		this.sravv_indivivp = sravv_indivivp;
	}

	public String getSrace_display() {
		return srace_display;
	}

	public void setSrace_display(String srace_display) {
		this.srace_display = srace_display;
	}
}
