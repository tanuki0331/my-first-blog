/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD inc.,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �e�X�g�\�����N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_testIndexNameEntity {

	private String abtt_date;
	private String abtt_code;
	private String abtt_name;
	private String abtt_name2;
	private String cau_abttcode;
	public String getAbtt_date() {
		return abtt_date;
	}
	public void setAbtt_date(String abtt_date) {
		this.abtt_date = abtt_date;
	}
	public String getAbtt_code() {
		return abtt_code;
	}
	public void setAbtt_code(String abtt_code) {
		this.abtt_code = abtt_code;
	}
	public String getAbtt_name() {
		return abtt_name;
	}
	public void setAbtt_name(String abtt_name) {
		this.abtt_name = abtt_name;
	}
	public String getAbtt_name2() {
		return abtt_name2;
	}
	public void setAbtt_name2(String abtt_name2) {
		this.abtt_name2 = abtt_name2;
	}
	public String getCau_abttcode() {
		return cau_abttcode;
	}
	public void setCau_abttcode(String cau_abttcode) {
		this.cau_abttcode = cau_abttcode;
	}


	
}
