/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INC, All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  �N���u �\���p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31927000_clubEntity {

	private String ext_code;
	private String cls_stucode;
	private String cls_number;
	private String clb_start;
	private String clb_stop;
	private String ext_name;
	
	
	public String getExt_code() {
		return ext_code;
	}
	public void setExt_code(String ext_code) {
		this.ext_code = ext_code;
	}
	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getCls_number() {
		return cls_number;
	}
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	public String getClb_start() {
		return clb_start;
	}
	public void setClb_start(String clb_start) {
		this.clb_start = clb_start;
	}
	public String getClb_stop() {
		return clb_stop;
	}
	public void setClb_stop(String clb_stop) {
		this.clb_stop = clb_stop;
	}
	public String getExt_name() {
		return ext_name;
	}
	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}

	
}
