package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.07.13 BY hirata <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31961000_ScorptevalDisplayEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * ���ȃR�[�h
	 */
	private String sriu_item;

	/**
	 * ���яo�͎����R�[�h
	 */
	private String srev_goptcode;

	/**
	 * �m��]��
	 */
	private String srevl_display;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getSriu_item() {
		return sriu_item;
	}

	public void setSriu_item(String sriu_item) {
		this.sriu_item = sriu_item;
	}

	public String getSrev_goptcode() {
		return srev_goptcode;
	}

	public void setSrev_goptcode(String srev_goptcode) {
		this.srev_goptcode = srev_goptcode;
	}

	public String getSrevl_display() {
		return srevl_display;
	}

	public void setSrevl_display(String srevl_display) {
		this.srevl_display = srevl_display;
	}
}
