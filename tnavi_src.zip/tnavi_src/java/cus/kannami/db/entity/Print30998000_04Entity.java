/**------------------------------------------------------------**
 * Te@cherNavi
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * ���k���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.12 nagaoka<BR>
 * �@��Data30026000_04Entity ��藬�p
 * <B>remark</B><BR>
 *
 * @author SystemD.Inc.
 * @since 1.0.
 */
public class Print30998000_04Entity{

	public final static String DEFALUT_VALUE = "";

    /**
     * �w�Дԍ�
     */
    private String cls_stucode;
    /**
     * �����ԍ�
     */
    private Integer cls_number;
    /**
     * ���i�敪
     */
    private String stu_qualifi;
    /**
     * ���w�N����
     */
    private String stu_entry;
    /**
     * ���k����(�ʏ�)
     */
    private String st4_name;
    /**
     * ���ʎx���w�� �������k�t���O
     */
    private String spe_supportflg;
    /**
     * �w�N(���ʎx���w���ŗ��p)
     */
    private String cls_glade;
    /**
     * �g(���ʎx���w���ŗ��p)
     */
    private String hmr_class;
	/**
	 * �]�����w�Z��
	 */
	private String st4_preschname;

	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public Integer getCls_number() {
		return cls_number;
	}
	public void setCls_number(Integer cls_number) {
		this.cls_number = cls_number;
	}
	public String getStu_qualifi() {
		return stu_qualifi;
	}
	public void setStu_qualifi(String stu_qualifi) {
		this.stu_qualifi = stu_qualifi;
	}
	public String getStu_entry() {
		return stu_entry;
	}
	public void setStu_entry(String stu_entry) {
		this.stu_entry = stu_entry;
	}
	public String getSt4_name() {
		return st4_name;
	}
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}
	public String getSpe_supportflg() {
		return spe_supportflg;
	}
	public void setSpe_supportflg(String spe_supportflg) {
		this.spe_supportflg = spe_supportflg;
	}
	public String getCls_glade() {
		return cls_glade;
	}
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}
	public String getHmr_class() {
		return hmr_class;
	}
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}
	public String getSt4_preschname() {
		return st4_preschname;
	}
	public void setSt4_preschname(String st4_preschname) {
		this.st4_preschname = st4_preschname;
	}

}
