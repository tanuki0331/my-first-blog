package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �N���u�����̋L�^�̏o��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31908000_ClubActivityEntity {
	
    /**
	 * �w�Дԍ�
	 */
	private String rsav_stucode;
		
	/**
	 * �]������
	 */
	private String rsav_term;
	
	/**
	 * 
	 */
	private String cod_value3;

	/**
	 * 
	 */
	private String cod_name4;

	/**
	 * �N���u�����̋L�^
	 */
	private String rsav_record;

	public String getRsav_stucode() {
		return rsav_stucode;
	}

	public void setRsav_stucode(String rsav_stucode) {
		this.rsav_stucode = rsav_stucode;
	}

	public String getRsav_term() {
		return rsav_term;
	}

	public void setRsav_term(String rsav_term) {
		this.rsav_term = rsav_term;
	}

	public String getCod_value3() {
		return cod_value3;
	}

	public void setCod_value3(String cod_value3) {
		this.cod_value3 = cod_value3;
	}

	public String getCod_name4() {
		return cod_name4;
	}

	public void setCod_name4(String cod_name4) {
		this.cod_name4 = cod_name4;
	}

	public String getRsav_record() {
		return rsav_record;
	}

	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}

}
