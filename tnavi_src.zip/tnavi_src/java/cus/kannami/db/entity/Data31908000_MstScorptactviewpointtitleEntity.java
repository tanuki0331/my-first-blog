package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * �s���̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31908000_MstScorptactviewpointtitleEntity {
	
	private String ravt_user;
	private String ravt_year;
	private String ravt_grade;
	private String ravt_term;
	private String ravt_ravtcode;
	private String ravt_gavtcode;
	private String ravt_ravtname;
	private String ravt_ravtname2;
	private String ravt_purpose;
	private String ravt_order;
	private String ravt_update;
	private String ravt_upuser;
	private String ravt_notuse;
	
	public String getRavt_user() {
		return ravt_user;
	}
	public void setRavt_user(String ravt_user) {
		this.ravt_user = ravt_user;
	}
	public String getRavt_year() {
		return ravt_year;
	}
	public void setRavt_year(String ravt_year) {
		this.ravt_year = ravt_year;
	}
	public String getRavt_grade() {
		return ravt_grade;
	}
	public void setRavt_grade(String ravt_grade) {
		this.ravt_grade = ravt_grade;
	}
	public String getRavt_term() {
		return ravt_term;
	}
	public void setRavt_term(String ravt_term) {
		this.ravt_term = ravt_term;
	}
	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}
	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}
	public String getRavt_gavtcode() {
		return ravt_gavtcode;
	}
	public void setRavt_gavtcode(String ravt_gavtcode) {
		this.ravt_gavtcode = ravt_gavtcode;
	}
	public String getRavt_ravtname() {
		return ravt_ravtname;
	}
	public void setRavt_ravtname(String ravt_ravtname) {
		this.ravt_ravtname = ravt_ravtname;
	}
	public String getRavt_ravtname2() {
		return ravt_ravtname2;
	}
	public void setRavt_ravtname2(String ravt_ravtname2) {
		this.ravt_ravtname2 = ravt_ravtname2;
	}
	public String getRavt_purpose() {
		return ravt_purpose;
	}
	public void setRavt_purpose(String ravt_purpose) {
		this.ravt_purpose = ravt_purpose;
	}
	public String getRavt_order() {
		return ravt_order;
	}
	public void setRavt_order(String ravt_order) {
		this.ravt_order = ravt_order;
	}
	public String getRavt_update() {
		return ravt_update;
	}
	public void setRavt_update(String ravt_update) {
		this.ravt_update = ravt_update;
	}
	public String getRavt_upuser() {
		return ravt_upuser;
	}
	public void setRavt_upuser(String ravt_upuser) {
		this.ravt_upuser = ravt_upuser;
	}
	public String getRavt_notuse() {
		return ravt_notuse;
	}
	public void setRavt_notuse(String ravt_notuse) {
		this.ravt_notuse = ravt_notuse;
	}


}
