/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD INCORPORATED,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kannami.db.entity;


/**
 * <PRE>
 *  ����(���̓e�X�g) �w�b�_�[ �e�X�g���� �\���p�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.10.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31927000_detailscoreEntity {


	/** 
	 * �w�Z�R�[�h 
	 */
	private String scl_cd ;
	/** 
     * �n��E�R�[�X�R�[�h
     */
	private String sclc_cd ;

	/** 
	 * �w�Z�� 
	 */
	private String scl_name;

	/** 
	 * ���̓e�X�g�����R�[�h 
	 */
	private String abtt_code;

	/** 
	 * ���̓e�X�g������ 
	 */
	private String abtt_name;
	/** 
	 * ���̓e�X�g�������Q 
	 */
	private String abtt_name2;
	/** 
	 * ���̓e�X�g�� 
	 */
	private String abtt_date;

	/** 
     * �����R�[�h
     */
    private String css_user;
    /** 
     * �N�x
     */
    private String css_year;
    /** 
     * ���Z���R�[�h
     */
    private String css_sclcd;
    /** 																																																																																																																																																																																																																																																															mst_holiday
     * �n��R�[�X�R�[�h																																																																																																																																																																																																																																																															mst_ipscreenobject
     */
    private String css_sclccd;
    /** 
     * ���{�����R�[�h
     */
    private String css_abttcode;
    /** 
     * �������_
     */
    private Integer css_scoresum;
    /** 
     * �X�V��
     */
    private String css_update;
    /** 
     * �X�V��
     */
    private String css_upuser;
    
    
	public String getScl_cd() {
		return scl_cd;
	}
	public void setScl_cd(String scl_cd) {
		this.scl_cd = scl_cd;
	}
	public String getSclc_cd() {
		return sclc_cd;
	}
	public void setSclc_cd(String sclc_cd) {
		this.sclc_cd = sclc_cd;
	}
	public String getScl_name() {
		return scl_name;
	}
	public void setScl_name(String scl_name) {
		this.scl_name = scl_name;
	}
	public String getAbtt_code() {
		return abtt_code;
	}
	public void setAbtt_code(String abtt_code) {
		this.abtt_code = abtt_code;
	}
	public String getAbtt_name() {
		return abtt_name;
	}
	public void setAbtt_name(String abtt_name) {
		this.abtt_name = abtt_name;
	}
	public String getAbtt_name2() {
		return abtt_name2;
	}
	public void setAbtt_name2(String abtt_name2) {
		this.abtt_name2 = abtt_name2;
	}
	public String getAbtt_date() {
		return abtt_date;
	}
	public void setAbtt_date(String abtt_date) {
		this.abtt_date = abtt_date;
	}
	public String getCss_user() {
		return css_user;
	}
	public void setCss_user(String css_user) {
		this.css_user = css_user;
	}
	public String getCss_year() {
		return css_year;
	}
	public void setCss_year(String css_year) {
		this.css_year = css_year;
	}
	public String getCss_sclcd() {
		return css_sclcd;
	}
	public void setCss_sclcd(String css_sclcd) {
		this.css_sclcd = css_sclcd;
	}
	public String getCss_sclccd() {
		return css_sclccd;
	}
	public void setCss_sclccd(String css_sclccd) {
		this.css_sclccd = css_sclccd;
	}
	public String getCss_abttcode() {
		return css_abttcode;
	}
	public void setCss_abttcode(String css_abttcode) {
		this.css_abttcode = css_abttcode;
	}
	public Integer getCss_scoresum() {
		return css_scoresum;
	}
	public void setCss_scoresum(Integer css_scoresum) {
		this.css_scoresum = css_scoresum;
	}
	public String getCss_update() {
		return css_update;
	}
	public void setCss_update(String css_update) {
		this.css_update = css_update;
	}
	public String getCss_upuser() {
		return css_upuser;
	}
	public void setCss_upuser(String css_upuser) {
		this.css_upuser = css_upuser;
	}

    
}
