package jp.co.systemd.tnavi.cus.kannami.db.entity;

/**
 * <PRE>
 * ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ϓ_�]�� Entity.
 * </PRE>
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31967000EvalEntity {

	/**
	 * ���ȃR�[�h
	 */
	private String si_item;
	
	/**
	 * ���Ȗ���
	 */
	private String si_reportname;
	
	/**
	 * �ϓ_�R�[�h
	 */
	private String srivt_srivtcode;
	
	/**
	 * �ϓ_����
	 */
	private String srivt_rname;
	
	/**
	 * �ʊϓ_
	 */
	private String srvpv_indivivp;
	
	/**
	 * �ʊϓ_�i�����l)
	 */
	private String srivt_purpose;
	
	/**
	 * �m��]��
	 */
	private String srvpv_manualest;

	public String getSi_item() {
		return si_item;
	}

	public void setSi_item(String si_item) {
		this.si_item = si_item;
	}

	public String getSi_reportname() {
		return si_reportname;
	}

	public void setSi_reportname(String si_reportname) {
		this.si_reportname = si_reportname;
	}

	public String getSrivt_srivtcode() {
		return srivt_srivtcode;
	}

	public void setSrivt_srivtcode(String srivt_srivtcode) {
		this.srivt_srivtcode = srivt_srivtcode;
	}

	public String getSrivt_rname() {
		return srivt_rname;
	}

	public void setSrivt_rname(String srivt_rname) {
		this.srivt_rname = srivt_rname;
	}

	public String getSrvpv_indivivp() {
		return srvpv_indivivp;
	}

	public void setSrvpv_indivivp(String srvpv_indivivp) {
		this.srvpv_indivivp = srvpv_indivivp;
	}

	public String getSrivt_purpose() {
		return srivt_purpose;
	}

	public void setSrivt_purpose(String srivt_purpose) {
		this.srivt_purpose = srivt_purpose;
	}

	public String getSrvpv_manualest() {
		return srvpv_manualest;
	}

	public void setSrvpv_manualest(String srvpv_manualest) {
		this.srvpv_manualest = srvpv_manualest;
	}
	
	
}