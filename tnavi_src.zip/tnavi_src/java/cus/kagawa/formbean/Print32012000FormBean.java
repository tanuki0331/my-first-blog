package jp.co.systemd.tnavi.cus.kagawa.formbean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_ActEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_AddItemEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_AttendEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_ClubEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_CommentEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_EvalItemEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_EvalValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_ForeignActEntity;
//import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_ForeignActFuzokukyotoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_HroomInfoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_ItemViewpointInfoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_PostEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_RetcValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_SpecialactEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_StaffEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_StuSchoolInfoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data32012000_TotalactEntity;
import lombok.Getter;
import lombok.Setter;

/**
 * <PRE>
 * ���k�w���v�^�l��2(���쌧����) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.2.20 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print32012000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �����R�[�h */
	private String userCode = DEFALUT_VALUE;

	/** �w�Z�敪 */
	private String useKind2 = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �N�x(yyyy) */
	private String nendoSeireki = DEFALUT_VALUE;

	/** �N�x�I���� */
	private String nendoEndYmd = DEFALUT_VALUE;

	/**COReports�o�͎� �l��2-1 �t�H�[���t�@�C��*/
	private String coFormPath_yosiki2_1 = DEFALUT_VALUE;

	/**COReports�o�͎� �l��2-2 �t�H�[���t�@�C��*/
	private String coFormPath_yosiki2_2 = DEFALUT_VALUE;

	/** ���w�̊ϓ_�������Ǘ����ۂ� */
	private boolean isTotalactMultiVp = false;

	/** ���k�����E�w�Z�� */
	Data32012000_StuSchoolInfoEntity stuSchoolInfo;

	/** �o�͑Ώ۔N�x�̃z�[�����[����� */
	Data32012000_HroomInfoEntity hroomInfoList;

	/** �]��̏o�͑Ώۋ��ȏ��̃��X�g */
	List<Data32012000_EvalItemEntity> evalItemList;

	/** ���ȕʊϓ_�E�ϓ_�ʕ]���̃��X�g */
	List<Data32012000_ItemViewpointInfoEntity> itemViewpointInfoList;

	/** ���Ȗ��ɕ����������ȕʊϓ_�E�ϓ_�ʕ]���̃��X�g */
	List<List<Data32012000_ItemViewpointInfoEntity>> itemViewpointInfoListList;

	/** ���ȕʊϓ_�̋��Ȗ��̊ϓ_�����i�[����Map */
	Map<String, Integer> viewpointItemCntMap = new HashMap<String, Integer>();

	/** ���ȕʂ̕]��̃��X�g */
	List<Data32012000_EvalValueEntity> evalValueList;

	/** �����I�Ȋw�K�̎��Ԃ̋L�^���̃��X�g(�ϓ_�P��Ǘ����p)  */
	private List<Data32012000_TotalactEntity> totalactEntityList;

	/** �����I�Ȋw�K�̎��Ԃ�Map(�ϓ_�����Ǘ����p key:�w�N value:�����I�Ȋw�K�̎��Ԃ̋L�^���̃��X�g)  */
	private Map<String ,List<Data32012000_TotalactEntity>> totalactEntityListMap;

	/** ���ʊ����̋L�^�ϓ_ */
	private String speactViewpoint = DEFALUT_VALUE;

	/** ���ʊ����̋L�^�̃��X�g */
	private List<Data32012000_SpecialactEntity> specialactEntityList;

	/** �s���̋L�^�̃��X�g */
	private List<Data32012000_ActEntity> actEntityList;

	/** �O���ꊈ���̋L�^�̃��X�g */
	private List<Data32012000_ForeignActEntity> foreignActList;

	/** �����̃��X�g */
	private Data32012000_CommentEntity commentEntityList;

	/** �o���̋L�^�̃��X�g */
	private Data32012000_AttendEntity attendEntityList;

	/** �������̏o�͗L��*/
	private boolean watermark_on = false;

	/** �����E�Z���̈󎚓��e�̑I��*/
	private String nameAddrOutputMode = DEFALUT_VALUE;

	/** �����E�Z���̗����y�[�W�̏o�͗L��*/
	private boolean outputHistoryPage = false;

	/** �w�Z������������� */
	private Data32012000_StaffEntity principalHistory;

	/** �w���S�C����������� */
	private Data32012000_StaffEntity staffHistory;

	/** ��������� */
	private List<Data32012000_ClubEntity> clubEntity;

	/** �ψ��E�W������� */
	private List<Data32012000_PostEntity> postEntity;

	/** ���k�t����� (����) */
	private Data32012000_AddItemEntity addItemEntityKan;

	/** ���k�t����� (�p��) */
	private Data32012000_AddItemEntity addItemEntityEnglish;

	/** ���k�t����� (�V�̗̓e�X�g ���{��) */
	@Getter @Setter
	private Data32012000_AddItemEntity addItemEntityPhysicalDate;

	/** ���k�t����� (�V�̗̓e�X�g �]��) */
	@Getter @Setter
	private Data32012000_AddItemEntity addItemEntityPhysicalEstimate;

	/** ��ܗ��Ȃ� */
	private Data32012000_RetcValueEntity retcValueEntity;

	/** ���{�t���O */
	private boolean shohon = false;

	/** �o�͑Ώۊw�N�@*/
	private String outputGrade = DEFALUT_VALUE;

	/** �o�͑Ώ۔N�@*/
	private String outputYear = DEFALUT_VALUE;
	/** �o�͑Ώی��@*/
	private String outputMonth = DEFALUT_VALUE;
	/** �o�͑Ώۓ��@*/
	private String outputDay = DEFALUT_VALUE;


	/**
	 * @return userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode the userCode to set
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUseKind2() {
		return useKind2;
	}

	public void setUseKind2(String useKind2) {
		this.useKind2 = useKind2;
	}

	/**
	 * @return nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo the nendo to set
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getNendoSeireki() {
		return nendoSeireki;
	}

	public void setNendoSeireki(String nendoSeireki) {
		this.nendoSeireki = nendoSeireki;
	}

	/**
	 * @return nendoEndYmd
	 */
	public String getNendoEndYmd() {
		return nendoEndYmd;
	}

	/**
	 * @param nendoEndYmd the nendoEndYmd to set
	 */
	public void setNendoEndYmd(String nendoEndYmd) {
		this.nendoEndYmd = nendoEndYmd;
	}

	public String getCoFormPath_yosiki2_1() {
		return coFormPath_yosiki2_1;
	}

	public void setCoFormPath_yosiki2_1(String coFormPath_yosiki2_1) {
		this.coFormPath_yosiki2_1 = coFormPath_yosiki2_1;
	}

	public String getCoFormPath_yosiki2_2() {
		return coFormPath_yosiki2_2;
	}

	public void setCoFormPath_yosiki2_2(String coFormPath_yosiki2_2) {
		this.coFormPath_yosiki2_2 = coFormPath_yosiki2_2;
	}

	/**
	 * @return isTotalactMultiVp
	 */
	public boolean isTotalactMultiVp() {
		return isTotalactMultiVp;
	}

	/**
	 * @param isTotalactMultiVp the isTotalactMultiVp to set
	 */
	public void setTotalactMultiVp(boolean isTotalactMultiVp) {
		this.isTotalactMultiVp = isTotalactMultiVp;
	}

	/**
	 * @return stuSchoolInfo
	 */
	public Data32012000_StuSchoolInfoEntity getStuSchoolInfo() {
		return stuSchoolInfo;
	}

	/**
	 * @param stuSchoolInfo the stuSchoolInfo to set
	 */
	public void setStuSchoolInfo(Data32012000_StuSchoolInfoEntity stuSchoolInfo) {
		this.stuSchoolInfo = stuSchoolInfo;
	}

	/**
	 * @return hroomInfoList
	 */
	public Data32012000_HroomInfoEntity getHroomInfoList() {
		return hroomInfoList;
	}

	/**
	 * @param hroomInfoList the hroomInfoList to set
	 */
	public void setHroomInfoList(Data32012000_HroomInfoEntity hroomInfoList) {
		this.hroomInfoList = hroomInfoList;
	}

	/**
	 * @return evalItemList
	 */
	public List<Data32012000_EvalItemEntity> getEvalItemList() {
		return evalItemList;
	}

	/**
	 * @param evalItemList the evalItemList to set
	 */
	public void setEvalItemList(List<Data32012000_EvalItemEntity> evalItemList) {
		this.evalItemList = evalItemList;
	}

	/**
	 * @return itemViewpointInfoList
	 */
	public List<Data32012000_ItemViewpointInfoEntity> getItemViewpointInfoList() {
		return itemViewpointInfoList;
	}

	/**
	 * @param itemViewpointInfoList the itemViewpointInfoList to set
	 */
	public void setItemViewpointInfoList(
			List<Data32012000_ItemViewpointInfoEntity> itemViewpointInfoList) {
		this.itemViewpointInfoList = itemViewpointInfoList;
	}

	/**
	 * @return itemViewpointInfoListList
	 */
	public List<List<Data32012000_ItemViewpointInfoEntity>> getItemViewpointInfoListList() {
		return itemViewpointInfoListList;
	}

	/**
	 * @param itemViewpointInfoListList the itemViewpointInfoListList to set
	 */
	public void setItemViewpointInfoListList(
			List<List<Data32012000_ItemViewpointInfoEntity>> itemViewpointInfoListList) {
		this.itemViewpointInfoListList = itemViewpointInfoListList;
	}

	/**
	 * @return viewpointItemCntMap
	 */
	public Map<String, Integer> getViewpointItemCntMap() {
		return viewpointItemCntMap;
	}

	/**
	 * @param viewpointItemCntMap the viewpointItemCntMap to set
	 */
	public void setViewpointItemCntMap(Map<String, Integer> viewpointItemCntMap) {
		this.viewpointItemCntMap = viewpointItemCntMap;
	}

	/**
	 * @return evalValueList
	 */
	public List<Data32012000_EvalValueEntity> getEvalValueList() {
		return evalValueList;
	}

	/**
	 * @param evalValueList the evalValueList to set
	 */
	public void setEvalValueList(List<Data32012000_EvalValueEntity> evalValueList) {
		this.evalValueList = evalValueList;
	}

	/**
	 * @return totalactEntityList
	 */
	public List<Data32012000_TotalactEntity> getTotalactEntityList() {
		return totalactEntityList;
	}

	/**
	 * @param totalactEntityList the totalactEntityList to set
	 */
	public void setTotalactEntityList(
			List<Data32012000_TotalactEntity> totalactEntityList) {
		this.totalactEntityList = totalactEntityList;
	}

	/**
	 * @return totalactEntityListMap
	 */
	public Map<String, List<Data32012000_TotalactEntity>> getTotalactEntityListMap() {
		return totalactEntityListMap;
	}

	/**
	 * @param totalactEntityListMap the totalactEntityListMap to set
	 */
	public void setTotalactEntityListMap(
			Map<String, List<Data32012000_TotalactEntity>> totalactEntityListMap) {
		this.totalactEntityListMap = totalactEntityListMap;
	}

	/**
	 * @return speactViewpoint
	 */
	public String getSpeactViewpoint() {
		return speactViewpoint;
	}

	/**
	 * @param speactViewpoint the speactViewpoint to set
	 */
	public void setSpeactViewpoint(String speactViewpoint) {
		this.speactViewpoint = speactViewpoint;
	}

	/**
	 * @return specialactEntityList
	 */
	public List<Data32012000_SpecialactEntity> getSpecialactEntityList() {
		return specialactEntityList;
	}

	/**
	 * @param specialactEntityList the specialactEntityList to set
	 */
	public void setSpecialactEntityList(
			List<Data32012000_SpecialactEntity> specialactEntityList) {
		this.specialactEntityList = specialactEntityList;
	}

	/**
	 * @return actEntityList
	 */
	public List<Data32012000_ActEntity> getActEntityList() {
		return actEntityList;
	}

	/**
	 * @param actEntityList the actEntityList to set
	 */
	public void setActEntityList(List<Data32012000_ActEntity> actEntityList) {
		this.actEntityList = actEntityList;
	}

	public List<Data32012000_ForeignActEntity> getForeignActList() {
		return foreignActList;
	}

	public void setForeignActList(List<Data32012000_ForeignActEntity> foreignActList) {
		this.foreignActList = foreignActList;
	}

	/**
	 * @return commentEntityList
	 */
	public Data32012000_CommentEntity getCommentEntityList() {
		return commentEntityList;
	}

	/**
	 * @param commentEntityList the commentEntityList to set
	 */
	public void setCommentEntityList(Data32012000_CommentEntity commentEntityList) {
		this.commentEntityList = commentEntityList;
	}

	/**
	 * @return attendEntityList
	 */
	public Data32012000_AttendEntity getAttendEntityList() {
		return attendEntityList;
	}

	/**
	 * @param attendEntityList the attendEntityList to set
	 */
	public void setAttendEntityList(Data32012000_AttendEntity attendEntityList) {
		this.attendEntityList = attendEntityList;
	}

	/**
	 * @return watermark_on
	 */
	public boolean isWatermark_on() {
		return watermark_on;
	}

	/**
	 * @param watermark_on watermark_on��ݒ肷��
	 */
	public void setWatermark_on(boolean watermark_on) {
		this.watermark_on = watermark_on;
	}

	/**
	 * @return nameAddrOutputMode
	 */
	public String getNameAddrOutputMode() {
		return nameAddrOutputMode;
	}

	/**
	 * @param nameAddrOutputMode nameAddrOutputMode��ݒ肷��
	 */
	public void setNameAddrOutputMode(String nameAddrOutputMode) {
		this.nameAddrOutputMode = nameAddrOutputMode;
	}

	/**
	 * @return outputHistoryPage
	 */
	public boolean isOutputHistoryPage() {
		return outputHistoryPage;
	}

	/**
	 * @param outputHistoryPage outputHistoryPage��ݒ肷��
	 */
	public void setOutputHistoryPage(boolean outputHistoryPage) {
		this.outputHistoryPage = outputHistoryPage;
	}

	public Data32012000_StaffEntity getPrincipalHistory() {
		return principalHistory;
	}

	public void setPrincipalHistory(Data32012000_StaffEntity principalHistory) {
		this.principalHistory = principalHistory;
	}

	public Data32012000_StaffEntity getStaffHistory() {
		return staffHistory;
	}

	public void setStaffHistory(Data32012000_StaffEntity staffHistory) {
		this.staffHistory = staffHistory;
	}

	public boolean isShohon() {
		return shohon;
	}

	public void setShohon(boolean shohon) {
		this.shohon = shohon;
	}

	public String getOutputGrade() {
		return outputGrade;
	}

	public void setOutputGrade(String outputGrade) {
		this.outputGrade = outputGrade;
	}

	public String getOutputYear() {
		return outputYear;
	}

	public void setOutputYear(String outputYear) {
		this.outputYear = outputYear;
	}

	public String getOutputMonth() {
		return outputMonth;
	}

	public void setOutputMonth(String outputMonth) {
		this.outputMonth = outputMonth;
	}

	public String getOutputDay() {
		return outputDay;
	}

	public void setOutputDay(String outputDay) {
		this.outputDay = outputDay;
	}

	public List<Data32012000_ClubEntity> getClubEntity() {
		return clubEntity;
	}

	public void setClubEntity(List<Data32012000_ClubEntity> clubEntity) {
		this.clubEntity = clubEntity;
	}

	public List<Data32012000_PostEntity> getPostEntity() {
		return postEntity;
	}

	public void setPostEntity(List<Data32012000_PostEntity> postEntity) {
		this.postEntity = postEntity;
	}

	public Data32012000_AddItemEntity getAddItemEntityKan() {
		return addItemEntityKan;
	}

	public void setAddItemEntityKan(Data32012000_AddItemEntity addItemEntityKan) {
		this.addItemEntityKan = addItemEntityKan;
	}

	public Data32012000_AddItemEntity getAddItemEntityEnglish() {
		return addItemEntityEnglish;
	}

	public void setAddItemEntityEnglish(Data32012000_AddItemEntity addItemEntityEnglish) {
		this.addItemEntityEnglish = addItemEntityEnglish;
	}

	public Data32012000_RetcValueEntity getRetcValueEntity() {
		return retcValueEntity;
	}

	public void setRetcValueEntity(Data32012000_RetcValueEntity retcValueEntity) {
		this.retcValueEntity = retcValueEntity;
	}

}
