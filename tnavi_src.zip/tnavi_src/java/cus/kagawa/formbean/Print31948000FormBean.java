package jp.co.systemd.tnavi.cus.kagawa.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ActViewpointValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_AttendEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_AttendMemoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_CommentEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ItemEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ItemEvalEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_SpeactValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_StudentInfoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_TotalactValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ViewpointEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ViewpointValueEntity;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31948000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String grade = DEFALUT_VALUE;

	/** �g **/
	private String hmrclass = DEFALUT_VALUE;

	/** �o�͎��� */
	private String goptCode = DEFALUT_VALUE;

	/** �o�͎����� */
	private String goptName = DEFALUT_VALUE;

	/** �ŏI�w���t���O */
	private String lastGopt = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C���N����*/
	private String completeDate = DEFALUT_VALUE;

	/** �Z�̓C���[�W */
	byte[] schoolStampImage;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �S�C���� */
	private String teacherName = DEFALUT_VALUE;

	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;

	/** ���k��񃊃X�g */
	private List<Data31948000_StudentInfoEntity> studentInfoEntityList;

	/** ���Ȃ̃��X�g */
	List<Data31948000_ItemEntity> itemEntityList;

	/** (���ȕ�)�ϓ_�}�b�v */
	Map<String, List<Data31948000_ViewpointEntity>> viewpointEntityListMap;

	/** (���k��)�ϓ_�ʕ]���}�b�v�̃}�b�v */
	private Map<String, Map<String, Data31948000_ViewpointValueEntity>> viewpointValueEntityMapMap;

	/** (���k��)���ȕʕ]��}�b�v�̃}�b�v */
	private Map<String, Map<String, Data31948000_ItemEvalEntity>> itemEvalEntityMapMap;

	/** (���k��)���ʊ����̋L�^�̕]�����X�g�}�b�v */
	private Map<String, List<Data31948000_SpeactValueEntity>> speactValueEntityListMap;

	/** �s���̋L�^�̊ϓ_���X�g  */
	private List<Data31948000_ActViewpointEntity> actViewpointEntityList;

	/** (���k��)�s���̋L�^�̕]�����X�g�̃}�b�v  */
	private Map<String, List<Data31948000_ActViewpointValueEntity>> actViewpointValueEntityListMap;

	/** (���k��)�o���̋L�^�}�b�v�̃}�b�v */
	private Map<String, Map<String, Data31948000_AttendEntity>> attendEntityMapMap;

	/** (���k��)�N�Ԍv�̏o���̋L�^�}�b�v�̃}�b�v */
	private Map<String, Map<String, Data31948000_AttendEntity>> totalAttendEntityListMapMap;

	/** (���k��)�o���̋L�^�̔��l�}�b�v	 */
	private Map<String, Data31948000_AttendMemoEntity> attendMemoEntityMap;

	/** �S�C����̌��t(�������e)�̃��X�g  */
	private List<Data31948000_CommentEntity> commentEntityList;

	/** �����I�Ȋw�K�̎��Ԃ̋L�^�̕]���̃��X�g  */
	private List<Data31948000_TotalactValueEntity> totalactValueEntityList;

	/** ����y�[�W�\���E�C���� */
	private boolean output_cover;

	/** ����y�[�W���� */
	private boolean output_score;

	/** ����y�[�W�ϓ_�ʕ]���E�]�� */
	private boolean output_eval;

	/** �o�͑Ώۂ̏o���̋L�^�̏o�͎����R�[�h���X�g*/
	private String[] attendTermArray;

	/**
	 * @return userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode �Z�b�g���� userCode
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	/**
	 * @return nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo �Z�b�g���� nendo
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return grade
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * @param grade �Z�b�g���� grade
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}


	/**
	 * @return hmrclass
	 */
	public String getHmrclass() {
		return hmrclass;
	}

	/**
	 * @param hmrclass �Z�b�g���� hmrclass
	 */
	public void setHmrclass(String hmrclass) {
		this.hmrclass = hmrclass;
	}

	/**
	 * @return goptCode
	 */
	public String getGoptCode() {
		return goptCode;
	}

	/**
	 * @param goptCode �Z�b�g���� goptCode
	 */
	public void setGoptCode(String goptCode) {
		this.goptCode = goptCode;
	}

	/**
	 * @return goptName
	 */
	public String getGoptName() {
		return goptName;
	}

	/**
	 * @param goptName �Z�b�g���� goptName
	 */
	public void setGoptName(String goptName) {
		this.goptName = goptName;
	}

	/**
	 * @return lastGopt
	 */
	public String getLastGopt() {
		return lastGopt;
	}

	/**
	 * @param lastGopt �Z�b�g���� lastGopt
	 */
	public void setLastGopt(String lastGopt) {
		this.lastGopt = lastGopt;
	}

	/**
	 * @return outputDate
	 */
	public String getOutputDate() {
		return outputDate;
	}

	/**
	 * @param outputDate �Z�b�g���� outputDate
	 */
	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	/**
	 * @return completeDate
	 */
	public String getCompleteDate() {
		return completeDate;
	}

	/**
	 * @param completeDate �Z�b�g���� completeDate
	 */
	public void setCompleteDate(String completeDate) {
		this.completeDate = completeDate;
	}

	/**
	 * @return schoolStampImage
	 */
	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	/**
	 * @param schoolStampImage �Z�b�g���� schoolStampImage
	 */
	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	/**
	 * @return principalName
	 */
	public String getPrincipalName() {
		return principalName;
	}

	/**
	 * @param principalName �Z�b�g���� principalName
	 */
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	/**
	 * @return teacherName
	 */
	public String getTeacherName() {
		return teacherName;
	}

	/**
	 * @param teacherName �Z�b�g���� teacherName
	 */
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	/**
	 * @return schoolName
	 */
	public String getSchoolName() {
		return schoolName;
	}

	/**
	 * @param schoolName �Z�b�g���� schoolName
	 */
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	/**
	 * @return studentInfoEntityList
	 */
	public List<Data31948000_StudentInfoEntity> getStudentInfoEntityList() {
		return studentInfoEntityList;
	}

	/**
	 * @param studentInfoEntityList �Z�b�g���� studentInfoEntityList
	 */
	public void setStudentInfoEntityList(List<Data31948000_StudentInfoEntity> studentInfoEntityList) {
		this.studentInfoEntityList = studentInfoEntityList;
	}

	/**
	 * @return itemEntityList
	 */
	public List<Data31948000_ItemEntity> getItemEntityList() {
		return itemEntityList;
	}

	/**
	 * @param itemEntityList �Z�b�g���� itemEntityList
	 */
	public void setItemEntityList(List<Data31948000_ItemEntity> itemEntityList) {
		this.itemEntityList = itemEntityList;
	}

	/**
	 * @return viewpointEntityListMap
	 */
	public Map<String, List<Data31948000_ViewpointEntity>> getViewpointEntityListMap() {
		return viewpointEntityListMap;
	}

	/**
	 * @param viewpointEntityListMap �Z�b�g���� viewpointEntityListMap
	 */
	public void setViewpointEntityListMap(Map<String, List<Data31948000_ViewpointEntity>> viewpointEntityListMap) {
		this.viewpointEntityListMap = viewpointEntityListMap;
	}

	/**
	 * @return viewpointValueEntityMapMap
	 */
	public Map<String, Map<String, Data31948000_ViewpointValueEntity>> getViewpointValueEntityMapMap() {
		return viewpointValueEntityMapMap;
	}

	/**
	 * @param viewpointValueEntityMapMap �Z�b�g���� viewpointValueEntityMapMap
	 */
	public void setViewpointValueEntityMapMap(
			Map<String, Map<String, Data31948000_ViewpointValueEntity>> viewpointValueEntityMapMap) {
		this.viewpointValueEntityMapMap = viewpointValueEntityMapMap;
	}

	/**
	 * @return itemEvalEntityMapMap
	 */
	public Map<String, Map<String, Data31948000_ItemEvalEntity>> getItemEvalEntityMapMap() {
		return itemEvalEntityMapMap;
	}

	/**
	 * @param itemEvalEntityMapMap �Z�b�g���� itemEvalEntityMapMap
	 */
	public void setItemEvalEntityMapMap(Map<String, Map<String, Data31948000_ItemEvalEntity>> itemEvalEntityMapMap) {
		this.itemEvalEntityMapMap = itemEvalEntityMapMap;
	}

	/**
	 * @return speactValueEntityListMap
	 */
	public Map<String, List<Data31948000_SpeactValueEntity>> getSpeactValueEntityListMap() {
		return speactValueEntityListMap;
	}

	/**
	 * @param speactValueEntityListMap �Z�b�g���� speactValueEntityListMap
	 */
	public void setSpeactValueEntityListMap(Map<String, List<Data31948000_SpeactValueEntity>> speactValueEntityListMap) {
		this.speactValueEntityListMap = speactValueEntityListMap;
	}

	/**
	 * @return actViewpointEntityList
	 */
	public List<Data31948000_ActViewpointEntity> getActViewpointEntityList() {
		return actViewpointEntityList;
	}

	/**
	 * @param actViewpointEntityList �Z�b�g���� actViewpointEntityList
	 */
	public void setActViewpointEntityList(List<Data31948000_ActViewpointEntity> actViewpointEntityList) {
		this.actViewpointEntityList = actViewpointEntityList;
	}

	/**
	 * @return actViewpointValueEntityListMap
	 */
	public Map<String, List<Data31948000_ActViewpointValueEntity>> getActViewpointValueEntityListMap() {
		return actViewpointValueEntityListMap;
	}

	/**
	 * @param actViewpointValueEntityListMap �Z�b�g���� actViewpointValueEntityListMap
	 */
	public void setActViewpointValueEntityListMap(
			Map<String, List<Data31948000_ActViewpointValueEntity>> actViewpointValueEntityListMap) {
		this.actViewpointValueEntityListMap = actViewpointValueEntityListMap;
	}

	/**
	 * @return attendEntityMapMap
	 */
	public Map<String, Map<String, Data31948000_AttendEntity>> getAttendEntityMapMap() {
		return attendEntityMapMap;
	}

	/**
	 * @param attendEntityMapMap �Z�b�g���� attendEntityMapMap
	 */
	public void setAttendEntityMapMap(Map<String, Map<String, Data31948000_AttendEntity>> attendEntityMapMap) {
		this.attendEntityMapMap = attendEntityMapMap;
	}

	public Map<String, Map<String, Data31948000_AttendEntity>> getTotalAttendEntityListMapMap() {
		return totalAttendEntityListMapMap;
	}

	public void setTotalAttendEntityListMapMap(
			Map<String, Map<String, Data31948000_AttendEntity>> totalAttendEntityListMapMap) {
		this.totalAttendEntityListMapMap = totalAttendEntityListMapMap;
	}

	/**
	 * @return attendMemoEntityMap
	 */
	public Map<String, Data31948000_AttendMemoEntity> getAttendMemoEntityMap() {
		return attendMemoEntityMap;
	}

	/**
	 * @param attendMemoEntityMap �Z�b�g���� attendMemoEntityMap
	 */
	public void setAttendMemoEntityMap(Map<String, Data31948000_AttendMemoEntity> attendMemoEntityMap) {
		this.attendMemoEntityMap = attendMemoEntityMap;
	}

	/**
	 * @return commentEntityList
	 */
	public List<Data31948000_CommentEntity> getCommentEntityList() {
		return commentEntityList;
	}

	/**
	 * @param commentEntityList �Z�b�g���� commentEntityList
	 */
	public void setCommentEntityList(List<Data31948000_CommentEntity> commentEntityList) {
		this.commentEntityList = commentEntityList;
	}

	/**
	 * @return totalactValueEntityList
	 */
	public List<Data31948000_TotalactValueEntity> getTotalactValueEntityList() {
		return totalactValueEntityList;
	}

	/**
	 * @param totalactValueEntityList �Z�b�g���� totalactValueEntityList
	 */
	public void setTotalactValueEntityList(List<Data31948000_TotalactValueEntity> totalactValueEntityList) {
		this.totalactValueEntityList = totalactValueEntityList;
	}

	/**
	 * @return output_cover
	 */
	public boolean isOutput_cover() {
		return output_cover;
	}

	/**
	 * @param output_cover �Z�b�g���� output_cover
	 */
	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	/**
	 * @return output_score
	 */
	public boolean isOutput_score() {
		return output_score;
	}

	/**
	 * @param output_score �Z�b�g���� output_score
	 */
	public void setOutput_score(boolean output_score) {
		this.output_score = output_score;
	}

	/**
	 * @return output_eval
	 */
	public boolean isOutput_eval() {
		return output_eval;
	}

	/**
	 * @param output_eval �Z�b�g���� output_eval
	 */
	public void setOutput_eval(boolean output_eval) {
		this.output_eval = output_eval;
	}

	/**
	 * @return attendTermArray
	 */
	public String[] getAttendTermArray() {
		return attendTermArray;
	}

	/**
	 * @param attendTermArray �Z�b�g���� attendTermArray
	 */
	public void setAttendTermArray(String[] attendTermArray) {
		this.attendTermArray = attendTermArray;
	}

}
