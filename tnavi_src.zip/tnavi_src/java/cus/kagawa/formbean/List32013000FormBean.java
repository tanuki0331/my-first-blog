/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kagawa.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.aff.db.entity.Data30367000_studentEntity;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;

/**
 * <PRE>
 * �w���v�^���{���(���쌧����) ��� FormBean�N���X.
 * </PRE>
 *
 * <B>Create</B> 2018.02.20 BY ueken<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List32013000FormBean {

	/**
	 * �����l
	 */
	public final static String DEFALUT_VALUE = "";

	/**
	 * �N�x
	 */
	private String nendo = DEFALUT_VALUE;

	/**
	 * �N�x�i��ʏ����l�j
	 */
	private String init_nendo = null;

	/**
	 * �w�N
	 */
	private String grade = DEFALUT_VALUE;

	/**
	 * ��ʁi��ʏ����l�j
	 */
	private String init_grade = null;

	/**
	 * �g
	 */
	private String cls = DEFALUT_VALUE;

	/**
	 * ���k���X�g
	 */
	private List<Data30367000_studentEntity> studentList = new ArrayList<Data30367000_studentEntity>();

	/**
	 * �o�͔N
	 */
	private String output_year = DEFALUT_VALUE;

	/**
	 * �o�͌�
	 */
	private String output_month = DEFALUT_VALUE;

	/**
	 * �o�͓�
	 */
	private String output_day = DEFALUT_VALUE;

	/**
	 * �������k����
	 */
	private String stu_name = DEFALUT_VALUE;

	/**
	 * CoReports���C�A�E�g
	 */
	private String crlayout = DEFALUT_VALUE;

    /**
     * ���v���_�E�����X�g
     */
    private List<SimpleTagFormBean> monthList = new ArrayList<SimpleTagFormBean>();
    /**
     * ���v���_�E�����X�g
     */
    private List<SimpleTagFormBean> dayList = new ArrayList<SimpleTagFormBean>();

	/**
	 * �v�^���ъw�N�i��ʏ����l�j
	 */
	private String output_grade = DEFALUT_VALUE;

    /**
     * �v�^���ъw�N�v���_�E�����X�g
     */
    private List<SimpleTagFormBean> outputGradeList = new ArrayList<SimpleTagFormBean>();

    /**
     * �ݐ�
     */
    private String zaiseki;
    /**
     * ����
     */
    private String sotsugyo;
    /**
     * �]�w
     */
    private String tengaku;
    /**
     * �ފw
     */
    private String taigaku;


	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getCls() {
		return cls;
	}

	public void setCls(String cls) {
		this.cls = cls;
	}

	public String getOutput_year() {
		return output_year;
	}

	public void setOutput_year(String output_year) {
		this.output_year = output_year;
	}

	public String getOutput_month() {
		return output_month;
	}

	public void setOutput_month(String output_month) {
		this.output_month = output_month;
	}

	public String getOutput_day() {
		return output_day;
	}

	public void setOutput_day(String output_day) {
		this.output_day = output_day;
	}

	public String getStu_name() {
		return stu_name;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public String getCrlayout() {
		return crlayout;
	}

	public void setCrlayout(String crlayout) {
		this.crlayout = crlayout;
	}

	public String getInit_nendo() {
		return init_nendo;
	}

	public void setInit_nendo(String init_nendo) {
		this.init_nendo = init_nendo;
	}

	public String getInit_grade() {
		return init_grade;
	}

	public void setInit_grade(String init_grade) {
		this.init_grade = init_grade;
	}

	public List<Data30367000_studentEntity> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<Data30367000_studentEntity> studentList) {
		this.studentList = studentList;
	}

	public List<SimpleTagFormBean> getMonthList() {
		return monthList;
	}
	public void setMonthList(List<SimpleTagFormBean> monthList) {
		this.monthList = monthList;
	}
	public List<SimpleTagFormBean> getDayList() {
		return dayList;
	}
	public void setDayList(List<SimpleTagFormBean> dayList) {
		this.dayList = dayList;
	}

	public String getOutput_grade() {
		return output_grade;
	}

	public void setOutput_grade(String output_grade) {
		this.output_grade = output_grade;
	}

	public List<SimpleTagFormBean> getOutputGradeList() {
		return outputGradeList;
	}
	public void setOutputGradeList(List<SimpleTagFormBean> outputGradeList) {
		this.outputGradeList = outputGradeList;
	}


	public String getZaiseki() {
		return zaiseki;
	}

	public void setZaiseki(String zaiseki) {
		this.zaiseki = zaiseki;
	}

	public String getSotsugyo() {
		return sotsugyo;
	}

	public void setSotsugyo(String sotsugyo) {
		this.sotsugyo = sotsugyo;
	}

	public String getTengaku() {
		return tengaku;
	}

	public void setTengaku(String tengaku) {
		this.tengaku = tengaku;
	}

	public String getTaigaku() {
		return taigaku;
	}

	public void setTaigaku(String taigaku) {
		this.taigaku = taigaku;
	}

}
