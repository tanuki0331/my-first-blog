/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kagawa.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.kagawa.db.service.List32013000Service;
import jp.co.systemd.tnavi.cus.kagawa.formbean.List32013000FormBean;

/**
 * <PRE>
 * �w���v�^���{���(���쌧����) ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2018.02.20 BY ueken<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List32013000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List32013000Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz�w���v�^���{��� START");

		// ------------------------------------------------------------------------------------------
		// FormBean����
		// ------------------------------------------------------------------------------------------
		List32013000FormBean listFormBean = (List32013000FormBean)copyRequestParamToFormBean(request, new List32013000FormBean());

		// ------------------------------------------------------------------------------------------
		// �����ݒ�
		// ------------------------------------------------------------------------------------------

		// �o�͓��t�@���A��
		String systemDate = DateUtility.getSystemDate();

		String useKind2 = "";

		useKind2 = sessionBean.getUseKind2() ;

		if(listFormBean.getNendo() == null || listFormBean.getNendo().length() == 0){
			listFormBean.setNendo(sessionBean.getSystemNendoSeireki());
			listFormBean.setOutput_year(systemDate.substring(0, 4));
			listFormBean.setOutput_month(systemDate.substring(4, 6));
			listFormBean.setOutput_day(systemDate.substring(6, 8));

			listFormBean.setZaiseki("1");
			listFormBean.setSotsugyo("1");
			listFormBean.setTengaku("1");
			listFormBean.setTaigaku("1");
		}else{
			if( listFormBean.getOutput_year()==null || listFormBean.getOutput_year().equals("") ){
				listFormBean.setOutput_year(systemDate.substring(0, 4));
			}
			if( listFormBean.getOutput_month()==null || listFormBean.getOutput_month().equals("") ){
				listFormBean.setOutput_month(systemDate.substring(4, 6));
			}
			if( listFormBean.getOutput_day()==null || listFormBean.getOutput_day().equals("") ){
				listFormBean.setOutput_day(systemDate.substring(6, 8));
			}
		}

		// ���R���{�{�b�N�X�p�f�[�^
		List<SimpleTagFormBean> simpleTagListMonth = new ArrayList<SimpleTagFormBean>();
		for(int i = 1; i <= 12; i++){
			simpleTagListMonth.add(new SimpleTagFormBean(String.format("%02d",i), String.format("%02d",i)));
		}
		listFormBean.setMonthList(simpleTagListMonth);

		// ���R���{�{�b�N�X�p�f�[�^
		List<SimpleTagFormBean> simpleTagListDay = new ArrayList<SimpleTagFormBean>();

		for(int i = 1; i <= 31; i++){
			simpleTagListDay.add(new SimpleTagFormBean(String.format("%02d",i), String.format("%02d",i)));
		}
		listFormBean.setDayList(simpleTagListDay);

		// �v�^���ъw�N
		int int_output_grade = 0;
		if ( useKind2.equals("1") ){
			int_output_grade = 6 ;//���w�Z �Œ�l
		}else{
			int_output_grade = 3 ;//���w�Z �Œ�l
		}

		// �v�^���ъw�N�p�f�[�^
		List<SimpleTagFormBean> simpleTagListOutputGrade = new ArrayList<SimpleTagFormBean>();
		for(int i = 1; i <= int_output_grade; i++){
			simpleTagListOutputGrade.add( new SimpleTagFormBean(String.valueOf(i), String.valueOf(i)));
		}
		listFormBean.setOutputGradeList(simpleTagListOutputGrade);
		listFormBean.setOutput_grade(String.valueOf(int_output_grade));

		//20160713 nagaoka �w���S�o�R�̏ꍇ�́A�w�������N�x�N�g���Z�b�g���Ă���(�����\�����̌����̂���)(��ʂł��ύX�s�Ȃ̂ŌŒ�Ŗ��Ȃ�)
		if(sessionBean.getSelectHroomKey() != null){
			listFormBean.setInit_nendo(sessionBean.getSelectHroomKey().getYear());//�N�x�@�����I��
			listFormBean.setInit_grade(sessionBean.getSelectHroomKey().getGlade());//�N�@�����I��
			listFormBean.setNendo(sessionBean.getSelectHroomKey().getYear());//�N�x
			listFormBean.setGrade(sessionBean.getSelectHroomKey().getGlade());//�N
			listFormBean.setCls(sessionBean.getSelectHroomKey().getHmrclass());//�g
		}

		// ------------------------------------------------------------------------------------------
		// �f�[�^�̎擾����
		// ------------------------------------------------------------------------------------------
		List32013000Service service = new List32013000Service(sessionBean, listFormBean);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", listFormBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz�w���v�^���{��� END");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}

}
