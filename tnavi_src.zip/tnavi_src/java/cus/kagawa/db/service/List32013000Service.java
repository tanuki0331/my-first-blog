/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kagawa.db.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.aff.db.entity.Data30367000_studentEntity;
import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.cus.kagawa.formbean.List32013000FormBean;


/**
 * <PRE>
 * �w���v�^���{��� (���쌧����)  ��� Service�N���X.
 * </PRE>
 *
 * <B>Create</B> 2018.02.20 BY ueken<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List32013000Service extends AbstractExecuteQuery{

	/** log4j */
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(List32013000Service.class);

	/** �����R�[�h */
	private String userCode;

	/** ���FormBean */
	private List32013000FormBean listFormBean;

	/** ���sSQL */
	private static final String EXEC_SQL_STUDENT_LIST = "aff/getData30367000_student_list.sql";				// ���k�ꗗ


	public List32013000Service(SystemInfoBean sessionBean, List32013000FormBean listFormBean) {
		this.userCode = sessionBean.getUserCode();
		this.listFormBean = listFormBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		if(listFormBean.getNendo().equals(listFormBean.getInit_nendo()) &&
		   listFormBean.getGrade().equals(listFormBean.getInit_grade())	){
			listFormBean.setStudentList(getStudentList());
		}
	}


	/**
	 * ���k�ꗗ���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Data30367000_studentEntity> getStudentList() {

		// �ǉ�SQL��
		StringBuffer plusSQL = new StringBuffer();

		// PrepearedParameter�̃��X�g
		List<Object> paramList = new ArrayList<Object>();
		paramList.add(userCode);
		paramList.add(listFormBean.getNendo());

		// ��ʂőI�����ꂽ�w�N
		String str_sql ="";
		if(listFormBean.getGrade() != null && listFormBean.getGrade().length() > 0){
			str_sql += " AND hmr_glade = '"+ listFormBean.getGrade() + "'" ;
		}
		// ��ʂőI�����ꂽ�g
		if(listFormBean.getCls() != null && listFormBean.getCls().length() > 0){
			str_sql += " AND hmr_class = '"+ listFormBean.getCls() + "'" ;
		}

		// ��ʂőI�����ꂽ���k����
		if(listFormBean.getStu_name() != null && listFormBean.getStu_name().length() > 0){
			str_sql += " AND ( REPLACE(REPLACE(stu_name  ,'�@',''),' ','') like '%" + listFormBean.getStu_name() + "%'" ;
			str_sql += "    OR REPLACE(REPLACE(st4_name_r,'�@',''),' ','') like '%" + listFormBean.getStu_name() + "%')" ;
		}

		// ��ʂňٓ����
		String str_zaiseki_status = "";

		if(listFormBean.getZaiseki() != null && listFormBean.getZaiseki().equals("1")){
			str_zaiseki_status += " ( cod_value1 = '' OR cod_value1 is null )";
		}

		// ����
		if(listFormBean.getSotsugyo() != null && listFormBean.getSotsugyo().equals("1")){
			if( str_zaiseki_status.length() > 0 ) str_zaiseki_status += " OR " ;
			str_zaiseki_status += " ( cod_value1 = '9' )";
		}

		// �]�w
		if(listFormBean.getTengaku() != null && listFormBean.getTengaku().equals("1")){
			if( str_zaiseki_status.length() > 0 ) str_zaiseki_status += " OR " ;
			str_zaiseki_status += " ( cod_value1 = '4' )";
		}

		// �ފw
		if(listFormBean.getTaigaku() != null && listFormBean.getTaigaku().equals("1")){
			if( str_zaiseki_status.length() > 0 ) str_zaiseki_status += " OR " ;
			str_zaiseki_status += " ( cod_value1 = '5' )";
		}

		if( str_zaiseki_status.length() > 0 ){
			str_sql     += "AND ( "+ str_zaiseki_status +" )" ;
		}
		plusSQL.append( str_sql );

		// ORDER BY��
		plusSQL.append(" ORDER BY cls_glade, hmr_order, cls_number ");

		QueryManager qm = new QueryManager(EXEC_SQL_STUDENT_LIST, paramList.toArray(), Data30367000_studentEntity.class);
		qm.setPlusSQL(plusSQL.toString());

		List<Data30367000_studentEntity> studentList = (List<Data30367000_studentEntity>) this.executeQuery(qm);

		DateFormatUtility utility = new DateFormatUtility(userCode);

		for (Data30367000_studentEntity studentEntity : studentList) {

			if( studentEntity.getReg_start() == null || studentEntity.getReg_start().equals("") ) {
		        studentEntity.setDisp_reg_start( "" );
			}else{
				utility.setZeroToSpace(true);
		        studentEntity.setDisp_reg_start( utility.formatDate("YYYY�NMM��DD��", studentEntity.getReg_start() ) );
			}
		}


		return studentList;
	}


}

