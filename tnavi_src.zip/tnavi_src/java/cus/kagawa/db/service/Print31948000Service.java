package jp.co.systemd.tnavi.cus.kagawa.db.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.SchoolStampEntity;
import jp.co.systemd.tnavi.common.db.entity.UserHistoryEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ActViewpointValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_AttendEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_AttendMemoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_AttendOutputMonthEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_CommentEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ItemEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ItemEvalEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_SpeactValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_StudentInfoEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_TotalactValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ViewpointEntity;
import jp.co.systemd.tnavi.cus.kagawa.db.entity.Data31948000_ViewpointValueEntity;
import jp.co.systemd.tnavi.cus.kagawa.formbean.Print31948000FormBean;
import jp.co.systemd.tnavi.junior.common.JuniorConstantsUseable;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) ��� Service.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31948000Service  extends AbstractExecuteQuery implements JuniorConstantsUseable {

	/** Log4j */
	private static final Log log = LogFactory.getLog(Print31948000Service.class);

	/** ���sSQL */
	private static final String EXEC_SQL_SCHOOLSTAMP				= "sys/getSchoolStamp.sql";										// �Z��
	private static final String EXEC_SQL_PRINCIPAL_NAME			= "cus/kagawa/getDataPrint31948000_principalName.sql";	 		// �w�Z������(�ʏ�)
	private static final String EXEC_SQL_TEACHER_NAME				= "cus/kagawa/getDataPrint31948000_teacherName.sql";			// �w���S�C����(�ʏ�) �S�C�������擾
	private static final String EXEC_SQL_TEACHER_NAME2			= "cus/kagawa/getDataPrint31948000_teacherName2.sql";			// �w���S�C����(�ʏ�) �z�[�����[�����擾
	private static final String EXEC_SQL_SCHOOLNAME				= "common/getUserhistoryByUserAndYear.sql";						// �w�Z��
	private static final String EXEC_SQL_STUDENTINFO				= "cus/kagawa/getDataPrint31948000_studentinfo.sql";			// ���k���

	private static final String EXEC_SQL_ITEM						= "cus/kagawa/getDataPrint31948000_item.sql";					// ����
	private static final String EXEC_SQL_VIEWPOINT				= "cus/kagawa/getDataPrint31948000_viewpoint.sql";				// �ϓ_
	private static final String EXEC_SQL_ITEM_EVAL				= "cus/kagawa/getDataPrint31948000_itemEval.sql";				// ���ȕʕ]��
	private static final String EXEC_SQL_VIEWPOINT_VALUE 		= "cus/kagawa/getDataPrint31948000_viewpointValue.sql";			// �ϓ_�ʕ]��

	private static final String EXEC_SQL_SPEACT_VALUE				= "cus/kagawa/getDataPrint31948000_speactValue.sql";			// ���ʊ����̕]��
	private static final String EXEC_SQL_ACT_VIEWPOINT			= "cus/kagawa/getDataPrint31948000_actViewpoint.sql";			// �s���̋L�^�̊ϓ_
	private static final String EXEC_SQL_ACT_VIEWPOINT_VALUE		= "cus/kagawa/getDataPrint31948000_actViewpointValue.sql";		// �s���̋L�^�̕]��

	private static final String EXEC_SQL_ATTEND_OUTPUT_MONTH		= "cus/kagawa/getDataPrint31948000_attendOutputMonth.sql";		// �o���̋L�^�i�o�͑Ώی��j
	private static final String EXEC_SQL_ATTEND					= "cus/kagawa/getDataPrint31948000_attend.sql";					// �o���̋L�^
	private static final String EXEC_SQL_ATTEND_MEMO				= "cus/kagawa/getDataPrint31948000_attendMemo.sql";				// ���L����(�o���̋L�^�̔��l)

	private static final String EXEC_SQL_COMMENT					= "cus/kagawa/getDataPrint31948000_comment.sql";				// �S�C����̌��t(�������e)

	private static final String EXEC_SQL_TOTALACT_VALUE			= "cus/kagawa/getDataPrint31948000_totalactValue.sql";			// �O���[�o���X�^�f�B�ւ̎��g��(�����I�Ȋw�K�̎��Ԃ̋L�^�̕]��)

	/** �����R�[�h */
	private String user;

	/** �N�x */
	private String nendoSeireki;

	/** �w�N  */
	private String grade;

	/** �z�[�����[���ԍ�  */
	private String clsno;

	/** �I�����ꂽ���k�̊w�Дԍ��̃��X�g */
	private List<String> stucodeList;

	/** �I�����ꂽ�o�͎��� */
	private String goptCode;

	/** ���яo�͎��� */
	private String scoreTerm;

	/** ���FormBean�@*/
	private Print31948000FormBean printFormBean;

	/**
	 * <pre>
	 * Request�̓��e��FormBean���쐬����
	 * ���̏�����Action.doAction���\�b�h���ŌĂяo�����
	 * </pre>
	 *
	 * @param request
	 *            HTTP���N�G�X�g
	 * @param sessionBean
	 *            �V�X�e�����Bean(�Z�b�V�������)
	 * @throws TnaviDbException
	 *             DB��O�������ɃX���[�����
	 */
	public void execute(HttpServletRequest request, SystemInfoBean sessionBean)
			throws TnaviDbException {

		printFormBean = new Print31948000FormBean();

		// �����R�[�h
		user = sessionBean.getUserCode();
		printFormBean.setUserCode(user);

		// �N�x
		nendoSeireki = sessionBean.getSystemNendoSeireki();
		printFormBean.setNendo(nendoSeireki);

		// �z�[�����[�����FormBean���擾
		HroomKeyFormBean hroomKeyFormBean = sessionBean.getSelectHroomKey();

		// �z�[�����[�������w�N�A�z�[�����[���ԍ��A�g���擾
		// �w�N
		grade = hroomKeyFormBean.getGlade();
		printFormBean.setGrade(grade);

		// �z�[�����[���ԍ�
		clsno = hroomKeyFormBean.getClsno();

		// �g
		printFormBean.setHmrclass(hroomKeyFormBean.getHmrclass());

		// �o�͎���
		goptCode = request.getParameter("goptCode");
		printFormBean.setGoptCode(goptCode);
		printFormBean.setGoptName(request.getParameter("goptName"));

		// ���яo�͎����A�ŏI�w���t���O
		String lastGopt;
		if (goptCode.equals(request.getParameter("lastGoptCode"))) {
			scoreTerm = "99";
			lastGopt = "1";
		} else {
			scoreTerm = goptCode;
			lastGopt = "0";
		}
		printFormBean.setLastGopt(lastGopt);

		// ����y�[�W
		printFormBean.setOutput_cover("1".equals(request.getParameter("output_cover")));
		printFormBean.setOutput_score("1".equals(request.getParameter("output_score")));
		printFormBean.setOutput_eval(!"1".equals(request.getParameter("output_eval")));

		// �o�͓��t
		printFormBean.setOutputDate(request.getParameter("output_year") +  request.getParameter("output_month") + request.getParameter("output_day"));
		// �C�����t
		printFormBean.setCompleteDate(request.getParameter("complete_year") +  request.getParameter("complete_month") + request.getParameter("complete_day"));

		// �I���������k�̊w�Дԍ������X�g�ɃZ�b�g
		stucodeList = new ArrayList<String>();
		stucodeList = Arrays.asList(request.getParameterValues("stucode"));

		// �N�G�������s����
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		try {
			// ------------------------------------------------------------------------------------------
			// ���k���
			// ------------------------------------------------------------------------------------------
			List<Data31948000_StudentInfoEntity> studentInfoEntityList = getStudentInfoEntityList(user, nendoSeireki, printFormBean.getOutputDate(), stucodeList);
			printFormBean.setStudentInfoEntityList(studentInfoEntityList);

			if (printFormBean.isOutput_cover()) {
				// ------------------------------------------------------------------------------------------
				// �Z�̓C���[�W
				// ------------------------------------------------------------------------------------------
				printFormBean.setSchoolStampImage(getSchoolStampImage(user));

				// ------------------------------------------------------------------------------------------
				// �w�Z������
				// ------------------------------------------------------------------------------------------
				printFormBean.setPrincipalName(getPrincipalName(user));

				// ------------------------------------------------------------------------------------------
				// �w�Z����
				// ------------------------------------------------------------------------------------------
				printFormBean.setSchoolName(getSchoolName(user, nendoSeireki));

				// ------------------------------------------------------------------------------------------
				// �w���S�C����
				// ------------------------------------------------------------------------------------------
				printFormBean.setTeacherName(getTeacherName(user, nendoSeireki, grade, clsno));
			}

			if (printFormBean.isOutput_score()) {
				// ------------------------------------------------------------------------------------------
				// ����
				// ------------------------------------------------------------------------------------------
				List<Data31948000_ItemEntity> itemEntityList = getItemList(user, nendoSeireki, grade);
				printFormBean.setItemEntityList(itemEntityList);

				// ------------------------------------------------------------------------------------------
				// (���ȕ�)�ϓ_
				// ------------------------------------------------------------------------------------------
				Map<String, List<Data31948000_ViewpointEntity>> viewpointEntityListMap = getViewpointListMap(user, nendoSeireki, grade, scoreTerm);
				printFormBean.setViewpointEntityListMap(viewpointEntityListMap);

				// ------------------------------------------------------------------------------------------
				// (���k��)�ϓ_�ʕ]��
				// ------------------------------------------------------------------------------------------
				Map<String, Map<String, Data31948000_ViewpointValueEntity>> viewpointValueEntityMapMap = getViewpointValueMapMap(user, nendoSeireki, grade, scoreTerm, stucodeList);
				printFormBean.setViewpointValueEntityMapMap(viewpointValueEntityMapMap);

				// ------------------------------------------------------------------------------------------
				// (���k��)���ȕʕ]��
				// ------------------------------------------------------------------------------------------
				Map<String, Map<String, Data31948000_ItemEvalEntity>> itemEvalEntityMapMap = getItemEvalList(user, nendoSeireki, grade, scoreTerm, stucodeList);
				printFormBean.setItemEvalEntityMapMap(itemEvalEntityMapMap);

				// ------------------------------------------------------------------------------------------
				// (���k��)���ʊ����̋L�^�̕]��
				// ------------------------------------------------------------------------------------------
				Map<String, List<Data31948000_SpeactValueEntity>> speactValueEntityListMap = getSpeactValueListMap(user, nendoSeireki, grade, goptCode, stucodeList);
				printFormBean.setSpeactValueEntityListMap(speactValueEntityListMap);

				// ------------------------------------------------------------------------------------------
				// (���k��)�s���̋L�^�̊ϓ_
				// ------------------------------------------------------------------------------------------
				List<Data31948000_ActViewpointEntity> actViewpointEntityList = getActViewpointList(user, nendoSeireki, grade, goptCode);
				printFormBean.setActViewpointEntityList(actViewpointEntityList);

				// ------------------------------------------------------------------------------------------
				// (���k��)�s���̋L�^�̕]��
				// ------------------------------------------------------------------------------------------
				Map<String, List<Data31948000_ActViewpointValueEntity>> actViewpointValueEntityListMap = getActViewpointValueListMap(user, nendoSeireki, grade, goptCode, stucodeList);
				printFormBean.setActViewpointValueEntityListMap(actViewpointValueEntityListMap);

				// ------------------------------------------------------------------------------------------
				// (���k��)�o���̋L�^
				// ------------------------------------------------------------------------------------------
				Map<String, Map<String, Data31948000_AttendEntity>> attendEntityListMap = getAttendMapMap(user, nendoSeireki, grade, goptCode, stucodeList);
				printFormBean.setAttendEntityMapMap(attendEntityListMap);

				// ------------------------------------------------------------------------------------------
				// (���k��)�N�Ԍv�̏o���̋L�^
				// ------------------------------------------------------------------------------------------
				Map<String, Map<String, Data31948000_AttendEntity>> totalAttendEntityListMapMap = gettotalAttendMapMap(user, nendoSeireki, grade, goptCode, stucodeList);
				printFormBean.setTotalAttendEntityListMapMap(totalAttendEntityListMapMap);

				// ------------------------------------------------------------------------------------------
				// (���k��)�o���̋L�^�̔��l
				// ------------------------------------------------------------------------------------------
				Map<String, Data31948000_AttendMemoEntity> attendMemoEntityMap = getAttendMemoList(user, nendoSeireki, grade, goptCode, stucodeList);
				printFormBean.setAttendMemoEntityMap(attendMemoEntityMap);

				// ------------------------------------------------------------------------------------------
				// �S�C����̌��t(�������e)
				// ------------------------------------------------------------------------------------------
				List<Data31948000_CommentEntity> commentEntityList = getCommentList(user, nendoSeireki, grade, goptCode, stucodeList);
				printFormBean.setCommentEntityList(commentEntityList);

				// ------------------------------------------------------------------------------------------
				// �����I�Ȋw�K�̎��Ԃ̋L�^�̕]��
				// ------------------------------------------------------------------------------------------
				List<Data31948000_TotalactValueEntity> totalactValueEntityList = getTotalactValueList(user, nendoSeireki, grade, goptCode, stucodeList);
				printFormBean.setTotalactValueEntityList(totalactValueEntityList);
			}

		} catch (Exception e) {
			log.error("���ђʒm�\���(���쌧�����w�Z) DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}

	}

	/**
	 * �Z�̓C���[�W���擾����
	 * @param user �����R�[�h
	 * @return �Z�̓C���[�W
	 */
	@SuppressWarnings("unchecked")
	private byte[] getSchoolStampImage(String user) {
		Object[] param = {user, "01"};
		QueryManager queryManager = new QueryManager(EXEC_SQL_SCHOOLSTAMP, param, SchoolStampEntity.class);
		List<SchoolStampEntity> schoolStampEntityList = (List<SchoolStampEntity>) this.executeQuery(queryManager);

		if(schoolStampEntityList.size() > 0){
			return schoolStampEntityList.get(0).getStm_image();
		}

		return null;
	}

	/**
	 * �w�Z���������擾����
	 * @param user �����R�[�h
	 * @return �w�Z������
	 */
	private String getPrincipalName(String user) {
		Object[] param = {user, printFormBean.getOutputDate()};
		QueryManager queryManager = new QueryManager(EXEC_SQL_PRINCIPAL_NAME, param, String.class);
		return (String) this.executeQuery(queryManager);
	}

	/**
	 * �w�Z��(��������)���擾����
	 * @param user		�����R�[�h
	 * @param nendo	�N�x
	 * @return	�w�Z��
	 */
	@SuppressWarnings("unchecked")
	private String getSchoolName(String user, String nendo) {
		Object[] param = {user, nendo};
		QueryManager queryManager = new QueryManager(EXEC_SQL_SCHOOLNAME, param, UserHistoryEntity.class);
		List<UserHistoryEntity> userHistoryEntityList = (List<UserHistoryEntity>)this.executeQuery(queryManager);

		if(userHistoryEntityList.size() > 0){
			return userHistoryEntityList.get(0).getUseh_name_s();
		}

		return null;
	}

	/**
	 * �w���S�C�������擾����
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param clsno	�g�ԍ�
	 * @return �w���S�C����
	 */
	private String getTeacherName(String user, String nendo, String grade, String clsno) {
		Object[] param = {user, nendo, clsno, printFormBean.getOutputDate()};
		QueryManager queryManager = new QueryManager(EXEC_SQL_TEACHER_NAME, param, String.class);
		String teacherName = (String)this.executeQuery(queryManager);

		if (teacherName == null) {
			Object[] param2 = {user, nendo, clsno};
			QueryManager queryManager2 = new QueryManager(EXEC_SQL_TEACHER_NAME2, param2, String.class);
			teacherName = (String)this.executeQuery(queryManager2);
		}

		return teacherName;
	}

	/**
	 * ���k�����擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param outputDate	�o�͓��t
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return	���k��񃊃X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data31948000_StudentInfoEntity> getStudentInfoEntityList(String user, String nendo, String outputDate, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {nendo, outputDate, user};
		QueryManager queryManager = new QueryManager(EXEC_SQL_STUDENTINFO, param, Data31948000_StudentInfoEntity.class);

		List<Data31948000_StudentInfoEntity> studentInfoEntityList = (List<Data31948000_StudentInfoEntity>)this.executeQuery(queryManager, inParam);
		return studentInfoEntityList;
	}

	/**
	 * ���ȏ����擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @return ���ȏ�񃊃X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data31948000_ItemEntity> getItemList(String user, String nendo, String grade) {
		Object[] param = {user, nendo, grade};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ITEM, param, Data31948000_ItemEntity.class);

		List<Data31948000_ItemEntity> itemEntityList = (List<Data31948000_ItemEntity>) this.executeQuery(queryManager);
		return itemEntityList;
	}

	/**
	 * �ϓ_��񃊃X�g�}�b�v���擾����
	 * @param user			�����R�[�h
	 * @param nendo 		�N�x
	 * @param grade		�w�N
	 * @param scoreTerm	���яo�͎���
	 * @return �ϓ_��񃊃X�g�}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, List<Data31948000_ViewpointEntity>> getViewpointListMap(String user, String nendo, String grade, String scoreTerm) {
		Object[] param = {user, nendo, grade, scoreTerm};
		QueryManager queryManager = new QueryManager(EXEC_SQL_VIEWPOINT, param, Data31948000_ViewpointEntity.class);
		List<Data31948000_ViewpointEntity> viewpointEntityListALL = (List<Data31948000_ViewpointEntity>) this.executeQuery(queryManager);

		Map<String, List<Data31948000_ViewpointEntity>> viewpointEntityListMap = new LinkedHashMap<String, List<Data31948000_ViewpointEntity>>();
		if (viewpointEntityListALL.size() > 0) {
			List<Data31948000_ViewpointEntity> viewpointEntityList = new ArrayList<Data31948000_ViewpointEntity>();
			String prevItemCode = null;

			for (Data31948000_ViewpointEntity entity : viewpointEntityListALL) {
				if (prevItemCode != null && !prevItemCode.equals(entity.getItem_code())) {
					viewpointEntityListMap.put(prevItemCode, viewpointEntityList);
					viewpointEntityList = new ArrayList<Data31948000_ViewpointEntity>();
				}

				prevItemCode = entity.getItem_code();
				viewpointEntityList.add(entity);
			}

			if (prevItemCode != null) {
				viewpointEntityListMap.put(prevItemCode, viewpointEntityList);
			}
		}

		return viewpointEntityListMap;
	}

	/**
	 * �ϓ_�ʕ]�������擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param scoreTerm	���яo�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return	�ϓ_�ʕ]���}�b�v�̃}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Data31948000_ViewpointValueEntity>> getViewpointValueMapMap(String user, String nendo, String grade, String scoreTerm, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {user, nendo, grade, scoreTerm};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_VIEWPOINT_VALUE, param, Data31948000_ViewpointValueEntity.class);
		List<Data31948000_ViewpointValueEntity> viewpointValueEntityListAll = (List<Data31948000_ViewpointValueEntity>)this.executeQuery(queryManager, inParam);

		Map<String, Map<String, Data31948000_ViewpointValueEntity>> viewpointValueEntityMapMap = new LinkedHashMap<String, Map<String, Data31948000_ViewpointValueEntity>>();

		if (viewpointValueEntityListAll.size() > 0) {
			Map<String, Data31948000_ViewpointValueEntity> viewpointValueEntityMap = new LinkedHashMap<String, Data31948000_ViewpointValueEntity>();
			String prevStucode = null;

			for (Data31948000_ViewpointValueEntity entity : viewpointValueEntityListAll) {
				if (prevStucode != null && !prevStucode.equals(entity.getCls_stucode())) {
					viewpointValueEntityMapMap.put(prevStucode, viewpointValueEntityMap);
					viewpointValueEntityMap = new LinkedHashMap<String, Data31948000_ViewpointValueEntity>();
				}

				prevStucode = entity.getCls_stucode();
				viewpointValueEntityMap.put(entity.getItem_code() + "|" + entity.getRivt_rivtcode(), entity);
			}

			if (prevStucode != null) {
				viewpointValueEntityMapMap.put(prevStucode, viewpointValueEntityMap);
			}
		}

		return viewpointValueEntityMapMap;
	}

	/**
	 * ���ȕʕ]������擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param scoreTerm	���яo�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return	���ȕʕ]��}�b�v�̃}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Data31948000_ItemEvalEntity>> getItemEvalList(String user, String nendo, String grade, String scoreTerm, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {user, nendo, grade, scoreTerm};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_ITEM_EVAL, param, Data31948000_ItemEvalEntity.class);
		List<Data31948000_ItemEvalEntity> itemEvalEntityListAll = (List<Data31948000_ItemEvalEntity>)this.executeQuery(queryManager, inParam);

		Map<String, Map<String, Data31948000_ItemEvalEntity>> itemEvalEntityMapMap = new LinkedHashMap<String, Map<String, Data31948000_ItemEvalEntity>>();

		if (itemEvalEntityListAll.size() > 0) {
			Map<String, Data31948000_ItemEvalEntity> itemEvalEntityMap = new LinkedHashMap<String, Data31948000_ItemEvalEntity>();
			String prevStucode = null;

			for (Data31948000_ItemEvalEntity entity : itemEvalEntityListAll) {
				if (prevStucode != null && !prevStucode.equals(entity.getCls_stucode())) {
					itemEvalEntityMapMap.put(prevStucode, itemEvalEntityMap);
					itemEvalEntityMap = new LinkedHashMap<String, Data31948000_ItemEvalEntity>();
				}

				prevStucode = entity.getCls_stucode();
				itemEvalEntityMap.put(entity.getItem_code(), entity);
			}

			if (prevStucode != null) {
				itemEvalEntityMapMap.put(prevStucode, itemEvalEntityMap);
			}
		}

		return itemEvalEntityMapMap;
	}

	/**
	 * ���ʊ����̋L�^�̕]�������擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param goptCode		�o�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return	���ʊ����̋L�^�̕]�����X�g�}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, List<Data31948000_SpeactValueEntity>> getSpeactValueListMap(String user, String nendo, String grade, String goptCode, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {nendo, user, grade, goptCode};
		QueryManager queryManager = new QueryManager(EXEC_SQL_SPEACT_VALUE, param, Data31948000_SpeactValueEntity.class);
		List<Data31948000_SpeactValueEntity> speactValueEntityListALL = (List<Data31948000_SpeactValueEntity>) this.executeQuery(queryManager, inParam);

		Map<String, List<Data31948000_SpeactValueEntity>> speactValueEntityListMap = new LinkedHashMap<String, List<Data31948000_SpeactValueEntity>>();
		if (speactValueEntityListALL.size() > 0) {
			List<Data31948000_SpeactValueEntity> speactValueEntityList = new ArrayList<Data31948000_SpeactValueEntity>();
			String prevStucode = null;

			for (Data31948000_SpeactValueEntity entity : speactValueEntityListALL) {
				if (prevStucode != null && !prevStucode.equals(entity.getCls_stucode())) {
					speactValueEntityListMap.put(prevStucode, speactValueEntityList);
					speactValueEntityList = new ArrayList<Data31948000_SpeactValueEntity>();
				}

				prevStucode = entity.getCls_stucode();
				speactValueEntityList.add(entity);
			}

			if (prevStucode != null) {
				speactValueEntityListMap.put(prevStucode, speactValueEntityList);
			}
		}

		return speactValueEntityListMap;
	}

	/**
	 * �s���̋L�^�̊ϓ_�����擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param goptCode		�o�͎���
	 * @return �s���̋L�^�̊ϓ_���X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data31948000_ActViewpointEntity> getActViewpointList(String user, String nendo, String grade, String goptCode) {
		Object[] param = {user, nendo, grade, goptCode};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ACT_VIEWPOINT, param, Data31948000_ActViewpointEntity.class);

		List<Data31948000_ActViewpointEntity> actViewpointEntityList = (List<Data31948000_ActViewpointEntity>) this.executeQuery(queryManager);
		return actViewpointEntityList;
	}

	/**
	 * �s���̋L�^�̕]�������擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param goptCode		�o�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return	�s���̋L�^�̕]�����X�g�}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, List<Data31948000_ActViewpointValueEntity>> getActViewpointValueListMap(String user, String nendo, String grade, String goptCode, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {user, nendo, grade, goptCode};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ACT_VIEWPOINT_VALUE, param, Data31948000_ActViewpointValueEntity.class);
		List<Data31948000_ActViewpointValueEntity> actViewpointValueEntityListALL = (List<Data31948000_ActViewpointValueEntity>) this.executeQuery(queryManager, inParam);

		Map<String, List<Data31948000_ActViewpointValueEntity>> actViewpointValueEntityListMap = new LinkedHashMap<String, List<Data31948000_ActViewpointValueEntity>>();
		if (actViewpointValueEntityListALL.size() > 0) {
			List<Data31948000_ActViewpointValueEntity> actViewpointValueEntityList = new ArrayList<Data31948000_ActViewpointValueEntity>();
			String prevStucode = null;

			for (Data31948000_ActViewpointValueEntity entity : actViewpointValueEntityListALL) {
				if (prevStucode != null && !prevStucode.equals(entity.getRavv_stucode())) {
					actViewpointValueEntityListMap.put(prevStucode, actViewpointValueEntityList);
					actViewpointValueEntityList = new ArrayList<Data31948000_ActViewpointValueEntity>();
				}

				prevStucode = entity.getRavv_stucode();
				actViewpointValueEntityList.add(entity);
			}

			if (prevStucode != null) {
				actViewpointValueEntityListMap.put(prevStucode, actViewpointValueEntityList);
			}
		}

		return actViewpointValueEntityListMap;
	}

	/**
	 * �o���̋L�^�����擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param goptCode		�o�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return	�o���̋L�^�}�b�v�̃}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Data31948000_AttendEntity>> getAttendMapMap(String user, String nendo, String grade, String goptCode, List<String> stucodeList) {
		// �ԋp�pMap
		Map<String, Map<String, Data31948000_AttendEntity>> attendEntityMapMap = new LinkedHashMap<String, Map<String, Data31948000_AttendEntity>>();

		// �S�Ă̐��k�ɑ΂���(�o�͑Ώ�)�����ŏ�����
		Object[] paramOutputMonth = {goptCode, user, grade, nendo};
		QueryManager queryManagerOutputMonth = new QueryManager(EXEC_SQL_ATTEND_OUTPUT_MONTH, paramOutputMonth, Data31948000_AttendOutputMonthEntity.class);
		List<Data31948000_AttendOutputMonthEntity> outputMonthList = (ArrayList<Data31948000_AttendOutputMonthEntity>)this.executeQuery(queryManagerOutputMonth);

		for (String stucode : stucodeList) {
			Map<String, Data31948000_AttendEntity> attendEntityMap = new LinkedHashMap<String, Data31948000_AttendEntity>();

			for (Data31948000_AttendOutputMonthEntity outputMonth : outputMonthList) {
				Data31948000_AttendEntity attendEntity = new Data31948000_AttendEntity();
				attendEntity.setStu_stucode(stucode);
				attendEntity.setEnf_month(outputMonth.getEnf_month());

				attendEntityMap.put(outputMonth.getEnf_month(), attendEntity);
			}

			attendEntityMapMap.put(stucode, attendEntityMap);
		}

		// �o���̋L�^����ݒ�
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {goptCode, user, grade, nendo};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ATTEND, param, Data31948000_AttendEntity.class);
		List<Data31948000_AttendEntity> attendEntityListALL = (List<Data31948000_AttendEntity>) this.executeQuery(queryManager, inParam);

		if (attendEntityListALL.size() > 0) {
			Map<String, Data31948000_AttendEntity> attendEntityMap = new LinkedHashMap<String, Data31948000_AttendEntity>();

			// (�o�͑Ώ�)�����ŏ�����
			for (Data31948000_AttendOutputMonthEntity outputMonth : outputMonthList) {
				Data31948000_AttendEntity attendEntity = new Data31948000_AttendEntity();
				attendEntity.setStu_stucode(attendEntityListALL.get(0).getStu_stucode());
				attendEntity.setEnf_month(outputMonth.getEnf_month());

				attendEntityMap.put(outputMonth.getEnf_month(), attendEntity);
			}

			String prevStucode = null;
			for (Data31948000_AttendEntity entity : attendEntityListALL) {
				if (prevStucode != null && !prevStucode.equals(entity.getStu_stucode())) {
					// �ԋp�pMap�ɓo�^
					attendEntityMapMap.put(prevStucode, attendEntityMap);
					attendEntityMap = new LinkedHashMap<String, Data31948000_AttendEntity>();

					// (�o�͑Ώ�)�����ŏ�����
					for (Data31948000_AttendOutputMonthEntity outputMonth : outputMonthList) {
						Data31948000_AttendEntity attendEntity = new Data31948000_AttendEntity();
						attendEntity.setStu_stucode(entity.getStu_stucode());
						attendEntity.setEnf_month(outputMonth.getEnf_month());

						attendEntityMap.put(outputMonth.getEnf_month(), attendEntity);
					}
				}

				prevStucode = entity.getStu_stucode();
				attendEntityMap.put(entity.getEnf_month(), entity);
			}

			// �ŏI�f�[�^�̏���
			if (prevStucode != null) {
				// �ԋp�pMap�ɓo�^
				attendEntityMapMap.put(prevStucode, attendEntityMap);
			}
		}

		return attendEntityMapMap;
	}

	/**
	 * �o���̋L�^�̔��l�����擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param goptCode		�o�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return �o���̋L�^�̔��l�}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Data31948000_AttendMemoEntity> getAttendMemoList(String user, String nendo, String grade, String goptCode, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {user, nendo, grade, goptCode};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ATTEND_MEMO, param, Data31948000_AttendMemoEntity.class);

		List<Data31948000_AttendMemoEntity> attendMemoEntityListAll = (List<Data31948000_AttendMemoEntity>) this.executeQuery(queryManager, inParam);

		Map<String, Data31948000_AttendMemoEntity> attendMemoEntityMap = new LinkedHashMap<String, Data31948000_AttendMemoEntity>();
		for (Data31948000_AttendMemoEntity entity : attendMemoEntityListAll) {
			attendMemoEntityMap.put(entity.getRar_stucode(), entity);
		}

		return attendMemoEntityMap;
	}

	/**
	 * �N�Ԍv�̏o���̋L�^�����擾����
	 * @param user			�����R�[�h
	 * @param nendo			�N�x
	 * @param grade			�w�N
	 * @param goptCode		�o�͎���99�Œ�
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return				�o���̋L�^�}�b�v
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Data31948000_AttendEntity>> gettotalAttendMapMap(String user, String nendo, String grade, String goptCode, List<String> stucodeList) {
		// �N�Ԃ̌v�̏o���̋L�^�����o�����߁A99�ŌŒ�
		goptCode = "99";
		// �ԋp�pMap
		Map<String, Map<String, Data31948000_AttendEntity>> totalAttendEntityMapMap = new LinkedHashMap<String, Map<String, Data31948000_AttendEntity>>();

		// �S�Ă̐��k�ɑ΂���(�o�͑Ώ�)�����ŏ�����
		Object[] paramOutputMonth = {goptCode, user, grade, nendo};
		QueryManager queryManagerOutputMonth = new QueryManager(EXEC_SQL_ATTEND_OUTPUT_MONTH, paramOutputMonth, Data31948000_AttendOutputMonthEntity.class);
		List<Data31948000_AttendOutputMonthEntity> outputMonthList = (ArrayList<Data31948000_AttendOutputMonthEntity>)this.executeQuery(queryManagerOutputMonth);

		for (String stucode : stucodeList) {
			Map<String, Data31948000_AttendEntity> totalAttendEntityMap = new LinkedHashMap<String, Data31948000_AttendEntity>();

			for (Data31948000_AttendOutputMonthEntity outputMonth : outputMonthList) {
				Data31948000_AttendEntity totalAttendEntity = new Data31948000_AttendEntity();
				totalAttendEntity.setStu_stucode(stucode);
				totalAttendEntity.setEnf_month(outputMonth.getEnf_month());

				totalAttendEntityMap.put(outputMonth.getEnf_month(), totalAttendEntity);
			}

			totalAttendEntityMapMap.put(stucode, totalAttendEntityMap);
		}

		// �N�Ԃ̌v�̏o���̋L�^����ݒ�
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {goptCode, user, grade, nendo};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ATTEND, param, Data31948000_AttendEntity.class);
		List<Data31948000_AttendEntity> totalAttendEntityListALL = (List<Data31948000_AttendEntity>) this.executeQuery(queryManager, inParam);

		if (totalAttendEntityListALL.size() > 0) {
			Map<String, Data31948000_AttendEntity> totalAttendEntityMap = new LinkedHashMap<String, Data31948000_AttendEntity>();

			// (�o�͑Ώ�)�����ŏ�����
			for (Data31948000_AttendOutputMonthEntity outputMonth : outputMonthList) {
				Data31948000_AttendEntity totalAttendEntity = new Data31948000_AttendEntity();
				totalAttendEntity.setStu_stucode(totalAttendEntityListALL.get(0).getStu_stucode());
				totalAttendEntity.setEnf_month(outputMonth.getEnf_month());

				totalAttendEntityMap.put(outputMonth.getEnf_month(), totalAttendEntity);
			}

			String prevStucode = null;
			for (Data31948000_AttendEntity entity : totalAttendEntityListALL) {
				if (prevStucode != null && !prevStucode.equals(entity.getStu_stucode())) {
					// �ԋp�pMap�ɓo�^
					totalAttendEntityMapMap.put(prevStucode, totalAttendEntityMap);
					totalAttendEntityMap = new LinkedHashMap<String, Data31948000_AttendEntity>();

					// (�o�͑Ώ�)�����ŏ�����
					for (Data31948000_AttendOutputMonthEntity outputMonth : outputMonthList) {
						Data31948000_AttendEntity totalAttendEntity = new Data31948000_AttendEntity();
						totalAttendEntity.setStu_stucode(entity.getStu_stucode());
						totalAttendEntity.setEnf_month(outputMonth.getEnf_month());

						totalAttendEntityMap.put(outputMonth.getEnf_month(), totalAttendEntity);
					}
				}

				prevStucode = entity.getStu_stucode();
				totalAttendEntityMap.put(entity.getEnf_month(), entity);
			}

			// �ŏI�f�[�^�̏���
			if (prevStucode != null) {
				// �ԋp�pMap�ɓo�^
				totalAttendEntityMapMap.put(prevStucode, totalAttendEntityMap);
			}
		}

		return totalAttendEntityMapMap;
	}

	/**
	 * �S�C����̌��t(�������e)�����擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param goptCode		�o�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return �S�C����̌��t(�������e)�̃��X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data31948000_CommentEntity> getCommentList(String user, String nendo, String grade, String goptCode, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {user, nendo, goptCode, grade};
		QueryManager queryManager = new QueryManager(EXEC_SQL_COMMENT, param, Data31948000_CommentEntity.class);

		List<Data31948000_CommentEntity> commentEntityList = (List<Data31948000_CommentEntity>) this.executeQuery(queryManager, inParam);
		return commentEntityList;
	}

	/**
	 * �����I�Ȋw�K�̎��Ԃ̋L�^�̕]�������擾����
	 * @param user			�����R�[�h
	 * @param nendo		�N�x
	 * @param grade		�w�N
	 * @param goptCode		�o�͎���
	 * @param stucodeList	�I�������w�Дԍ��̃��X�g
	 * @return �����I�Ȋw�K�̎��Ԃ̋L�^�̕]���̃��X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data31948000_TotalactValueEntity> getTotalactValueList(String user, String nendo, String grade, String goptCode, List<String> stucodeList) {
		String[] inParam = {createIN(stucodeList)};
		Object[] param = {user, nendo, grade, goptCode};
		QueryManager queryManager = new QueryManager(EXEC_SQL_TOTALACT_VALUE, param, Data31948000_TotalactValueEntity.class);

		List<Data31948000_TotalactValueEntity> totalactValueEntityList = (List<Data31948000_TotalactValueEntity>) this.executeQuery(queryManager, inParam);
		return totalactValueEntityList;
	}

	/**
	 * @return the printFormBean
	 */
	public Print31948000FormBean getPrintFormBean() {
		return printFormBean;
	}
}
