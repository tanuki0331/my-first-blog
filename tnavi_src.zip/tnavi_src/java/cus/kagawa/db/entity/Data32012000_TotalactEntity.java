package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * �����I�Ȋw�K�̎��Ԃ̋L�^���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_TotalactEntity {

	public final static String DEFALUT_VALUE = "";

	/** �N�x */
	private String cls_year = DEFALUT_VALUE;

	/** �w�N */
	private String cls_glade = DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String cls_stucode = DEFALUT_VALUE;

	/** �ϓ_�R�[�h */
	private String gtat_gtatcode = DEFALUT_VALUE;

	/** �w�K���� */
	private String gtat_act = DEFALUT_VALUE;

	/** �ϓ_ */
	private String gtat_pointview = DEFALUT_VALUE;

	/** �]�� */
	private String gtav_value = DEFALUT_VALUE;

	/**
	 * @return cls_year
	 */
	public String getCls_year() {
		return cls_year;
	}

	/**
	 * @param cls_year the cls_year to set
	 */
	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	/**
	 * @return cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade the cls_glade to set
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode the cls_stucode to set
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return gtat_gtatcode
	 */
	public String getGtat_gtatcode() {
		return gtat_gtatcode;
	}

	/**
	 * @param gtat_gtatcode the gtat_gtatcode to set
	 */
	public void setGtat_gtatcode(String gtat_gtatcode) {
		this.gtat_gtatcode = gtat_gtatcode;
	}

	/**
	 * @return gtat_act
	 */
	public String getGtat_act() {
		return gtat_act;
	}

	/**
	 * @param gtat_act the gtat_act to set
	 */
	public void setGtat_act(String gtat_act) {
		this.gtat_act = gtat_act;
	}

	/**
	 * @return gtat_pointview
	 */
	public String getGtat_pointview() {
		return gtat_pointview;
	}

	/**
	 * @param gtat_pointview the gtat_pointview to set
	 */
	public void setGtat_pointview(String gtat_pointview) {
		this.gtat_pointview = gtat_pointview;
	}

	/**
	 * @return gtav_value
	 */
	public String getGtav_value() {
		return gtav_value;
	}

	/**
	 * @param gtav_value the gtav_value to set
	 */
	public void setGtav_value(String gtav_value) {
		this.gtav_value = gtav_value;
	}

}
