package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) ���ȕʊϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31948000_ViewpointEntity {

	/**
	 * ���ȃR�[�h
	 */
	private String item_code;

	/**
	 * �ʒm�\�p���Ȗ���
	 */
	private String item_name;

	/**
	 * ���ȕ��я�
	 */
	private String item_order;

	/**
	 * �ϓ_�R�[�h
	 */
	private String rivt_rivtcode;

	/**
	 * �ϓ_���́@rivt_purpose �ł͂Ȃ��_�ɒ���
	 */
	private String rivt_rivtname;

	/**
	 * �ϓ_���я�
	 */
	private String rivt_order;

	/**
	 * @return item_code
	 */
	public String getItem_code() {
		return item_code;
	}

	/**
	 * @param item_code �Z�b�g���� item_code
	 */
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	/**
	 * @return item_name
	 */
	public String getItem_name() {
		return item_name;
	}

	/**
	 * @param item_name �Z�b�g���� item_name
	 */
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	/**
	 * @return item_order
	 */
	public String getItem_order() {
		return item_order;
	}

	/**
	 * @param item_order �Z�b�g���� item_order
	 */
	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	/**
	 * @return rivt_rivtcode
	 */
	public String getRivt_rivtcode() {
		return rivt_rivtcode;
	}

	/**
	 * @param rivt_rivtcode �Z�b�g���� rivt_rivtcode
	 */
	public void setRivt_rivtcode(String rivt_rivtcode) {
		this.rivt_rivtcode = rivt_rivtcode;
	}

	/**
	 * @return rivt_rivtname
	 */
	public String getRivt_rivtname() {
		return rivt_rivtname;
	}

	/**
	 * @param rivt_rivtname �Z�b�g���� rivt_rivtname
	 */
	public void setRivt_rivtname(String rivt_rivtname) {
		this.rivt_rivtname = rivt_rivtname;
	}

	/**
	 * @return rivt_order
	 */
	public String getRivt_order() {
		return rivt_order;
	}

	/**
	 * @param rivt_order �Z�b�g���� rivt_order
	 */
	public void setRivt_order(String rivt_order) {
		this.rivt_order = rivt_order;
	}

}
