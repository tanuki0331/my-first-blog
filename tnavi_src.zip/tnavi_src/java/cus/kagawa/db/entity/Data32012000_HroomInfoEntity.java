package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * �z�[�����[�����Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_HroomInfoEntity {

	public final static String DEFALUT_VALUE = "";

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �w�N */
	private String grade = DEFALUT_VALUE;

	/** �g */
	private String hmrClass = DEFALUT_VALUE;

	/** �o�Ȕԍ� */
	private String number = DEFALUT_VALUE;

	/**
	 * @return nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo the nendo to set
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return grade
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}

	/**
	 * @return hmrClass
	 */
	public String getHmrClass() {
		return hmrClass;
	}

	/**
	 * @param hmrClass the hmrClass to set
	 */
	public void setHmrClass(String hmrClass) {
		this.hmrClass = hmrClass;
	}

	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

}
