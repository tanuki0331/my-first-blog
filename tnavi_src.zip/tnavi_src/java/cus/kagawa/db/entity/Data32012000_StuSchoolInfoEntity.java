package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���k�����E�w�Z�����Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_StuSchoolInfoEntity {

	public final static String DEFALUT_VALUE = "";

	/** ���k����(�ː�) */
	private String stuName = DEFALUT_VALUE;

	/** ���k����(�ӂ肪��) */
	private String stuNameKana = DEFALUT_VALUE;

	/** ���k���� */
	private String stu_sex = DEFALUT_VALUE;

	/** �w�N */
	private String grade = DEFALUT_VALUE;

	/** ���N���� */
	private String stu_birth = DEFALUT_VALUE;

	/** ���Z�� */
	private String stu_address = DEFALUT_VALUE;

	/** �ی�Ҏ���  */
	private String st4_parent_r = DEFALUT_VALUE;

	/** ���ƔN����  */
	private String stu_finish = DEFALUT_VALUE;

	/** ���Ɨ\��N�x  */
	private String finish_yoteinendo = DEFALUT_VALUE;

	/** �w�Z���� */
	private String schoolName = DEFALUT_VALUE;

	/** �w�Z���ݒn */
	private String schoolAddress = DEFALUT_VALUE;

	/** �w�Z�敪 */
	private String useKind2 = DEFALUT_VALUE;

	/** ���w���̎������k ����(�ː�) */
	private String stuname_koseki_entry = DEFALUT_VALUE;

	/** ���w�N���� */
	private String stu_entry = DEFALUT_VALUE;

	/** �ݐЏI���� */
	private String stu_enddate = DEFALUT_VALUE;

	/**
	 * @return stuName
	 */
	public String getStuName() {
		return stuName;
	}

	/**
	 * @return grade
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}

	/**
	 * @param stuName the stuName to set
	 */
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	/**
	 * @return schoolName
	 */
	public String getSchoolName() {
		return schoolName;
	}

	/**
	 * @param schoolName the schoolName to set
	 */
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getUseKind2() {
		return useKind2;
	}

	public void setUseKind2(String useKind2) {
		this.useKind2 = useKind2;
	}

	/**
	 * @return stuname_koseki_entry
	 */
	public String getStuname_koseki_entry() {
		return stuname_koseki_entry;
	}

	/**
	 * @param stuname_koseki_entry stuname_koseki_entry��ݒ肷��
	 */
	public void setStuname_koseki_entry(String stuname_koseki_entry) {
		this.stuname_koseki_entry = stuname_koseki_entry;
	}

	/**
	 * @return stu_entry
	 */
	public String getStu_entry() {
		return stu_entry;
	}

	/**
	 * @param stu_entry the stu_entry to set
	 */
	public void setStu_entry(String stu_entry) {
		this.stu_entry = stu_entry;
	}

	/**
	 * @return stu_enddate
	 */
	public String getStu_enddate() {
		return stu_enddate;
	}

	/**
	 * @param stu_enddate the stu_enddate to set
	 */
	public void setStu_enddate(String stu_enddate) {
		this.stu_enddate = stu_enddate;
	}

	public String getStuNameKana() {
		return stuNameKana;
	}

	public void setStuNameKana(String stuNameKana) {
		this.stuNameKana = stuNameKana;
	}

	public String getStu_sex() {
		return stu_sex;
	}

	public void setStu_sex(String stu_sex) {
		this.stu_sex = stu_sex;
	}

	public String getStu_birth() {
		return stu_birth;
	}

	public void setStu_birth(String stu_birth) {
		this.stu_birth = stu_birth;
	}

	public String getStu_address() {
		return stu_address;
	}

	public void setStu_address(String stu_address) {
		this.stu_address = stu_address;
	}

	public String getSt4_parent_r() {
		return st4_parent_r;
	}

	public void setSt4_parent_r(String st4_parent_r) {
		this.st4_parent_r = st4_parent_r;
	}

	public String getStu_finish() {
		return stu_finish;
	}

	public void setStu_finish(String stu_finish) {
		this.stu_finish = stu_finish;
	}

	public String getFinish_yoteinendo() {
		return finish_yoteinendo;
	}

	public void setFinish_yoteinendo(String finish_yoteinendo) {
		this.finish_yoteinendo = finish_yoteinendo;
	}

	public String getSchoolAddress() {
		return schoolAddress;
	}

	public void setSchoolAddress(String schoolAddress) {
		this.schoolAddress = schoolAddress;
	}

}
