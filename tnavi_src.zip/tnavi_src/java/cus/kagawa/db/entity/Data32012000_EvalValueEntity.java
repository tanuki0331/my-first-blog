package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ȕʂ̕]����Entity.
 * </PRE>
 *
 * <B>Create</B> 2015.12.17 hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_EvalValueEntity {

	public final static String DEFALUT_VALUE = "";
	
	/** �N�x */
	private String cls_year = DEFALUT_VALUE;
	
	/** �w�N */
	private String cls_glade = DEFALUT_VALUE;
	
	/** �w�Дԍ� */
	private String cls_stucode = DEFALUT_VALUE;
	
	/** ���ȃR�[�h */
	private String cod_code = DEFALUT_VALUE;
	
	/** ���Ȗ� */
	private String cod_name1 = DEFALUT_VALUE;
	
	/** �]��R�[�h */
	private String gev_cmlguideteval = DEFALUT_VALUE;
	
	/** �]�� �\���p�̒l */
	private String gevl_display = DEFALUT_VALUE;
	
	/** ���� �\���� */
	private String item_ord = DEFALUT_VALUE;

	/**
	 * @return cls_year
	 */
	public String getCls_year() {
		return cls_year;
	}

	/**
	 * @param cls_year the cls_year to set
	 */
	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	/**
	 * @return cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade the cls_glade to set
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode the cls_stucode to set
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return cod_code
	 */
	public String getCod_code() {
		return cod_code;
	}

	/**
	 * @param cod_code the cod_code to set
	 */
	public void setCod_code(String cod_code) {
		this.cod_code = cod_code;
	}

	/**
	 * @return cod_name1
	 */
	public String getCod_name1() {
		return cod_name1;
	}

	/**
	 * @param cod_name1 the cod_name1 to set
	 */
	public void setCod_name1(String cod_name1) {
		this.cod_name1 = cod_name1;
	}

	/**
	 * @return gev_cmlguideteval
	 */
	public String getGev_cmlguideteval() {
		return gev_cmlguideteval;
	}

	/**
	 * @param gev_cmlguideteval the gev_cmlguideteval to set
	 */
	public void setGev_cmlguideteval(String gev_cmlguideteval) {
		this.gev_cmlguideteval = gev_cmlguideteval;
	}

	/**
	 * @return gevl_display
	 */
	public String getGevl_display() {
		return gevl_display;
	}

	/**
	 * @param gevl_display the gevl_display to set
	 */
	public void setGevl_display(String gevl_display) {
		this.gevl_display = gevl_display;
	}

	/**
	 * @return item_ord
	 */
	public String getItem_ord() {
		return item_ord;
	}

	/**
	 * @param item_ord the item_ord to set
	 */
	public void setItem_ord(String item_ord) {
		this.item_ord = item_ord;
	}
	
}
