package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���������Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.3.5 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_ClubEntity {

	public final static String DEFALUT_VALUE = "";

	/** �N�x */
	private String cls_year = DEFALUT_VALUE;

	/** �w�N */
	private String cls_grade = DEFALUT_VALUE;
	
	/**  */
	private String ext_code = DEFALUT_VALUE;
	
	/** �w�Дԍ� */
	private String cls_stucode = DEFALUT_VALUE;

	/** �o�Ȕԍ� */
	private String cls_number = DEFALUT_VALUE;
	
	/** �����N���� */
	private String clb_start = DEFALUT_VALUE;
	
	/** �ޕ��N���� */
	private String clb_stop = DEFALUT_VALUE;
	
	/** ���������� */
	private String ext_name = DEFALUT_VALUE;
	
	/** ��E */
	private String pst_name = DEFALUT_VALUE;
	
	/** �N���u�ԍ� */
	private String clb_number = DEFALUT_VALUE;

	public String getCls_year() {
		return cls_year;
	}

	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	public String getCls_grade() {
		return cls_grade;
	}

	public void setCls_grade(String cls_grade) {
		this.cls_grade = cls_grade;
	}

	public String getExt_code() {
		return ext_code;
	}

	public void setExt_code(String ext_code) {
		this.ext_code = ext_code;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getClb_start() {
		return clb_start;
	}

	public void setClb_start(String clb_start) {
		this.clb_start = clb_start;
	}

	public String getClb_stop() {
		return clb_stop;
	}

	public void setClb_stop(String clb_stop) {
		this.clb_stop = clb_stop;
	}

	public String getExt_name() {
		return ext_name;
	}

	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}

	public String getPst_name() {
		return pst_name;
	}

	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}

	public String getClb_number() {
		return clb_number;
	}

	public void setClb_number(String clb_number) {
		this.clb_number = clb_number;
	}
	





}
