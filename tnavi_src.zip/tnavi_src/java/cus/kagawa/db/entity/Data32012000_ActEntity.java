package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * �s���̋L�^���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_ActEntity {

	public final static String DEFALUT_VALUE = "";

	/** ���ڃR�[�h */
	private String gavt_gavtcode = DEFALUT_VALUE;

	/** ���ږ� */
	private String gavt_gavtname = DEFALUT_VALUE;

	/** ���ڗ��� */
	private String gavt_gavtname2 = DEFALUT_VALUE;

	/** �]���l�R�[�h */
	private String gavv_gacecode = DEFALUT_VALUE;

	/** �]���l */
	private String gace_display = DEFALUT_VALUE;


	/**
	 * @return gavt_gavtcode
	 */
	public String getGavt_gavtcode() {
		return gavt_gavtcode;
	}

	/**
	 * @param gavt_gavtcode the gavt_gavtcode to set
	 */
	public void setGavt_gavtcode(String gavt_gavtcode) {
		this.gavt_gavtcode = gavt_gavtcode;
	}

	/**
	 * @return gavt_gavtname
	 */
	public String getGavt_gavtname() {
		return gavt_gavtname;
	}

	/**
	 * @param gavt_gavtname the gavt_gavtname to set
	 */
	public void setGavt_gavtname(String gavt_gavtname) {
		this.gavt_gavtname = gavt_gavtname;
	}

	/**
	 * @return gavt_gavtname2
	 */
	public String getGavt_gavtname2() {
		return gavt_gavtname2;
	}

	/**
	 * @param gavt_gavtname2 the gavt_gavtname2 to set
	 */
	public void setGavt_gavtname2(String gavt_gavtname2) {
		this.gavt_gavtname2 = gavt_gavtname2;
	}

	/**
	 * @return gavv_gacecode
	 */
	public String getGavv_gacecode() {
		return gavv_gacecode;
	}

	/**
	 * @param gavv_gacecode the gavv_gacecode to set
	 */
	public void setGavv_gacecode(String gavv_gacecode) {
		this.gavv_gacecode = gavv_gacecode;
	}

	/**
	 * @return gace_display
	 */
	public String getGace_display() {
		return gace_display;
	}

	/**
	 * @param gace_display the gace_display to set
	 */
	public void setGace_display(String gace_display) {
		this.gace_display = gace_display;
	}


}
