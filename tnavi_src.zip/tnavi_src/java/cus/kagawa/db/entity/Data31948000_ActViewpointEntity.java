package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) �s���̋L�^�̊ϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31948000_ActViewpointEntity {

	/**
	 * �ϓ_�R�[�h
	 */
	private String ravt_ravtcode;

	/**
	 * �ϓ_
	 */
	private String ravt_ravtname;

	/**
	 * @return ravt_ravtcode
	 */
	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}

	/**
	 * @param ravt_ravtcode �Z�b�g���� ravt_ravtcode
	 */
	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}

	/**
	 * @return ravt_ravtname
	 */
	public String getRavt_ravtname() {
		return ravt_ravtname;
	}

	/**
	 * @param ravt_ravtname �Z�b�g���� ravt_ravtname
	 */
	public void setRavt_ravtname(String ravt_ravtname) {
		this.ravt_ravtname = ravt_ravtname;
	}


}
