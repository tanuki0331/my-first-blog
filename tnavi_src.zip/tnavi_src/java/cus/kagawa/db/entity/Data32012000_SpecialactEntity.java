package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ʊ����̋L�^���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_SpecialactEntity {

	public final static String DEFALUT_VALUE = "";

	/** �ϓ_�R�[�h */
	private String gsat_gsatcode = DEFALUT_VALUE;

	/** ���� */
	private String gsat_gsatname = DEFALUT_VALUE;

	/** ���� */
	private String gsat_gsatname2 = DEFALUT_VALUE;

	/** ���ʊ����̋L�^�]���lID */
	private String gsav_gsaecode = DEFALUT_VALUE;

	/** �]���l */
	private String gsae_display = DEFALUT_VALUE;

	/** �ϓ_�g�p�t���O */
	private String gsas_flg = DEFALUT_VALUE;



	/**
	 * @return gsat_gsatcode
	 */
	public String getGsat_gsatcode() {
		return gsat_gsatcode;
	}

	/**
	 * @param gsat_gsatcode the gsat_gsatcode to set
	 */
	public void setGsat_gsatcode(String gsat_gsatcode) {
		this.gsat_gsatcode = gsat_gsatcode;
	}

	/**
	 * @return gsat_gsatname
	 */
	public String getGsat_gsatname() {
		return gsat_gsatname;
	}

	/**
	 * @param gsat_gsatname the gsat_gsatname to set
	 */
	public void setGsat_gsatname(String gsat_gsatname) {
		this.gsat_gsatname = gsat_gsatname;
	}

	/**
	 * @return gsat_gsatname2
	 */
	public String getGsat_gsatname2() {
		return gsat_gsatname2;
	}

	/**
	 * @param gsat_gsatname2 the gsat_gsatname2 to set
	 */
	public void setGsat_gsatname2(String gsat_gsatname2) {
		this.gsat_gsatname2 = gsat_gsatname2;
	}

	/**
	 * @return gsav_gsaecode
	 */
	public String getGsav_gsaecode() {
		return gsav_gsaecode;
	}

	/**
	 * @param gsav_gsaecode the gsav_gsaecode to set
	 */
	public void setGsav_gsaecode(String gsav_gsaecode) {
		this.gsav_gsaecode = gsav_gsaecode;
	}

	/**
	 * @return gsae_display
	 */
	public String getGsae_display() {
		return gsae_display;
	}

	/**
	 * @param gsae_display the gsae_display to set
	 */
	public void setGsae_display(String gsae_display) {
		this.gsae_display = gsae_display;
	}

	/**
	 * @return gsas_flg
	 */
	public String getGsas_flg() {
		return gsas_flg;
	}

	/**
	 * @param gsas_flg the gsas_flg to set
	 */
	public void setGsas_flg(String gsas_flg) {
		this.gsas_flg = gsas_flg;
	}



}
