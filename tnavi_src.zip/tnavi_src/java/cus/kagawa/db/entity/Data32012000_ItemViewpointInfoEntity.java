package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_�E�ϓ_�ʕ]�����Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_ItemViewpointInfoEntity {

	public final static String DEFALUT_VALUE = "";

	/** ���ȃR�[�h */
	private String item_code = DEFALUT_VALUE;

	/** ���Ȗ� */
	private String item_name = DEFALUT_VALUE;

	/** ���� �\���� */
	private String item_ord = DEFALUT_VALUE;

	/** �w���v�̃R�[�h */
	private String gst_curcode = DEFALUT_VALUE;

	/** �ϓ_�R�[�h */
	private String givt_givtcode = DEFALUT_VALUE;

	/** �ϓ_�� */
	private String givt_givtname = DEFALUT_VALUE;

	/** �ϓ_ �\���� */
	private String givtorder = DEFALUT_VALUE;

	/** �ϓ_�ʕ]���lID */
	private String gvpv_gvpecode = DEFALUT_VALUE;

	/** �]���l */
	private String gvpe_display = DEFALUT_VALUE;



	/** ���Ȏ��(0:�ʏ틳�� 1:�I������) */
	private String itemKind = DEFALUT_VALUE;

	/**
	 * @return item_code
	 */
	public String getItem_code() {
		return item_code;
	}

	/**
	 * @param item_code the item_code to set
	 */
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	/**
	 * @return item_name
	 */
	public String getItem_name() {
		return item_name;
	}

	/**
	 * @param item_name the item_name to set
	 */
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	/**
	 * @return item_ord
	 */
	public String getItem_ord() {
		return item_ord;
	}

	/**
	 * @param item_ord the item_ord to set
	 */
	public void setItem_ord(String item_ord) {
		this.item_ord = item_ord;
	}

	/**
	 * @return gst_curcode
	 */
	public String getGst_curcode() {
		return gst_curcode;
	}

	/**
	 * @param gst_curcode the gst_curcode to set
	 */
	public void setGst_curcode(String gst_curcode) {
		this.gst_curcode = gst_curcode;
	}

	/**
	 * @return givt_givtcode
	 */
	public String getGivt_givtcode() {
		return givt_givtcode;
	}

	/**
	 * @param givt_givtcode the givt_givtcode to set
	 */
	public void setGivt_givtcode(String givt_givtcode) {
		this.givt_givtcode = givt_givtcode;
	}

	/**
	 * @return givt_givtname
	 */
	public String getGivt_givtname() {
		return givt_givtname;
	}

	/**
	 * @param givt_givtname the givt_givtname to set
	 */
	public void setGivt_givtname(String givt_givtname) {
		this.givt_givtname = givt_givtname;
	}

	/**
	 * @return givtorder
	 */
	public String getGivtorder() {
		return givtorder;
	}

	/**
	 * @param givtorder the givtorder to set
	 */
	public void setGivtorder(String givtorder) {
		this.givtorder = givtorder;
	}

	/**
	 * @return gvpv_gvpecode
	 */
	public String getGvpv_gvpecode() {
		return gvpv_gvpecode;
	}

	/**
	 * @param gvpv_gvpecode the gvpv_gvpecode to set
	 */
	public void setGvpv_gvpecode(String gvpv_gvpecode) {
		this.gvpv_gvpecode = gvpv_gvpecode;
	}

	/**
	 * @return gvpe_display
	 */
	public String getGvpe_display() {
		return gvpe_display;
	}

	/**
	 * @param gvpe_display the gvpe_display to set
	 */
	public void setGvpe_display(String gvpe_display) {
		this.gvpe_display = gvpe_display;
	}



	public String getItemKind() {
		return itemKind;
	}

	public void setItemKind(String itemKind) {
		this.itemKind = itemKind;
	}

}
