package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���E�������������Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_StaffEntity {

	public final static String DEFALUT_VALUE = "";

	/** �A�C�� */
	private String stf_start = DEFALUT_VALUE;

	/** �ޔC�� */
	private String stf_end = DEFALUT_VALUE;

	/** ���E���R�[�h */
	private String stf_stfcode = DEFALUT_VALUE;

	/** ���E������ */
	private String stf_name = DEFALUT_VALUE;

	/** ��e�o�C�i��*/
    private byte[] stp_stampfile;

	/**
	 * @return stf_start
	 */
	public String getStf_start() {
		return stf_start;
	}

	/**
	 * @param stf_start the stf_start to set
	 */
	public void setStf_start(String stf_start) {
		this.stf_start = stf_start;
	}

	/**
	 * @return stf_end
	 */
	public String getStf_end() {
		return stf_end;
	}

	/**
	 * @param stf_end the stf_end to set
	 */
	public void setStf_end(String stf_end) {
		this.stf_end = stf_end;
	}

	/**
	 * @return stf_stfcode
	 */
	public String getStf_stfcode() {
		return stf_stfcode;
	}

	/**
	 * @param stf_stfcode the stf_stfcode to set
	 */
	public void setStf_stfcode(String stf_stfcode) {
		this.stf_stfcode = stf_stfcode;
	}

	/**
	 * @return stf_name
	 */
	public String getStf_name() {
		return stf_name;
	}

	/**
	 * @param stf_name the stf_name to set
	 */
	public void setStf_name(String stf_name) {
		this.stf_name = stf_name;
	}

	/**
	 * @return stp_stampfile
	 */
	public byte[] getStp_stampfile() {
		return stp_stampfile;
	}

	/**
	 * @param stp_stampfile the stp_stampfile to set
	 */
	public void setStp_stampfile(byte[] stp_stampfile) {
		this.stp_stampfile = stp_stampfile;
	}

}
