package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * �o���̋L�^���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_AttendEntity {

	public final static String DEFALUT_VALUE = "";

	/** �N�x */
	private String gar_year = DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String gar_stucode = DEFALUT_VALUE;

	/** �w�N */
	private String gar_grade = DEFALUT_VALUE;

	/** ���Ɠ��� */
	private String gar_count = DEFALUT_VALUE;

	/** �o�Ȓ�~�E������������ */
	private String gar_stop = DEFALUT_VALUE;

	/** �o�Ȃ��Ȃ���΂Ȃ�Ȃ����� */
	private String gar_must = DEFALUT_VALUE;

	/** ���ȓ��� */
	private String gar_absence = DEFALUT_VALUE;

	/** �o�ȓ��� */
	private String gar_attend = DEFALUT_VALUE;

	/** �x������ */
	private String gar_late = DEFALUT_VALUE;

	/** ���ޓ��� */
	private String gar_leave = DEFALUT_VALUE;

	/** ���l */
	private String gar_memo = DEFALUT_VALUE;

	/**
	 * @return gar_year
	 */
	public String getGar_year() {
		return gar_year;
	}

	/**
	 * @param gar_year the gar_year to set
	 */
	public void setGar_year(String gar_year) {
		this.gar_year = gar_year;
	}

	/**
	 * @return gar_stucode
	 */
	public String getGar_stucode() {
		return gar_stucode;
	}

	/**
	 * @param gar_stucode the gar_stucode to set
	 */
	public void setGar_stucode(String gar_stucode) {
		this.gar_stucode = gar_stucode;
	}

	/**
	 * @return gar_grade
	 */
	public String getGar_grade() {
		return gar_grade;
	}

	/**
	 * @param gar_grade the gar_grade to set
	 */
	public void setGar_grade(String gar_grade) {
		this.gar_grade = gar_grade;
	}

	/**
	 * @return gar_count
	 */
	public String getGar_count() {
		return gar_count;
	}

	/**
	 * @param gar_count the gar_count to set
	 */
	public void setGar_count(String gar_count) {
		this.gar_count = gar_count;
	}

	/**
	 * @return gar_stop
	 */
	public String getGar_stop() {
		return gar_stop;
	}

	/**
	 * @param gar_stop the gar_stop to set
	 */
	public void setGar_stop(String gar_stop) {
		this.gar_stop = gar_stop;
	}

	/**
	 * @return gar_must
	 */
	public String getGar_must() {
		return gar_must;
	}

	/**
	 * @param gar_must the gar_must to set
	 */
	public void setGar_must(String gar_must) {
		this.gar_must = gar_must;
	}

	/**
	 * @return gar_absence
	 */
	public String getGar_absence() {
		return gar_absence;
	}

	/**
	 * @param gar_absence the gar_absence to set
	 */
	public void setGar_absence(String gar_absence) {
		this.gar_absence = gar_absence;
	}

	/**
	 * @return gar_attend
	 */
	public String getGar_attend() {
		return gar_attend;
	}

	/**
	 * @param gar_attend the gar_attend to set
	 */
	public void setGar_attend(String gar_attend) {
		this.gar_attend = gar_attend;
	}

	/**
	 * @return gar_late
	 */
	public String getGar_late() {
		return gar_late;
	}

	/**
	 * @param gar_late the gar_late to set
	 */
	public void setGar_late(String gar_late) {
		this.gar_late = gar_late;
	}

	/**
	 * @return gar_leave
	 */
	public String getGar_leave() {
		return gar_leave;
	}

	/**
	 * @param gar_leave the gar_leave to set
	 */
	public void setGar_leave(String gar_leave) {
		this.gar_leave = gar_leave;
	}

	/**
	 * @return gar_memo
	 */
	public String getGar_memo() {
		return gar_memo;
	}

	/**
	 * @param gar_memo the gar_memo to set
	 */
	public void setGar_memo(String gar_memo) {
		this.gar_memo = gar_memo;
	}

}
