package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * �]��̏o�͑Ώۋ��ȏ��Entity.
 * </PRE>
 *
 * <B>Create</B> 2015.12.17 hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_EvalItemEntity {
	
	public final static String DEFALUT_VALUE = "";

	/** ���ȃR�[�h */
	private String givg_item = DEFALUT_VALUE;
	
	/** ���Ȗ� */
	private String cod_name1 = DEFALUT_VALUE;
	
	/** �\���� */
	private String cod_value2 = DEFALUT_VALUE;

	/** ���Ȏ�ʔ��ʗp(0:�ʏ틳�� 1:�I������) */
	private String itemKind = DEFALUT_VALUE;
	
	/**
	 * @return givg_item
	 */
	public String getGivg_item() {
		return givg_item;
	}

	/**
	 * @param givg_item the givg_item to set
	 */
	public void setGivg_item(String givg_item) {
		this.givg_item = givg_item;
	}

	/**
	 * @return cod_name1
	 */
	public String getCod_name1() {
		return cod_name1;
	}

	/**
	 * @param cod_name1 the cod_name1 to set
	 */
	public void setCod_name1(String cod_name1) {
		this.cod_name1 = cod_name1;
	}

	/**
	 * @return cod_value2
	 */
	public String getCod_value2() {
		return cod_value2;
	}

	/**
	 * @param cod_value2 the cod_value2 to set
	 */
	public void setCod_value2(String cod_value2) {
		this.cod_value2 = cod_value2;
	}

	/**
	 * @return itemKind
	 */
	public String getItemKind() {
		return itemKind;
	}

	/**
	 * @param itemKind the itemKind to set
	 */
	public void setItemKind(String itemKind) {
		this.itemKind = itemKind;
	}

}
