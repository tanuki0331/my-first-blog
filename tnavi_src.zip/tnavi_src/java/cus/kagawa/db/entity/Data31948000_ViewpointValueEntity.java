package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) �ϓ_�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31948000_ViewpointValueEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * ���ȃR�[�h
	 */
	private String item_code;

	/**
	 * ���ȕ��я�
	 */
	private String item_order;

	/**
	 * �ϓ_�R�[�h
	 */
	private String rivt_rivtcode;

	/**
	 * �o�͎����R�[�h
	 */
	private String rvpv_goptcode;

	/**
	 * �]���l�R�[�h
	 */
	private String rvpv_manualrevpecode;

	/**
	 * �]��
	 */
	private String rvpe_reportdisplay;

	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return item_code
	 */
	public String getItem_code() {
		return item_code;
	}

	/**
	 * @param item_code �Z�b�g���� item_code
	 */
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	/**
	 * @return item_order
	 */
	public String getItem_order() {
		return item_order;
	}

	/**
	 * @param item_order �Z�b�g���� item_order
	 */
	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	/**
	 * @return rivt_rivtcode
	 */
	public String getRivt_rivtcode() {
		return rivt_rivtcode;
	}

	/**
	 * @param rivt_rivtcode �Z�b�g���� rivt_rivtcode
	 */
	public void setRivt_rivtcode(String rivt_rivtcode) {
		this.rivt_rivtcode = rivt_rivtcode;
	}

	/**
	 * @return rvpv_goptcode
	 */
	public String getRvpv_goptcode() {
		return rvpv_goptcode;
	}

	/**
	 * @param rvpv_goptcode �Z�b�g���� rvpv_goptcode
	 */
	public void setRvpv_goptcode(String rvpv_goptcode) {
		this.rvpv_goptcode = rvpv_goptcode;
	}

	/**
	 * @return rvpv_manualrevpecode
	 */
	public String getRvpv_manualrevpecode() {
		return rvpv_manualrevpecode;
	}

	/**
	 * @param rvpv_manualrevpecode �Z�b�g���� rvpv_manualrevpecode
	 */
	public void setRvpv_manualrevpecode(String rvpv_manualrevpecode) {
		this.rvpv_manualrevpecode = rvpv_manualrevpecode;
	}

	/**
	 * @return rvpe_reportdisplay
	 */
	public String getRvpe_reportdisplay() {
		return rvpe_reportdisplay;
	}

	/**
	 * @param rvpe_reportdisplay �Z�b�g���� rvpe_reportdisplay
	 */
	public void setRvpe_reportdisplay(String rvpe_reportdisplay) {
		this.rvpe_reportdisplay = rvpe_reportdisplay;
	}

}
