package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���k�t�������Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.3.5 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_AddItemEntity {

	public final static String DEFALUT_VALUE = "";

	/** ���[�U�[�ԍ� */
	private String said_user = DEFALUT_VALUE;

	/** �w���ԍ� */
	private String said_stucode = DEFALUT_VALUE;

	/** �R�[�h�l */
	private String said_saicode = DEFALUT_VALUE;

	/** �o�^�l */
	private String said_inputdata = DEFALUT_VALUE;

	public String getSaid_user() {
		return said_user;
	}

	public void setSaid_user(String said_user) {
		this.said_user = said_user;
	}

	public String getSaid_stucode() {
		return said_stucode;
	}

	public void setSaid_stucode(String said_stucode) {
		this.said_stucode = said_stucode;
	}

	public String getSaid_saicode() {
		return said_saicode;
	}

	public void setSaid_saicode(String said_saicode) {
		this.said_saicode = said_saicode;
	}

	public String getSaid_inputdata() {
		return said_inputdata;
	}

	public void setSaid_inputdata(String said_inputdata) {
		this.said_inputdata = said_inputdata;
	}

}
