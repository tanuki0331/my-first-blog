package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * �������Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_CommentEntity {

	public final static String DEFALUT_VALUE = "";

	/** �N�x */
	private String gcom_year = DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String gcom_stucode = DEFALUT_VALUE;

	/** �w�N */
	private String gcom_grade = DEFALUT_VALUE;

	/** ���� */
	private String gcom_comment = DEFALUT_VALUE;

	/** �����E�W�E�N���u(�O��) */
	private String gcom_splitcomment1 = DEFALUT_VALUE;

	/** �����E�W�E�N���u(���) */
	private String gcom_splitcomment2 = DEFALUT_VALUE;

	/** �����E�W�E�N���u(����) */
	private String gcom_splitcomment3 = DEFALUT_VALUE;

	/** ���i�E�� */
	private String gcom_splitcomment4 = DEFALUT_VALUE;

	/** ���g�p */
	private String gcom_splitcomment5 = DEFALUT_VALUE;

	/**
	 * @return gcom_year
	 */
	public String getGcom_year() {
		return gcom_year;
	}

	/**
	 * @param gcom_year the gcom_year to set
	 */
	public void setGcom_year(String gcom_year) {
		this.gcom_year = gcom_year;
	}

	/**
	 * @return gcom_stucode
	 */
	public String getGcom_stucode() {
		return gcom_stucode;
	}

	/**
	 * @param gcom_stucode the gcom_stucode to set
	 */
	public void setGcom_stucode(String gcom_stucode) {
		this.gcom_stucode = gcom_stucode;
	}

	/**
	 * @return gcom_grade
	 */
	public String getGcom_grade() {
		return gcom_grade;
	}

	/**
	 * @param gcom_grade the gcom_grade to set
	 */
	public void setGcom_grade(String gcom_grade) {
		this.gcom_grade = gcom_grade;
	}

	/**
	 * @return gcom_comment
	 */
	public String getGcom_comment() {
		return gcom_comment;
	}

	/**
	 * @param gcom_comment the gcom_comment to set
	 */
	public void setGcom_comment(String gcom_comment) {
		this.gcom_comment = gcom_comment;
	}

	/**
	 * @return gcom_splitcomment1
	 */
	public String getGcom_splitcomment1() {
		return gcom_splitcomment1;
	}

	/**
	 * @param gcom_splitcomment1 the gcom_splitcomment1 to set
	 */
	public void setGcom_splitcomment1(String gcom_splitcomment1) {
		this.gcom_splitcomment1 = gcom_splitcomment1;
	}

	/**
	 * @return gcom_splitcomment2
	 */
	public String getGcom_splitcomment2() {
		return gcom_splitcomment2;
	}

	/**
	 * @param gcom_splitcomment2 the gcom_splitcomment2 to set
	 */
	public void setGcom_splitcomment2(String gcom_splitcomment2) {
		this.gcom_splitcomment2 = gcom_splitcomment2;
	}

	/**
	 * @return gcom_splitcomment3
	 */
	public String getGcom_splitcomment3() {
		return gcom_splitcomment3;
	}

	/**
	 * @param gcom_splitcomment3 the gcom_splitcomment3 to set
	 */
	public void setGcom_splitcomment3(String gcom_splitcomment3) {
		this.gcom_splitcomment3 = gcom_splitcomment3;
	}

	/**
	 * @return gcom_splitcomment4
	 */
	public String getGcom_splitcomment4() {
		return gcom_splitcomment4;
	}

	/**
	 * @param gcom_splitcomment4 the gcom_splitcomment4 to set
	 */
	public void setGcom_splitcomment4(String gcom_splitcomment4) {
		this.gcom_splitcomment4 = gcom_splitcomment4;
	}

	/**
	 * @return gcom_splitcomment5
	 */
	public String getGcom_splitcomment5() {
		return gcom_splitcomment5;
	}

	/**
	 * @param gcom_splitcomment5 the gcom_splitcomment5 to set
	 */
	public void setGcom_splitcomment5(String gcom_splitcomment5) {
		this.gcom_splitcomment5 = gcom_splitcomment5;
	}

}
