package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) ���ȕ]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31948000_ItemEvalEntity {


	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * ���ȃR�[�h
	 */
	private String item_code;

	/**
	 * ���ȕ��я�
	 */
	private String item_order;

	/**
	 * �]��R�[�h
	 */
	private String rev_manualscorpteval;

	/**
	 * �]��
	 */
	private String revl_display;

	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return item_code
	 */
	public String getItem_code() {
		return item_code;
	}

	/**
	 * @param item_code �Z�b�g���� item_code
	 */
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	/**
	 * @return item_order
	 */
	public String getItem_order() {
		return item_order;
	}

	/**
	 * @param item_order �Z�b�g���� item_order
	 */
	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	/**
	 * @return rev_manualscorpteval
	 */
	public String getRev_manualscorpteval() {
		return rev_manualscorpteval;
	}

	/**
	 * @param rev_manualscorpteval �Z�b�g���� rev_manualscorpteval
	 */
	public void setRev_manualscorpteval(String rev_manualscorpteval) {
		this.rev_manualscorpteval = rev_manualscorpteval;
	}

	/**
	 * @return revl_display
	 */
	public String getRevl_display() {
		return revl_display;
	}

	/**
	 * @param revl_display �Z�b�g���� revl_display
	 */
	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}

}
