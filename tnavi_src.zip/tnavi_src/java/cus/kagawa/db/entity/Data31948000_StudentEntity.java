/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD Inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kagawa.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) �ꗗ ���k��� Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31948000_StudentEntity implements CommonConstantsUseable {

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String stuNumber;
	/** �w�Дԍ� **/
	private String stuStucode;
	/** ���k�E�������� **/
	private String stuStuname;
	/**
	 * ���k�ݐЏ�(0:��ݐ�, 1:�ݐ�)
	 */
	private String STU_EXIST;

	/**
	 * @return stuNumber
	 */
	public String getStuNumber() {
		return stuNumber;
	}
	/**
	 * @param stuNumber �Z�b�g���� stuNumber
	 */
	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}
	/**
	 * @return stuStucode
	 */
	public String getStuStucode() {
		return stuStucode;
	}
	/**
	 * @param stuStucode �Z�b�g���� stuStucode
	 */
	public void setStuStucode(String stuStucode) {
		this.stuStucode = stuStucode;
	}
	/**
	 * @return stuStuname
	 */
	public String getStuStuname() {
		return stuStuname;
	}
	/**
	 * @param stuStuname �Z�b�g���� stuStuname
	 */
	public void setStuStuname(String stuStuname) {
		this.stuStuname = stuStuname;
	}
	/**
	 * @return sTU_EXIST
	 */
	public String getSTU_EXIST() {
		return STU_EXIST;
	}
	/**
	 * @param sTU_EXIST �Z�b�g���� sTU_EXIST
	 */
	public void setSTU_EXIST(String sTU_EXIST) {
		STU_EXIST = sTU_EXIST;
	}

}