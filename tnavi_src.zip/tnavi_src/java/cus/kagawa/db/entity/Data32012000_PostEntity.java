package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���������Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.3.5 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_PostEntity {

	public final static String DEFALUT_VALUE = "";

	/** �N�x */
	private String cls_year = DEFALUT_VALUE;

	/**  */
	private String ext_code = DEFALUT_VALUE;

	/** �w�Дԍ� */
	private String cls_stucode = DEFALUT_VALUE;

	/** �o�Ȕԍ� */
	private String cls_number = DEFALUT_VALUE;

	/** �w���J�n�� */
	private String semStartDate = DEFALUT_VALUE;

	/** �w���I���� */
	private String semEndDate = DEFALUT_VALUE;

	/** �w������ */
	private String sem_name = DEFALUT_VALUE;

	/**  */
	private String pos_kind = DEFALUT_VALUE;

	/**  */
	private String pos_number = DEFALUT_VALUE;

	/** �ψ���E�N���X�ψ������� */
	private String ext_name = DEFALUT_VALUE;

	/** ��E */
	private String pst_name = DEFALUT_VALUE;

	/** �W(1�w��) */
	private String term1_kakari = DEFALUT_VALUE;

	/** ����(1�w��) */
	private String term1_iin = DEFALUT_VALUE;

	/** �W(2�w��) */
	private String term2_kakari = DEFALUT_VALUE;

	/** ����(3�w��) */
	private String term2_iin = DEFALUT_VALUE;

	/** �W(3�w��) */
	private String term3_kakari = DEFALUT_VALUE;

	/** ����(3�w��) */
	private String term3_iin = DEFALUT_VALUE;

	public String getCls_year() {
		return cls_year;
	}

	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	public String getExt_code() {
		return ext_code;
	}

	public void setExt_code(String ext_code) {
		this.ext_code = ext_code;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getSemStartDate() {
		return semStartDate;
	}

	public void setSemStartDate(String semStartDate) {
		this.semStartDate = semStartDate;
	}

	public String getSemEndDate() {
		return semEndDate;
	}

	public void setSemEndDate(String semEndDate) {
		this.semEndDate = semEndDate;
	}

	public String getSem_name() {
		return sem_name;
	}

	public void setSem_name(String sem_name) {
		this.sem_name = sem_name;
	}

	public String getPos_kind() {
		return pos_kind;
	}

	public void setPos_kind(String pos_kind) {
		this.pos_kind = pos_kind;
	}

	public String getPos_number() {
		return pos_number;
	}

	public void setPos_number(String pos_number) {
		this.pos_number = pos_number;
	}

	public String getExt_name() {
		return ext_name;
	}

	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}

	public String getPst_name() {
		return pst_name;
	}

	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}

	public String getTerm1_kakari() {
		return term1_kakari;
	}

	public void setTerm1_kakari(String term1_kakari) {
		this.term1_kakari = term1_kakari;
	}

	public String getTerm1_iin() {
		return term1_iin;
	}

	public void setTerm1_iin(String term1_iin) {
		this.term1_iin = term1_iin;
	}

	public String getTerm2_kakari() {
		return term2_kakari;
	}

	public void setTerm2_kakari(String term2_kakari) {
		this.term2_kakari = term2_kakari;
	}

	public String getTerm2_iin() {
		return term2_iin;
	}

	public void setTerm2_iin(String term2_iin) {
		this.term2_iin = term2_iin;
	}

	public String getTerm3_kakari() {
		return term3_kakari;
	}

	public void setTerm3_kakari(String term3_kakari) {
		this.term3_kakari = term3_kakari;
	}

	public String getTerm3_iin() {
		return term3_iin;
	}

	public void setTerm3_iin(String term3_iin) {
		this.term3_iin = term3_iin;
	}

	public static String getDefalutValue() {
		return DEFALUT_VALUE;
	}







}
