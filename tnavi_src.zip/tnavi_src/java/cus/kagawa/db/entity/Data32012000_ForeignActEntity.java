package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * �O���ꊈ���̋L�^���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.2.16 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_ForeignActEntity {

	public final static String DEFALUT_VALUE = "";

	/** ���ȃR�[�h */
	private String item_code = DEFALUT_VALUE;

	/** ���Ȗ� */
	private String item_name = DEFALUT_VALUE;

	/** �w���v�̃R�[�h */
	private String gst_curcode = DEFALUT_VALUE;

	/** �ϓ_�R�[�h */
	private String givt_givtcode = DEFALUT_VALUE;

	/** �ϓ_�� */
	private String givt_givtname = DEFALUT_VALUE;

	/** �]�� */
	private String gfla_eval = DEFALUT_VALUE;



	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getGst_curcode() {
		return gst_curcode;
	}

	public void setGst_curcode(String gst_curcode) {
		this.gst_curcode = gst_curcode;
	}

	public String getGivt_givtcode() {
		return givt_givtcode;
	}

	public void setGivt_givtcode(String givt_givtcode) {
		this.givt_givtcode = givt_givtcode;
	}

	public String getGivt_givtname() {
		return givt_givtname;
	}

	public void setGivt_givtname(String givt_givtname) {
		this.givt_givtname = givt_givtname;
	}

	public String getGfla_eval() {
		return gfla_eval;
	}

	public void setGfla_eval(String gfla_eval) {
		this.gfla_eval = gfla_eval;
	}



}
