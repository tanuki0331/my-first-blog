package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ��܋L�^���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.3.5 BY iwata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32012000_RetcValueEntity {

	public final static String DEFALUT_VALUE = "";


	/** ��܋L�^ */
	private String retc_value = DEFALUT_VALUE;


	public String getRetc_value() {
		return retc_value;
	}


	public void setRetc_value(String retc_value) {
		this.retc_value = retc_value;
	}


}
