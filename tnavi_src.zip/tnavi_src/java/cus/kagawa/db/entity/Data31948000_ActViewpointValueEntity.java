package jp.co.systemd.tnavi.cus.kagawa.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(���쌧�����w�Z) �s���̋L�^�̊ϓ_�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.05.18 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31948000_ActViewpointValueEntity {

	/**
	 * �ϓ_�R�[�h
	 */
	private String ravt_ravtcode;

	/**
	 * �w�Дԍ�
	 */
	private String ravv_stucode;

	/**
	 * �o�͎����R�[�h
	 */
	private String ravv_term;

	/**
	 * �]���l�R�[�h
	 */
	private String ravv_racecode;

	/**
	 * �]���l(�\���p�l)
	 */
	private String race_reportdisplay;

	/**
	 * @return ravt_ravtcode
	 */
	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}

	/**
	 * @param ravt_ravtcode �Z�b�g���� ravt_ravtcode
	 */
	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}

	/**
	 * @return ravv_stucode
	 */
	public String getRavv_stucode() {
		return ravv_stucode;
	}

	/**
	 * @param ravv_stucode �Z�b�g���� ravv_stucode
	 */
	public void setRavv_stucode(String ravv_stucode) {
		this.ravv_stucode = ravv_stucode;
	}

	/**
	 * @return ravv_term
	 */
	public String getRavv_term() {
		return ravv_term;
	}

	/**
	 * @param ravv_term �Z�b�g���� ravv_term
	 */
	public void setRavv_term(String ravv_term) {
		this.ravv_term = ravv_term;
	}

	/**
	 * @return ravv_racecode
	 */
	public String getRavv_racecode() {
		return ravv_racecode;
	}

	/**
	 * @param ravv_racecode �Z�b�g���� ravv_racecode
	 */
	public void setRavv_racecode(String ravv_racecode) {
		this.ravv_racecode = ravv_racecode;
	}

	/**
	 * @return race_reportdisplay
	 */
	public String getRace_reportdisplay() {
		return race_reportdisplay;
	}

	/**
	 * @param race_reportdisplay �Z�b�g���� race_reportdisplay
	 */
	public void setRace_reportdisplay(String race_reportdisplay) {
		this.race_reportdisplay = race_reportdisplay;
	}

}
