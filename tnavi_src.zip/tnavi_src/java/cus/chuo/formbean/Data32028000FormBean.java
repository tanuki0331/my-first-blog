package jp.co.systemd.tnavi.cus.chuo.formbean;

/**
 * <PRE>
 * ���N�̋L�^���(�����s) ��� ���k��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32028000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String stuGrade = DEFALUT_VALUE;

	/** �g **/
	private String stuClass = DEFALUT_VALUE;

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String stuNumber = DEFALUT_VALUE;

	/** �w�Дԍ� **/
	private String stucode = DEFALUT_VALUE;

	/** ���k�E�������� **/
	private String stuname = DEFALUT_VALUE;

	/** ���N���� **/
	private String stuBirth = DEFALUT_VALUE;

	/** ���ʎx���w���t���O **/
	private String specialSupport = DEFALUT_VALUE;

	/** �𗬐�N���X�ԍ� **/
	private String excClsno = DEFALUT_VALUE;

	/** �𗬐�o�Ȕԍ� **/
	private String excNumber = DEFALUT_VALUE;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getStuGrade() {
		return stuGrade;
	}

	public void setStuGrade(String stuGrade) {
		this.stuGrade = stuGrade;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getStuNumber() {
		return stuNumber;
	}

	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getStucode() {
		return stucode;
	}

	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	public String getStuname() {
		return stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getStuBirth() {
		return stuBirth;
	}

	public void setStuBirth(String stuBirth) {
		this.stuBirth = stuBirth;
	}

	/**
	 * @return specialSupport
	 */
	public String getSpecialSupport() {
		return specialSupport;
	}

	/**
	 * @param specialSupport �Z�b�g���� specialSupport
	 */
	public void setSpecialSupport(String specialSupport) {
		this.specialSupport = specialSupport;
	}

	/**
	 * @return excClsno
	 */
	public String getExcClsno() {
		return excClsno;
	}

	/**
	 * @param excClsno �Z�b�g���� excClsno
	 */
	public void setExcClsno(String excClsno) {
		this.excClsno = excClsno;
	}

	/**
	 * @return excNumber
	 */
	public String getExcNumber() {
		return excNumber;
	}

	/**
	 * @param excNumber �Z�b�g���� excNumber
	 */
	public void setExcNumber(String excNumber) {
		this.excNumber = excNumber;
	}

}
