package jp.co.systemd.tnavi.cus.chuo.formbean;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.chuo.constants.CusChuoConstantsUseable;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028000_AverageEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028000_BmiEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028000_DiagnosticsResultEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028000_MemoEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028000_TransitionHeightEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028000_TransitionWeightEntity;

/**
 * <PRE>
 * ���N�̋L�^���(�����s) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print32028000FormBean implements CusChuoConstantsUseable {

	public final static String DEFALUT_VALUE = "";

	/** �����R�[�h */
	private String userCode = DEFALUT_VALUE;

	/** �w�Z�敪 */
	private String useKind2 = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �a��N�x */
	private String nendoWareki = DEFALUT_VALUE;

	/** �I���w���R�[�h */
	private String term = DEFALUT_VALUE;

	/** �\���摜�C���[�W */
	byte[] coverImage;

	/** �w�Z��(����) */
	private String schoolNameS = DEFALUT_VALUE;

	/** ���k���̃f�[�^ */
	private List<Data32028000FormBean> dataFormBeanList;

	/** ����y�[�W �\�� */
	private boolean output_Cover;

	/** ����y�[�W �f�f�̋L�^ */
	private boolean output_Record;

	/** ����y�[�W �g���E�̏d�̐��� */
	private boolean output_Transition;

	/** ����y�[�W ���\�� */
	private boolean output_Deed;

	/** ���ڃO���t�o�� */
	private boolean output_graph;

	/** �O�N�x �g���E�̏d���ϒl�f�[�^ */
	private List<Data32028000_AverageEntity> avgEntList;

	/** �f�f�̋L�^���i�[Map[key:�w�Дԍ� value:�f�f�̋L�^���Entity] */
	private HashMap<String,Data32028000_DiagnosticsResultEntity> diagnosticsResultMap = new HashMap<String, Data32028000_DiagnosticsResultEntity>();

	/** �e�w���̔얞�xMap [key:�w�Дԍ� value:�얞�x��List] */
	private HashMap<String, List<Data32028000_BmiEntity>> bmiMap = new HashMap<String, List<Data32028000_BmiEntity>>();

	/** �g���̐��ڏ��Map [key:�w�Дԍ� value:�e�w���̐g�����List] */
	private Map<String,List<Data32028000_TransitionHeightEntity>> transitonHeightMap = null;

	/** �̏d�̐��ڏ��Map [key:�w�Дԍ� value:�e�w���̑̏d���List] */
	private Map<String,List<Data32028000_TransitionWeightEntity>> transitonWeightMap = null;

	/** �g���̐��ڃO���tMap [key:�w�Дԍ� value:�g�����ڃO���timage] */
	Map<String, byte[]> heightGraphImageMap = null;

	/** �̏d�̐��ڃO���tMap [key:�w�Дԍ� value:�̏d���ڃO���timage] */
	Map<String, byte[]> weightGraphImageMap = null;

	/** ���l���List */
	private List<Data32028000_MemoEntity> MemoList = null;

	@SuppressWarnings("serial")
	// ���w�Z �̏d�o��List�̌���INDEX�Ή��\
	private final LinkedHashMap<String, Integer> monthListIdxMap = new LinkedHashMap<String, Integer>(){
        {put("04", 0);} {put("05", 1);} {put("06", 2);} {put("07", 3);} {put("08", 4);} {put("09", 5);}
        {put("10", 6);} {put("11", 7);} {put("12", 8);} {put("01", 9);} {put("02", 10);} {put("03", 11);}
    };

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUseKind2() {
		return useKind2;
	}

	public void setUseKind2(String useKind2) {
		this.useKind2 = useKind2;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getNendoWareki() {
		return nendoWareki;
	}

	public void setNendoWareki(String nendoWareki) {
		this.nendoWareki = nendoWareki;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public byte[] getCoverImage() {
		return coverImage;
	}

	public void setCoverImage(byte[] coverImage) {
		this.coverImage = coverImage;
	}

	public String getSchoolNameS() {
		return schoolNameS;
	}

	public void setSchoolNameS(String schoolNameS) {
		this.schoolNameS = schoolNameS;
	}

	public List<Data32028000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	public void setDataFormBeanList(List<Data32028000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	public boolean isOutput_Cover() {
		return output_Cover;
	}

	public void setOutput_Cover(boolean output_Cover) {
		this.output_Cover = output_Cover;
	}

	public boolean isOutput_Record() {
		return output_Record;
	}

	public void setOutput_Record(boolean output_Record) {
		this.output_Record = output_Record;
	}

	public boolean isOutput_Transition() {
		return output_Transition;
	}

	public void setOutput_Transition(boolean output_Transition) {
		this.output_Transition = output_Transition;
	}

	public boolean isOutput_Deed() {
		return output_Deed;
	}

	public void setOutput_Deed(boolean output_Deed) {
		this.output_Deed = output_Deed;
	}

	public boolean isOutput_graph() {
		return output_graph;
	}

	public void setOutput_graph(boolean output_graph) {
		this.output_graph = output_graph;
	}

	public List<Data32028000_AverageEntity> getAvgEntList() {
		return avgEntList;
	}

	public void setAvgEntList(List<Data32028000_AverageEntity> avgEntList) {
		this.avgEntList = avgEntList;
	}

	public HashMap<String, Data32028000_DiagnosticsResultEntity> getDiagnosticsResultMap() {
		return diagnosticsResultMap;
	}

	public void setDiagnosticsResultMap(
			HashMap<String, Data32028000_DiagnosticsResultEntity> diagnosticsResultMap) {
		this.diagnosticsResultMap = diagnosticsResultMap;
	}

	public HashMap<String, List<Data32028000_BmiEntity>> getBmiMap() {
		return bmiMap;
	}

	public void setBmiMap(HashMap<String, List<Data32028000_BmiEntity>> bmiMap) {
		this.bmiMap = bmiMap;
	}

	public Map<String, List<Data32028000_TransitionHeightEntity>> getTransitonHeightMap() {
		return transitonHeightMap;
	}

	public void setTransitonHeightMap(
			Map<String, List<Data32028000_TransitionHeightEntity>> transitonHeightMap) {
		this.transitonHeightMap = transitonHeightMap;
	}

	public Map<String, List<Data32028000_TransitionWeightEntity>> getTransitonWeightMap() {
		return transitonWeightMap;
	}

	public void setTransitonWeightMap(
			Map<String, List<Data32028000_TransitionWeightEntity>> transitonWeightMap) {
		this.transitonWeightMap = transitonWeightMap;
	}

	public Map<String, byte[]> getHeightGraphImageMap() {
		return heightGraphImageMap;
	}

	public void setHeightGraphImageMap(Map<String, byte[]> heightGraphImageMap) {
		this.heightGraphImageMap = heightGraphImageMap;
	}

	public Map<String, byte[]> getWeightGraphImageMap() {
		return weightGraphImageMap;
	}

	public void setWeightGraphImageMap(Map<String, byte[]> weightGraphImageMap) {
		this.weightGraphImageMap = weightGraphImageMap;
	}

	public LinkedHashMap<String, Integer> getMonthListIdxMap() {
		return monthListIdxMap;
	}

	public List<Data32028000_MemoEntity> getMemoList() {
		return MemoList;
	}

	public void setMemoList(List<Data32028000_MemoEntity> memoList) {
		MemoList = memoList;
	}

}
