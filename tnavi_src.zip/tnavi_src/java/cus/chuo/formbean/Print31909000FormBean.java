package jp.co.systemd.tnavi.cus.chuo.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.entity.CodeEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_AttendEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_ForeignlangactEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_MoralEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_SpecialactEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_SpecialactMemoEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_TotalactEntity;

/**
 * <PRE>
 * ���ђʒm�\���(�����s���w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31909000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C�����t */
	private String endDate = DEFALUT_VALUE;

	/** �Z�̓C���[�W */
	byte[] schoolStampImage;

	/** �w�Z����ڕW�C���[�W */
	byte[] educationalgoalImage;

	/** �Z����C���[�W */
	byte[] principalStampImage;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �Z������(�C����) */
	private String principalNameDeed = DEFALUT_VALUE;

	/** �S�C���� */
	private String teacherName = DEFALUT_VALUE;

	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameS = DEFALUT_VALUE;

	/** ���k���̃f�[�^ */
	private List<Data31909000FormBean> dataFormBeanList;

	/** ���ȕʊϓ_�w�b�_���� */
	private CodeEntity itemViewpointHeader;

	/** ���ȕʊϓ_���i�[����Map */
	private Map<String, List<List<Data31909000_ItemViewpointEntity>>> itemViewpointListListMap;

	/** �����I�Ȋw�K�̎��Ԃ̃��X�g  */
	private List<Data31909000_TotalactEntity> totalactEntityList;

	/** �s���̋L�^�̃��X�g  */
	private Map<String,List<Data31909000_ActViewpointEntity>> actViewpointEntityListMap;

	/** �O���ꊈ���̃��X�g */
	private List<Data31909000_ForeignlangactEntity> ForeignlangactEntityList;
	/** ���ʊ����̋L�^�̃��X�g  */
	private List<Data31909000_SpecialactEntity> specialactEntityList;

	/** �ʐM��(�w�Z����) */
	private List<Data31909000_SpecialactMemoEntity> specialactMemoEntityList;

	/** �����̃��X�g  */
	private List<Data31909000_MoralEntity> moralEntityList;

	/** �o���̋L�^��Map */
	Map<String, List<Data31909000_AttendEntity>> attendEntityListMap;

	/** ����y�[�W�\�� */
	private boolean output_cover;

	/** ����y�[�W���Ȃ̊w�K */
	private boolean output_page1;

	/** ����y�[�W���̑����� */
	private boolean output_page2;

	/** ����y�[�W�C���� */
	private boolean output_deed;

	/** �]����\�� */
	private boolean output_no_eval;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public byte[] getEducationalgoalImage() {
		return educationalgoalImage;
	}

	public void setEducationalgoalImage(byte[] educationalgoalImage) {
		this.educationalgoalImage = educationalgoalImage;
	}

	public byte[] getPrincipalStampImage() {
		return principalStampImage;
	}

	public void setPrincipalStampImage(byte[] principalStampImage) {
		this.principalStampImage = principalStampImage;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getPrincipalNameDeed() {
		return principalNameDeed;
	}

	public void setPrincipalNameDeed(String principalNameDeed) {
		this.principalNameDeed = principalNameDeed;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolNameS() {
		return schoolNameS;
	}

	public void setSchoolNameS(String schoolNameS) {
		this.schoolNameS = schoolNameS;
	}

	public List<Data31909000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	public void setDataFormBeanList(List<Data31909000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	public CodeEntity getItemViewpointHeader() {
		return itemViewpointHeader;
	}

	public void setItemViewpointHeader(CodeEntity itemViewpointHeader) {
		this.itemViewpointHeader = itemViewpointHeader;
	}

	public Map<String, List<List<Data31909000_ItemViewpointEntity>>> getItemViewpointListListMap() {
		return itemViewpointListListMap;
	}

	public void setItemViewpointListListMap(
			Map<String, List<List<Data31909000_ItemViewpointEntity>>> itemViewpointListListMap) {
		this.itemViewpointListListMap = itemViewpointListListMap;
	}

	public List<Data31909000_TotalactEntity> getTotalactEntityList() {
		return totalactEntityList;
	}

	public void setTotalactEntityList(List<Data31909000_TotalactEntity> totalactEntityList) {
		this.totalactEntityList = totalactEntityList;
	}

	public Map<String, List<Data31909000_ActViewpointEntity>> getActViewpointEntityListMap() {
		return actViewpointEntityListMap;
	}

	public void setActViewpointEntityListMap(Map<String, List<Data31909000_ActViewpointEntity>> actViewpointEntityListMap) {
		this.actViewpointEntityListMap = actViewpointEntityListMap;
	}

	public List<Data31909000_ForeignlangactEntity> getForeignlangactEntityList() {
		return ForeignlangactEntityList;
	}

	public void setForeignlangactEntityList(List<Data31909000_ForeignlangactEntity> foreignlangactEntityList) {
		ForeignlangactEntityList = foreignlangactEntityList;
	}

	public List<Data31909000_SpecialactEntity> getSpecialactEntityList() {
		return specialactEntityList;
	}

	public void setSpecialactEntityList(List<Data31909000_SpecialactEntity> specialactEntityList) {
		this.specialactEntityList = specialactEntityList;
	}

	public List<Data31909000_SpecialactMemoEntity> getSpecialactMemoEntityList() {
		return specialactMemoEntityList;
	}

	public void setSpecialactMemoEntityList(List<Data31909000_SpecialactMemoEntity> specialactMemoEntityList) {
		this.specialactMemoEntityList = specialactMemoEntityList;
	}

	public Map<String, List<Data31909000_AttendEntity>> getAttendEntityListMap() {
		return attendEntityListMap;
	}

	public void setAttendEntityListMap(Map<String, List<Data31909000_AttendEntity>> attendEntityListMap) {
		this.attendEntityListMap = attendEntityListMap;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_page1() {
		return output_page1;
	}

	public void setOutput_page1(boolean output_page1) {
		this.output_page1 = output_page1;
	}

	public boolean isOutput_page2() {
		return output_page2;
	}

	public void setOutput_page2(boolean output_page2) {
		this.output_page2 = output_page2;
	}

	public boolean isOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(boolean output_deed) {
		this.output_deed = output_deed;
	}

	public boolean isOutput_no_eval() {
		return output_no_eval;
	}

	public void setOutput_no_eval(boolean output_no_eval) {
		this.output_no_eval = output_no_eval;
	}

	/**
	 * @return moralEntityList
	 */
	public List<Data31909000_MoralEntity> getMoralEntityList() {
		return moralEntityList;
	}

	/**
	 * @param moralEntityList �Z�b�g���� moralEntityList
	 */
	public void setMoralEntityList(List<Data31909000_MoralEntity> moralEntityList) {
		this.moralEntityList = moralEntityList;
	}


}
