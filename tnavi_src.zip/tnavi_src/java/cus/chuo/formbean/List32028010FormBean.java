package jp.co.systemd.tnavi.cus.chuo.formbean;

import java.util.Map;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;
import jp.co.systemd.tnavi.cus.chuo.constants.CusChuoConstantsUseable;

/**
 * <PRE>
 * ���N�̋L�^���(�����s) ���l�o�^ FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.03.05 BY AIVICK<BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List32028010FormBean implements CommonConstantsUseable, CusChuoConstantsUseable {

	/** �����l */
	public final static String DEFALUT_VALUE = "";

	/**
	 * ���������t���O
	 */
	private boolean completeFlg;
	/**
	 * ���l�f�[�^map
	 */
	private Map<String, String> memoMap;

	/**
	 * @return completeFlg
	 */
	public boolean isCompleteFlg() {
		return completeFlg;
	}
	/**
	 * @param completeFlg �Z�b�g���� completeFlg
	 */
	public void setCompleteFlg(boolean completeFlg) {
		this.completeFlg = completeFlg;
	}
	/**
	 * @return memoMap
	 */
	public Map<String, String> getMemoMap() {
		return memoMap;
	}
	/**
	 * @param memoMap �Z�b�g���� memoMap
	 */
	public void setMemoMap(Map<String, String> memoMap) {
		this.memoMap = memoMap;
	}

}
