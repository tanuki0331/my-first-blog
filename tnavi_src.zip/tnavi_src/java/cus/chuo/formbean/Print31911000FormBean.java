package jp.co.systemd.tnavi.cus.chuo.formbean;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_CommentEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_EvalEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_HomeroomHistoryEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_MstScorptactviewpointtitleEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_OtherActivityEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_ScoreEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_SpecialActivityEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_AttendEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31911000_TotalactEntity;

/**
 * <PRE>
 * ���ђʒm�\���(�����s���w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31911000FormBean {
	
	public final static String DEFALUT_VALUE = "";

	/** �����R�[�h */
	private String userCode = DEFALUT_VALUE;
	
	/** �N�x */
	private String nendo = DEFALUT_VALUE;
	
	/** �I���w���� */
	private String termName = DEFALUT_VALUE;
	
	/** �I���w�� */
	private String term = DEFALUT_VALUE;
	
	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;
	
	/** �\���\���t���O */
	private boolean output_cover;

	/** ����y�[�W�P�\���t���O */
	private boolean output_page1;

	/** ����y�[�W�Q�\���t���O */
	private boolean output_page2;

	/** �ؖ����\���t���O */
	private boolean output_deed;

	/** �Z�̓C���[�W */
	byte[] schoolStampImage;

	/** �Z�̓C���[�W */
	byte[] schoolStampImage2;

	/** �Z����C���[�W */
	byte[] schoolStampImage3;
	
	/** �Z������ */
	private String principalName = DEFALUT_VALUE;
	
	/** �S�C���� */
	private String teacherName = DEFALUT_VALUE;
	
	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;
	
	/** �w�Z��(����) */
	private String schoolNameS = DEFALUT_VALUE;
	
	/** �w�Z��(����) */
	private String schoolNameO = DEFALUT_VALUE;

	/** ���k���̐��k��� */
	private List<Data31911000FormBean> dataFormBeanList;
	
	/** �z�[�����[������ */
	private Map<String, Map<String, Data31911000_HomeroomHistoryEntity>> homeroomHistoryEntityMapMap;

	/** ���ȕʊϓ_���i�[����Map */
	private LinkedHashMap<String, LinkedList<Data31911000_ItemViewpointEntity> > itemViewpointEntityListMap ;
	
	/** �]���E�]��̌��ʃ��X�g */
	private Map<String, Map<String, Data31911000_ScoreEntity>> scoreEntityMapMap;

	/** �]��̃��X�g */
	private Map<String, Map<String, Data31911000_EvalEntity>> evalEntityMapMap; 

	/** �s���̋L�^�̃��X�g  */
	private List<Data31911000_MstScorptactviewpointtitleEntity> mst_ScorptactviewpointtitleEntityList ;
	
	/** �s���̋L�^ �]���̌��ʃ��X�g  */
	private Map<String, Map<String, Data31911000_ActViewpointEntity>> actViewpointEntityMapMap;

	/** �o���̋L�^�̃��X�g */
	private Map<String, Map<String, Data31911000_AttendEntity>> attendEntityMapMap;
	
	/** �����I�Ȋw�K�̎��Ԃ̃��X�g  */
	private List<Data31911000_TotalactEntity> totalactEntityList;

	/** ���ʊ����̋L�^���X�g */
	private Map<String, Map<String, Data31911000_SpecialActivityEntity>> specialActivityEntityMapMap;

	/** �������̋L�^ */
	private Map<String, Map<String, Data31911000_OtherActivityEntity>> otherActivityEntityMapMap ; 

	/** ������(3�w��:�w�Z����) */
	private List<Data31911000_CommentEntity> commentEntityList;

	
	
	
	
	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_page1() {
		return output_page1;
	}

	public void setOutput_page1(boolean output_page1) {
		this.output_page1 = output_page1;
	}

	public boolean isOutput_page2() {
		return output_page2;
	}

	public void setOutput_page2(boolean output_page2) {
		this.output_page2 = output_page2;
	}

	public boolean isOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(boolean output_deed) {
		this.output_deed = output_deed;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public byte[] getSchoolStampImage2() {
		return schoolStampImage2;
	}

	public void setSchoolStampImage2(byte[] schoolStampImage2) {
		this.schoolStampImage2 = schoolStampImage2;
	}

	public byte[] getSchoolStampImage3() {
		return schoolStampImage3;
	}

	public void setSchoolStampImage3(byte[] schoolStampImage3) {
		this.schoolStampImage3 = schoolStampImage3;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolNameS() {
		return schoolNameS;
	}

	public void setSchoolNameS(String schoolNameS) {
		this.schoolNameS = schoolNameS;
	}

	public String getSchoolNameO() {
		return schoolNameO;
	}

	public void setSchoolNameO(String schoolNameO) {
		this.schoolNameO = schoolNameO;
	}

	public List<Data31911000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	public void setDataFormBeanList(List<Data31911000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	public Map<String, Map<String, Data31911000_HomeroomHistoryEntity>> getHomeroomHistoryEntityMapMap() {
		return homeroomHistoryEntityMapMap;
	}

	public void setHomeroomHistoryEntityMapMap(
			Map<String, Map<String, Data31911000_HomeroomHistoryEntity>> homeroomHistoryEntityMapMap) {
		this.homeroomHistoryEntityMapMap = homeroomHistoryEntityMapMap;
	}
	
	public LinkedHashMap<String, LinkedList<Data31911000_ItemViewpointEntity>> getItemViewpointEntityListMap() {
		return itemViewpointEntityListMap;
	}

	public void setItemViewpointEntityListMap(
			LinkedHashMap<String, LinkedList<Data31911000_ItemViewpointEntity>> itemViewpointEntityListMap) {
		this.itemViewpointEntityListMap = itemViewpointEntityListMap;
	}

	public Map<String, Map<String, Data31911000_ScoreEntity>> getScoreEntityMapMap() {
		return scoreEntityMapMap;
	}

	public void setScoreEntityMapMap(
			Map<String, Map<String, Data31911000_ScoreEntity>> scoreEntityMapMap) {
		this.scoreEntityMapMap = scoreEntityMapMap;
	}

	public Map<String, Map<String, Data31911000_EvalEntity>> getEvalEntityMapMap() {
		return evalEntityMapMap;
	}

	public void setEvalEntityMapMap(
			Map<String, Map<String, Data31911000_EvalEntity>> evalEntityMapMap) {
		this.evalEntityMapMap = evalEntityMapMap;
	}

	
	public List<Data31911000_MstScorptactviewpointtitleEntity> getMst_ScorptactviewpointtitleEntityList() {
		return mst_ScorptactviewpointtitleEntityList;
	}

	public void setMst_ScorptactviewpointtitleEntityList(
			List<Data31911000_MstScorptactviewpointtitleEntity> mst_ScorptactviewpointtitleEntityList) {
		this.mst_ScorptactviewpointtitleEntityList = mst_ScorptactviewpointtitleEntityList;
	}

	public Map<String, Map<String, Data31911000_ActViewpointEntity>> getActViewpointEntityMapMap() {
		return actViewpointEntityMapMap;
	}

	public void setActViewpointEntityMapMap(
			Map<String, Map<String, Data31911000_ActViewpointEntity>> actViewpointEntityMapMap) {
		this.actViewpointEntityMapMap = actViewpointEntityMapMap;
	}

	public Map<String, Map<String, Data31911000_AttendEntity>> getAttendEntityMapMap() {
		return attendEntityMapMap;
	}

	public void setAttendEntityMapMap(
			Map<String, Map<String, Data31911000_AttendEntity>> attendEntityMapMap) {
		this.attendEntityMapMap = attendEntityMapMap;
	}


	public List<Data31911000_TotalactEntity> getTotalactEntityList() {
		return totalactEntityList;
	}

	public void setTotalactEntityList(
			List<Data31911000_TotalactEntity> totalactEntityList) {
		this.totalactEntityList = totalactEntityList;
	}

	public Map<String, Map<String, Data31911000_SpecialActivityEntity>> getSpecialActivityEntityMapMap() {
		return specialActivityEntityMapMap;
	}

	public void setSpecialActivityEntityMapMap(
			Map<String, Map<String, Data31911000_SpecialActivityEntity>> specialActivityEntityMapMap) {
		this.specialActivityEntityMapMap = specialActivityEntityMapMap;
	}

	public Map<String, Map<String, Data31911000_OtherActivityEntity>> getOtherActivityEntityMapMap() {
		return otherActivityEntityMapMap;
	}

	public void setOtherActivityEntityMapMap(
			Map<String, Map<String, Data31911000_OtherActivityEntity>> otherActivityEntityMapMap) {
		this.otherActivityEntityMapMap = otherActivityEntityMapMap;
	}

	public List<Data31911000_CommentEntity> getCommentEntityList() {
		return commentEntityList;
	}

	public void setCommentEntityList(
			List<Data31911000_CommentEntity> commentEntityList) {
		this.commentEntityList = commentEntityList;
	}


	
}
