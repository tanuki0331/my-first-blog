package jp.co.systemd.tnavi.cus.chuo.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.chuo.db.entity.List32028000_01Entity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.List32028000_02Entity;

/**
 * <PRE>
 * ���N�̋L�^���(�����s) �ꗗ FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.03.05 BY AIVICK<BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List32028000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** ���샂�[�h�萔(0:�����J�ڎ� 1:�����{�^�������� 2:�����[�h 3:�i���l�o�^��ʁj�߂�{�^��������) */
	public static final String MODE_FIRST ="0";
	public static final String MODE_FIND ="1";
	public static final String MODE_RELOAD ="2";
	public static final String MODE_BACK ="3";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String grade = DEFALUT_VALUE;

	/** �g **/
	private String hmrClass = DEFALUT_VALUE;

	/** �o�͊w�� **/
	private String semCode = DEFALUT_VALUE;

	/** �w������ **/
	private String semName = DEFALUT_VALUE;

	/** ����y�[�W �\�� **/
	private boolean checkCover = true;

	/** ����y�[�W �f�f�̋L�^ **/
	private boolean checkRecord = true;

	/** ����y�[�W �g���E�̏d�̐��� **/
	private boolean checkTransition = true;

	/** ����y�[�W ���\�� **/
	private boolean checkDeed = true;

	/** ���ڃO���t�o�� **/
	private boolean isGraphOutput = true;

	/** ���k�ꗗ **/
	private List<List32028000_01Entity> stuEntList;

	/** �w�����X�g **/
	private List<SimpleTagFormBean> semesterList;

	/** �o�͓��e(�g���E�̏d�E����) **/
	private List<List32028000_02Entity> heightWeightEyeList = new ArrayList<List32028000_02Entity>();

	/** �o�͓��e(�얞�x) **/
	private List<List32028000_02Entity> bmiList = new ArrayList<List32028000_02Entity>();

	/** �o�͓��e(���ڃO���t�g��) **/
	private List<List32028000_02Entity> heightGraphList = new ArrayList<List32028000_02Entity>();

	/** �o�͓��e(���ڃO���t�̏d) **/
	private List<List32028000_02Entity> weightGraphList = new ArrayList<List32028000_02Entity>();

	/** ���k�ꗗ�E�o�͐ݒ�ꗗ�̕\���L�� **/
	private boolean isDisplayList = false;

	/** �J�ڃ��[�h(�����\�����E�������s���E�߂莞) **/
	private String mode;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getHmrClass() {
		return hmrClass;
	}

	public void setHmrClass(String hmrClass) {
		this.hmrClass = hmrClass;
	}

	public String getSemCode() {
		return semCode;
	}

	public void setSemCode(String semCode) {
		this.semCode = semCode;
	}

	public String getSemName() {
		return semName;
	}

	public void setSemName(String semName) {
		this.semName = semName;
	}

	public boolean isCheckCover() {
		return checkCover;
	}

	public void setCheckCover(boolean checkCover) {
		this.checkCover = checkCover;
	}

	public boolean isCheckRecord() {
		return checkRecord;
	}

	public void setCheckRecord(boolean checkRecord) {
		this.checkRecord = checkRecord;
	}

	public boolean isCheckTransition() {
		return checkTransition;
	}

	public void setCheckTransition(boolean checkTransition) {
		this.checkTransition = checkTransition;
	}

	public boolean isCheckDeed() {
		return checkDeed;
	}

	public void setCheckDeed(boolean checkDeed) {
		this.checkDeed = checkDeed;
	}

	public boolean isGraphOutput() {
		return isGraphOutput;
	}

	public void setGraphOutput(boolean isGraphOutput) {
		this.isGraphOutput = isGraphOutput;
	}

	public List<List32028000_01Entity> getStuEntList() {
		return stuEntList;
	}

	public void setStuEntList(List<List32028000_01Entity> stuEntList) {
		this.stuEntList = stuEntList;
	}

	public List<SimpleTagFormBean> getSemesterList() {
		return semesterList;
	}

	public void setSemesterList(List<SimpleTagFormBean> semesterList) {
		this.semesterList = semesterList;
	}

	public List<List32028000_02Entity> getHeightWeightEyeList() {
		return heightWeightEyeList;
	}

	public void setHeightWeightEyeList(
			List<List32028000_02Entity> heightWeightEyeList) {
		this.heightWeightEyeList = heightWeightEyeList;
	}

	public List<List32028000_02Entity> getBmiList() {
		return bmiList;
	}

	public void setBmiList(List<List32028000_02Entity> bmiList) {
		this.bmiList = bmiList;
	}

	public List<List32028000_02Entity> getHeightGraphList() {
		return heightGraphList;
	}

	public void setHeightGraphList(List<List32028000_02Entity> heightGraphList) {
		this.heightGraphList = heightGraphList;
	}

	public List<List32028000_02Entity> getWeightGraphList() {
		return weightGraphList;
	}

	public void setWeightGraphList(List<List32028000_02Entity> weightGraphList) {
		this.weightGraphList = weightGraphList;
	}

	public boolean isDisplayList() {
		return isDisplayList;
	}

	public void setDisplayList(boolean isDisplayList) {
		this.isDisplayList = isDisplayList;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

}