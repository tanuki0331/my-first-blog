package jp.co.systemd.tnavi.cus.chuo.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028010Entity;
import jp.co.systemd.tnavi.cus.chuo.db.service.List32028010Service;
import jp.co.systemd.tnavi.cus.chuo.db.service.Regist32028010Service;
import jp.co.systemd.tnavi.cus.chuo.formbean.List32028010FormBean;

/**
 * <PRE>
 * ���N�̋L�^���(�����s) ���l�o�^ �X�V Action.
 * </PRE>
 *
 * <B>Create</B> 2018.03.05 BY AIVICK<BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Regist32028010Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist32028010Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("�y��ʁz���N�̋L�^���(�����s) ���l�o�^ �X�V START");

		String user = sessionBean.getUserCode();

		// �c�a�����i�o�^�܂��͍X�V�܂��͍폜�j
		Regist32028010Service service = new Regist32028010Service();
		service.setParameter(user, sessionBean.getStaffId(), getMemoList(request));
		service.execute();

		// �Č����������e��\��
		List32028010Service listService = new List32028010Service();
		listService.setUser(user);
		listService.execute();

		// FormBean����
		List32028010FormBean formBean = listService.getListFormBean();
		formBean.setCompleteFlg(true);

		// Request��FormBean���Z�b�g����
		request.setAttribute("FORM_BEAN", formBean);

		log.info("�y��ʁz���N�̋L�^���(�����s) ���l�o�^ �X�V END");

		return null;
	}

	private List<Data32028010Entity> getMemoList(HttpServletRequest request) {
		List<Data32028010Entity> entityList = new ArrayList<Data32028010Entity>();

		String[] memoKeys = request.getParameterValues("memo_key");

		for (String memoKey : memoKeys) {
			Data32028010Entity entity = new Data32028010Entity();
			entity.setCrt_key1(memoKey);
			entity.setCrt_value1(request.getParameter("memo_" + memoKey));
			entityList.add(entity);
		}

		return entityList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return false;
	}
}
