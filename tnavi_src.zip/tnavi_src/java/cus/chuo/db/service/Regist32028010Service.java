package jp.co.systemd.tnavi.cus.chuo.db.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.db.QueryUpdateManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028010Entity;

/**
 * <PRE>
 * ���N�̋L�^���(�����s) ���l�o�^ �X�V Service.
 * </PRE>
 *
 * <B>Create</B> 2018.03.05 BY AIVICK<BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Regist32028010Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist32028010Service.class);

	/** �@�\ID */
	private static final String KINOID = "32028000";

	/** ���sSQL */
	private static final String EXEC_SQL_DEL = "cus/chuo/delete32028010.sql";	 // �폜
	private static final String EXEC_SQL_INS = "cus/chuo/insert32028010.sql";	 // �o�^


	/** �����R�[�h */
	private String user;
	/** ���[�U�[ID */
	private String staffId;
	/** ���l���list */
	private List<Data32028010Entity> entityList;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		QueryUpdateManager qmDel = null;
		QueryUpdateBatchManager qmIns = null;

		try {
			String systemDate = DateUtility.getSystemDate();

			// �폜
			Object[] paramDel = new Object[]{user, KINOID};
			qmDel = new QueryUpdateManager(EXEC_SQL_DEL, paramDel);
			this.executeUpdate(qmDel);

			// �o�^����
			qmIns = new QueryUpdateBatchManager(EXEC_SQL_INS);
			this.initialBatchUpdate(qmIns);

			for (Data32028010Entity entity : entityList) {
				Object[] paramIns = new Object[]{
					    user
					  , KINOID
					  , entity.getCrt_key1()
					  , entity.getCrt_value1()
					  , systemDate
					  , staffId
				};

				this.executeBatchUpdate(qmIns, paramIns);
			}

			// �R�~�b�g
			this.commit();

		} catch (Exception e) {
			// ���[���o�b�N
			super.rollback();
			log.error("���N�̋L�^���(�����s) ���l�o�^ DB�X�V�����Ɏ��s���܂����B");
			log.error(e);
			throw new TnaviDbException(e);
		}
	}

	/**
	 * �p�����[�^�ݒ�
	 *
	 * @param user �����R�[�h
	 * @param staffId ���[�U�[ID
	 * @param entityList ���l���list
	 */
	public void setParameter(String user, String staffId, List<Data32028010Entity> entityList) {
		this.user = user;
		this.staffId = staffId;
		this.entityList = entityList;
	}

}
