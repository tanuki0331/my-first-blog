package jp.co.systemd.tnavi.cus.chuo.db.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.chuo.formbean.List31911000FormBean;
import jp.co.systemd.tnavi.sco.db.entity.ScoCommonStuListEntity;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * ���ђʒm�\���(�����s ���w�Z) �ꗗ Service.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List31911000Service  extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(List31911000Service.class);
	
	/** ���sSQL */
	private static final String EXEC_SQL  = "cus/chuo/list31911000.sql";					// ���k�ʒʒm�\
	private static final String EXEC_SQL2 = "cus/chuo/getDataPrint31911000_termCheck.sql";// �o�͊��Ԉꗗ
	
	/** ����SessionBean */
	private SystemInfoBean sessionBean;

	/** �ꗗFormBean. */
	private List31911000FormBean listFormBean;

	/** �z�[�����[�����FormBean. */
	private HroomKeyFormBean hroomKeyFormBean;

	
	/**
	 * <pre>
	 * Request�̓��e��FormBean���쐬����
	 * ���̏�����Action.doAction���\�b�h���ŌĂяo�����
	 * </pre>
	 *
	 * @param request
	 *            HTTP���N�G�X�g
	 * @param sessionBean
	 *            �V�X�e�����Bean(�Z�b�V�������)
	 * @throws TnaviDbException
	 *             DB��O�������ɃX���[�����
	 */
	public void execute(HttpServletRequest request, SystemInfoBean sessionBean)
			throws TnaviDbException {
		// ����Session��ݒ�
		this.sessionBean = sessionBean;

		// �z�[�����[�����FormBean��ݒ�
		hroomKeyFormBean = sessionBean.getSelectHroomKey();

		// �N�G�������s����
		super.execute();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {
		
		try {
			// ------------------------------------------------------------------------------------------
			// �ꗗFormBean�̍쐬
			// ------------------------------------------------------------------------------------------
			listFormBean = new List31911000FormBean();

			// ------------------------------------------------------------------------------------------
			// �z�[�����[����� �擾
			// ------------------------------------------------------------------------------------------
			// -- �N�x
			String nendo = sessionBean.getSystemNendoSeireki();
			// -- �\���p�N�x
			String dispYear = sessionBean.getSystemNendo();
			// -- �w�N
			String grade = hroomKeyFormBean.getGlade();
			// -- �g
			String hmrClass = hroomKeyFormBean.getHmrclass();
			// -- �N���X��
			String hmrName  = hroomKeyFormBean.getHmrname();
			// �����R�[�h
			String user = sessionBean.getUserCode();
			// �N���X�ԍ�
			String clsno = hroomKeyFormBean.getClsno();


			// ------------------------------------------------------------------------------------------
			// ���k��� �擾
			// ------------------------------------------------------------------------------------------
			// �p�����[�^�̐���
			Object[] param1 = {user, nendo, clsno};

			// QueryManager�̍쐬
			QueryManager queryManager1 = new QueryManager(EXEC_SQL, param1, ScoCommonStuListEntity.class);

			// �N�G���̎��s(List�`���Ńf�[�^�i�[)
			List<ScoCommonStuListEntity> entityList = (List<ScoCommonStuListEntity>) this.executeQuery(queryManager1);

			// ------------------------------------------------------------------------------------------
			// attend start/end date ���擾
			// ------------------------------------------------------------------------------------------
			// �p�����[�^�̐���
			Object[] param2 = {user, nendo };
			// QueryManager�̍쐬
			QueryManager queryManager2 = new QueryManager(EXEC_SQL2, param2, CmlguideoutputtermEntity.class);

			// �N�G���̎��s(List�`���Ńf�[�^�i�[)
			List<CmlguideoutputtermEntity> termList = (List<CmlguideoutputtermEntity>) this.executeQuery(queryManager2);
			int termList_len = termList.size();
			
			String termCode_seq        = "";
			String termName_seq        = "";
			String termAttendStart_seq = "";
			String termAttendEnd_seq   = "";
			
			int i=0;
			for ( CmlguideoutputtermEntity termListEntity:termList ){
				
				String	tempTermAttendStart = termListEntity.getGopt_attend_start();
				if( tempTermAttendStart == null )  tempTermAttendStart = "";
				
				String	tempTermAttendEnd   = termListEntity.getGopt_attend_end();
				if( tempTermAttendEnd == null )  tempTermAttendEnd = "";

				String	tempTermName   = termListEntity.getGopt_name();
				if( tempTermName == null )  tempTermName = "";
				
				if(i==0){
					termCode_seq        = "'"+termListEntity.getGopt_goptcode()+"'";
					termName_seq        = "'"+tempTermName+"'";
					termAttendStart_seq = "'"+tempTermAttendStart+"'";
					termAttendEnd_seq   = "'"+tempTermAttendEnd+"'";
				}else{
					termCode_seq        = termCode_seq       + ',' + "'"+termListEntity.getGopt_goptcode()+"'";
					termName_seq        = termName_seq       + ',' + "'"+tempTermName+"'";
					termAttendStart_seq = termAttendStart_seq+ ',' + "'"+tempTermAttendStart+"'";
					termAttendEnd_seq   = termAttendEnd_seq  + ',' + "'"+tempTermAttendEnd+"'";
				}
				i++;
			}
			listFormBean.setTermCode_seq(termCode_seq);
			listFormBean.setTermName_seq(termName_seq);
			listFormBean.setTermAttendStart_seq(termAttendStart_seq);			
			listFormBean.setTermAttendEnd_seq(termAttendEnd_seq);
			
			// ------------------------------------------------------------------------------------------
			// �擾�����f�[�^��FormBean�֐ݒ�
			// ------------------------------------------------------------------------------------------
			// -- �N�x
			listFormBean.setNendo(nendo);
			// -- �\���p�N�x
			listFormBean.setNendoStr(dispYear + "�N�x");
			// -- �w�N
			listFormBean.setHmrGlade(grade);
			listFormBean.setHmrGladeStr(grade + "�N");
			// -- �g
			listFormBean.setHmrClass(hmrClass);
			listFormBean.setHmrClassStr(hmrClass + "�g");

			// -- �N���X��
			listFormBean.setHmrName(hmrName);

			// -- ���k�ʒʒm�\���
			listFormBean.setEntityList(entityList);
			// -- �ꗗ����(���k)����
			listFormBean.setCntListDetail(entityList.size());

		} catch (Exception e) {
			log.error("�ʒm�\����(�ʒm�\) DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
		
	}

	public List31911000FormBean getListFormBean() {
		return listFormBean;
	}

}
