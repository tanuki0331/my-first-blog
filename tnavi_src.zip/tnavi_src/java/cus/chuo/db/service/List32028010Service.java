package jp.co.systemd.tnavi.cus.chuo.db.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data32028010Entity;
import jp.co.systemd.tnavi.cus.chuo.formbean.List32028010FormBean;

/**
 * <PRE>
 * ���N�̋L�^���(�����s) ���l�o�^ �ꗗ Service.
 * </PRE>
 *
 * <B>Create</B> 2018.03.05 BY AIVICK<BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List32028010Service extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(List32028010Service.class);

	/** �@�\ID */
	private static final String KINOID = "32028000";

	/** ���sSQL */
	private static final String EXEC_SQL = "cus/chuo/list32028010.sql";	 // ���l���擾

	/** �ꗗFormBean. */
	private List32028010FormBean listFormBean;
	/** �����R�[�h */
	private String user = "";

	/**
	 * <pre>
	 * Request�̓��e��FormBean���쐬����
	 * ���̏�����Action.doAction���\�b�h���ŌĂяo�����
	 * </pre>
	 *
	 * @throws TnaviDbException
	 *             DB��O�������ɃX���[�����
	 */
	public void execute() throws TnaviDbException {
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {

		try {
			// ------------------------------------------------------------------------------------------
			// �ꗗFormBean�̍쐬
			// ------------------------------------------------------------------------------------------
			listFormBean = new List32028010FormBean();

			// ------------------------------------------------------------------------------------------
			// ���l���̎擾
			// ------------------------------------------------------------------------------------------
			Object[] param = new Object[] {user, KINOID};
			QueryManager qm = new QueryManager(EXEC_SQL, param, Data32028010Entity.class);
			List<Data32028010Entity> entityList = (List<Data32028010Entity>) this.executeQuery(qm);

			// ���l���map�ɐݒ�
			Map<String, String> memoMap = new HashMap<String, String>();
			for (Data32028010Entity entity : entityList) {
				memoMap.put(entity.getCrt_key1(), entity.getCrt_value1());
			}

			// ------------------------------------------------------------------------------------------
			// �擾�����f�[�^��FormBean�֐ݒ�
			// ------------------------------------------------------------------------------------------
			// ���l���map
			listFormBean.setMemoMap(memoMap);

		} catch (Exception e) {
			log.error("���N�̋L�^���(�����s) ���l�o�^ DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
	}

	/**
	 * @return user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user �Z�b�g���� user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	public List32028010FormBean getListFormBean() {
		return listFormBean;
	}

}
