package jp.co.systemd.tnavi.cus.chuo.db.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CodeEntity;
import jp.co.systemd.tnavi.common.db.entity.SchoolStampEntity;
import jp.co.systemd.tnavi.common.db.entity.StaffEntity;
import jp.co.systemd.tnavi.common.db.entity.UserHistoryEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_AttendEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_ForeignlangactEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_MoralEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_SpecialactEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_SpecialactMemoEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_StudentInfoEntity;
import jp.co.systemd.tnavi.cus.chuo.db.entity.Data31909000_TotalactEntity;
import jp.co.systemd.tnavi.cus.chuo.formbean.Data31909000FormBean;
import jp.co.systemd.tnavi.cus.chuo.formbean.Print31909000FormBean;

/**
 * <PRE>
 * ���ђʒm�\���(�����s���w�Z) ��� Service.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31909000Service  extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(Print31909000Service.class);

	/** ���sSQL */
	private static final String EXEC_SQL_SCHOOLSTAMP = "sys/getSchoolStamp.sql";									// �Z��
	private static final String EXEC_SQL_PRINCIPAL_NAME = "cus/chuo/getDataPrint31909000_principalName.sql"; 		// �Z������
	private static final String EXEC_SQL_PRINCIPAL_NAME_DEED = "cus/chuo/getDataPrint31909000_principalNameDeed.sql"; 	// �Z������(�C����)
	private static final String EXEC_SQL_TEACHER_NAME = "cus/chuo/getDataPrint31909000_teacherName.sql";			// �S�C����
	private static final String EXEC_SQL_SCHOOLNAME = "common/getUserhistoryByUserAndYear.sql";						// �w�Z��
	private static final String EXEC_SQL_STUDENTINFO = "cus/chuo/getDataPrint31909000_studentinfo.sql";				// ���k���
	private static final String EXEC_SQL_FOREIGNLANGACT = "cus/chuo/getDataPrint31909000_foreignlangact.sql";		// �O���ꊈ��
	private static final String EXEC_SQL_ITEMVIEWPOINT_HEADER = "common/getCodeByPK.sql";							// �w�K�̋L�^�@���ȁE�ϓ_���w�b�_
	private static final String EXEC_SQL_ITEMVIEWPOINT = "cus/chuo/getDataPrint31909000_itemViewpoint.sql";			// �w�K�̋L�^�@���ȁE�ϓ_���
	private static final String EXEC_SQL_ACT_VIEWPOINT = "cus/chuo/getDataPrint31909000_actViewpoint.sql";			// �����̂悤��
	private static final String EXEC_SQL_TOTALACT = "cus/chuo/getDataPrint31909000_totalact.sql";					// �����I�Ȋw�K�̋L�^
	private static final String EXEC_SQL_SPECIALACT = "cus/chuo/getDataPrint31909000_specialact.sql";				// ���ʊ����̋L�^
	private static final String EXEC_SQL_SPECIALACTMEMO = "cus/chuo/getDataPrint31909000_specialactMemo.sql";		// ����
	private static final String EXEC_SQL_ATTEND = "cus/chuo/getDataPrint31909000_attend.sql";						// �o���̋L�^
	private static final String EXEC_SQL_MORAL = "cus/chuo/getDataPrint31909000_moral.sql";						// �����̋L�^

	/** ����SessionBean */
	private SystemInfoBean sessionBean;

	/** �z�[�����[�����FormBean. */
	private HroomKeyFormBean hroomKeyFormBean;

	/** �I�𐶓k�w�Дԍ��̔z�� */
	private String[] stucodeArray = null;

	/** �I�����ꂽ���� */
	private String term;

	/** �N�x�J�n�N���� */
	private String nendoStartDate;

	/** �N�x�C���N���� */
	private String nendoEndDate;


	/** ���FormBean�@*/
	private Print31909000FormBean printFormBean;

	/**
	 * <pre>
	 * Request�̓��e��FormBean���쐬����
	 * ���̏�����Action.doAction���\�b�h���ŌĂяo�����
	 * </pre>
	 *
	 * @param request
	 *            HTTP���N�G�X�g
	 * @param sessionBean
	 *            �V�X�e�����Bean(�Z�b�V�������)
	 * @throws TnaviDbException
	 *             DB��O�������ɃX���[�����
	 */
	public void execute(HttpServletRequest request, SystemInfoBean sessionBean)
			throws TnaviDbException {

		printFormBean = new Print31909000FormBean();

		// ����Session��ݒ�
		this.sessionBean = sessionBean;

		// �z�[�����[�����FormBean��ݒ�
		hroomKeyFormBean = sessionBean.getSelectHroomKey();

		// ���ԏ����擾�A�ݒ�
		term = request.getParameter("goptCode");
		printFormBean.setTerm(term);
		printFormBean.setTermName(request.getParameter("termName"));

		// �o�͓��t���擾�A�ݒ�
		printFormBean.setOutputDate(request.getParameter("year") +  request.getParameter("month") + request.getParameter("day"));

		// �I�𐶓k�w�Дԍ����擾
		if(request.getParameter("stucode") != null){
			stucodeArray  = request.getParameter("stucode").split(",");
		}

		//�]����\�����Z�b�g
		printFormBean.setOutput_no_eval("1".equals(request.getParameter("output_no_eval")));

		//����y�[�W���Z�b�g
		printFormBean.setOutput_cover("1".equals(request.getParameter("output_cover")));
		printFormBean.setOutput_page1("1".equals(request.getParameter("output_page1")));
		printFormBean.setOutput_page2("1".equals(request.getParameter("output_page2")));
		printFormBean.setOutput_deed("1".equals(request.getParameter("output_deed")));

		//�C�����t���擾�A�ݒ�
		printFormBean.setEndDate(request.getParameter("end_year") +  request.getParameter("end_month") + request.getParameter("end_day"));


		//�N�x�J�n�N�����A�C���N����
		nendoStartDate = sessionBean.getSystemNendoSeireki() + sessionBean.getSystemNendoStartDate();
		if(sessionBean.getSystemNendoStartDate().compareTo(sessionBean.getSystemNendoEndDate()) > 0){
			Integer endYear = Integer.parseInt(sessionBean.getSystemNendoSeireki()) + 1;
			nendoEndDate = endYear + sessionBean.getSystemNendoEndDate();
		}else{
			nendoEndDate = sessionBean.getSystemNendoSeireki() + sessionBean.getSystemNendoEndDate();
		}

		// �N�G�������s����
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		List<Data31909000FormBean> dataFormBeanList = new ArrayList<Data31909000FormBean>();

		try {
			// �����R�[�h
			String user = sessionBean.getUserCode();

			// �N�x
			String nendoSeireki = sessionBean.getSystemNendoSeireki();
			DateFormatUtility dfu = new DateFormatUtility(user);
			dfu.setZeroToSpace(true);
			printFormBean.setNendo(nendoSeireki);

			// �w�N
			String grade = hroomKeyFormBean.getGlade();

			// �N���X
			String clsno = hroomKeyFormBean.getClsno();

			// ------------------------------------------------------------------------------------------
			// �Z������
			// ------------------------------------------------------------------------------------------
			printFormBean.setPrincipalName(getPrincipalName(user));

			// ------------------------------------------------------------------------------------------
			// �Z������(�C����)
			// ------------------------------------------------------------------------------------------
			printFormBean.setPrincipalNameDeed(getPrincipalNameDeed(user));

			// ------------------------------------------------------------------------------------------
			// �w�Z��
			// ------------------------------------------------------------------------------------------
			UserHistoryEntity usehEntity = getSchoolName(user, nendoSeireki);
			if (usehEntity != null) {
				printFormBean.setSchoolName(usehEntity.getUseh_name());
				printFormBean.setSchoolNameS(usehEntity.getUseh_name_s());
			}

			// ------------------------------------------------------------------------------------------
			// �S�C����
			// ------------------------------------------------------------------------------------------
			printFormBean.setTeacherName(getTeacherName(user, nendoSeireki, grade, clsno));

			// ------------------------------------------------------------------------------------------
			// ���k�����擾
			// ------------------------------------------------------------------------------------------
			List<Data31909000_StudentInfoEntity> studentInfoEntityList = getStudentInfoEntityList(user, nendoSeireki, grade);

			for(String stucode : stucodeArray){
				// �ꗗFormBean�̍쐬
				Data31909000FormBean dataFormBean = new Data31909000FormBean();

				// �w�Дԍ�
				dataFormBean.setStuStucode(stucode);
				// �N�x
				dataFormBean.setNendo(nendoSeireki);
				// �w�N
				dataFormBean.setStuGrade(grade);
				// �g
				dataFormBean.setStuClass(hroomKeyFormBean.getHmrclass());

				for(Data31909000_StudentInfoEntity entity : studentInfoEntityList){
					if(stucode.equals(entity.getStu_stucode())){
						dataFormBean.setStuStuname(entity.getStu_name());
						dataFormBean.setStuNumber(entity.getCls_number());
						dataFormBean.setStuBirth(entity.getStu_birth());
						// ���ʎx���w���t���O
						dataFormBean.setSpSupportFlg(entity.getHmr_spsupport_flg());
						// �z�[�����[����
						dataFormBean.setHmrName(entity.getHmr_name());

						break;
					}
				}

				dataFormBeanList.add(dataFormBean);
			}

			printFormBean.setUserCode(user);
			printFormBean.setDataFormBeanList(dataFormBeanList);

			//�\�����o�͂���ꍇ
			if (printFormBean.isOutput_cover()) {
				// ------------------------------------------------------------------------------------------
				// �Z��
				// ------------------------------------------------------------------------------------------
				printFormBean.setSchoolStampImage(getSchoolStampImage(user, "01"));

				// ------------------------------------------------------------------------------------------
				// ����ڕW
				// ------------------------------------------------------------------------------------------
				printFormBean.setEducationalgoalImage(getSchoolStampImage(user, "02"));
			}


			//���Ȃ̊w�K���o�͂���ꍇ
			if (printFormBean.isOutput_page1()) {
				// ------------------------------------------------------------------------------------------
				// ���ȕʊϓ_�w�b�_�����̓��e���擾
				// ------------------------------------------------------------------------------------------
				printFormBean.setItemViewpointHeader(getItemViewpointHeader(user, grade));

				// ------------------------------------------------------------------------------------------
				// ���ȕʊϓ_�̓��e���擾
				// ------------------------------------------------------------------------------------------
				List<Data31909000_ItemViewpointEntity> itemViewpointList = getItemViewpointList(user, nendoSeireki, grade);

				//�擾���ʂ��w�Дԍ�����MAP�i�[
				Map<String, List<List<Data31909000_ItemViewpointEntity>>> itemViewpointListListMap = new HashMap<String, List<List<Data31909000_ItemViewpointEntity>>>();
				List<List<Data31909000_ItemViewpointEntity>> itemViewpointListList = new ArrayList<List<Data31909000_ItemViewpointEntity>>();
				List<Data31909000_ItemViewpointEntity> newItemViewpointList = new ArrayList<Data31909000_ItemViewpointEntity>();
				String itemOrder = "";
				String tmpStucode = "";

				for (Data31909000_ItemViewpointEntity entity :itemViewpointList) {
					if (itemOrder != null && !itemOrder.equals(entity.getItem_order())) {//���Ȃ��قȂ�^�C�~���O��ListList�i�[
						itemViewpointListList.add(newItemViewpointList);
						newItemViewpointList = new ArrayList<Data31909000_ItemViewpointEntity>();
					}
					if (tmpStucode != null && !tmpStucode.equals(entity.getCls_stucode())) {//�w�Дԍ����قȂ�^�C�~���O��MAP�i�[
						itemViewpointListListMap.put(tmpStucode, itemViewpointListList);
						itemViewpointListList = new ArrayList<List<Data31909000_ItemViewpointEntity>>();
					}
					tmpStucode = entity.getCls_stucode();
					itemOrder = entity.getItem_order();
					newItemViewpointList.add(entity);
				}
				if (tmpStucode != null) {
					itemViewpointListList.add(newItemViewpointList);
					itemViewpointListListMap.put(tmpStucode, itemViewpointListList);
				}
				printFormBean.setItemViewpointListListMap(itemViewpointListListMap);

			}

			if (printFormBean.isOutput_page2()) {

				// ------------------------------------------------------------------------------------------
				// �����̂悤��
				// ------------------------------------------------------------------------------------------
				List<Data31909000_ActViewpointEntity> actViewpointList = getActViewpointList(user, nendoSeireki, grade);

				//�擾���ʂ��w�Дԍ����A�ϓ_���Ƃ�MAP�i�[
				Map<String, List<Data31909000_ActViewpointEntity>> tmpActEntityListMap = new HashMap<String, List<Data31909000_ActViewpointEntity>>();
				String tmpStucode = null;
				List<Data31909000_ActViewpointEntity> tmpActEntityList = new ArrayList<Data31909000_ActViewpointEntity>();

				for (Data31909000_ActViewpointEntity entity :actViewpointList) {
					if (tmpStucode != null && !tmpStucode.equals(entity.getCls_stucode())) {//�w�Дԍ����قȂ�^�C�~���O��MAP�i�[
						tmpActEntityListMap.put(tmpStucode, tmpActEntityList);
						tmpActEntityList = new ArrayList<Data31909000_ActViewpointEntity>();
					}
					tmpStucode = entity.getCls_stucode();
					tmpActEntityList.add(entity);
				}
				if (tmpStucode != null) {
					tmpActEntityListMap.put(tmpStucode, tmpActEntityList);
				}

				printFormBean.setActViewpointEntityListMap(tmpActEntityListMap);

				// ------------------------------------------------------------------------------------------
				// �O���ꊈ��
				// ------------------------------------------------------------------------------------------
				List<Data31909000_ForeignlangactEntity> foreignlangactList = getForeignlangactList(user, nendoSeireki, grade);
				printFormBean.setForeignlangactEntityList(foreignlangactList);

				// ------------------------------------------------------------------------------------------
				// �����I�Ȋw�K�̎���
				// ------------------------------------------------------------------------------------------
				List<Data31909000_TotalactEntity> totalactList = getTotalactList(user, nendoSeireki, grade);
				printFormBean.setTotalactEntityList(totalactList);

				// ------------------------------------------------------------------------------------------
				// ���ʊ����̋L�^
				// ------------------------------------------------------------------------------------------
				List<Data31909000_SpecialactEntity> specialactList = getSpecialactList(user, nendoSeireki, grade);
				printFormBean.setSpecialactEntityList(specialactList);

				// ------------------------------------------------------------------------------------------
				// �ʐM��(�w�Z����)
				// ------------------------------------------------------------------------------------------
				List<Data31909000_SpecialactMemoEntity> specialactMemoEntityList = getSpecialActMemo(user, nendoSeireki, grade);
				printFormBean.setSpecialactMemoEntityList(specialactMemoEntityList);

				// ------------------------------------------------------------------------------------------
				// ����
				// ------------------------------------------------------------------------------------------
				List<Data31909000_MoralEntity> moralList = getMoralList(user, nendoSeireki, grade);
				printFormBean.setMoralEntityList(moralList);

				// ------------------------------------------------------------------------------------------
				// �o���̋L�^
				// ------------------------------------------------------------------------------------------
				Map<String, List<Data31909000_AttendEntity>> attendEntityListMap = getAttendListMap(user, nendoSeireki);
				printFormBean.setAttendEntityListMap(attendEntityListMap);
			}

			if(printFormBean.isOutput_deed()){
				// ------------------------------------------------------------------------------------------
				// ����ڕW
				// ------------------------------------------------------------------------------------------
				printFormBean.setPrincipalStampImage(getSchoolStampImage(user, "03"));
			}

		} catch (Exception e) {
			log.error("�ʒm�\����(�ʒm�\) DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}

	}

	/**
	 * ���ȕʊϓ_�̃w�b�_���擾����
	 * @param user �����R�[�h
	 * @param nendo �N�x
	 * @param grade �w�N
	 * @return ���ȕʊϓ_�̃��X�g
	 */
	private CodeEntity getItemViewpointHeader(String user, String grade) {
		Object[] param = {user, "696", grade};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ITEMVIEWPOINT_HEADER, param, CodeEntity.class);

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<CodeEntity> codeEntityList = (List<CodeEntity>) this.executeQuery(queryManager);

		if(codeEntityList.size() > 0){
			return codeEntityList.get(0);
		}else{
			return new CodeEntity();
		}

	}

	/**
	 * ���ȕʊϓ_�̃��X�g���擾����
	 * @param user �����R�[�h
	 * @param nendo �N�x
	 * @param grade �w�N
	 * @return ���ȕʊϓ_�̃��X�g
	 */
	private List<Data31909000_ItemViewpointEntity> getItemViewpointList(String user,
			String nendo, String grade) {
		Object[] param = {term, user, nendo, grade};
		QueryManager queryManager = new QueryManager(EXEC_SQL_ITEMVIEWPOINT, param, Data31909000_ItemViewpointEntity.class);
		queryManager.setPlusSQL("AND cls_stucode IN(" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY cls_stucode, COD59.cod_value2, sp_order, sp_code ");

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<Data31909000_ItemViewpointEntity> itemViewpointList = (List<Data31909000_ItemViewpointEntity>) this.executeQuery(queryManager);
		return itemViewpointList;
	}

	/**
	 * �w�Z�����擾����
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param clsno	�g�ԍ�
	 * @return�@�S�C����
	 */
	private UserHistoryEntity getSchoolName(String user, String nendo) {
		Object[] param = {user, nendo};
		QueryManager queryManager = new QueryManager(EXEC_SQL_SCHOOLNAME, param, UserHistoryEntity.class);
		@SuppressWarnings("unchecked")
		List<UserHistoryEntity> userHistoryEntityList = (List<UserHistoryEntity>) this.executeQuery(queryManager);

		if(userHistoryEntityList.size() > 0){
			return userHistoryEntityList.get(0);
		}

		return null;
	}

	/**
	 * �S�C�������擾����
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param clsno	�g�ԍ�
	 * @return�@�S�C����
	 */
	private String getTeacherName(String user, String nendo, String grade, String clsno) {
		Object[] param = { user, nendo, clsno, printFormBean.getOutputDate()};
		QueryManager queryManager = new QueryManager(EXEC_SQL_TEACHER_NAME, param, StaffEntity.class);

		@SuppressWarnings("unchecked")
		List<StaffEntity> stfList = (List<StaffEntity>)this.executeQuery(queryManager);

		StringBuilder sb = new StringBuilder();
		for(StaffEntity stf : stfList){
			if(sb.length() > 0){
				sb.append(",");
			}
			sb.append(stf.getStf_name_w());
		}


		return sb.toString();
	}

	/**
	 * ���k�����擾����
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param grade	�w�N
	 * @param stucodeArray	�I�������w�Дԍ��̔z��
	 * @return	���k���̃��X�g
	 */
	private List<Data31909000_StudentInfoEntity> getStudentInfoEntityList(String user, String nendo, String grade) {

		Object[] param = {user, printFormBean.getOutputDate(), user, nendo};
		QueryManager queryManager = new QueryManager(EXEC_SQL_STUDENTINFO, param, Data31909000_StudentInfoEntity.class);
		queryManager.setPlusSQL("AND cls_stucode IN(" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY cls_glade, cls_clsno, cls_number ");

		@SuppressWarnings("unchecked")
		List<Data31909000_StudentInfoEntity> studentInfoEntityList = (List<Data31909000_StudentInfoEntity>)this.executeQuery(queryManager);

		return studentInfoEntityList;
	}

	/**
	 * �O���ꊈ���̋L�^�̃f�[�^�擾
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param grade	�w�N
	 * @return	�O���ꊈ���̃f�[�^�̃��X�g
	 */
	private List<Data31909000_ForeignlangactEntity> getForeignlangactList(String user, String nendo, String grade) {

		Object[] param = {sessionBean.getUserCode(), nendo, grade, term};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_FOREIGNLANGACT, param, Data31909000_ForeignlangactEntity.class);
		queryManager.setPlusSQL("AND rfla_stucode IN (" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY rfla_stucode ");

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<Data31909000_ForeignlangactEntity> entityList = (List<Data31909000_ForeignlangactEntity>) this.executeQuery(queryManager);

		return entityList;
	}

	/**
	 * �����I�Ȋw�K�̎��Ԃ̋L�^�̃f�[�^�擾
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param grade	�w�N
	 * @return	�����I�Ȋw�K�̎��Ԃ̋L�^�̃f�[�^�̃��X�g
	 */
	private List<Data31909000_TotalactEntity> getTotalactList(String user, String nendo, String grade) {

		Object[] param = {sessionBean.getUserCode(), nendo, grade, term};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_TOTALACT, param, Data31909000_TotalactEntity.class);
		queryManager.setPlusSQL("AND rtav_stucode IN (" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY rtav_stucode ");

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<Data31909000_TotalactEntity> entityList = (List<Data31909000_TotalactEntity>) this.executeQuery(queryManager);

		return entityList;
	}

	/**
	 * ���ʊ����̋L�^�̃f�[�^�擾
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param grade	�w�N
	 * @return	���ʊ����̋L�^�̃f�[�^�̃��X�g
	 */
	private List<Data31909000_SpecialactEntity> getSpecialactList(String user, String nendo, String grade) {

		Object[] param = {term, sessionBean.getUserCode(), nendo};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_SPECIALACT, param, Data31909000_SpecialactEntity.class);
		queryManager.setPlusSQL("AND rsav_stucode IN (" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY rsav_stucode ");

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<Data31909000_SpecialactEntity> entityList = (List<Data31909000_SpecialactEntity>) this.executeQuery(queryManager);

		return entityList;
	}

	/**
	 * �����̂悤���̃f�[�^�擾
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param grade	�w�N
	 * @param termArray	�I�������w���̔z��
	 * @return	�s���̂�����̃f�[�^�̃��X�g
	 */
	private List<Data31909000_ActViewpointEntity> getActViewpointList(String user, String nendo, String grade) {

		Object[] param = {user, nendo, grade, term};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_ACT_VIEWPOINT, param, Data31909000_ActViewpointEntity.class);
		queryManager.setPlusSQL("AND cls_stucode IN (" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY cls_stucode, ravt_term, ravt_order ");

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<Data31909000_ActViewpointEntity> entityList = (List<Data31909000_ActViewpointEntity>) this.executeQuery(queryManager);

		return entityList;
	}

	/**
	 * �o���̋L�^���擾����
	 * @param user �����R�[�h
	 * @param nendo �N�x
	 * @param grade �w�N
	 * @param termArray ����
	 * @return �o���̋L�^���X�g
	 */
	private Map<String, List<Data31909000_AttendEntity>> getAttendListMap(String user, String nendo) {

		Map<String, List<Data31909000_AttendEntity>> map = new HashMap<String, List<Data31909000_AttendEntity>>();

		for(String stucode : stucodeArray){
			Object[] param = {user, nendo, term, user, nendo, stucode};
			QueryManager queryManager =  new QueryManager(EXEC_SQL_ATTEND, param, Data31909000_AttendEntity.class);
			queryManager.setPlusSQL("GROUP BY gopt_name, gopt_goptcode, gopt_order, cls_glade, cls_stucode, cls_number ");
			queryManager.setPlusSQL("ORDER BY gopt_order, gopt_goptcode ");

			// �N�G���̎��s(List�`���Ńf�[�^�i�[)
			@SuppressWarnings("unchecked")
			List<Data31909000_AttendEntity> entityList = (List<Data31909000_AttendEntity>) this.executeQuery(queryManager);

			map.put(stucode, entityList);
		}

		return map;
	}

	/**
	 * �����̃f�[�^�擾
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param grade	�w�N
	 * @return	�����̃f�[�^�̃��X�g
	 */
	private List<Data31909000_MoralEntity> getMoralList(String user, String nendo, String grade) {

		Object[] param = {sessionBean.getUserCode(), nendo, grade, term};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_MORAL, param, Data31909000_MoralEntity.class);
		queryManager.setPlusSQL("AND rmrl_stucode IN (" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY rmrl_stucode ");

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<Data31909000_MoralEntity> entityList = (List<Data31909000_MoralEntity>) this.executeQuery(queryManager);

		return entityList;
	}

	/**
	 * �Z���������擾����
	 * @param user�@�����R�[�h
	 * @return�@�Z������
	 */
	private String getPrincipalName(String user) {
		Object[] param = {user, printFormBean.getOutputDate(), this.nendoStartDate};
		QueryManager queryManager = new QueryManager(EXEC_SQL_PRINCIPAL_NAME, param, StaffEntity.class);

		@SuppressWarnings("unchecked")
		List<StaffEntity> stfList = (List<StaffEntity>)this.executeQuery(queryManager);

		StringBuilder sb = new StringBuilder();
		for(StaffEntity stf : stfList){
			if(sb.length() > 0){
				sb.append(",");
			}
			sb.append(stf.getStf_name());
		}

		return sb.toString();
	}

	/**
	 * �Z���������擾����(�C����)
	 * @param user�@�����R�[�h
	 * @return�@�Z������
	 */
	private String getPrincipalNameDeed(String user) {
		Object[] param = {user, printFormBean.getEndDate()};
		QueryManager queryManager = new QueryManager(EXEC_SQL_PRINCIPAL_NAME_DEED, param, String.class);

		return (String)this.executeQuery(queryManager);

	}



	/**
	 * �C���[�W���擾����
	 * @param user �����R�[�h
	 * @param stm_kind ���
	 * @return �C���[�W
	 */
	private byte[] getSchoolStampImage(String user, String kind) {

		Object[] param = {user, kind};
		QueryManager queryManager = new QueryManager(EXEC_SQL_SCHOOLSTAMP, param, SchoolStampEntity.class);
		@SuppressWarnings("unchecked")
		List<SchoolStampEntity> schoolStampEntityList = (List<SchoolStampEntity>) this.executeQuery(queryManager);

		if(schoolStampEntityList.size() > 0){
			return schoolStampEntityList.get(0).getStm_image();
		}

		return null;
	}

	/**
	 * �����̃f�[�^�擾
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @return	�����̃f�[�^�̃��X�g
	 */
	private List<Data31909000_SpecialactMemoEntity> getSpecialActMemo(String user, String nendo, String grade) {

		Object[] param = {user, nendo, term, grade};
		QueryManager queryManager =  new QueryManager(EXEC_SQL_SPECIALACTMEMO, param, Data31909000_SpecialactMemoEntity.class);
		queryManager.setPlusSQL("AND rcom_stucode IN (" + createIN(stucodeArray) +") ");
		queryManager.setPlusSQL("ORDER BY rcom_stucode ");

		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		@SuppressWarnings("unchecked")
		List<Data31909000_SpecialactMemoEntity> entityList = (List<Data31909000_SpecialactMemoEntity>) this.executeQuery(queryManager);

		return entityList;
	}

	/**
	 * �z�񂩂�IN��Ɏg�p���镶����𐶐�����
	 * @param strArray	���ƂȂ�z��
	 * @return	���`��̕�����
	 */
	private String createIN(String[] strArray) {

		StringBuilder sb = new StringBuilder();

		for(int i=0; i<strArray.length; i++){
			sb.append("'");
			sb.append(strArray[i]);
			sb.append("'");
			if(i < strArray.length - 1){
				sb.append(",");
			}
		}
		return sb.toString();
	}

	/**
	 * @return the printFormBean
	 */
	public Print31909000FormBean getPrintFormBean() {
		return printFormBean;
	}
}
