package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���ʊ����̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31911000_SpecialActivityEntity {
	
    /**
	 * �w�Дԍ�
	 */
	private String rsav_stucode;
		
	/**
	 * ���ʊ����̋L�^
	 */
	private String rsav_record;

	/**
	 * ���ʊ����R�[�h
	 */
	private String rsav_rsatcode;

	
	public String getRsav_stucode() {
		return rsav_stucode;
	}

	public void setRsav_stucode(String rsav_stucode) {
		this.rsav_stucode = rsav_stucode;
	}

	public String getRsav_record() {
		return rsav_record;
	}

	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}

	public String getRsav_rsatcode() {
		return rsav_rsatcode;
	}

	public void setRsav_rsatcode(String rsav_rsatcode) {
		this.rsav_rsatcode = rsav_rsatcode;
	}

	
}
