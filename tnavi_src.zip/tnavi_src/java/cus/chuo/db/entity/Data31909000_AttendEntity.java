package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �o���̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31909000_AttendEntity {

	/**
	 * ���ԃR�[�h
	 */
	private String gopt_goptcode;

	/**
	 * ���Ԗ���
	 */
	private String gopt_name;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * ���Ɠ���
	 */
	private Integer classcount;

	/**
	 * �o��E����������
	 */
	private Integer schoolkindcount;

	/**
	 * �o�Ȃ��ׂ�����
	 */
	private Integer mustcount;

	/**
	 * �a������
	 */
	private Integer sickcount;

	/**
	 * ���̌�����
	 */
	private Integer jikocount;

	/**
	 * �o�ȓ���
	 */
	private Integer attendcount;

	/**
	 * �x������
	 */
	private Integer latecount;

	/**
	 * ���ޓ���
	 */
	private Integer leavecount;

	public String getGopt_goptcode() {
		return gopt_goptcode;
	}

	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}

	public String getGopt_name() {
		return gopt_name;
	}

	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public Integer getClasscount() {
		return classcount;
	}

	public void setClasscount(Integer classcount) {
		this.classcount = classcount;
	}

	public Integer getSchoolkindcount() {
		return schoolkindcount;
	}

	public void setSchoolkindcount(Integer schoolkindcount) {
		this.schoolkindcount = schoolkindcount;
	}

	public Integer getMustcount() {
		return mustcount;
	}

	public void setMustcount(Integer mustcount) {
		this.mustcount = mustcount;
	}

	public Integer getSickcount() {
		return sickcount;
	}

	public void setSickcount(Integer sickcount) {
		this.sickcount = sickcount;
	}

	public Integer getJikocount() {
		return jikocount;
	}

	public void setJikocount(Integer jikocount) {
		this.jikocount = jikocount;
	}

	public Integer getAttendcount() {
		return attendcount;
	}

	public void setAttendcount(Integer attendcount) {
		this.attendcount = attendcount;
	}

	public Integer getLatecount() {
		return latecount;
	}

	public void setLatecount(Integer latecount) {
		this.latecount = latecount;
	}

	public Integer getLeavecount() {
		return leavecount;
	}

	public void setLeavecount(Integer leavecount) {
		this.leavecount = leavecount;
	}



}
