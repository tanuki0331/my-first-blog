package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���k���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028000_StudentInfoEntity {

	/**
	 * �w�Дԍ�
	 */
	private String stu_stucode;

	/**
	 * ���k����
	 */
	private String stu_name;

	/**
	 * �w�N
	 */
	private String cls_glade;

	/**
	 * �g
	 */
	private String hmr_class;

	/**
	 * ��
	 */
	private String cls_number;

	/**
	 * ���N����
	 */
	private String stu_birth;

	/**
	 * ���ʎx���w���t���O
	 */
	private String hmr_spsupport_flg;

	/**
	 * �𗬐�g
	 */
	private String exc_hmr_class;

	/**
	 * �𗬐�o�Ȕԍ�
	 */
	private String exc_number;

	/**
	 * @return the stu_stucode
	 */
	public String getStu_stucode() {
		return stu_stucode;
	}

	/**
	 * @param stu_stucode the stu_stucode to set
	 */
	public void setStu_stucode(String stu_stucode) {
		this.stu_stucode = stu_stucode;
	}

	/**
	 * @return the stu_name
	 */
	public String getStu_name() {
		return stu_name;
	}

	/**
	 * @param stu_name the stu_name to set
	 */
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	/**
	 * @return the cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade the cls_glade to set
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return the hmr_class
	 */
	public String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class the hmr_class to set
	 */
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return the cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number the cls_number to set
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getStu_birth() {
		return stu_birth;
	}

	public void setStu_birth(String stu_birth) {
		this.stu_birth = stu_birth;
	}

	/**
	 * @return st4_special_support
	 */
	public String getHmr_spsupport_flg() {
		return hmr_spsupport_flg;
	}

	/**
	 * @param st4_special_support �Z�b�g���� st4_special_support
	 */
	public void setHmr_spsupport_flg(String st4_special_support) {
		this.hmr_spsupport_flg = st4_special_support;
	}

	/**
	 * @return exc_hmr_class
	 */
	public String getExc_hmr_class() {
		return exc_hmr_class;
	}

	/**
	 * @param exc_hmr_class �Z�b�g���� exc_hmr_class
	 */
	public void setExc_hmr_class(String exc_hmr_class) {
		this.exc_hmr_class = exc_hmr_class;
	}

	/**
	 * @return exc_number
	 */
	public String getExc_number() {
		return exc_number;
	}

	/**
	 * @param exc_number �Z�b�g���� exc_number
	 */
	public void setExc_number(String exc_number) {
		this.exc_number = exc_number;
	}

}
