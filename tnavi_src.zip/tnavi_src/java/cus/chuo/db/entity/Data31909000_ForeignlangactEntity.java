package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �O���ꊈ��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31909000_ForeignlangactEntity {

	/**
	 * �w�Дԍ�
	 */
	private String rfla_stucode;

	/**
	 * �]��
	 */
	private String rfla_eval;

	public String getRfla_stucode() {
		return rfla_stucode;
	}

	public void setRfla_stucode(String rfla_stucode) {
		this.rfla_stucode = rfla_stucode;
	}

	public String getRfla_eval() {
		return rfla_eval;
	}

	public void setRfla_eval(String rfla_eval) {
		this.rfla_eval = rfla_eval;
	}

}
