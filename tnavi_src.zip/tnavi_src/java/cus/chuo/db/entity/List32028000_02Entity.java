package jp.co.systemd.tnavi.cus.chuo.db.entity;

import jp.co.systemd.tnavi.common.db.entity.HealthcardSettingEntity;

/**
 * <PRE>
 * ���N�J�[�h�o�͐ݒ�Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.05 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List32028000_02Entity extends HealthcardSettingEntity {

	/**
	 * ���{��������
	 */
	private String mhlr_name;

	public String getMhlr_name() {
		return mhlr_name;
	}

	public void setMhlr_name(String mhlr_name) {
		this.mhlr_name = mhlr_name;
	}

}
