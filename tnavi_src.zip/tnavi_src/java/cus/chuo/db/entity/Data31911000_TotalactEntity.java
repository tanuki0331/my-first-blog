package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �����I�Ȋw�K�̎��Ԃ̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31911000_TotalactEntity {
	
   /**
	 * �w�Дԍ�
	 */
	private String rtav_stucode;
	
    /**
     * �]��
     */
    private String rtav_value;

    /**
     * �o�͎���
     */
    private String rtav_term;

    /**
     * �w�K�����F��������
     */
    private String rtav_contents;

    /**
     * �w�K�����F�w�N����A�N���X���œ���
     */
    private String rtat_act;

    /**
     * �w�K�����F�w�N����A�N���X���œ���
     */
    private String cod_value1;
    
    
    

	public String getRtav_stucode() {
		return rtav_stucode;
	}

	public void setRtav_stucode(String rtav_stucode) {
		this.rtav_stucode = rtav_stucode;
	}

	public String getRtav_value() {
		return rtav_value;
	}

	public void setRtav_value(String rtav_value) {
		this.rtav_value = rtav_value;
	}

	public String getRtav_term() {
		return rtav_term;
	}

	public void setRtav_term(String rtav_term) {
		this.rtav_term = rtav_term;
	}

	public String getRtav_contents() {
		return rtav_contents;
	}

	public void setRtav_contents(String rtav_contents) {
		this.rtav_contents = rtav_contents;
	}

	public String getRtat_act() {
		return rtat_act;
	}

	public void setRtat_act(String rtat_act) {
		this.rtat_act = rtat_act;
	}

	public String getCod_value1() {
		return cod_value1;
	}

	public void setCod_value1(String cod_value1) {
		this.cod_value1 = cod_value1;
	}
    
    
    
	
}
