package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �̏d���ڏ��Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028000_TransitionWeightEntity {

	/**
	 * �w�Дԍ�
	 */
	private String stucode;

	/**
	 * �w�N
	 */
	private String grade;

	/**
	 * �w����
	 */
	private String termName;

	/**
	 * ��
	 */
	private String month;

	/**
	 * �̏d
	 */
	private String weight;

	public String getStucode() {
		return stucode;
	}

	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

}
