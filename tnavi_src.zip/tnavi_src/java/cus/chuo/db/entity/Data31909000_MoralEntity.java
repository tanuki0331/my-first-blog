package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �����̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.11.02 BY SD ito<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31909000_MoralEntity {

	/**
	 * �w�Дԍ�
	 */
	private String rmrl_stucode;

    /**
     * �]��
     */
    private String rmrl_value;

	/**
	 * @return rmrl_stucode
	 */
	public String getRmrl_stucode() {
		return rmrl_stucode;
	}

	/**
	 * @param rmrl_stucode �Z�b�g���� rmrl_stucode
	 */
	public void setRmrl_stucode(String rmrl_stucode) {
		this.rmrl_stucode = rmrl_stucode;
	}

	/**
	 * @return rmrl_value
	 */
	public String getRmrl_value() {
		return rmrl_value;
	}

	/**
	 * @param rmrl_value �Z�b�g���� rmrl_value
	 */
	public void setRmrl_value(String rmrl_value) {
		this.rmrl_value = rmrl_value;
	}
}
