package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31909000_ItemViewpointEntity {

	/**
	 * ���ȃR�[�h
	 */
	private String item_code;

	/**
	 * �\����
	 */
	private String item_order;

	/**
	 * ���Ȗ���
	 */
	private String item_name;

	/**
	 * ���Ȗ���(�Ђ炪�ȕ\�L)
	 */
	private String item_kana;

	/**
	 * �w�K�̂߂₷
	 */
	private String sp_purpose;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �]��
	 */
	private String upe_manualupecode;

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_order() {
		return item_order;
	}

	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_kana() {
		return item_kana;
	}

	public void setItem_kana(String item_kana) {
		this.item_kana = item_kana;
	}

	public String getSp_purpose() {
		return sp_purpose;
	}

	public void setSp_purpose(String sp_purpose) {
		this.sp_purpose = sp_purpose;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getUpe_manualupecode() {
		return upe_manualupecode;
	}

	public void setUpe_manualupecode(String upe_manualupecode) {
		this.upe_manualupecode = upe_manualupecode;
	}

}
