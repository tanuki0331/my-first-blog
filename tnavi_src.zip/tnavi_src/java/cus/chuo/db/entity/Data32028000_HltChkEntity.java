package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���N�f�f���ʏ��Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028000_HltChkEntity {

	/**
	 * �w�Дԍ�
	 */
	private String stucode;

	/**
	 * �Ғ��E���s�E�l��
	 */
	private String spine_thoracic;

	/**
	 * �畆����
	 */
	private String skin_disease;

	/**
	 * ���j
	 */
	private String bercle;

	/**
	 * �S�d�}
	 */
	private String electrocardiogram;

	/**
	 * �S������
	 */
	private String heart_disease;

	/**
	 * ���͋����敪
	 */
	private String vision_correctkbn;

	/**
	 * ���� ��
	 */
	private String vision_left;

	/**
	 * ���� �E
	 */
	private String vision_right;

	/**
	 * ���ᎋ�� ��
	 */
	private String vision_naked_left;

	/**
	 * ���ᎋ�� �E
	 */
	private String vision_naked_right;

	/**
	 * �Ꮎ�a
	 */
	private String eye_disease;

	/**
	 * ���� �E
	 */
	private String hearing_right;

	/**
	 * ���� ��
	 */
	private String hearing_left;

	/**
	 * ���@��A����
	 */
	private String ear_disease;

	/**
	 * �A �`��
	 */
	private String urine_protein;

	/**
	 * �A ��
	 */
	private String urine_diabetes;

	/**
	 * �A ����
	 */
	private String urine_blood;

	/**
	 * ���̑��̎��a�y�шُ�
	 */
	private String other_diabetes;

	/**
	 * ���l
	 */
	private String memo;

	public String getStucode() {
		return stucode;
	}

	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	/**
	 * @return spine_thoracic
	 */
	public String getSpine_thoracic() {
		return spine_thoracic;
	}

	/**
	 * @param spine_thoracic �Z�b�g���� spine_thoracic
	 */
	public void setSpine_thoracic(String spine_thoracic) {
		this.spine_thoracic = spine_thoracic;
	}

	/**
	 * @return skin_disease
	 */
	public String getSkin_disease() {
		return skin_disease;
	}

	/**
	 * @param skin_disease �Z�b�g���� skin_disease
	 */
	public void setSkin_disease(String skin_disease) {
		this.skin_disease = skin_disease;
	}

	/**
	 * @return bercle
	 */
	public String getBercle() {
		return bercle;
	}

	/**
	 * @param bercle �Z�b�g���� bercle
	 */
	public void setBercle(String bercle) {
		this.bercle = bercle;
	}

	/**
	 * @return electrocardiogram
	 */
	public String getElectrocardiogram() {
		return electrocardiogram;
	}

	/**
	 * @param electrocardiogram �Z�b�g���� electrocardiogram
	 */
	public void setElectrocardiogram(String electrocardiogram) {
		this.electrocardiogram = electrocardiogram;
	}

	/**
	 * @return heart_disease
	 */
	public String getHeart_disease() {
		return heart_disease;
	}

	/**
	 * @param heart_disease �Z�b�g���� heart_disease
	 */
	public void setHeart_disease(String heart_disease) {
		this.heart_disease = heart_disease;
	}

	/**
	 * @return vision_correctkbn
	 */
	public String getVision_correctkbn() {
		return vision_correctkbn;
	}

	/**
	 * @param vision_correctkbn �Z�b�g���� vision_correctkbn
	 */
	public void setVision_correctkbn(String vision_correctkbn) {
		this.vision_correctkbn = vision_correctkbn;
	}

	/**
	 * @return vision_left
	 */
	public String getVision_left() {
		return vision_left;
	}

	/**
	 * @param vision_left �Z�b�g���� vision_left
	 */
	public void setVision_left(String vision_left) {
		this.vision_left = vision_left;
	}

	/**
	 * @return vision_right
	 */
	public String getVision_right() {
		return vision_right;
	}

	/**
	 * @param vision_right �Z�b�g���� vision_right
	 */
	public void setVision_right(String vision_right) {
		this.vision_right = vision_right;
	}

	/**
	 * @return vision_naked_left
	 */
	public String getVision_naked_left() {
		return vision_naked_left;
	}

	/**
	 * @param vision_naked_left �Z�b�g���� vision_naked_left
	 */
	public void setVision_naked_left(String vision_naked_left) {
		this.vision_naked_left = vision_naked_left;
	}

	/**
	 * @return vision_naked_right
	 */
	public String getVision_naked_right() {
		return vision_naked_right;
	}

	/**
	 * @param vision_naked_right �Z�b�g���� vision_naked_right
	 */
	public void setVision_naked_right(String vision_naked_right) {
		this.vision_naked_right = vision_naked_right;
	}

	/**
	 * @return eye_disease
	 */
	public String getEye_disease() {
		return eye_disease;
	}

	/**
	 * @param eye_disease �Z�b�g���� eye_disease
	 */
	public void setEye_disease(String eye_disease) {
		this.eye_disease = eye_disease;
	}

	/**
	 * @return hearing_right
	 */
	public String getHearing_right() {
		return hearing_right;
	}

	/**
	 * @param hearing_right �Z�b�g���� hearing_right
	 */
	public void setHearing_right(String hearing_right) {
		this.hearing_right = hearing_right;
	}

	/**
	 * @return hearing_left
	 */
	public String getHearing_left() {
		return hearing_left;
	}

	/**
	 * @param hearing_left �Z�b�g���� hearing_left
	 */
	public void setHearing_left(String hearing_left) {
		this.hearing_left = hearing_left;
	}

	/**
	 * @return ear_disease
	 */
	public String getEar_disease() {
		return ear_disease;
	}

	/**
	 * @param ear_disease �Z�b�g���� ear_disease
	 */
	public void setEar_disease(String ear_disease) {
		this.ear_disease = ear_disease;
	}

	/**
	 * @return urine_protein
	 */
	public String getUrine_protein() {
		return urine_protein;
	}

	/**
	 * @param urine_protein �Z�b�g���� urine_protein
	 */
	public void setUrine_protein(String urine_protein) {
		this.urine_protein = urine_protein;
	}

	/**
	 * @return urine_diabetes
	 */
	public String getUrine_diabetes() {
		return urine_diabetes;
	}

	/**
	 * @param urine_diabetes �Z�b�g���� urine_diabetes
	 */
	public void setUrine_diabetes(String urine_diabetes) {
		this.urine_diabetes = urine_diabetes;
	}

	/**
	 * @return urine_blood
	 */
	public String getUrine_blood() {
		return urine_blood;
	}

	/**
	 * @param urine_blood �Z�b�g���� urine_blood
	 */
	public void setUrine_blood(String urine_blood) {
		this.urine_blood = urine_blood;
	}

	/**
	 * @return other_diabetes
	 */
	public String getOther_diabetes() {
		return other_diabetes;
	}

	/**
	 * @param other_diabetes �Z�b�g���� other_diabetes
	 */
	public void setOther_diabetes(String other_diabetes) {
		this.other_diabetes = other_diabetes;
	}

	/**
	 * @return memo
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * @param memo �Z�b�g���� memo
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

}
