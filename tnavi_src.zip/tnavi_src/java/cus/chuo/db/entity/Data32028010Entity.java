package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���[�o�͕����Ǘ��ėp�e�[�u�����Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.05 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028010Entity {

    /**
     * �L�[����1
     */
    private String crt_key1;
    /**
     * �o�͒l1
     */
    private String crt_value1;

    /**
	 * @return crt_key1
	 */
	public String getCrt_key1() {
		return crt_key1;
	}
	/**
	 * @param crt_key1 �Z�b�g���� crt_key1
	 */
	public void setCrt_key1(String crt_key1) {
		this.crt_key1 = crt_key1;
	}
	/**
	 * @return crt_value1
	 */
	public String getCrt_value1() {
		return crt_value1;
	}
	/**
	 * @param crt_value1 �Z�b�g���� crt_value1
	 */
	public void setCrt_value1(String crt_value1) {
		this.crt_value1 = crt_value1;
	}

}
