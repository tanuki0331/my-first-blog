package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���k���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31911000_StudentInfoEntity {
	
	/**
	 * �w�Дԍ�
	 */
	private String stu_stucode;
	
	/**
	 * ���w�N�x
	 */
	private String stu_year;

	/**
	 * ���k����
	 */
	private String stu_name;
	
	/**
	 * �w�N
	 */
	private String cls_glade;
	
	/**
	 * �g
	 */
	private String hmr_class;
	
	/**
	 * ��
	 */
	private String cls_number;
	
	/**
	 * ���N����
	 */
	private String stu_birth;

	/**
	 * @return the stu_stucode
	 */
	public String getStu_stucode() {
		return stu_stucode;
	}

	/**
	 * @param stu_stucode the stu_stucode to set
	 */
	public void setStu_stucode(String stu_stucode) {
		this.stu_stucode = stu_stucode;
	}

	public String getStu_year() {
		return stu_year;
	}

	public void setStu_year(String stu_year) {
		this.stu_year = stu_year;
	}

	/**
	 * @return the stu_name
	 */
	public String getStu_name() {
		return stu_name;
	}

	/**
	 * @param stu_name the stu_name to set
	 */
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	/**
	 * @return the cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade the cls_glade to set
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return the hmr_class
	 */
	public String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class the hmr_class to set
	 */
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return the cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number the cls_number to set
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getStu_birth() {
		return stu_birth;
	}

	public void setStu_birth(String stu_birth) {
		this.stu_birth = stu_birth;
	}

}
