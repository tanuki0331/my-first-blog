package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31911000_ItemViewpointEntity {
	
	/**
	 * ���ȃR�[�h
	 */
	private String item_code;
	
	/**
	 * ���Ȗ���
	 */
	private String item_name;
	
	/**
	 * �\����
	 */
	private String item_order;
	
	/**
	 * �ϓ_�R�[�h
	 */
	private String rivt_rivtcode;

	/**
	 * �ϓ_����
	 */
	private String rivt_rivtname;

	/**
	 * ���Ȋϓ_
	 */
	private String rivt_purpose;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �]��
	 */
	private String upe_manualupecode;

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_order() {
		return item_order;
	}

	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getUpe_manualupecode() {
		return upe_manualupecode;
	}

	public void setUpe_manualupecode(String upe_manualupecode) {
		this.upe_manualupecode = upe_manualupecode;
	}

	public String getRivt_rivtcode() {
		return rivt_rivtcode;
	}

	public void setRivt_rivtcode(String rivt_rivtcode) {
		this.rivt_rivtcode = rivt_rivtcode;
	}

	public String getRivt_rivtname() {
		return rivt_rivtname;
	}

	public void setRivt_rivtname(String rivt_rivtname) {
		this.rivt_rivtname = rivt_rivtname;
	}

	public String getRivt_purpose() {
		return rivt_purpose;
	}

	public void setRivt_purpose(String rivt_purpose) {
		this.rivt_purpose = rivt_purpose;
	}


}
