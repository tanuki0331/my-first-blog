package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * ���N�̋L�^���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028000_HealthRecordEntity {

	/**
	 * �敪
	 */
	private String hcs_kind;

	/**
	 * �A��
	 */
	private String hcs_seq;

	/**
	 * �w�Дԍ�
	 */
	private String hlr_stucode;

	/**
	 * �g��
	 */
	private String hlr_height;

	/**
	 * �̏d
	 */
	private String hlr_weight;


	public String getHcs_kind() {
		return hcs_kind;
	}

	public void setHcs_kind(String hcs_kind) {
		this.hcs_kind = hcs_kind;
	}

	public String getHcs_seq() {
		return hcs_seq;
	}

	public void setHcs_seq(String hcs_seq) {
		this.hcs_seq = hcs_seq;
	}

	public String getHlr_stucode() {
		return hlr_stucode;
	}

	public void setHlr_stucode(String hlr_stucode) {
		this.hlr_stucode = hlr_stucode;
	}

	public String getHlr_height() {
		return hlr_height;
	}

	public void setHlr_height(String hlr_height) {
		this.hlr_height = hlr_height;
	}

	public String getHlr_weight() {
		return hlr_weight;
	}

	public void setHlr_weight(String hlr_weight) {
		this.hlr_weight = hlr_weight;
	}

}
