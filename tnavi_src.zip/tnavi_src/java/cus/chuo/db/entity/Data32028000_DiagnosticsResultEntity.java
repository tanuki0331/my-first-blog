package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �f�f���ʏ��Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028000_DiagnosticsResultEntity {

	/**
	 * �g��
	 */
	private String height = "";

	/**
	 * �̏d
	 */
	private String weight = "";

	/**
	 * �Ғ��E���s�E�l��
	 */
	private String spine_thoracic = "";

	/**
	 * �畆����
	 */
	private String skinDisease = "";

	/**
	 * ���j
	 */
	private String bercle = "";

	/**
	 * �S�� �S�d�}�����i�P�N���̂݁j
	 */
	private String electrocardiogram = "";

	/**
	 * �S�� ���a�y�шُ�
	 */
	private String heartDisease = "";

	/**
	 * ���� ���� �E
	 */
	private String eyesight_right = "";

	/**
	 * ���� ���� �E
	 */
	private String eyesight_right_corrected = "";

	/**
	 * ���� ���� ��
	 */
	private String eyesight_left = "";

	/**
	 * ���� ���� ��
	 */
	private String eyesight_left_corrected = "";

	/**
	 * ��̎��a�y�шُ�
	 */
	private String eyeDisease = "";

	/**
	 * ���� �E
	 */
	private String hearing_right = "";

	/**
	 * ���� ��
	 */
	private String hearing_left = "";

	/**
	 * ���@��A����
	 */
	private String earNoseDisease = "";

	/**
	 * �A���� �`��
	 */
	private String urineProtein = "";

	/**
	 * �A���� ��
	 */
	private String urineDiabetes = "";

	/**
	 * �A���� ����
	 */
	private String urineOccultBlood = "";

	/**
	 * ���̑��̎��a�y�шُ�
	 */
	private String otherDisease = "";

	/**
	 * ���� �{�֐�
	 */
	private String jawStatus = "";

	/**
	 * ���� �������
	 */
	private String occludeStatus = "";

	/**
	 * ���� ���C�̏��
	 */
	private String plaqueStatus = "";

	/**
	 * ���� �����̏��
	 */
	private String gumStatus = "";

	/**
	 * ���� �i�����j   �����u���t���O�i0:�Ȃ� 1:����j
	 */
	private String decayedMilkToothFlg = "";

	/**
	 * ���� �i�i�v���j �����u���t���O�i0:�Ȃ� 1:����j
	 */
	private String decayedPermanentToothFlg = "";

	/**
	 * ���� �v���ӓ����t���O�i0:�Ȃ� 1:����j
	 */
	private String cautionMilkToothFlg = "";

	/**
	 * ���� �v�ώ@���t���O�i0:�Ȃ� 1:����j
	 */
	private String CO_ToothFlg = "";

	/**
	 * ���� ���̑��̎��a�y�шُ�
	 */
	private String otherSick = "";

	/**
	 * ���l
	 */
	private String memo = "";

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	/**
	 * @return weight
	 */
	public String getWeight() {
		return weight;
	}

	/**
	 * @param weight �Z�b�g���� weight
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}

	/**
	 * @return spine_thoracic
	 */
	public String getSpine_thoracic() {
		return spine_thoracic;
	}

	/**
	 * @param spine_thoracic �Z�b�g���� spine_thoracic
	 */
	public void setSpine_thoracic(String spine_thoracic) {
		this.spine_thoracic = spine_thoracic;
	}

	/**
	 * @return skinDisease
	 */
	public String getSkinDisease() {
		return skinDisease;
	}

	/**
	 * @param skinDisease �Z�b�g���� skinDisease
	 */
	public void setSkinDisease(String skinDisease) {
		this.skinDisease = skinDisease;
	}

	/**
	 * @return bercle
	 */
	public String getBercle() {
		return bercle;
	}

	/**
	 * @param bercle �Z�b�g���� bercle
	 */
	public void setBercle(String bercle) {
		this.bercle = bercle;
	}

	/**
	 * @return electrocardiogram
	 */
	public String getElectrocardiogram() {
		return electrocardiogram;
	}

	/**
	 * @param electrocardiogram �Z�b�g���� electrocardiogram
	 */
	public void setElectrocardiogram(String electrocardiogram) {
		this.electrocardiogram = electrocardiogram;
	}

	/**
	 * @return heartDisease
	 */
	public String getHeartDisease() {
		return heartDisease;
	}

	/**
	 * @param heartDisease �Z�b�g���� heartDisease
	 */
	public void setHeartDisease(String heartDisease) {
		this.heartDisease = heartDisease;
	}

	/**
	 * @return eyesight_right
	 */
	public String getEyesight_right() {
		return eyesight_right;
	}

	/**
	 * @param eyesight_right �Z�b�g���� eyesight_right
	 */
	public void setEyesight_right(String eyesight_right) {
		this.eyesight_right = eyesight_right;
	}

	/**
	 * @return eyesight_right_corrected
	 */
	public String getEyesight_right_corrected() {
		return eyesight_right_corrected;
	}

	/**
	 * @param eyesight_right_corrected �Z�b�g���� eyesight_right_corrected
	 */
	public void setEyesight_right_corrected(String eyesight_right_corrected) {
		this.eyesight_right_corrected = eyesight_right_corrected;
	}

	/**
	 * @return eyesight_left
	 */
	public String getEyesight_left() {
		return eyesight_left;
	}

	/**
	 * @param eyesight_left �Z�b�g���� eyesight_left
	 */
	public void setEyesight_left(String eyesight_left) {
		this.eyesight_left = eyesight_left;
	}

	/**
	 * @return eyesight_left_corrected
	 */
	public String getEyesight_left_corrected() {
		return eyesight_left_corrected;
	}

	/**
	 * @param eyesight_left_corrected �Z�b�g���� eyesight_left_corrected
	 */
	public void setEyesight_left_corrected(String eyesight_left_corrected) {
		this.eyesight_left_corrected = eyesight_left_corrected;
	}

	/**
	 * @return eyeDisease
	 */
	public String getEyeDisease() {
		return eyeDisease;
	}

	/**
	 * @param eyeDisease �Z�b�g���� eyeDisease
	 */
	public void setEyeDisease(String eyeDisease) {
		this.eyeDisease = eyeDisease;
	}

	/**
	 * @return hearing_right
	 */
	public String getHearing_right() {
		return hearing_right;
	}

	/**
	 * @param hearing_right �Z�b�g���� hearing_right
	 */
	public void setHearing_right(String hearing_right) {
		this.hearing_right = hearing_right;
	}

	/**
	 * @return hearing_left
	 */
	public String getHearing_left() {
		return hearing_left;
	}

	/**
	 * @param hearing_left �Z�b�g���� hearing_left
	 */
	public void setHearing_left(String hearing_left) {
		this.hearing_left = hearing_left;
	}

	/**
	 * @return earNoseDisease
	 */
	public String getEarNoseDisease() {
		return earNoseDisease;
	}

	/**
	 * @param earNoseDisease �Z�b�g���� earNoseDisease
	 */
	public void setEarNoseDisease(String earNoseDisease) {
		this.earNoseDisease = earNoseDisease;
	}

	/**
	 * @return urineProtein
	 */
	public String getUrineProtein() {
		return urineProtein;
	}

	/**
	 * @param urineProtein �Z�b�g���� urineProtein
	 */
	public void setUrineProtein(String urineProtein) {
		this.urineProtein = urineProtein;
	}

	/**
	 * @return urineDiabetes
	 */
	public String getUrineDiabetes() {
		return urineDiabetes;
	}

	/**
	 * @param urineDiabetes �Z�b�g���� urineDiabetes
	 */
	public void setUrineDiabetes(String urineDiabetes) {
		this.urineDiabetes = urineDiabetes;
	}

	/**
	 * @return urineOccultBlood
	 */
	public String getUrineOccultBlood() {
		return urineOccultBlood;
	}

	/**
	 * @param urineOccultBlood �Z�b�g���� urineOccultBlood
	 */
	public void setUrineOccultBlood(String urineOccultBlood) {
		this.urineOccultBlood = urineOccultBlood;
	}

	/**
	 * @return otherDisease
	 */
	public String getOtherDisease() {
		return otherDisease;
	}

	/**
	 * @param otherDisease �Z�b�g���� otherDisease
	 */
	public void setOtherDisease(String otherDisease) {
		this.otherDisease = otherDisease;
	}

	/**
	 * @return jawStatus
	 */
	public String getJawStatus() {
		return jawStatus;
	}

	/**
	 * @param jawStatus �Z�b�g���� jawStatus
	 */
	public void setJawStatus(String jawStatus) {
		this.jawStatus = jawStatus;
	}

	/**
	 * @return occludeStatus
	 */
	public String getOccludeStatus() {
		return occludeStatus;
	}

	/**
	 * @param occludeStatus �Z�b�g���� occludeStatus
	 */
	public void setOccludeStatus(String occludeStatus) {
		this.occludeStatus = occludeStatus;
	}

	/**
	 * @return plaqueStatus
	 */
	public String getPlaqueStatus() {
		return plaqueStatus;
	}

	/**
	 * @param plaqueStatus �Z�b�g���� plaqueStatus
	 */
	public void setPlaqueStatus(String plaqueStatus) {
		this.plaqueStatus = plaqueStatus;
	}

	/**
	 * @return gumStatus
	 */
	public String getGumStatus() {
		return gumStatus;
	}

	/**
	 * @param gumStatus �Z�b�g���� gumStatus
	 */
	public void setGumStatus(String gumStatus) {
		this.gumStatus = gumStatus;
	}

	/**
	 * @return decayedMilkToothFlg
	 */
	public String getDecayedMilkToothFlg() {
		return decayedMilkToothFlg;
	}

	/**
	 * @param decayedMilkToothFlg �Z�b�g���� decayedMilkToothFlg
	 */
	public void setDecayedMilkToothFlg(String decayedMilkToothFlg) {
		this.decayedMilkToothFlg = decayedMilkToothFlg;
	}

	/**
	 * @return decayedPermanentToothFlg
	 */
	public String getDecayedPermanentToothFlg() {
		return decayedPermanentToothFlg;
	}

	/**
	 * @param decayedPermanentToothFlg �Z�b�g���� decayedPermanentToothFlg
	 */
	public void setDecayedPermanentToothFlg(String decayedPermanentToothFlg) {
		this.decayedPermanentToothFlg = decayedPermanentToothFlg;
	}

	/**
	 * @return cautionMilkToothFlg
	 */
	public String getCautionMilkToothFlg() {
		return cautionMilkToothFlg;
	}

	/**
	 * @param cautionMilkToothFlg �Z�b�g���� cautionMilkToothFlg
	 */
	public void setCautionMilkToothFlg(String cautionMilkToothFlg) {
		this.cautionMilkToothFlg = cautionMilkToothFlg;
	}

	/**
	 * @return cO_ToothFlg
	 */
	public String getCO_ToothFlg() {
		return CO_ToothFlg;
	}

	/**
	 * @param cO_ToothFlg �Z�b�g���� cO_ToothFlg
	 */
	public void setCO_ToothFlg(String cO_ToothFlg) {
		CO_ToothFlg = cO_ToothFlg;
	}

	/**
	 * @return otherSick
	 */
	public String getOtherSick() {
		return otherSick;
	}

	/**
	 * @param otherSick �Z�b�g���� otherSick
	 */
	public void setOtherSick(String otherSick) {
		this.otherSick = otherSick;
	}

	/**
	 * @return memo
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * @param memo �Z�b�g���� memo
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

}
