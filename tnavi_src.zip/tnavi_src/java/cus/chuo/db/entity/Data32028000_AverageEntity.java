package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �g���E�̏d�̕��ϒl���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028000_AverageEntity {

	/**
	 * �w�N
	 */
	private String grade;

	/**
	 * ���
	 */
	private String pha_kind;

	/**
	 * �g��(�j)
	 */
	private String height_male;

	/**
	 * �g��(��)
	 */
	private String height_female;

	/**
	 * �̏d(�j)
	 */
	private String weight_male;

	/**
	 * �̏d(��)
	 */
	private String weight_female;

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getPha_kind() {
		return pha_kind;
	}

	public void setPha_kind(String pha_kind) {
		this.pha_kind = pha_kind;
	}

	public String getHeight_male() {
		return height_male;
	}

	public void setHeight_male(String height_male) {
		this.height_male = height_male;
	}

	public String getHeight_female() {
		return height_female;
	}

	public void setHeight_female(String height_female) {
		this.height_female = height_female;
	}

	public String getWeight_male() {
		return weight_male;
	}

	public void setWeight_male(String weight_male) {
		this.weight_male = weight_male;
	}

	public String getWeight_female() {
		return weight_female;
	}

	public void setWeight_female(String weight_female) {
		this.weight_female = weight_female;
	}

}
