package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �]���E�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.16 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31911000_ScoreEntity {
	
	/**
	 * ���ȃR�[�h
	 */
	private String item_code;

	/**
	 * �ϓ_�R�[�h
	 */
	private String rivt_rivtcode;

	/**
	 * �o�͎���
	 */
	private String rivt_term;

	/**
	 * �w�Дԍ�
	 */
	private String rvpv_stucode;

	/**
	 * �]��
	 */
	private String rvpe_reportdisplay;

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getRivt_rivtcode() {
		return rivt_rivtcode;
	}

	public void setRivt_rivtcode(String rivt_rivtcode) {
		this.rivt_rivtcode = rivt_rivtcode;
	}

	public String getRivt_term() {
		return rivt_term;
	}

	public void setRivt_term(String rivt_term) {
		this.rivt_term = rivt_term;
	}

	public String getRvpv_stucode() {
		return rvpv_stucode;
	}

	public void setRvpv_stucode(String rvpv_stucode) {
		this.rvpv_stucode = rvpv_stucode;
	}

	public String getRvpe_reportdisplay() {
		return rvpe_reportdisplay;
	}

	public void setRvpe_reportdisplay(String rvpe_reportdisplay) {
		this.rvpe_reportdisplay = rvpe_reportdisplay;
	}


	
	
}
