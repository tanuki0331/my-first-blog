package jp.co.systemd.tnavi.cus.chuo.db.entity;

/**
 * <PRE>
 * �얞�x���Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.03.08 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32028000_BmiEntity {

	/**
	 * �s�w�b�_�\����
	 */
	private String hcs_name;

	/**
	 * �얞�x
	 */
	private String bmi;

	public String getHcs_name() {
		return hcs_name;
	}

	public void setHcs_name(String hcs_name) {
		this.hcs_name = hcs_name;
	}

	public String getBmi() {
		return bmi;
	}

	public void setBmi(String bmi) {
		this.bmi = bmi;
	}

}
