package jp.co.systemd.tnavi.cus.hakone.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.hakone.db.service.Print32071000Service;
import jp.co.systemd.tnavi.cus.hakone.print.Print32071000;

/**
 * ���ђʒm�\���(������ ���w�Z) ��� Action.
 *
 * <B>Create</B> 2018.05.24 BY aivick <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print32071000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32071000Action.class);

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("���ђʒm�\���(������ ���w�Z) START");

		//-----���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("���ђʒm�\");

		try{

			//���[�t�H�[���t�@�C��
			String formFileName = "cus/hakone/form32071000.cfx";

			Print32071000Service service = new Print32071000Service();
			service.execute(request, sessionBean);

			Print32071000 print31936000 = new Print32071000();
			print31936000.setPrintFormBean(service.getPrintFormBean());
			print31936000.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print31936000.execute(formFileName);

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("���ђʒm�\���(������ ���w�Z) END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return null;
	}

}
