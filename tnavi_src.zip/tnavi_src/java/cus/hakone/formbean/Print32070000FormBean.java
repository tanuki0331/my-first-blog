package jp.co.systemd.tnavi.cus.hakone.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32070000_ActiveEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32070000_AttendEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32070000_OtherScoreEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32070000_StudentDetailEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32070000_ViewPointEntity;


/**
 * <PRE>
 *  ���ђʒm�\���(������ ���w�Z) ���FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.05.23 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print32070000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/* �I���p�����[�^ */

	/** �N�x�J�n���t */
	private String startDate = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �\���\���t���O */
	private boolean output_cover;

	/** �]���E�]��y�[�W�\���t���O */
	private boolean output_score;

	/** �]���̊ϓ_�y�[�W�\���t���O */
	private boolean output_view;

	/** �w�Z�����̗l�q���y�[�W�\���t���O */
	private boolean output_attend;

	/** �C�����\���t���O */
	private boolean output_deed;

	/** �I���w�Дԍ� */
	private String[] selectStuCode;

	/** ������� */
	private CmlguideoutputtermEntity cmlguideoutputtermEntity;

	/** �]���\���t���O  1�F�ʏ�A�Q�F�]�������A�R�F���і��� */
	private String outputEvalFlg;


	/* ����\���p�����[�^ */
	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���ŏI�w���� */
	private String lastTermName = DEFALUT_VALUE;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameS = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameO = DEFALUT_VALUE;

	/** �S�C���� */
	private String classTeacher = DEFALUT_VALUE;

	/** �z�[�����[����� */
	private HroomKeyFormBean hroomKeyFormBean;

	/** �C�����t */
	private String endDate = DEFALUT_VALUE;

	/** �ʒm�\�^�C�g���C���[�W */
	byte[] schoolStampImage;

	/** �ʒm�\�^�C�g���C���[�W */
	byte[] schoolStampImageDeed;

	/** ���k��� */
	private Map<String,Data32070000_StudentDetailEntity> studentDetailEntityMap;

	/** �o����� */
	private Map<String,Data32070000_AttendEntity> attendEntityMap;

	/** �ϓ_�����X�g */
	private List<Data32070000_ViewPointEntity> viewPointNameEntityList;

	/** �ϓ_�E�]�萬��Map */
	private Map<String,Data32070000_ViewPointEntity> viewPointScoreMap;

	/** �s���̋L�^���X�g */
	private List<Data32070000_ActiveEntity> activeNameList;

	/** �s���̋L�^���Map */
	private Map<String,Data32070000_ActiveEntity> activeEntityMap;

	/** ���ʊ����̋L�^�i�ϓ_�j */
	private String totalActViewPoint = DEFALUT_VALUE;

	/** ���̑��̐��� */
	private Map<String,List<Data32070000_OtherScoreEntity>> otherScoreMap;

	/** �ϓ_�̕]�� */
	private String viewPointEval = DEFALUT_VALUE;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_score() {
		return output_score;
	}

	public void setOutput_score(boolean output_score) {
		this.output_score = output_score;
	}

	public boolean isOutput_view() {
		return output_view;
	}

	public void setOutput_view(boolean output_view) {
		this.output_view = output_view;
	}

	public boolean isOutput_attend() {
		return output_attend;
	}

	public void setOutput_attend(boolean output_attend) {
		this.output_attend = output_attend;
	}

	public boolean isOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(boolean output_deed) {
		this.output_deed = output_deed;
	}

	public String[] getSelectStuCode() {
		return selectStuCode;
	}

	public void setSelectStuCode(String[] selectStuCode) {
		this.selectStuCode = selectStuCode;
	}

	public CmlguideoutputtermEntity getCmlguideoutputtermEntity() {
		return cmlguideoutputtermEntity;
	}

	public void setCmlguideoutputtermEntity(CmlguideoutputtermEntity cmlguideoutputtermEntity) {
		this.cmlguideoutputtermEntity = cmlguideoutputtermEntity;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getLastTermName() {
		return lastTermName;
	}

	public void setLastTermName(String lastTermName) {
		this.lastTermName = lastTermName;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolNameS() {
		return schoolNameS;
	}

	public void setSchoolNameS(String schoolNameS) {
		this.schoolNameS = schoolNameS;
	}

	public String getSchoolNameO() {
		return schoolNameO;
	}

	public void setSchoolNameO(String schoolNameO) {
		this.schoolNameO = schoolNameO;
	}

	public String getClassTeacher() {
		return classTeacher;
	}

	public void setClassTeacher(String classTeacher) {
		this.classTeacher = classTeacher;
	}

	public HroomKeyFormBean getHroomKeyFormBean() {
		return hroomKeyFormBean;
	}

	public void setHroomKeyFormBean(HroomKeyFormBean hroomKeyFormBean) {
		this.hroomKeyFormBean = hroomKeyFormBean;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public byte[] getSchoolStampImageDeed() {
		return schoolStampImageDeed;
	}

	public void setSchoolStampImageDeed(byte[] schoolStampImageDeed) {
		this.schoolStampImageDeed = schoolStampImageDeed;
	}

	public Map<String, Data32070000_StudentDetailEntity> getStudentDetailEntityMap() {
		return studentDetailEntityMap;
	}

	public void setStudentDetailEntityMap(Map<String, Data32070000_StudentDetailEntity> studentDetailEntityMap) {
		this.studentDetailEntityMap = studentDetailEntityMap;
	}

	public Map<String, Data32070000_AttendEntity> getAttendEntityMap() {
		return attendEntityMap;
	}

	public void setAttendEntityMap(Map<String, Data32070000_AttendEntity> attendEntityMap) {
		this.attendEntityMap = attendEntityMap;
	}

	public List<Data32070000_ViewPointEntity> getViewPointNameEntityList() {
		return viewPointNameEntityList;
	}

	public void setViewPointNameEntityList(List<Data32070000_ViewPointEntity> viewPointNameEntityList) {
		this.viewPointNameEntityList = viewPointNameEntityList;
	}

	public Map<String, Data32070000_ViewPointEntity> getViewPointScoreMap() {
		return viewPointScoreMap;
	}

	public void setViewPointScoreMap(Map<String, Data32070000_ViewPointEntity> viewPointScoreMap) {
		this.viewPointScoreMap = viewPointScoreMap;
	}

	public List<Data32070000_ActiveEntity> getActiveNameList() {
		return activeNameList;
	}

	public void setActiveNameList(List<Data32070000_ActiveEntity> activeNameList) {
		this.activeNameList = activeNameList;
	}

	public Map<String, Data32070000_ActiveEntity> getActiveEntityMap() {
		return activeEntityMap;
	}

	public void setActiveEntityMap(Map<String, Data32070000_ActiveEntity> activeEntityMap) {
		this.activeEntityMap = activeEntityMap;
	}

	public String getOutputEvalFlg() {
		return outputEvalFlg;
	}

	public void setOutputEvalFlg(String outputEvalFlg) {
		this.outputEvalFlg = outputEvalFlg;
	}

	public String getTotalActViewPoint() {
		return totalActViewPoint;
	}

	public void setTotalActViewPoint(String totalActViewPoint) {
		this.totalActViewPoint = totalActViewPoint;
	}

	public Map<String, List<Data32070000_OtherScoreEntity>> getOtherScoreMap() {
		return otherScoreMap;
	}

	public void setOtherScoreMap(Map<String, List<Data32070000_OtherScoreEntity>> otherScoreMap) {
		this.otherScoreMap = otherScoreMap;
	}

	public String getViewPointEval() {
		return viewPointEval;
	}

	public void setViewPointEval(String viewPointEval) {
		this.viewPointEval = viewPointEval;
	}
}
