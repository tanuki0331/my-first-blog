package jp.co.systemd.tnavi.cus.hakone.formbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32071000_AttendEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32071000_AwardEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32071000_HomeroomHistoryEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32071000_ScorptspeactTitleEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32071000_SpecialActivityEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32071000_TotalactEntity;
import jp.co.systemd.tnavi.cus.hakone.db.entity.Data32071000_ViewpointScoreEntity;

/**
 * <PRE>
 * ���ђʒm�\���(���� ���w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.05.24 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print32071000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���ŏI�w���� */
	private String lastTermName = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C�����t */
	private String endDate = DEFALUT_VALUE;

	/** �\���\���t���O */
	private boolean output_cover;

	/** ���уy�[�W�\���t���O */
	private boolean output_score;

	/** �A���[�y�[�W�\���t���O */
	private boolean output_contact;

	/** �C�����\���t���O */
	private boolean output_deed;

	/** �ʒm�\�^�C�g���C���[�W */
	byte[] schoolStampImage;

	/** �w�Z��C���[�W */
	private byte[] schoolSignImage;

	/** �ʒm�\�a�� */
	private String wareki = DEFALUT_VALUE;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �S�C�� */
	private String teacherName = DEFALUT_VALUE;

	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameS = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameO = DEFALUT_VALUE;

	/** ���k���̐��k��� */
	private List<Data32071000FormBean> dataFormBeanList;

	/** �z�[�����[������ */
	private Map<String, Map<String, Data32071000_HomeroomHistoryEntity>> homeroomHistoryEntityMapMap;

	/** ���ȕʊϓ_�]���E�]����i�[����Map */
	private Map<String,List<List<Data32071000_ViewpointScoreEntity>>> viewpointScoreEntityListListMap;

	/** ���ʊ������ږ����X�g */
	private List<Data32071000_ScorptspeactTitleEntity> scorptspeactTitleList = new ArrayList<Data32071000_ScorptspeactTitleEntity>();

	/** ���ʊ���Map */
	private Map<String,Map<String, Data32071000_SpecialActivityEntity>> specialActivityMap = new HashMap<String, Map<String, Data32071000_SpecialActivityEntity>>();

	/** �����I�Ȋw�K�]�����i�[����Map */
	private Map<String,String> rtavValueMap = new HashMap<String, String>();

	/** �������i�[����Map */
	private Map<String,String> rcomCommentMap = new HashMap<String, String>();

	/** ���ʊ����̋L�^���X�g */
	private List<Data32071000_SpecialActivityEntity> specialActivityEntityList;

	private Map<String,Map<String,String>> spActivityMap;

	/** ���������i�[����Map */
	private Map<String, Map<String, String>> clubActivityMap;

	/** �\���E���̑��̋L�^���X�g */
	private List<Data32071000_AwardEntity> awardEntityList;

	/** �o���̋L�^�̃��X�g */
	private Map<String, List<Data32071000_AttendEntity>> attendEntityListMap;

	/** �����I�Ȋw�K�̎��Ԃ̃��X�g  */
	private List<Data32071000_TotalactEntity> totalactEntityList;

	/** ���ʊ����̋L�^�̍��ڂƕ]�����i�[����Map */
	private Map<String, List<Data32071000_SpecialActivityEntity>> speActEvalListMap;

	/** �]���E�]��̏o�̓t���O */
	private String outputEvalFlg = DEFALUT_VALUE;


	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getLastTermName() {
		return lastTermName;
	}

	public void setLastTermName(String lastTermName) {
		this.lastTermName = lastTermName;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_score() {
		return output_score;
	}

	public void setOutput_score(boolean output_score) {
		this.output_score = output_score;
	}

	public boolean isOutput_contact() {
		return output_contact;
	}

	public void setOutput_contact(boolean output_contact) {
		this.output_contact = output_contact;
	}

	public boolean isOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(boolean output_deed) {
		this.output_deed = output_deed;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public byte[] getSchoolSignImage() {
		return schoolSignImage;
	}

	public void setSchoolSignImage(byte[] schoolSignImage) {
		this.schoolSignImage = schoolSignImage;
	}

	public String getWareki() {
		return wareki;
	}

	public void setWareki(String wareki) {
		this.wareki = wareki;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolNameS() {
		return schoolNameS;
	}

	public void setSchoolNameS(String schoolNameS) {
		this.schoolNameS = schoolNameS;
	}

	public String getSchoolNameO() {
		return schoolNameO;
	}

	public void setSchoolNameO(String schoolNameO) {
		this.schoolNameO = schoolNameO;
	}

	public List<Data32071000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	public void setDataFormBeanList(List<Data32071000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	public Map<String, Map<String, Data32071000_HomeroomHistoryEntity>> getHomeroomHistoryEntityMapMap() {
		return homeroomHistoryEntityMapMap;
	}

	public void setHomeroomHistoryEntityMapMap(
			Map<String, Map<String, Data32071000_HomeroomHistoryEntity>> homeroomHistoryEntityMapMap) {
		this.homeroomHistoryEntityMapMap = homeroomHistoryEntityMapMap;
	}

	public Map<String, List<List<Data32071000_ViewpointScoreEntity>>> getViewpointScoreEntityListListMap() {
		return viewpointScoreEntityListListMap;
	}

	public void setViewpointScoreEntityListListMap(
			Map<String, List<List<Data32071000_ViewpointScoreEntity>>> viewpointScoreEntityListListMap) {
		this.viewpointScoreEntityListListMap = viewpointScoreEntityListListMap;
	}

	public List<Data32071000_ScorptspeactTitleEntity> getScorptspeactTitleList() {
		return scorptspeactTitleList;
	}

	public void setScorptspeactTitleList(List<Data32071000_ScorptspeactTitleEntity> scorptspeactTitleList) {
		this.scorptspeactTitleList = scorptspeactTitleList;
	}

	public Map<String, Map<String, Data32071000_SpecialActivityEntity>> getSpecialActivityMap() {
		return specialActivityMap;
	}

	public void setSpecialActivityMap(Map<String, Map<String, Data32071000_SpecialActivityEntity>> specialActivityMap) {
		this.specialActivityMap = specialActivityMap;
	}

	public Map<String, String> getRtavValueMap() {
		return rtavValueMap;
	}

	public void setRtavValueMap(Map<String, String> rtavValueMap) {
		this.rtavValueMap = rtavValueMap;
	}

	public Map<String, String> getRcomCommentMap() {
		return rcomCommentMap;
	}

	public void setRcomCommentMap(Map<String, String> rcomCommentMap) {
		this.rcomCommentMap = rcomCommentMap;
	}

	public List<Data32071000_SpecialActivityEntity> getSpecialActivityEntityList() {
		return specialActivityEntityList;
	}

	public void setSpecialActivityEntityList(List<Data32071000_SpecialActivityEntity> specialActivityEntityList) {
		this.specialActivityEntityList = specialActivityEntityList;
	}

	public Map<String, Map<String, String>> getSpActivityMap() {
		return spActivityMap;
	}

	public void setSpActivityMap(Map<String, Map<String, String>> spActivityMap) {
		this.spActivityMap = spActivityMap;
	}

	public Map<String, Map<String, String>> getClubActivityMap() {
		return clubActivityMap;
	}

	public void setClubActivityMap(Map<String, Map<String, String>> clubActivityMap) {
		this.clubActivityMap = clubActivityMap;
	}

	public List<Data32071000_AwardEntity> getAwardEntityList() {
		return awardEntityList;
	}

	public void setAwardEntityList(List<Data32071000_AwardEntity> awardEntityList) {
		this.awardEntityList = awardEntityList;
	}

	public Map<String, List<Data32071000_AttendEntity>> getAttendEntityListMap() {
		return attendEntityListMap;
	}

	public void setAttendEntityListMap(Map<String, List<Data32071000_AttendEntity>> attendEntityListMap) {
		this.attendEntityListMap = attendEntityListMap;
	}

	public List<Data32071000_TotalactEntity> getTotalactEntityList() {
		return totalactEntityList;
	}

	public void setTotalactEntityList(List<Data32071000_TotalactEntity> totalactEntityList) {
		this.totalactEntityList = totalactEntityList;
	}

	public Map<String, List<Data32071000_SpecialActivityEntity>> getSpeActEvalListMap() {
		return speActEvalListMap;
	}

	public void setSpeActEvalListMap(Map<String, List<Data32071000_SpecialActivityEntity>> speActEvalListMap) {
		this.speActEvalListMap = speActEvalListMap;
	}

	public String getOutputEvalFlg() {
		return outputEvalFlg;
	}

	public void setOutputEvalFlg(String outputEvalFlg) {
		this.outputEvalFlg = outputEvalFlg;
	}


}
