package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �����I�Ȋw�K�̎��Ԃ̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.25 BY aivick <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_TotalactEntity {

	/** �w�K���� */
	private String rtat_act = "";
	/** �ϓ_ */
	private String rtat_pointview = "";

	public String getRtat_act() {
		return rtat_act;
	}
	public void setRtat_act(String rtat_act) {
		this.rtat_act = rtat_act;
	}
	public String getRtat_pointview() {
		return rtat_pointview;
	}
	public void setRtat_pointview(String rtat_pointview) {
		this.rtat_pointview = rtat_pointview;
	}
}
