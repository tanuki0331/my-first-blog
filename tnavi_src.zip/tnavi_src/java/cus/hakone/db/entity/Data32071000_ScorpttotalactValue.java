package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �w�K�̕]��(�ʒm�\)Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.25 BY aivick <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_ScorpttotalactValue {

	/**
	 * �w�Дԍ�
	 */
	private String rtav_stucode;
	/**
	 * �l
	 */
	private String rtav_value;
	public String getRtav_stucode() {
		return rtav_stucode;
	}
	public void setRtav_stucode(String rtav_stucode) {
		this.rtav_stucode = rtav_stucode;
	}
	public String getRtav_value() {
		return rtav_value;
	}
	public void setRtav_value(String rtav_value) {
		this.rtav_value = rtav_value;
	}
}
