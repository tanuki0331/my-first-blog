package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �z�[�����[�������̏o��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.04.17 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_HomeroomHistoryEntity {

    /**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �w�N
	 */
	private String cls_glade;

	/**
	 * �g
	 */
	private String hmr_class;

	/**
	 * �o�Ȕԍ�
	 */
	private String cls_number;



	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_glade() {
		return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public String getHmr_class() {
		return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}


}
