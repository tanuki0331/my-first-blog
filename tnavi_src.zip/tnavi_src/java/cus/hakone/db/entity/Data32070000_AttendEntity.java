package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �o�����擾 Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.24 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32070000_AttendEntity {

	/** �w�Дԍ� */
	private String att_stucode;

	/** �Ώی� */
	private String enf_month;

	/** ���Ɠ��� */
	private String enf_count;

	/** �o�Ȓ�~�E���� */
	private String att_stop;

	/** �o�Ȃ��ׂ����� */
	private String att_must;

	/** ���ȓ��� */
	private String absencecount;

	/** �o�ȓ��� */
	private String att_attend;

	public String getAtt_stucode() {
		return att_stucode;
	}

	public void setAtt_stucode(String att_stucode) {
		this.att_stucode = att_stucode;
	}

	public String getEnf_month() {
		return enf_month;
	}

	public void setEnf_month(String enf_month) {
		this.enf_month = enf_month;
	}

	public String getEnf_count() {
		return enf_count;
	}

	public void setEnf_count(String enf_count) {
		this.enf_count = enf_count;
	}

	public String getAtt_stop() {
		return att_stop;
	}

	public void setAtt_stop(String att_stop) {
		this.att_stop = att_stop;
	}

	public String getAtt_must() {
		return att_must;
	}

	public void setAtt_must(String att_must) {
		this.att_must = att_must;
	}

	public String getAbsencecount() {
		return absencecount;
	}

	public void setAbsencecount(String absencecount) {
		this.absencecount = absencecount;
	}

	public String getAtt_attend() {
		return att_attend;
	}

	public void setAtt_attend(String att_attend) {
		this.att_attend = att_attend;
	}
}
