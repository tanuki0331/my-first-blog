package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �w���A�S�C�����擾 Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.23 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32070000_HRoomTeacherEntity {

	/** �����R�[�h */
	private String hmr_user;

	/** �N�x */
	private String hmr_year;

	/** �w�N */
	private String hmr_glade;

	/** �g */
	private String hmr_class;

	/** �N���X���[��No */
	private String hmr_clsno;

	/** �z�[�����[���� */
	private String hmr_name;

	/** �����R�[�h�i�S�C�j */
	private String hmr_stfcodem;

	/** ���������i�S�C�j */
	private String stf_name_w;

	/** �����ӂ肪�ȁi�S�C�j */
	private String stf_kana;

	/** �S�C������ */
	private String his_stfno;

	/** �A�C�� */
	private String stfh_start;

	/** �ޔC�� */
	private String stfh_end;

	public String getHmr_user() {
		return hmr_user;
	}

	public void setHmr_user(String hmr_user) {
		this.hmr_user = hmr_user;
	}

	public String getHmr_year() {
		return hmr_year;
	}

	public void setHmr_year(String hmr_year) {
		this.hmr_year = hmr_year;
	}

	public String getHmr_glade() {
		return hmr_glade;
	}

	public void setHmr_glade(String hmr_glade) {
		this.hmr_glade = hmr_glade;
	}

	public String getHmr_class() {
		return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	public String getHmr_clsno() {
		return hmr_clsno;
	}

	public void setHmr_clsno(String hmr_clsno) {
		this.hmr_clsno = hmr_clsno;
	}

	public String getHmr_name() {
		return hmr_name;
	}

	public void setHmr_name(String hmr_name) {
		this.hmr_name = hmr_name;
	}

	public String getHmr_stfcodem() {
		return hmr_stfcodem;
	}

	public void setHmr_stfcodem(String hmr_stfcodem) {
		this.hmr_stfcodem = hmr_stfcodem;
	}

	public String getStf_name_w() {
		return stf_name_w;
	}

	public void setStf_name_w(String stf_name_w) {
		this.stf_name_w = stf_name_w;
	}

	public String getStf_kana() {
		return stf_kana;
	}

	public void setStf_kana(String stf_kana) {
		this.stf_kana = stf_kana;
	}

	public String getHis_stfno() {
		return his_stfno;
	}

	public void setHis_stfno(String his_stfno) {
		this.his_stfno = his_stfno;
	}

	public String getStfh_start() {
		return stfh_start;
	}

	public void setStfh_start(String stfh_start) {
		this.stfh_start = stfh_start;
	}

	public String getStfh_end() {
		return stfh_end;
	}

	public void setStfh_end(String stfh_end) {
		this.stfh_end = stfh_end;
	}
}
