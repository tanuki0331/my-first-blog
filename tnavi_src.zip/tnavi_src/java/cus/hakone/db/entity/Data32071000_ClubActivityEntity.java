package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �N���u�����̋L�^�̏o��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.09 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_ClubActivityEntity {

    /**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �N���X�ԍ�
	 */
	private String cls_number;

	/**
	 * �C��
	 */
	private String term;

	/**
	 * ��������
	 */
	private String ext_name;

	/**
	 * ��E��
	 */
	private String pst_name;


	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getExt_name() {
		return ext_name;
	}

	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}

	public String getPst_name() {
		return pst_name;
	}

	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}



}
