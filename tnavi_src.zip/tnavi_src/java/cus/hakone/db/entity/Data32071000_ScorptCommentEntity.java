package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * ����Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.25 BY aivick <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_ScorptCommentEntity {

	/**
	 * �w�Дԍ�
	 */
	private String rcom_stucode = "";
	/**
	 * �������e
	 */
	private String rcom_comment = "";

	public String getRcom_stucode() {
		return rcom_stucode;
	}
	public void setRcom_stucode(String rcom_stucode) {
		this.rcom_stucode = rcom_stucode;
	}
	public String getRcom_comment() {
		return rcom_comment;
	}
	public void setRcom_comment(String rcom_comment) {
		this.rcom_comment = rcom_comment;
	}

}
