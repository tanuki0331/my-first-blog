package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �s���̋L�^�擾 Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.27 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32070000_ActiveEntity {

	/** �w�Дԍ� */
	private String ravv_stucode;

	/** �o�͎����R�[�h */
	private String ravt_term;

	/** �ϓ_�R�[�h */
	private String ravt_ravtcode;

	/** �ϓ_���� */
	private String ravt_ravtname;

	/** �ϓ_�̎�|�E�w�K�̂߂��� */
	private String ravt_purpose	;

	/** �]���l�R�[�h */
	private String ravv_racecode;

	/** �]���l(�ʒm�\�\���p) */
	private String race_reportdisplay;

	public String getRavv_stucode() {
		return ravv_stucode;
	}

	public void setRavv_stucode(String ravv_stucode) {
		this.ravv_stucode = ravv_stucode;
	}

	public String getRavt_term() {
		return ravt_term;
	}

	public void setRavt_term(String ravt_term) {
		this.ravt_term = ravt_term;
	}

	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}

	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}

	public String getRavt_ravtname() {
		return ravt_ravtname;
	}

	public void setRavt_ravtname(String ravt_ravtname) {
		this.ravt_ravtname = ravt_ravtname;
	}

	public String getRavt_purpose() {
		return ravt_purpose;
	}

	public void setRavt_purpose(String ravt_purpose) {
		this.ravt_purpose = ravt_purpose;
	}

	public String getRavv_racecode() {
		return ravv_racecode;
	}

	public void setRavv_racecode(String ravv_racecode) {
		this.ravv_racecode = ravv_racecode;
	}

	public String getRace_reportdisplay() {
		return race_reportdisplay;
	}

	public void setRace_reportdisplay(String race_reportdisplay) {
		this.race_reportdisplay = race_reportdisplay;
	}
}
