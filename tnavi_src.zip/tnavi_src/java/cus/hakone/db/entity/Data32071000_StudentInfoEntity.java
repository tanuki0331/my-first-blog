package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * ���k���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.09 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_StudentInfoEntity {

	/**
	 * �w�Дԍ�
	 */
	private String stu_stucode;

	/**
	 * ���k����
	 */
	private String st4_name;

	/**
	 * �w�N
	 */
	private String cls_glade;

	/**
	 * �g
	 */
	private String hmr_class;

	/**
	 * ��
	 */
	private String cls_number;

	/**
	 * ���N����
	 */
	private String stu_birth;

	/**
	 * @return the stu_stucode
	 */
	public String getStu_stucode() {
		return stu_stucode;
	}

	/**
	 * @param stu_stucode the stu_stucode to set
	 */
	public void setStu_stucode(String stu_stucode) {
		this.stu_stucode = stu_stucode;
	}

	/**
	 * @return the st4_name
	 */
	public String getSt4_name() {
		return st4_name;
	}

	/**
	 * @param stu_name the st4_name to set
	 */
	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	/**
	 * @return the cls_glade
	 */
	public String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade the cls_glade to set
	 */
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return the hmr_class
	 */
	public String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class the hmr_class to set
	 */
	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return the cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number the cls_number to set
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getStu_birth() {
		return stu_birth;
	}

	public void setStu_birth(String stu_birth) {
		this.stu_birth = stu_birth;
	}

}
