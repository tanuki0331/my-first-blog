package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * ���ʊ����̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.09 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_SpecialActivityEntity {

    /**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �]������
	 */
	private String rsat_term;

	/**
	 * ���ʊ���ID
	 */
	private String rsat_rsatcode;

	/**
	 * ���ʊ�������
	 */
	private String rsat_rsatname;

	/**
	 * ���ʊ����̋L�^
	 */
	private String rsav_record;

	/**
	 * ���ʊ����̋L�^�]���l�\���p�̒l
	 */
	private String rsae_display;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getRsat_term() {
		return rsat_term;
	}

	public void setRsat_term(String rsat_term) {
		this.rsat_term = rsat_term;
	}

	public String getRsat_rsatcode() {
		return rsat_rsatcode;
	}

	public void setRsat_rsatcode(String rsat_rsatcode) {
		this.rsat_rsatcode = rsat_rsatcode;
	}

	public String getRsat_rsatname() {
		return rsat_rsatname;
	}

	public void setRsat_rsatname(String rsat_rsatname) {
		this.rsat_rsatname = rsat_rsatname;
	}

	public String getRsav_record() {
		return rsav_record;
	}

	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}

	public String getRsae_display() {
		return rsae_display;
	}

	public void setRsae_display(String rsae_display) {
		this.rsae_display = rsae_display;
	}


}
