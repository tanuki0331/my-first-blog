package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �o���̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.09 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_AttendEntity {

	/**
	 * �w�N
	 */
	private String cls_glade;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �o�Ȕԍ�
	 */
	private String cls_number;

	/**
	 * ��
	 */
	private String enf_month;;

	/**
	 * ���Ɠ���
	 */
	private Integer classcount;

	/**
	 * �o�Ȓ�~�i�o�Ȓ�~�E���������̓����j
	 */
	private Integer schoolkindcount;

	/**
	 * �o�Ȃ��ׂ�����
	 */
	private Integer mustcount;

	/**
	 * ���ȓ���
	 */
	private Integer absencecount;

	/**
	 * �o�ȓ���
	 */
	private Integer attendcount;

	/**
     * �x��
     */
    private Integer latecount;


    /**
     * ����
     */
    private Integer leavecount;

    /**
     * ���l
     */
    private String rarm_memo;


	public String getCls_glade() {
		return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getEnf_month() {
		return enf_month;
	}

	public void setEnf_month(String enf_month) {
		this.enf_month = enf_month;
	}

	public Integer getClasscount() {
		return classcount;
	}

	public void setClasscount(Integer classcount) {
		this.classcount = classcount;
	}

	public Integer getSchoolkindcount() {
		return schoolkindcount;
	}

	public void setSchoolkindcount(Integer schoolkindcount) {
		this.schoolkindcount = schoolkindcount;
	}

	public Integer getMustcount() {
		return mustcount;
	}

	public void setMustcount(Integer mustcount) {
		this.mustcount = mustcount;
	}

	public Integer getAbsencecount() {
		return absencecount;
	}

	public void setAbsencecount(Integer absencecount) {
		this.absencecount = absencecount;
	}

	public Integer getAttendcount() {
		return attendcount;
	}

	public void setAttendcount(Integer attendcount) {
		this.attendcount = attendcount;
	}

	public Integer getLatecount() {
		return latecount;
	}

	public void setLatecount(Integer latecount) {
		this.latecount = latecount;
	}

	public Integer getLeavecount() {
		return leavecount;
	}

	public void setLeavecount(Integer leavecount) {
		this.leavecount = leavecount;
	}

	public String getRarm_memo() {
		return rarm_memo;
	}

	public void setRarm_memo(String rarm_memo) {
		this.rarm_memo = rarm_memo;
	}




}
