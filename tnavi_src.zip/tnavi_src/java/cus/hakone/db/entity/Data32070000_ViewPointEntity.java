package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �ϓ_���ꗗ�擾 Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.27 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32070000_ViewPointEntity {

	/* ���� */
	/** ���ȃR�[�h */
	private String item_code;

	/**���Ȗ��� */
	private String item_name;

	/** �ϓ_�R�[�h */
	private String rivt_rivtcode;

	/** �ϓ_���� */
	private String rivt_rivtname;



	/* �ϓ_�� */
	/** �Ώۊw�N */
	private String gst_grade;

	/** �w�N�� */
	private String grade_pattun;

	/** �ϓ_���� */
	private String rivt_rivtname2;

	/** �ϓ_�̎�|�E�w�K�̂߂��� */
	private String rivt_purpose;

	/** �\���� */
	private String rivt_order;

	/** ���ȃR�[�h�i���j */
	private String item_code_r;



	/* �ϓ_�E�]�萬�� */
	/** �N�x */
	private String cls_year;

	/** �w�Дԍ� */
	private String cls_stucode;

	/** �w�N */
	private String cls_glade;

	/** �N���X�ԍ� */
	private String cls_clsno;

	/** �g */
	private String hmr_class;

	/** �o�Ȕԍ� */
	private String cls_number;

	/** ���k�����ʏ� */
	private String st4_name;

	/** ���k�����ː� */
	private String st4_name_r;

	/** �]�������R�[�h */
	private String gopt_goptcode;

	/** �]���������� */
	private String gopt_name;

	/** ���� */
	private String item_name2;

	/** ���ȕ��я� */
	private String item_order;

	/** �]��R�[�h */
	private String rev_manualscorpteval;

	/** �]��\���l */
	private String revl_display;

	/** �]���s�\�t���O   �W�v�̍ۂɍl���i�d�l�ɂ��j */
	private String revl_cannot_flg;

	/** �]�������{�t���O �W�v�̍ۂɍl���i�d�l�ɂ��j */
	private String revl_none_flg;

	/** �]���R�[�h */
	private String rvpv_manualrevpecode;

	/** �]���\���� */
	private String rvpe_display;

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getRivt_rivtcode() {
		return rivt_rivtcode;
	}

	public void setRivt_rivtcode(String rivt_rivtcode) {
		this.rivt_rivtcode = rivt_rivtcode;
	}

	public String getRivt_rivtname() {
		return rivt_rivtname;
	}

	public void setRivt_rivtname(String rivt_rivtname) {
		this.rivt_rivtname = rivt_rivtname;
	}

	public String getGst_grade() {
		return gst_grade;
	}

	public void setGst_grade(String gst_grade) {
		this.gst_grade = gst_grade;
	}

	public String getGrade_pattun() {
		return grade_pattun;
	}

	public void setGrade_pattun(String grade_pattun) {
		this.grade_pattun = grade_pattun;
	}

	public String getRivt_rivtname2() {
		return rivt_rivtname2;
	}

	public void setRivt_rivtname2(String rivt_rivtname2) {
		this.rivt_rivtname2 = rivt_rivtname2;
	}

	public String getRivt_purpose() {
		return rivt_purpose;
	}

	public void setRivt_purpose(String rivt_purpose) {
		this.rivt_purpose = rivt_purpose;
	}

	public String getRivt_order() {
		return rivt_order;
	}

	public void setRivt_order(String rivt_order) {
		this.rivt_order = rivt_order;
	}

	public String getItem_code_r() {
		return item_code_r;
	}

	public void setItem_code_r(String item_code_r) {
		this.item_code_r = item_code_r;
	}

	public String getCls_year() {
		return cls_year;
	}

	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_glade() {
		return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public String getCls_clsno() {
		return cls_clsno;
	}

	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}

	public String getHmr_class() {
		return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getSt4_name() {
		return st4_name;
	}

	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public String getSt4_name_r() {
		return st4_name_r;
	}

	public void setSt4_name_r(String st4_name_r) {
		this.st4_name_r = st4_name_r;
	}

	public String getGopt_goptcode() {
		return gopt_goptcode;
	}

	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}

	public String getGopt_name() {
		return gopt_name;
	}

	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}

	public String getItem_name2() {
		return item_name2;
	}

	public void setItem_name2(String item_name2) {
		this.item_name2 = item_name2;
	}

	public String getItem_order() {
		return item_order;
	}

	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	public String getRev_manualscorpteval() {
		return rev_manualscorpteval;
	}

	public void setRev_manualscorpteval(String rev_manualscorpteval) {
		this.rev_manualscorpteval = rev_manualscorpteval;
	}

	public String getRevl_display() {
		return revl_display;
	}

	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}

	public String getRevl_cannot_flg() {
		return revl_cannot_flg;
	}

	public void setRevl_cannot_flg(String revl_cannot_flg) {
		this.revl_cannot_flg = revl_cannot_flg;
	}

	public String getRevl_none_flg() {
		return revl_none_flg;
	}

	public void setRevl_none_flg(String revl_none_flg) {
		this.revl_none_flg = revl_none_flg;
	}

	public String getRvpv_manualrevpecode() {
		return rvpv_manualrevpecode;
	}

	public void setRvpv_manualrevpecode(String rvpv_manualrevpecode) {
		this.rvpv_manualrevpecode = rvpv_manualrevpecode;
	}

	public String getRvpe_display() {
		return rvpe_display;
	}

	public void setRvpe_display(String rvpe_display) {
		this.rvpe_display = rvpe_display;
	}
}
