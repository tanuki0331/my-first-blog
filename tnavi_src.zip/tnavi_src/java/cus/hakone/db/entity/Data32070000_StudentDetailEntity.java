package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * ���k���擾 Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.24 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32070000_StudentDetailEntity {

	/** �N�x */
	private String cls_year;

	/** �w�Дԍ� */
	private String stuStucode;

	/** �w�N */
	private String cls_glade;

	/** �N���X�ԍ� */
	private String cls_clsno;

	/** �g */
	private String hmr_class;

	/** �o�Ȕԍ� */
	private String cls_number;

	/** �����ԍ� */
	private String stuNumber;

	/** ���k�����ʏ� */
	private String stuStuname;

	/** ���k�����ː� */
	private String st4_name_r;

	public String getCls_year() {
		return cls_year;
	}

	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	public String getStuStucode() {
		return stuStucode;
	}

	public void setStuStucode(String stuStucode) {
		this.stuStucode = stuStucode;
	}

	public String getCls_glade() {
		return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public String getCls_clsno() {
		return cls_clsno;
	}

	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}

	public String getHmr_class() {
		return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getStuNumber() {
		return stuNumber;
	}

	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getStuStuname() {
		return stuStuname;
	}

	public void setStuStuname(String stuStuname) {
		this.stuStuname = stuStuname;
	}

	public String getSt4_name_r() {
		return st4_name_r;
	}

	public void setSt4_name_r(String st4_name_r) {
		this.st4_name_r = st4_name_r;
	}
}
