package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * ���k���擾 Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.24 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32070000_OtherScoreEntity {


	/* �����I�Ȋw�K�̊ϓ_ */
	/** �w�K���� */
	private String rtat_act;

	/** �����I�Ȋw�K�̊ϓ_ */
	private String rtat_pointview;




	/* ���̑��̐��� */
	/** �����R�[�h */
	private String cls_user;

	/** �N�x */
	private String cls_year;

	/** �z�[�����[���ԍ� */
	private String cls_clsno;

	/** �w�N */
	private String cls_glade;

	/** �g */
	private String hmr_class;

	/** �� */
	private String cls_number;

	/** �z�[�����[������ */
	private String hmr_name;

	/** �w�Дԍ� */
	private String st4_stucode;

	/** ���k�� */
	private String st4_name;

	/** �����R�[�h */
	private String gopt_goptcode;

	/** ������ */
	private String gopt_name;

	/** ���ʊ����R�[�h(�A��) */
	private String rsat_rsatcode;

	/** ���ʊ����s�����e */
	private String rsat_rsatname;

	/** ���ʊ����s������ */
	private String rsat_rsatname2;

	/** ���ʊ����s���ϓ_ */
	private String rsat_pointview;

	/** �����R�[�h */
	private String rsav_rsatcode;

	/** ������ */
	private String rsav_record;

	/** �]���R�[�h */
	private String rsav_rsaecode;

	/** �]�����e */
	private String rsae_display;

	/** �����w�K�̓��e */
	private String rtav_contents;

	/** �����w�K�̕]�� */
	private String rtav_value;

	/** �O���ꊈ���̋L�^�]�� */
	private String rfla_eval;

	/** �w�K�Ɛ����̗l�q */
	private String rcom_comment;

	public String getRtat_act() {
		return rtat_act;
	}

	public void setRtat_act(String rtat_act) {
		this.rtat_act = rtat_act;
	}

	public String getRtat_pointview() {
		return rtat_pointview;
	}

	public void setRtat_pointview(String rtat_pointview) {
		this.rtat_pointview = rtat_pointview;
	}

	public String getCls_user() {
		return cls_user;
	}

	public void setCls_user(String cls_user) {
		this.cls_user = cls_user;
	}

	public String getCls_year() {
		return cls_year;
	}

	public void setCls_year(String cls_year) {
		this.cls_year = cls_year;
	}

	public String getCls_clsno() {
		return cls_clsno;
	}

	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}

	public String getCls_glade() {
		return cls_glade;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public String getHmr_class() {
		return hmr_class;
	}

	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getHmr_name() {
		return hmr_name;
	}

	public void setHmr_name(String hmr_name) {
		this.hmr_name = hmr_name;
	}

	public String getSt4_stucode() {
		return st4_stucode;
	}

	public void setSt4_stucode(String st4_stucode) {
		this.st4_stucode = st4_stucode;
	}

	public String getSt4_name() {
		return st4_name;
	}

	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public String getGopt_goptcode() {
		return gopt_goptcode;
	}

	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}

	public String getGopt_name() {
		return gopt_name;
	}

	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}

	public String getRsat_rsatcode() {
		return rsat_rsatcode;
	}

	public void setRsat_rsatcode(String rsat_rsatcode) {
		this.rsat_rsatcode = rsat_rsatcode;
	}

	public String getRsat_rsatname() {
		return rsat_rsatname;
	}

	public void setRsat_rsatname(String rsat_rsatname) {
		this.rsat_rsatname = rsat_rsatname;
	}

	public String getRsat_rsatname2() {
		return rsat_rsatname2;
	}

	public void setRsat_rsatname2(String rsat_rsatname2) {
		this.rsat_rsatname2 = rsat_rsatname2;
	}

	public String getRsat_pointview() {
		return rsat_pointview;
	}

	public void setRsat_pointview(String rsat_pointview) {
		this.rsat_pointview = rsat_pointview;
	}

	public String getRsav_rsatcode() {
		return rsav_rsatcode;
	}

	public void setRsav_rsatcode(String rsav_rsatcode) {
		this.rsav_rsatcode = rsav_rsatcode;
	}

	public String getRsav_record() {
		return rsav_record;
	}

	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}

	public String getRsav_rsaecode() {
		return rsav_rsaecode;
	}

	public void setRsav_rsaecode(String rsav_rsaecode) {
		this.rsav_rsaecode = rsav_rsaecode;
	}

	public String getRsae_display() {
		return rsae_display;
	}

	public void setRsae_display(String rsae_display) {
		this.rsae_display = rsae_display;
	}

	public String getRtav_contents() {
		return rtav_contents;
	}

	public void setRtav_contents(String rtav_contents) {
		this.rtav_contents = rtav_contents;
	}

	public String getRtav_value() {
		return rtav_value;
	}

	public void setRtav_value(String rtav_value) {
		this.rtav_value = rtav_value;
	}

	public String getRfla_eval() {
		return rfla_eval;
	}

	public void setRfla_eval(String rfla_eval) {
		this.rfla_eval = rfla_eval;
	}

	public String getRcom_comment() {
		return rcom_comment;
	}

	public void setRcom_comment(String rcom_comment) {
		this.rcom_comment = rcom_comment;
	}
}
