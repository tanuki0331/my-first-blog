package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * ���ʊ����̋L�^���e�}�X�^(�ʒm�\)Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.25 BY aivick <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_ScorptspeactTitleEntity {

	/**
	 * ID
	 */
	private String rsat_rsatcode = "";
	/**
	 * ���e
	 */
	private String rsat_rsatname = "";

	public String getRsat_rsatcode() {
		return rsat_rsatcode;
	}
	public void setRsat_rsatcode(String rsat_rsatcode) {
		this.rsat_rsatcode = rsat_rsatcode;
	}
	public String getRsat_rsatname() {
		return rsat_rsatname;
	}
	public void setRsat_rsatname(String rsat_rsatname) {
		this.rsat_rsatname = rsat_rsatname;
	}



}
