package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * �w�Z�����A�Z�������擾 Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.05.23 BY AIVICK takeuchi <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32070000_SchoolAndPrincipalEntity {

	/** �����R�[�h */
	private String useh_user;

	/** �N�x */
	private String useh_year;

	/** �w�Z�� */
	private String useh_name_o;

	/** �����R�[�h�i�Z���j*/
	private String prh_staffcode;

	/** ���������i�Z���j*/
	private String prh_name;

	/** �����ӂ肪�ȁi�Z���j*/
	private String prh_kana;

	/** �A�C�J�n�� */
	private String prh_start;

	/** �A�C�C���� */
	private String prh_end;


	public String getUseh_user() {
		return useh_user;
	}

	public void setUseh_user(String useh_user) {
		this.useh_user = useh_user;
	}

	public String getUseh_year() {
		return useh_year;
	}

	public void setUseh_year(String useh_year) {
		this.useh_year = useh_year;
	}

	public String getUseh_name_o() {
		return useh_name_o;
	}

	public void setUseh_name_o(String useh_name_o) {
		this.useh_name_o = useh_name_o;
	}

	public String getPrh_staffcode() {
		return prh_staffcode;
	}

	public void setPrh_staffcode(String prh_staffcode) {
		this.prh_staffcode = prh_staffcode;
	}

	public String getPrh_name() {
		return prh_name;
	}

	public void setPrh_name(String prh_name) {
		this.prh_name = prh_name;
	}

	public String getPrh_kana() {
		return prh_kana;
	}

	public void setPrh_kana(String prh_kana) {
		this.prh_kana = prh_kana;
	}

	public String getPrh_start() {
		return prh_start;
	}

	public void setPrh_start(String prh_start) {
		this.prh_start = prh_start;
	}

	public String getPrh_end() {
		return prh_end;
	}

	public void setPrh_end(String prh_end) {
		this.prh_end = prh_end;
	}
}
