package jp.co.systemd.tnavi.cus.hakone.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.12.09 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32071000_ViewpointScoreEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * ���ȃR�[�h
	 */
	private String item_code;

	/**
	 * ���Ȗ���
	 */
	private String cod_name1;

	/**
	 * �\����
	 */
	private String item_order;

	/**
	 * �ϓ_����
	 */
	private String rivt_rivtname;

	/**
	 * ���Ȋϓ_
	 */
	private String rivt_purpose;

	/**
	 * �]��
	 */
	private String rvpe_reportdisplay;

	/**
	 * �]��
	 */
	private String revl_display;


	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getCod_name1() {
		return cod_name1;
	}

	public void setCod_name1(String cod_name1) {
		this.cod_name1 = cod_name1;
	}

	public String getItem_order() {
		return item_order;
	}

	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	public String getRivt_rivtname() {
		return rivt_rivtname;
	}

	public void setRivt_rivtname(String rivt_rivtname) {
		this.rivt_rivtname = rivt_rivtname;
	}

	public String getRivt_purpose() {
		return rivt_purpose;
	}

	public void setRivt_purpose(String rivt_purpose) {
		this.rivt_purpose = rivt_purpose;
	}

	public String getRvpe_reportdisplay() {
		return rvpe_reportdisplay;
	}

	public void setRvpe_reportdisplay(String rvpe_reportdisplay) {
		this.rvpe_reportdisplay = rvpe_reportdisplay;
	}

	public String getRevl_display() {
		return revl_display;
	}

	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}





}
