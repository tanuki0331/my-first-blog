/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2018 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.db.entity;


/**
 * <PRE>
 *  ��������(�w���v�^)(�������S���w�Z) �������̈��p��� Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Quote32155000Ajax_ClubEntity {


	/** �w�Дԍ� */
	private String cls_stucode;

	/** �ۊO�����R�[�h */
	private String ext_code;

	/** �������� */
	private String ext_name;

	/** ������ */
	private String clb_start;

	/** �ޕ��� */
	private String clb_stop;

	/** �ł��Â��ޕ��� */
	private String oldest_stop_date;


	/** ��E�� */
	private String pst_name;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getExt_code() {
		return ext_code;
	}

	public void setExt_code(String ext_code) {
		this.ext_code = ext_code;
	}

	public String getExt_name() {
		return ext_name;
	}

	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}

	public String getClb_start() {
		return clb_start;
	}

	public void setClb_start(String clb_start) {
		this.clb_start = clb_start;
	}

	public String getClb_stop() {
		return clb_stop;
	}

	public void setClb_stop(String clb_stop) {
		this.clb_stop = clb_stop;
	}

	public String getPst_name() {
		return pst_name;
	}

	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}

	public String getOldest_stop_date() {
		return oldest_stop_date;
	}

	public void setOldest_stop_date(String oldest_stop_date) {
		this.oldest_stop_date = oldest_stop_date;
	}



}
