/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2018 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.db.entity;


/**
 * <PRE>
 *  ��������(�w���v�^)(�������S���w�Z) ���ʊ����̎Q�l��� Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32155000Ajax_ClubEntity {


	/** ������ */
	private String clb_start;

	/** �ޕ��� */
	private String clb_stop;

	/** �������� */
	private String ext_name;

	/** ��E�� */
	private String pst_name;

	/** �\���p�f�[�^ */
	private String disp_data;

	public String getClb_start() {
		return clb_start;
	}

	public void setClb_start(String clb_start) {
		this.clb_start = clb_start;
	}

	public String getClb_stop() {
		return clb_stop;
	}

	public void setClb_stop(String clb_stop) {
		this.clb_stop = clb_stop;
	}

	public String getExt_name() {
		return ext_name;
	}

	public void setExt_name(String ext_name) {
		this.ext_name = ext_name;
	}

	public String getPst_name() {
		return pst_name;
	}

	public void setPst_name(String pst_name) {
		this.pst_name = pst_name;
	}

	public String getDisp_data() {
		return disp_data;
	}

	public void setDisp_data(String disp_data) {
		this.disp_data = disp_data;
	}


}
