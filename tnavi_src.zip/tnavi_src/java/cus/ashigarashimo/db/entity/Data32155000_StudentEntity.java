/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2018 SystemD inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.db.entity;


/**
 * <PRE>
 *  ��������(�w���v�^)(�������S���w�Z) ���k�ꗗEntity.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data32155000_StudentEntity {


	/** �w�Дԍ� */
	private String cls_stucode;

	/** �o�Ȕԍ� */
	private String cls_number;

	/** ���k���� */
	private String st4_name;

	/** �w�������F�O�� */
	private String gcom_splitcomment1;

	/** �w�������F��� */
	private String gcom_splitcomment2;

	/** ���k����F�O�� */
	private String gcom_splitcomment3;

	/** ���k����F��� */
	private String gcom_splitcomment4;

	/** �w�Z�s���F�O�� */
	private String gcom_splitcomment5;

	/** �w�Z�s���F��� */
	private String gcom_splitcomment6;

	/** �������� */
	private String gcom_splitcomment7;

	/** ������ */
	private String gcom_splitcomment8;

	/** �\���̋L�^ */
	private String gcom_splitcomment9;



	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getCls_number() {
		return cls_number;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public String getSt4_name() {
		return st4_name;
	}

	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public String getGcom_splitcomment1() {
		return gcom_splitcomment1;
	}

	public void setGcom_splitcomment1(String gcom_splitcomment1) {
		this.gcom_splitcomment1 = gcom_splitcomment1;
	}

	public String getGcom_splitcomment2() {
		return gcom_splitcomment2;
	}

	public void setGcom_splitcomment2(String gcom_splitcomment2) {
		this.gcom_splitcomment2 = gcom_splitcomment2;
	}

	public String getGcom_splitcomment3() {
		return gcom_splitcomment3;
	}

	public void setGcom_splitcomment3(String gcom_splitcomment3) {
		this.gcom_splitcomment3 = gcom_splitcomment3;
	}

	public String getGcom_splitcomment4() {
		return gcom_splitcomment4;
	}

	public void setGcom_splitcomment4(String gcom_splitcomment4) {
		this.gcom_splitcomment4 = gcom_splitcomment4;
	}

	public String getGcom_splitcomment5() {
		return gcom_splitcomment5;
	}

	public void setGcom_splitcomment5(String gcom_splitcomment5) {
		this.gcom_splitcomment5 = gcom_splitcomment5;
	}

	public String getGcom_splitcomment6() {
		return gcom_splitcomment6;
	}

	public void setGcom_splitcomment6(String gcom_splitcomment6) {
		this.gcom_splitcomment6 = gcom_splitcomment6;
	}

	public String getGcom_splitcomment7() {
		return gcom_splitcomment7;
	}

	public void setGcom_splitcomment7(String gcom_splitcomment7) {
		this.gcom_splitcomment7 = gcom_splitcomment7;
	}

	public String getGcom_splitcomment8() {
		return gcom_splitcomment8;
	}

	public void setGcom_splitcomment8(String gcom_splitcomment8) {
		this.gcom_splitcomment8 = gcom_splitcomment8;
	}

	public String getGcom_splitcomment9() {
		return gcom_splitcomment9;
	}

	public void setGcom_splitcomment9(String gcom_splitcomment9) {
		this.gcom_splitcomment9 = gcom_splitcomment9;
	}




}
