/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2018 SystemD Inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.db.entity;

/**
 * <PRE>
 * CmlguidecommentEntity.
 *
 * ����(�w���v�^)�e�[�u��.
 * </PRE>
 *
 * <B>Create</B> 2018.10.31 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data32155000_CmlguidecommentEntity {

    /**
     * �e�[�u����
     */
    public String TABLE_NAME = "tbl_cmlguidecomment";

    /**
     * �����R�[�h
     */
    private String gcom_user;
    /**
     * �N�x
     */
    private String gcom_year;
    /**
     * �w�N
     */
    private String gcom_grade;
    /**
     * �w�Дԍ�
     */
    private String gcom_stucode;
    /**
     * �������e
     */
    private String gcom_comment;
    /**
     * �����������e1
     */
    private String gcom_splitcomment1;
    /**
     * �����������e2
     */
    private String gcom_splitcomment2;
    /**
     * �����������e3
     */
    private String gcom_splitcomment3;
    /**
     * �����������e4
     */
    private String gcom_splitcomment4;
    /**
     * �����������e5
     */
    private String gcom_splitcomment5;
    /**
     * �����������e5
     */
    private String gcom_splitcomment6;
    /**
     * �����������e5
     */
    private String gcom_splitcomment7;
    /**
     * �����������e5
     */
    private String gcom_splitcomment8;
    /**
     * �����������e5
     */
    private String gcom_splitcomment9;
    /**
     * �����������e5
     */
    private String gcom_splitcomment10;
    /**
     * �X�V��
     */
    private String gcom_update;
    /**
     * �X�V��
     */
    private String gcom_upuser;


    public String getTABLE_NAME() {
	    return TABLE_NAME;
	}
	public void setTABLE_NAME(String TABLE_NAME) {
	    this.TABLE_NAME = TABLE_NAME;
	}
	public String getGcom_user() {
		return gcom_user;
	}
	public void setGcom_user(String gcom_user) {
		this.gcom_user = gcom_user;
	}
	public String getGcom_year() {
		return gcom_year;
	}
	public void setGcom_year(String gcom_year) {
		this.gcom_year = gcom_year;
	}
	public String getGcom_grade() {
		return gcom_grade;
	}
	public void setGcom_grade(String gcom_grade) {
		this.gcom_grade = gcom_grade;
	}
	public String getGcom_stucode() {
		return gcom_stucode;
	}
	public void setGcom_stucode(String gcom_stucode) {
		this.gcom_stucode = gcom_stucode;
	}
	public String getGcom_comment() {
		return gcom_comment;
	}
	public void setGcom_comment(String gcom_comment) {
		this.gcom_comment = gcom_comment;
	}
	public String getGcom_splitcomment1() {
		return gcom_splitcomment1;
	}
	public void setGcom_splitcomment1(String gcom_splitcomment1) {
		this.gcom_splitcomment1 = gcom_splitcomment1;
	}
	public String getGcom_splitcomment2() {
		return gcom_splitcomment2;
	}
	public void setGcom_splitcomment2(String gcom_splitcomment2) {
		this.gcom_splitcomment2 = gcom_splitcomment2;
	}
	public String getGcom_splitcomment3() {
		return gcom_splitcomment3;
	}
	public void setGcom_splitcomment3(String gcom_splitcomment3) {
		this.gcom_splitcomment3 = gcom_splitcomment3;
	}
	public String getGcom_splitcomment4() {
		return gcom_splitcomment4;
	}
	public void setGcom_splitcomment4(String gcom_splitcomment4) {
		this.gcom_splitcomment4 = gcom_splitcomment4;
	}
	public String getGcom_splitcomment5() {
		return gcom_splitcomment5;
	}
	public void setGcom_splitcomment5(String gcom_splitcomment5) {
		this.gcom_splitcomment5 = gcom_splitcomment5;
	}
	public String getGcom_splitcomment6() {
		return gcom_splitcomment6;
	}
	public void setGcom_splitcomment6(String gcom_splitcomment6) {
		this.gcom_splitcomment6 = gcom_splitcomment6;
	}
	public String getGcom_splitcomment7() {
		return gcom_splitcomment7;
	}
	public void setGcom_splitcomment7(String gcom_splitcomment7) {
		this.gcom_splitcomment7 = gcom_splitcomment7;
	}
	public String getGcom_splitcomment8() {
		return gcom_splitcomment8;
	}
	public void setGcom_splitcomment8(String gcom_splitcomment8) {
		this.gcom_splitcomment8 = gcom_splitcomment8;
	}
	public String getGcom_splitcomment9() {
		return gcom_splitcomment9;
	}
	public void setGcom_splitcomment9(String gcom_splitcomment9) {
		this.gcom_splitcomment9 = gcom_splitcomment9;
	}
	public String getGcom_splitcomment10() {
		return gcom_splitcomment10;
	}
	public void setGcom_splitcomment10(String gcom_splitcomment10) {
		this.gcom_splitcomment10 = gcom_splitcomment10;
	}
	public String getGcom_update() {
		return gcom_update;
	}
	public void setGcom_update(String gcom_update) {
		this.gcom_update = gcom_update;
	}
	public String getGcom_upuser() {
		return gcom_upuser;
	}
	public void setGcom_upuser(String gcom_upuser) {
		this.gcom_upuser = gcom_upuser;
	}

}
