package jp.co.systemd.tnavi.cus.ashigarashimo.db.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Data32155000_StudentEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.formbean.List32155000FormBean;

/**
 * ��������(�w���v�^)(�������S���w�Z) Service.
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List32155000Service extends AbstractExecuteQuery {

	/** FormBean */
	private List32155000FormBean listFormBean;

	/** SystemInfoBean */
	private SystemInfoBean sessionBean;

	public List32155000Service( HttpServletRequest request, SystemInfoBean sessionBean ) {
		this.sessionBean = sessionBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		// ------------------------------------------------------------------------------------------
		// �Ώې��k�����擾
		// ------------------------------------------------------------------------------------------
		Object[] param_student = {
				 sessionBean.getUserCode()
				,listFormBean.getNendo()
				,listFormBean.getClsno()
		};
		QueryManager qm_student = new QueryManager("cus/ashigarashimo/getData32155000_student.sql", param_student, Data32155000_StudentEntity.class);

		List<Data32155000_StudentEntity> studentList = (List<Data32155000_StudentEntity>) this.executeQuery( qm_student );
		listFormBean.setStudentList(studentList);
		listFormBean.setStudentCount(studentList.size());

		if( studentList != null && studentList.size() > 0 ){
			if( listFormBean.getStucode().equals("")  ){
				listFormBean.setStucode(studentList.get(0).getCls_stucode() );
			}
		}

		// ------------------------------------------------------------------------------------------
		// ���яo�͎������擾
		// ------------------------------------------------------------------------------------------
		Object[] param_term = {
				 sessionBean.getUserCode()
				,listFormBean.getNendo()
		};
		QueryManager qm_term = new QueryManager("cus/ashigarashimo/getData32155000_term.sql", param_term, CmlguideoutputtermEntity.class);

		List<CmlguideoutputtermEntity> termList = (List<CmlguideoutputtermEntity>) this.executeQuery(qm_term);

		List<SimpleTagFormBean> termPullDownList = new ArrayList<SimpleTagFormBean>();
		for(CmlguideoutputtermEntity cmlguideoutputtermEntity:termList) {
			SimpleTagFormBean simpleTagFormBean = new SimpleTagFormBean(cmlguideoutputtermEntity.getGopt_goptcode(), cmlguideoutputtermEntity.getGopt_name());
			termPullDownList.add( simpleTagFormBean ) ;
		}
		listFormBean.setTermPullDownList(termPullDownList);

	}

	public List32155000FormBean getListFormBean() {
		return listFormBean;
	}

	public void setListFormBean(List32155000FormBean listFormBean) {
		this.listFormBean = listFormBean;
	}

}
