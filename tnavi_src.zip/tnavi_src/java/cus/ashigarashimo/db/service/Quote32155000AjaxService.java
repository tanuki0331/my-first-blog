/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2018 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.db.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_ClubEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_CommentEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_EtceteraEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_SpeactEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.formbean.Quote32155000AjaxFormBean;

/**
 * <PRE>
 * ��������(�w���v�^)(�������S���w�Z) Ajax Service.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Quote32155000AjaxService extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Quote32155000AjaxService.class);

	/** �����R�[�h **/
	private String user = null;

	/** �N�x **/
	private String nendo = null;

	/** �N���X */
	private String clsno = null;

	/** �V�X�e�����t */
	private String systemDate = null;

	/** �V�X�e�����t */
	private String nendoStartDate = null;


	/**FormBean**/
	Quote32155000AjaxFormBean quote32155000AjaxFormBean;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {

		Object[] param = null;

		QueryManager queryManager = null;

		// --- 0.���ʊ����̏��擾
		List<Quote32155000Ajax_SpeactEntity> listSpeact = null;
		LinkedHashMap< String , Quote32155000Ajax_SpeactEntity> quote32155000Ajax_SpeactEntityMap =  new  LinkedHashMap< String , Quote32155000Ajax_SpeactEntity> ();

		if ("0".equals(quote32155000AjaxFormBean.getActiveTabIndex())){
			// ���N�x�́u���ʊ����v�̏����擾����(�ψ���E�������E�W������)
			param = new Object[] { user, nendo, clsno };
			queryManager = new QueryManager("cus/ashigarashimo/getQuote32155000Ajax_speact.sql", param, Quote32155000Ajax_SpeactEntity.class);

			// ���p�Ώۂ��S�ĂŖ����ꍇ�́A�w��̏�����ݒ肷��B
			if( !quote32155000AjaxFormBean.getSpeactitem().equals("ALL") ){
				queryManager.setPlusSQL("AND   rsav_rsatcode ='" + quote32155000AjaxFormBean.getSpeactitem() +"'");
			}
			// ���p�Ώۂ��S�Ă̏ꍇ�́A���Ԃ� 01�C02�ɐݒ肷��B
			if( !quote32155000AjaxFormBean.getSpeactterm().equals("ALL") ){
				queryManager.setPlusSQL("AND   rsav_term ='" + quote32155000AjaxFormBean.getSpeactterm() +"'");
			}else{
				queryManager.setPlusSQL("AND   rsav_term IN('01', '02')");
			}

			listSpeact = (List<Quote32155000Ajax_SpeactEntity>) this.executeQuery(queryManager);

			if(listSpeact != null &&  listSpeact.size() > 0){

				for(int i = 0; i < listSpeact.size(); i++){

					if( listSpeact.get(i).getRsav_record()==null || listSpeact.get(i).getRsav_record().equals("") ){
						continue;
					}
					String hash_key = "speact_" + listSpeact.get(i).getRsav_rsatcode() +"_"+ listSpeact.get(i).getRsav_term() +"_"+ listSpeact.get(i).getCls_stucode() ;
					quote32155000Ajax_SpeactEntityMap.put( hash_key , listSpeact.get(i) );
				}
			}
			quote32155000AjaxFormBean.setQuote32155000Ajax_SpeactEntityMap( quote32155000Ajax_SpeactEntityMap );
		}

		// --- 1.�ʒm�\ �����̏��擾
		List<Quote32155000Ajax_CommentEntity> listComment= null;
		LinkedHashMap< String , Quote32155000Ajax_CommentEntity> quote32155000Ajax_CommentEntityMap =  new  LinkedHashMap< String , Quote32155000Ajax_CommentEntity> ();

		if ("1".equals(quote32155000AjaxFormBean.getActiveTabIndex())){
			param = new Object[] { user, nendo, clsno };
			queryManager = new QueryManager("cus/ashigarashimo/getQuote32155000Ajax_comment.sql", param, Quote32155000Ajax_CommentEntity.class);

			// ���p�Ώۂ��S�ĂŖ����ꍇ�́A�w��̏�����ݒ肷��B
			if( !quote32155000AjaxFormBean.getGoptcode().equals("") ){
				queryManager.setPlusSQL("AND   rcom_term ='" + quote32155000AjaxFormBean.getGoptcode() +"'");
			}
			queryManager.setPlusSQL("ORDER BY cls_stucode , rcom_term ");

			listComment = (List<Quote32155000Ajax_CommentEntity>) this.executeQuery(queryManager);

			if(listComment != null &&  listComment.size() > 0){

				for(int i = 0; i < listComment.size(); i++){

					if( listComment.get(i).getRcom_comment()==null || listComment.get(i).getRcom_comment().equals("") ){
						continue;
					}
					String hash_key = "comment_"+ listComment.get(i).getCls_stucode()+"_"+ listComment.get(i).getRcom_term();
					quote32155000Ajax_CommentEntityMap.put( hash_key ,listComment.get(i) );
				}
			}
			quote32155000AjaxFormBean.setQuote32155000Ajax_CommentEntityMap(quote32155000Ajax_CommentEntityMap);
		}


		// --- 2.�N���u�̏����擾����
		List<Quote32155000Ajax_ClubEntity> listClub = null;
		LinkedHashMap< String , String > clubEntityMap =  new  LinkedHashMap< String , String> ();

		if ("2".equals(quote32155000AjaxFormBean.getActiveTabIndex())){
			Object[] param7 = { user, nendo,clsno, nendoStartDate };
			QueryManager qm7 = new QueryManager("cus/ashigarashimo/getQuote32155000Ajax_club.sql", param7, Quote32155000Ajax_ClubEntity.class);
			listClub = (List<Quote32155000Ajax_ClubEntity>) this.executeQuery(qm7);

			if(listClub != null &&  listClub.size() > 0){

				for(int i = 0; i < listClub.size(); i++){

					String cur_stucode      =listClub.get(i).getCls_stucode();
					String start_date       =listClub.get(i).getClb_start();
					String stop_date        =listClub.get(i).getClb_stop();
					String oldest_stop_date =listClub.get(i).getOldest_stop_date();
					String pst_name         =listClub.get(i).getPst_name();

					// ��������
					String result_data = listClub.get(i).getExt_name();

					if( result_data != null && !result_data.equals("")){

						// �ł��Â��ޕ������V�������ɓ������Ă�����A��������\������B
						String add_info ="";
						if( oldest_stop_date != null && oldest_stop_date.compareTo(start_date) <= 0 ){
							add_info     += String.valueOf(Integer.parseInt(start_date.substring(4,6)))+"��";
						}
						if( pst_name!=null && !pst_name.equals("") ){
							add_info     += pst_name ;
						}
						// ���łɑޕ����Ă�����
						if( stop_date!=null && !stop_date.equals("        ") ){
							add_info     += String.valueOf(Integer.parseInt(stop_date.substring(4,6)))+"���ޕ�";
						}

						if( !add_info.equals("")){
							result_data += " " + add_info;
						}

						String hash_key = "club_"+ cur_stucode;

						if( result_data != null ) {
							// �������k�̃f�[�^�����łɂ���B
							if( clubEntityMap.containsKey(hash_key) ){
								String current_result = clubEntityMap.get(hash_key) ;

								// �Y�����k�̐��k�̃f�[�^������΁A�A������B
								if( !current_result.equals("") ){
									current_result += "�C"+ result_data ;
									clubEntityMap.put( hash_key , current_result );
								}else{
									clubEntityMap.put( hash_key , result_data );
								}
							}
							// �������k�̃f�[�^��������Βǉ�����B
							else{
								clubEntityMap.put( hash_key , result_data );
							}
						}
					}

				}
			}
			quote32155000AjaxFormBean.setClubEntityMap(clubEntityMap);
		}


		// --- 3.�\���̏����擾����
		List<Quote32155000Ajax_EtceteraEntity> listEtcetera = null;
		LinkedHashMap< String , Quote32155000Ajax_EtceteraEntity> quote32155000Ajax_EtceteraEntityMap =  new  LinkedHashMap< String , Quote32155000Ajax_EtceteraEntity> ();
		if ("3".equals(quote32155000AjaxFormBean.getActiveTabIndex())){
			Object[] param7 = { user, nendo, clsno };
			QueryManager qm7 = new QueryManager("cus/ashigarashimo/getQuote32155000Ajax_etcetera.sql", param7, Quote32155000Ajax_EtceteraEntity.class);
			listEtcetera = (List<Quote32155000Ajax_EtceteraEntity>) this.executeQuery(qm7);

			if(listEtcetera != null &&  listEtcetera.size() > 0){

				for(int i = 0; i < listEtcetera.size(); i++){

					if( listEtcetera.get(i).getRetc_value()==null || listEtcetera.get(i).getRetc_value().equals("") ){
						continue;
					}
					String hash_key = "etcetera_"+listEtcetera.get(i).getCls_stucode();
					quote32155000Ajax_EtceteraEntityMap.put( hash_key ,listEtcetera.get(i) );
				}
			}
			quote32155000AjaxFormBean.setQuote32155000Ajax_EtceteraEntityMap(quote32155000Ajax_EtceteraEntityMap);
		}
	}


	/**
	 * �w�肳�ꂽ���K�\���Ɉ�v����ꍇ�A�Ώە�����Œu������
	 *
	 * @param value �����ΏۂƂȂ镶����
	 * @param regex ���K�\��
	 * @param replacement �u��������
	 * @return �u����̔z��
	 */
	private static String replaceAllRegex(String value, String regex, String replacement) {
	    if ( value == null || value.length() == 0 || regex == null || regex.length() == 0 || replacement == null ){
	    	return "";
	    }

	    return Pattern.compile(regex).matcher(value).replaceAll(replacement);
	}

	/**
	 * /**
	 * <PRE>
	 * �p�����[�^�ݒ�.
	 * </PRE>
	 * @param user      �����R�[�h
	 * @param nendo     �N�x
	 * @param startDate	�N�x�J�n����
	 * @param endDate	�N�x�I������
	 * @param clsno		�z�[�����[���ԍ�
	 * @param dcode	 	�w�ȃR�[�h
	 * @param glade
	 * @param hmrclass
	 * @param hmrname
	 * @param stucode
	 * @param getEtcValue
	 */
	public void setParameter(SystemInfoBean sessionBean, String nendo, String clsno,  String systemDate	) {
		this.user = sessionBean.getUserCode();
		this.nendo = nendo;
		this.clsno = clsno;
		this.systemDate = systemDate;
		this.nendoStartDate = sessionBean.getSystemNendo()+sessionBean.getSystemNendoStartDate().trim();
	}


	public Quote32155000AjaxFormBean getQuote32155000AjaxFormBean() {
		return quote32155000AjaxFormBean;
	}

	public void setQuote32155000AjaxFormBean(Quote32155000AjaxFormBean quote32155000AjaxFormBean) {
		this.quote32155000AjaxFormBean = quote32155000AjaxFormBean;
	}
}
