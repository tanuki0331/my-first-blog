/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2018 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.action;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.CharacterEncode;
import jp.co.systemd.tnavi.common.action.AbstractUploadAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.formbean.ResultMessage;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Data32155000_StudentEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.service.List32155000Service;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.service.Upload32155000Service;
import jp.co.systemd.tnavi.cus.ashigarashimo.formbean.List32155000FormBean;
import uty.utySpreadSheetReader;

/**
 * <PRE>
 * ��������(�w���v�^)(�������S���w�Z) �ǂݍ���Action.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Upload32155000Action extends AbstractUploadAction {

	/** �����l */
	private final static String DEFALUT_VALUE = "";

	/** log4j */
	private static final Log log = LogFactory.getLog(Upload32155000Action.class);

	/** �t�@�C�����iSessionID�{���̖��O�Ńt�@�C�����Ƃ���j*/
	private static final String UPLOAD_FILE_NAME_SPEACT   = "_upload32155000_SPEACT_format.dat";
	private static final String UPLOAD_FILE_NAME_COMMENT  = "_upload32155000_COMMENT_format.dat";
	private static final String UPLOAD_FILE_NAME_CLUB     = "_upload32155000_CLUB_format.dat";
	private static final String UPLOAD_FILE_NAME_ETCETERA = "_upload32155000_ETCETERA_format.dat";

	/** �G���[�t�@�C�����iSessionID�{���̖��O�Ńt�@�C�����Ƃ���j*/
	private static final String ERROR_FILE_NAME_SPEACT   = "_upload32155000_SPEACT_format_err.csv";
	private static final String ERROR_FILE_NAME_COMMENT  = "_upload32155000_COMMENT_format_err.csv";
	private static final String ERROR_FILE_NAME_CLUB     = "_upload32155000_CLUB_format_err.csv";
	private static final String ERROR_FILE_NAME_ETCETERA = "_upload32155000_ETCETERA_format_err.csv";

	/** CSV�t�@�C�����i�ϊ��p�j **/
	private static final String CSV_FILE_NAME_SPEACT   = "_upload32155000_SPEACT_format.csv";
	private static final String CSV_FILE_NAME_COMMENT  = "_upload32155000_COMMENT_format.csv";
	private static final String CSV_FILE_NAME_CLUB     = "_upload32155000_CLUB_format.csv";
	private static final String CSV_FILE_NAME_ETCETERA = "_upload32155000_ETCETERA_format.csv";

	/** �X�V������ʁu3:�Ǎ����� 4:�Ǎ����s�v */
	private static final String COMPLET_KIND_3 = "3";
	private static final String COMPLET_KIND_4 = "4";

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		try{
			// ------------------------------------------------------------------------------------------
			// �����J�n���O�o��
			// ------------------------------------------------------------------------------------------
			log.info("�y��ʁz��������(�w���v�^) �ǂݍ��� START");


			// ------------------------------------------------------------------------------------------
			// FormBean����
			// ------------------------------------------------------------------------------------------
			List32155000FormBean list32155000FormBean = new List32155000FormBean();


			// ------------------------------------------------------------------------------------------
			// �ǂݍ��݁i�A�b�v���[�h�j����
			// ------------------------------------------------------------------------------------------
			String orgFileName = null;
			boolean isCSV = false;

			String uploadFilePath = DEFALUT_VALUE;
			String uploadFileName = DEFALUT_VALUE;
			String errorFilePath  = DEFALUT_VALUE;
			String errorFileName  = DEFALUT_VALUE;
			String csvFileName    = DEFALUT_VALUE;

			// �p�����[�^����N�x���ƑI�����ꂽ���t�@�C����PATH���������t�@�C�������擾
			String nendo = "";
			String grade = "";
			String hmrclass = "";
			String hmrname = "";
			String clsno = "";
			String hroomFlg = "";
			Integer activeTabIndex = 0;
			String hasErrorFileSpeact ="";
			String hasErrorFileComment ="";
			String hasErrorFileClub ="";
			String hasErrorFileEtcetera ="";

			// ��ʏ�̃f�[�^���ꎞ�I�ɕێ����邽�߂�HashMap
			HashMap <String, String > speactMap   = new HashMap <String, String >();
			HashMap <String, String > commentMap  = new HashMap <String, String >();
			HashMap <String, String > clubMap     = new HashMap <String, String >();
			HashMap <String, String > etceteraMap = new HashMap <String, String >();
			HashMap <String, String > studentMap  = new HashMap <String, String >();
			HashMap <String, String > clsnumberMap = new HashMap <String, String >();
			HashMap <String, String > st4nameMap  = new HashMap <String, String >();


			// ------------------------------------------------------------------------------------------
			// ��ʓ��̃f�[�^���擾����
			// ------------------------------------------------------------------------------------------
			List<FileItem> fileItemList = super.getUploadParameterList();
			for (FileItem fileItem : fileItemList) {
				String itemName = fileItem.getFieldName();
				// �t�@�C���f�[�^�̏ꍇ
				if (!(fileItem.isFormField())) {
					// �t�@�C����
					if ((itemName != null) && ("filename".equals(itemName))) {
						File f = new File(fileItem.getName());
						orgFileName = f.getName();
					}
				}else{
					if(itemName != null && itemName.equals("nendo")) {
						//�N�x
						nendo = fileItem.getString();
					}else if(itemName != null && itemName.equals("grade")) {
						//�w�N
						grade = fileItem.getString();
					}else if(itemName != null && itemName.equals("hmrclass")) {
						//�g
						hmrclass = (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet());
					}else if(itemName != null && itemName.equals("hmrname")) {
						//�N���X����
						//�}���`�p�[�g�ő��M���Ă邽�߁A�v�G���R�[�h
						hmrname = (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet());
					}else if(itemName != null && itemName.equals("clsno")) {
						//�N���X�ԍ�
						clsno = fileItem.getString();
					}else if(itemName != null && itemName.equals("hroomFlg")) {
						//�w���S�C�t���O
						hroomFlg = fileItem.getString();
					}else if(itemName != null && itemName.equals("hasErrorFileSpeact")) {
						//�w���S�C�t���O
						hasErrorFileSpeact = fileItem.getString();
					}else if(itemName != null && itemName.equals("hasErrorFileComment")) {
						//�w���S�C�t���O
						hasErrorFileComment = fileItem.getString();
					}else if(itemName != null && itemName.equals("hasErrorFileClub")) {
						//�w���S�C�t���O
						hasErrorFileClub = fileItem.getString();
					}else if(itemName != null && itemName.equals("hasErrorFileEtcetera")) {
						//�w���S�C�t���O
						hasErrorFileEtcetera = fileItem.getString();
					}else if(itemName != null && itemName.equals("activeTabIndex")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							activeTabIndex = Integer.parseInt(fileItem.getString());
						}
					}else if(itemName != null && itemName.startsWith("speact_")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							speactMap.put(itemName, (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet()) );
						}
					}else if(itemName != null && itemName.startsWith("comment_")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							commentMap.put(itemName, (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet())  );
						}
					}else if(itemName != null && itemName.startsWith("club_")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							clubMap.put(itemName, (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet())  );
						}
					}else if(itemName != null && itemName.startsWith("etcetera_")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							etceteraMap.put(itemName, (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet())  );
						}
					}else if(itemName != null && itemName.startsWith("stucode_0_")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							studentMap.put(itemName, fileItem.getString() );
						}
					}else if(itemName != null && itemName.startsWith("name_0_")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							st4nameMap.put(itemName, (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet())  );
						}
					}else if(itemName != null && itemName.startsWith("number_0_")) {
						//�I���^�u���
						if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
							clsnumberMap.put(itemName, (String)fileItem.getString(CharacterEncode.getSqlReadingCharacterSet())  );
						}
					}else {

					}
				}
			}


			// ------------------------------------------------------------------------------------------
			//DB���猻��̈ꗗ�����擾
			// ------------------------------------------------------------------------------------------
			list32155000FormBean.setNendo(nendo);
			list32155000FormBean.setGrade(grade);
			list32155000FormBean.setHmrclass(hmrclass);
			list32155000FormBean.setHmrname(hmrname);
			list32155000FormBean.setClsno(clsno);
			list32155000FormBean.setHroomFlg(hroomFlg);
			list32155000FormBean.setActiveTabIndex(activeTabIndex);

			if( hasErrorFileSpeact.equals("true")){
				list32155000FormBean.setHasErrorFileSpeact(true);
			}else{
				list32155000FormBean.setHasErrorFileSpeact(false);
			}
			if( hasErrorFileComment.equals("true")){
				list32155000FormBean.setHasErrorFileComment(true);
			}else{
				list32155000FormBean.setHasErrorFileComment(false);
			}
			if( hasErrorFileClub.equals("true")){
				list32155000FormBean.setHasErrorFileClub(true);
			}else{
				list32155000FormBean.setHasErrorFileClub(false);
			}
			if( hasErrorFileEtcetera.equals("true")){
				list32155000FormBean.setHasErrorFileEtcetera(true);
			}else{
				list32155000FormBean.setHasErrorFileEtcetera(false);
			}

			List32155000Service list30387000Service = new List32155000Service( request, sessionBean );
			list30387000Service.setListFormBean(list32155000FormBean);
			list30387000Service.execute();

			// ------------------------------------------------------------------------------------------
			//DB����̎擾�f�[�^�̏�����ێ����Ȃ���A��ʂŕύX���ꂽ���X�V�̃f�[�^��ێ�����B(�S�Ẵ^�u�̃f�[�^��ΏۂƂ���B)
			// ------------------------------------------------------------------------------------------
			List<Data32155000_StudentEntity> studentEntityList = list30387000Service.getListFormBean().getStudentList();

			for( Data32155000_StudentEntity data32155000_StudentEntity : studentEntityList){

				String stucode = data32155000_StudentEntity.getCls_stucode();

				// ��ʏ����`�F�b�N����B
				if( studentMap.containsKey( "stucode_0_"+ stucode) ){

					String gcom_splitcomment1 = speactMap.get("speact_0001_01_"+stucode); //���ʊ���
					String gcom_splitcomment2 = speactMap.get("speact_0001_02_"+stucode);
					String gcom_splitcomment3 = speactMap.get("speact_0002_01_"+stucode); //���k���
					String gcom_splitcomment4 = speactMap.get("speact_0002_02_"+stucode);
					String gcom_splitcomment5 = speactMap.get("speact_0003_01_"+stucode); //�w�Z�s��
					String gcom_splitcomment6 = speactMap.get("speact_0003_02_"+stucode);
					String gcom_splitcomment7 = commentMap.get("comment_"+stucode);       //��������
					String gcom_splitcomment8 = clubMap.get("club_"+stucode);             //������
					String gcom_splitcomment9 = etceteraMap.get("etcetera_"+stucode);     //�\���̋L�^

					if( gcom_splitcomment1 == null ) gcom_splitcomment1 = "";
					if( gcom_splitcomment2 == null ) gcom_splitcomment2 = "";
					if( gcom_splitcomment3 == null ) gcom_splitcomment3 = "";
					if( gcom_splitcomment4 == null ) gcom_splitcomment4 = "";
					if( gcom_splitcomment5 == null ) gcom_splitcomment5 = "";
					if( gcom_splitcomment6 == null ) gcom_splitcomment6 = "";
					if( gcom_splitcomment7 == null ) gcom_splitcomment7 = "";
					if( gcom_splitcomment8 == null ) gcom_splitcomment8 = "";
					if( gcom_splitcomment9 == null ) gcom_splitcomment9 = "";

					data32155000_StudentEntity.setGcom_splitcomment1(gcom_splitcomment1);
					data32155000_StudentEntity.setGcom_splitcomment2(gcom_splitcomment2);
					data32155000_StudentEntity.setGcom_splitcomment3(gcom_splitcomment3);
					data32155000_StudentEntity.setGcom_splitcomment4(gcom_splitcomment4);
					data32155000_StudentEntity.setGcom_splitcomment5(gcom_splitcomment5);
					data32155000_StudentEntity.setGcom_splitcomment6(gcom_splitcomment6);
					data32155000_StudentEntity.setGcom_splitcomment7(gcom_splitcomment7);
					data32155000_StudentEntity.setGcom_splitcomment8(gcom_splitcomment8);
					data32155000_StudentEntity.setGcom_splitcomment9(gcom_splitcomment9);
				}
			}

			list32155000FormBean.setStudentList(studentEntityList);


			// ------------------------------------------------------------------------------------------
			// �t�@�C�����ݒ�
			// ------------------------------------------------------------------------------------------
			// �A�b�v���[�h�����t�@�C���p�X�ƃt�@�C����
			// �G���[�̃t�@�C���p�X�ƃt�@�C����
			// CSV�̃t�@�C���p�X�ƃt�@�C����
			uploadFilePath = sc.getInitParameter("upldir");
			errorFilePath = sc.getInitParameter("dwldir");

			if( activeTabIndex == 0 ){
				uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_SPEACT;
				errorFileName = sessionBean.getSessionId() + ERROR_FILE_NAME_SPEACT;
				csvFileName = sc.getInitParameter("upldir") + sessionBean.getSessionId() + CSV_FILE_NAME_SPEACT;
			}else if( activeTabIndex == 1 ){
				uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_COMMENT;
				errorFileName = sessionBean.getSessionId() + ERROR_FILE_NAME_COMMENT;
				csvFileName = sc.getInitParameter("upldir") + sessionBean.getSessionId() + CSV_FILE_NAME_COMMENT;
			}else if( activeTabIndex == 2 ){
				uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_CLUB;
				errorFileName = sessionBean.getSessionId() + ERROR_FILE_NAME_CLUB;
				csvFileName = sc.getInitParameter("upldir") + sessionBean.getSessionId() + CSV_FILE_NAME_CLUB;
			}else if( activeTabIndex == 3 ){
				uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_ETCETERA;
				errorFileName = sessionBean.getSessionId() + ERROR_FILE_NAME_ETCETERA;
				csvFileName = sc.getInitParameter("upldir") + sessionBean.getSessionId() + CSV_FILE_NAME_ETCETERA;
			}


			// ------------------------------------------------------------------------------------------
			//�A�b�v���[�h���ꂽ�t�@�C�����T�[�o�ɕۑ�����
			// ------------------------------------------------------------------------------------------
			List<ResultMessage> messageList = super.doUpload(sc, request, response, sessionBean);
			if (messageList.size() > 0) {
				// �A�b�v���[�h���s
				// �X�V������ʂ��Z�b�g
				list32155000FormBean.setCompletKind(COMPLET_KIND_4);
			} else {
				// ���t�@�C����CSV���ǂ���
				isCSV = orgFileName.toLowerCase().endsWith(".csv");

				// CSV�̏ꍇ
				if (isCSV) {
					csvFileName = uploadFilePath + uploadFileName;
				// CSV�łȂ��ꍇ
				} else {
					// CSV�t�@�C���֏o��
					int sheetIndex = 0;		// �V�[�g�ԍ�
					try {
						this.saveToCSV(orgFileName, uploadFilePath + uploadFileName, csvFileName, sheetIndex);
					} catch (Exception e) {
						log.error("�Ǎ��t�@�C����CSV�o�͎��s", e);
						throw new TnaviException(e);
					}
				}

				// ------------------------------------------------------------------------------------------
				// �A�b�v���[�h�����f�[�^��ێ����Ă���f�[�^�ɏ㏑������B
				// ��ʓ��ŕێ�����Ă���f�[�^�́AExcel����̎擾�f�[�^�ɂ��㏑������邪�A���s�����^�u��ł̃f�[�^�݂̂��㏑�������B
				// ------------------------------------------------------------------------------------------
				Upload32155000Service uploadService = new Upload32155000Service();
				uploadService.setParameter(
					csvFileName,
					errorFilePath + errorFileName
				);
				uploadService.setListFormBean(list32155000FormBean);
				uploadService.execute(request, sessionBean);

				// �쐬����FormBean���擾
				list32155000FormBean = uploadService.getListFormBean();

				// �G���[�t�@�C���̑��݊m�F
				errorFilePath = sc.getInitParameter("dwldir");
				File file = new File(errorFilePath + "/" + errorFileName);

				if( activeTabIndex == 0 ){
					list32155000FormBean.setHasErrorFileSpeact(file.exists());
				}else if( activeTabIndex == 1 ){
					list32155000FormBean.setHasErrorFileComment(file.exists());
				}else if( activeTabIndex == 2 ){
					list32155000FormBean.setHasErrorFileClub(file.exists());
				}else if( activeTabIndex == 3 ){
					list32155000FormBean.setHasErrorFileEtcetera(file.exists());
				}

				// ------------------------------------------------------------------------------------------
				// �A�b�v���[�h�����t�@�C���̍폜
				// ------------------------------------------------------------------------------------------
				deleteTempFile( uploadFilePath ,  uploadFileName,  csvFileName);

				// ------------------------------------------------------------------------------------------
				// Request��FormBean���Z�b�g����B
				// ------------------------------------------------------------------------------------------
				request.setAttribute("FORM_BEAN", list32155000FormBean);

				// ------------------------------------------------------------------------------------------
				// �����I�����O�o��
				// ------------------------------------------------------------------------------------------
				log.info("�y��ʁz��������(�w���v�^) �ǂݍ��� END");
			}
		}catch (Exception e) {
			log.error("�y��ʁz��������(�w���v�^) �ǂݍ��� �������ɃG���[���������܂����B");
			log.error(e);
			throw new TnaviException(e);
		}


		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String[] getUploadFileNames(ServletContext sc,
			List<FileItem> uploadParameterList, SystemInfoBean sessionBean) {

		Integer  activeTabIndex = 0;

		for (FileItem fileItem : uploadParameterList) {
			String itemName = fileItem.getFieldName();

			if(itemName != null && itemName.equals("activeTabIndex")) {
				//�I���^�u���
				if(fileItem.getString() != null && !"".equals(fileItem.getString())) {
					activeTabIndex = Integer.parseInt(fileItem.getString());
				}
			}
		}

		String temp_uploadFileName ="";

		if( activeTabIndex == 0 ){
			temp_uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_SPEACT;
		}else if( activeTabIndex == 1 ){
			temp_uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_COMMENT;
		}else if( activeTabIndex == 2 ){
			temp_uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_CLUB;
		}else if( activeTabIndex == 3 ){
			temp_uploadFileName = sessionBean.getSessionId() + UPLOAD_FILE_NAME_ETCETERA;
		}else{

		}

		String fileName[] = {temp_uploadFileName};
		return fileName;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getUploadFilePath(ServletContext sc,
			List<FileItem> uploadParameterList, SystemInfoBean sessionBean) {
//		return this.uploadFilePath;
		return sc.getInitParameter("upldir");
	}

	/**
	 * <PRE>
	 * �ǂݍ��񂾃f�[�^��CSV�t�@�C���ŏo��.
	 * </PRE>
	 * @param param			uploadedFileName�F�ǂݍ��݃t�@�C��.
	 * 				tmpFileName     �F�A�b�v���[�h�t�@�C��.
	 * 				csvFileName     �FCSV�t�@�C��
	 * @return			Boolean true    �F����.
	 * 					false   �F���s.
	 * @throws Exception		���s�����ꍇ�ɃX���[����.
	 */
	private void saveToCSV(String uploadedFileName, String tmpFileName, String csvFileName, int sheetIndex)
	throws Exception  {
		utySpreadSheetReader reader = utySpreadSheetReader.createReader(uploadedFileName);
		boolean parsed = reader.parse(tmpFileName, sheetIndex);
		if (parsed) {
			// save as csv
			FileOutputStream fos = null;
			try {
				// �ǂݍ��񂾃f�[�^��CSV�ŏo��
				fos = new FileOutputStream(csvFileName);
				reader.saveAsCSV(fos);
			}
			finally {
				if (fos != null) {
					fos.close();
				}
			}
		} else {
			throw new IOException(reader.getErrMessage());
		}
	}

	/**
	 * �A�b�v���[�h�����ꎞ�t�@�C���폜
	 */
	private void deleteTempFile(String uploadFilePath , String uploadFileName, String csvFileName) throws TnaviException {
		try {
				// dataFile
				File dataFile = new File( uploadFilePath + uploadFileName);
				// csvFile
				File csvFile = new File( csvFileName);

				// dataFile�̍폜
				if (dataFile.exists()) {
					dataFile.delete();
				}

				// csvFile�̍폜
				if(csvFile.exists()){
					csvFile.delete();
				}

		} catch (Exception e) {
		log.error("�G���[�t�@�C���폜�ŗ�O����", e);
			throw new TnaviException(e);
		}
	}
}
