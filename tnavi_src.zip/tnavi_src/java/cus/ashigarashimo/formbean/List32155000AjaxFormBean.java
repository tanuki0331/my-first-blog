/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2018 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.formbean;

/**
 * <PRE>
 *  ��������(�w���v�^)(�������S���w�Z) Ajax FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author
 * @since 1.0.
 */
public class List32155000AjaxFormBean  {

	/**
	 * �Q�Ə��
	 */
	protected String comment;

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}



}
