package jp.co.systemd.tnavi.cus.ashigarashimo.formbean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.aff.db.entity.Data30066000_ActEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_AttendEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_CommentEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_EvalItemEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_EvalValueEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_ForeignActEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_ForeignActFuzokukyotoEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_HroomInfoEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_ItemViewpointInfoEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_MoralEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_SpCmlguideitemcommentEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_SpCommonrecordsEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_SpecialactEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_StuSchoolInfoEntity;
import jp.co.systemd.tnavi.aff.db.entity.Data30066000_TotalactEntity;

/**
 * <PRE>
 * ���k�w���v�^�l��2(COReports��) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2015.12.17 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print30066000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �����R�[�h */
	private String userCode = DEFALUT_VALUE;

	/** �w�Z�敪 */
	private String useKind2 = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �N�x(yyyy) */
	private String nendoSeireki = DEFALUT_VALUE;

	/** �o�͓��t */
//	private String outputDate = DEFALUT_VALUE;

	/** �N�x�I���� */
	private String nendoEndYmd = DEFALUT_VALUE;

	/**COReports�o�͎� �l��2-1 �t�H�[���t�@�C��*/
	private String coFormPath_yosiki2_1 = DEFALUT_VALUE;

	/**COReports�o�͎� �l��2-2 �t�H�[���t�@�C��*/
	private String coFormPath_yosiki2_2 = DEFALUT_VALUE;

	/** ���w�̊ϓ_�������Ǘ����ۂ� */
	private boolean isTotalactMultiVp = false;

	/** ���k�����E�w�Z�� */
	Data30066000_StuSchoolInfoEntity stuSchoolInfo;

	/** �o�͑Ώ۔N�x�܂ł̃z�[�����[�����̃��X�g */
	List<Data30066000_HroomInfoEntity> hroomInfoList;

	/** �]��̏o�͑Ώۋ��ȏ��̃��X�g */
	List<Data30066000_EvalItemEntity> evalItemList;

	/** ���ȕʊϓ_�E�ϓ_�ʕ]���̃��X�g */
	List<Data30066000_ItemViewpointInfoEntity> itemViewpointInfoList;

	/** ���Ȗ��ɕ����������ȕʊϓ_�E�ϓ_�ʕ]���̃��X�g */
	List<List<Data30066000_ItemViewpointInfoEntity>> itemViewpointInfoListList;

	/** ���ȕʊϓ_�̋��Ȗ��̊ϓ_�����i�[����Map */
	Map<String, Integer> viewpointItemCntMap = new HashMap<String, Integer>();

	/** ���ȕʂ̕]��̃��X�g */
	List<Data30066000_EvalValueEntity> evalValueList;

	/** �����I�Ȋw�K�̎��Ԃ̋L�^���̃��X�g(�ϓ_�P��Ǘ����p)  */
	private List<Data30066000_TotalactEntity> totalactEntityList;

	/** �����I�Ȋw�K�̎��Ԃ�Map(�ϓ_�����Ǘ����p key:�w�N value:�����I�Ȋw�K�̎��Ԃ̋L�^���̃��X�g)  */
	private Map<String ,List<Data30066000_TotalactEntity>> totalactEntityListMap;

	/** ���ʊ����̋L�^�ϓ_ */
	private String speactViewpoint = DEFALUT_VALUE;

	/** ���ʊ����̋L�^�̃��X�g */
	private List<Data30066000_SpecialactEntity> specialactEntityList;

	/** ���ʊ����̋L�^�L�q�]�����X�g�i���x�v�^�]���ėp�e�[�u���o�^�j */
	private List<Data30066000_SpCommonrecordsEntity> specialactCommentEntityList;

	/** �s���̋L�^�̃��X�g */
	private List<Data30066000_ActEntity> actEntityList;

	/** �s���̋L�^���X�g�i���x�v�^�]���ėp�e�[�u���o�^�j */
	private List<Data30066000_SpCommonrecordsEntity> actSpEntityList;

	/** �O���ꊈ���̋L�^�̃��X�g */
	private List<Data30066000_ForeignActEntity> foreignActList;

	/** �����̃��X�g */
	private List<Data30066000_MoralEntity> moralList;

	/** �����̃��X�g */
	private List<Data30066000_CommentEntity> commentEntityList;

	/** ���������̋L�^���X�g */
	private List<Data30066000_SpCommonrecordsEntity> spclassActEntityList;

	/** �o���̋L�^�̃��X�g */
	private List<Data30066000_AttendEntity> attendEntityList;

	/** �p��]���̃��X�g(���s����啍������ ���w�Z) */
	List<Data30066000_ForeignActFuzokukyotoEntity> foreignActFuzokukyotoList;

	/** �m�I�l���̊w�K�̋L�^���X�g */
	private List<Data30066000_SpCmlguideitemcommentEntity> spItemCommentList;

	/** �����Ǝ����̃��X�g */
	private List<Data30066000_SpCommonrecordsEntity> totalClassesEntityList;

	/** �������̏o�͗L��*/
	private boolean watermark_on = false;

	/** �����E�Z���̈󎚓��e�̑I��*/
	private String nameAddrOutputMode = DEFALUT_VALUE;

	/** �����E�Z���̗����y�[�W�̏o�͗L��*/
	private boolean outputHistoryPage = false;


	/**
	 * @return userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode the userCode to set
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUseKind2() {
		return useKind2;
	}

	public void setUseKind2(String useKind2) {
		this.useKind2 = useKind2;
	}

	/**
	 * @return nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo the nendo to set
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

//	/**
//	 * @return outputDate
//	 */
//	public String getOutputDate() {
//		return outputDate;
//	}
//
//	/**
//	 * @param outputDate the outputDate to set
//	 */
//	public void setOutputDate(String outputDate) {
//		this.outputDate = outputDate;
//	}

	public String getNendoSeireki() {
		return nendoSeireki;
	}

	public void setNendoSeireki(String nendoSeireki) {
		this.nendoSeireki = nendoSeireki;
	}

	/**
	 * @return nendoEndYmd
	 */
	public String getNendoEndYmd() {
		return nendoEndYmd;
	}

	/**
	 * @param nendoEndYmd the nendoEndYmd to set
	 */
	public void setNendoEndYmd(String nendoEndYmd) {
		this.nendoEndYmd = nendoEndYmd;
	}

	public String getCoFormPath_yosiki2_1() {
		return coFormPath_yosiki2_1;
	}

	public void setCoFormPath_yosiki2_1(String coFormPath_yosiki2_1) {
		this.coFormPath_yosiki2_1 = coFormPath_yosiki2_1;
	}

	public String getCoFormPath_yosiki2_2() {
		return coFormPath_yosiki2_2;
	}

	public void setCoFormPath_yosiki2_2(String coFormPath_yosiki2_2) {
		this.coFormPath_yosiki2_2 = coFormPath_yosiki2_2;
	}

	/**
	 * @return isTotalactMultiVp
	 */
	public boolean isTotalactMultiVp() {
		return isTotalactMultiVp;
	}

	/**
	 * @param isTotalactMultiVp the isTotalactMultiVp to set
	 */
	public void setTotalactMultiVp(boolean isTotalactMultiVp) {
		this.isTotalactMultiVp = isTotalactMultiVp;
	}

	/**
	 * @return stuSchoolInfo
	 */
	public Data30066000_StuSchoolInfoEntity getStuSchoolInfo() {
		return stuSchoolInfo;
	}

	/**
	 * @param stuSchoolInfo the stuSchoolInfo to set
	 */
	public void setStuSchoolInfo(Data30066000_StuSchoolInfoEntity stuSchoolInfo) {
		this.stuSchoolInfo = stuSchoolInfo;
	}

	/**
	 * @return hroomInfoList
	 */
	public List<Data30066000_HroomInfoEntity> getHroomInfoList() {
		return hroomInfoList;
	}

	/**
	 * @param hroomInfoList the hroomInfoList to set
	 */
	public void setHroomInfoList(List<Data30066000_HroomInfoEntity> hroomInfoList) {
		this.hroomInfoList = hroomInfoList;
	}

	/**
	 * @return evalItemList
	 */
	public List<Data30066000_EvalItemEntity> getEvalItemList() {
		return evalItemList;
	}

	/**
	 * @param evalItemList the evalItemList to set
	 */
	public void setEvalItemList(List<Data30066000_EvalItemEntity> evalItemList) {
		this.evalItemList = evalItemList;
	}

	/**
	 * @return itemViewpointInfoList
	 */
	public List<Data30066000_ItemViewpointInfoEntity> getItemViewpointInfoList() {
		return itemViewpointInfoList;
	}

	/**
	 * @param itemViewpointInfoList the itemViewpointInfoList to set
	 */
	public void setItemViewpointInfoList(
			List<Data30066000_ItemViewpointInfoEntity> itemViewpointInfoList) {
		this.itemViewpointInfoList = itemViewpointInfoList;
	}

	/**
	 * @return itemViewpointInfoListList
	 */
	public List<List<Data30066000_ItemViewpointInfoEntity>> getItemViewpointInfoListList() {
		return itemViewpointInfoListList;
	}

	/**
	 * @param itemViewpointInfoListList the itemViewpointInfoListList to set
	 */
	public void setItemViewpointInfoListList(
			List<List<Data30066000_ItemViewpointInfoEntity>> itemViewpointInfoListList) {
		this.itemViewpointInfoListList = itemViewpointInfoListList;
	}

	/**
	 * @return viewpointItemCntMap
	 */
	public Map<String, Integer> getViewpointItemCntMap() {
		return viewpointItemCntMap;
	}

	/**
	 * @param viewpointItemCntMap the viewpointItemCntMap to set
	 */
	public void setViewpointItemCntMap(Map<String, Integer> viewpointItemCntMap) {
		this.viewpointItemCntMap = viewpointItemCntMap;
	}

	/**
	 * @return evalValueList
	 */
	public List<Data30066000_EvalValueEntity> getEvalValueList() {
		return evalValueList;
	}

	/**
	 * @param evalValueList the evalValueList to set
	 */
	public void setEvalValueList(List<Data30066000_EvalValueEntity> evalValueList) {
		this.evalValueList = evalValueList;
	}

	/**
	 * @return totalactEntityList
	 */
	public List<Data30066000_TotalactEntity> getTotalactEntityList() {
		return totalactEntityList;
	}

	/**
	 * @param totalactEntityList the totalactEntityList to set
	 */
	public void setTotalactEntityList(
			List<Data30066000_TotalactEntity> totalactEntityList) {
		this.totalactEntityList = totalactEntityList;
	}

	/**
	 * @return totalactEntityListMap
	 */
	public Map<String, List<Data30066000_TotalactEntity>> getTotalactEntityListMap() {
		return totalactEntityListMap;
	}

	/**
	 * @param totalactEntityListMap the totalactEntityListMap to set
	 */
	public void setTotalactEntityListMap(
			Map<String, List<Data30066000_TotalactEntity>> totalactEntityListMap) {
		this.totalactEntityListMap = totalactEntityListMap;
	}

	/**
	 * @return speactViewpoint
	 */
	public String getSpeactViewpoint() {
		return speactViewpoint;
	}

	/**
	 * @param speactViewpoint the speactViewpoint to set
	 */
	public void setSpeactViewpoint(String speactViewpoint) {
		this.speactViewpoint = speactViewpoint;
	}

	/**
	 * @return specialactEntityList
	 */
	public List<Data30066000_SpecialactEntity> getSpecialactEntityList() {
		return specialactEntityList;
	}

	/**
	 * @param specialactEntityList the specialactEntityList to set
	 */
	public void setSpecialactEntityList(
			List<Data30066000_SpecialactEntity> specialactEntityList) {
		this.specialactEntityList = specialactEntityList;
	}

	public List<Data30066000_SpCommonrecordsEntity> getSpecialactCommentEntityList() {
		return specialactCommentEntityList;
	}

	public void setSpecialactCommentEntityList(List<Data30066000_SpCommonrecordsEntity> specialactCommentEntityList) {
		this.specialactCommentEntityList = specialactCommentEntityList;
	}

	/**
	 * @return actEntityList
	 */
	public List<Data30066000_ActEntity> getActEntityList() {
		return actEntityList;
	}

	/**
	 * @param actEntityList the actEntityList to set
	 */
	public void setActEntityList(List<Data30066000_ActEntity> actEntityList) {
		this.actEntityList = actEntityList;
	}

	/**
	 * @return actSpEntityList
	 */
	public List<Data30066000_SpCommonrecordsEntity> getActSpEntityList() {
		return actSpEntityList;
	}

	/**
	 * @param actSpEntityList �Z�b�g���� actSpEntityList
	 */
	public void setActSpEntityList(List<Data30066000_SpCommonrecordsEntity> actSpEntityList) {
		this.actSpEntityList = actSpEntityList;
	}

	/**
	 * @return foreignActList
	 */
	public List<Data30066000_ForeignActEntity> getForeignActList() {
		return foreignActList;
	}

	/**
	 * @param foreignActList �Z�b�g���� foreignActList
	 */
	public void setForeignActList(List<Data30066000_ForeignActEntity> foreignActList) {
		this.foreignActList = foreignActList;
	}

	/**
	 * @return moralList
	 */
	public List<Data30066000_MoralEntity> getMoralList() {
		return moralList;
	}

	/**
	 * @param moralList �Z�b�g���� moralList
	 */
	public void setMoralList(List<Data30066000_MoralEntity> moralList) {
		this.moralList = moralList;
	}

	/**
	 * @return commentEntityList
	 */
	public List<Data30066000_CommentEntity> getCommentEntityList() {
		return commentEntityList;
	}

	/**
	 * @param commentEntityList the commentEntityList to set
	 */
	public void setCommentEntityList(
			List<Data30066000_CommentEntity> commentEntityList) {
		this.commentEntityList = commentEntityList;
	}

	/**
	 * @return spclassActEntityList
	 */
	public List<Data30066000_SpCommonrecordsEntity> getSpclassActEntityList() {
		return spclassActEntityList;
	}

	/**
	 * @param spclassActEntityList �Z�b�g���� spclassActEntityList
	 */
	public void setSpclassActEntityList(List<Data30066000_SpCommonrecordsEntity> spclassActEntityList) {
		this.spclassActEntityList = spclassActEntityList;
	}

	/**
	 * @return attendEntityList
	 */
	public List<Data30066000_AttendEntity> getAttendEntityList() {
		return attendEntityList;
	}

	/**
	 * @param attendEntityList the attendEntityList to set
	 */
	public void setAttendEntityList(List<Data30066000_AttendEntity> attendEntityList) {
		this.attendEntityList = attendEntityList;
	}

	public List<Data30066000_ForeignActFuzokukyotoEntity> getForeignActFuzokukyotoList() {
		return foreignActFuzokukyotoList;
	}

	public void setForeignActFuzokukyotoList(List<Data30066000_ForeignActFuzokukyotoEntity> foreignActFuzokukyotoList) {
		this.foreignActFuzokukyotoList = foreignActFuzokukyotoList;
	}

	/**
	 * @return spItemCommentList
	 */
	public List<Data30066000_SpCmlguideitemcommentEntity> getSpItemCommentList() {
		return spItemCommentList;
	}

	/**
	 * @param spItemCommentList �Z�b�g���� spItemCommentList
	 */
	public void setSpItemCommentList(List<Data30066000_SpCmlguideitemcommentEntity> spItemCommentList) {
		this.spItemCommentList = spItemCommentList;
	}

	/**
	 * @return totalClassesEntityList
	 */
	public List<Data30066000_SpCommonrecordsEntity> getTotalClassesEntityList() {
		return totalClassesEntityList;
	}

	/**
	 * @param totalClassesEntityList �Z�b�g���� totalClassesEntityList
	 */
	public void setTotalClassesEntityList(List<Data30066000_SpCommonrecordsEntity> totalClassesEntityList) {
		this.totalClassesEntityList = totalClassesEntityList;
	}

	/**
	 * @return watermark_on
	 */
	public boolean isWatermark_on() {
		return watermark_on;
	}

	/**
	 * @param watermark_on watermark_on��ݒ肷��
	 */
	public void setWatermark_on(boolean watermark_on) {
		this.watermark_on = watermark_on;
	}

	/**
	 * @return nameAddrOutputMode
	 */
	public String getNameAddrOutputMode() {
		return nameAddrOutputMode;
	}

	/**
	 * @param nameAddrOutputMode nameAddrOutputMode��ݒ肷��
	 */
	public void setNameAddrOutputMode(String nameAddrOutputMode) {
		this.nameAddrOutputMode = nameAddrOutputMode;
	}

	/**
	 * @return outputHistoryPage
	 */
	public boolean isOutputHistoryPage() {
		return outputHistoryPage;
	}

	/**
	 * @param outputHistoryPage outputHistoryPage��ݒ肷��
	 */
	public void setOutputHistoryPage(boolean outputHistoryPage) {
		this.outputHistoryPage = outputHistoryPage;
	}

}
