/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2018 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.formbean;

import java.util.HashMap;
import java.util.LinkedHashMap;

import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_ClubEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_CommentEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_EtceteraEntity;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Quote32155000Ajax_SpeactEntity;

/**
 * <PRE>
 *  ��������(�w���v�^)(�������S���w�Z) Ajax FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author
 * @since 1.0.
 */
public class Quote32155000AjaxFormBean  {

	/** ���ʊ����Ώۍ��� */
	private String speactitem = null;

	/** ���ʊ����Ώۊ��� */
	private String speactterm = null;

	/** ���ʊ����Ώۊ��� */
	private String goptcode = null;

	/** �����Ώ�tabIndex*/
	private String activeTabIndex = null;


	protected LinkedHashMap< String , Quote32155000Ajax_SpeactEntity> quote32155000Ajax_SpeactEntityMap;

	protected LinkedHashMap< String , Quote32155000Ajax_CommentEntity> quote32155000Ajax_CommentEntityMap ;

	protected LinkedHashMap< String , String > clubEntityMap =  new  LinkedHashMap< String , String> ();

	protected LinkedHashMap< String , Quote32155000Ajax_EtceteraEntity> quote32155000Ajax_EtceteraEntityMap;



	public String getSpeactitem() {
		return speactitem;
	}

	public void setSpeactitem(String speactitem) {
		this.speactitem = speactitem;
	}

	public String getSpeactterm() {
		return speactterm;
	}

	public void setSpeactterm(String speactterm) {
		this.speactterm = speactterm;
	}

	public String getGoptcode() {
		return goptcode;
	}

	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}

	public String getActiveTabIndex() {
		return activeTabIndex;
	}

	public void setActiveTabIndex(String activeTabIndex) {
		this.activeTabIndex = activeTabIndex;
	}

	public HashMap<String, Quote32155000Ajax_SpeactEntity> getQuote32155000Ajax_SpeactEntityMap() {
		return quote32155000Ajax_SpeactEntityMap;
	}

	public void setQuote32155000Ajax_SpeactEntityMap(
			LinkedHashMap<String, Quote32155000Ajax_SpeactEntity> quote32155000Ajax_SpeactEntityMap) {
		this.quote32155000Ajax_SpeactEntityMap = quote32155000Ajax_SpeactEntityMap;
	}

	public LinkedHashMap<String, Quote32155000Ajax_CommentEntity> getQuote32155000Ajax_CommentEntityMap() {
		return quote32155000Ajax_CommentEntityMap;
	}

	public void setQuote32155000Ajax_CommentEntityMap(
			LinkedHashMap<String, Quote32155000Ajax_CommentEntity> quote32155000Ajax_CommentEntityMap) {
		this.quote32155000Ajax_CommentEntityMap = quote32155000Ajax_CommentEntityMap;
	}

	public LinkedHashMap<String, String> getClubEntityMap() {
		return clubEntityMap;
	}

	public void setClubEntityMap(LinkedHashMap<String, String> clubEntityMap) {
		this.clubEntityMap = clubEntityMap;
	}

	public LinkedHashMap<String, Quote32155000Ajax_EtceteraEntity> getQuote32155000Ajax_EtceteraEntityMap() {
		return quote32155000Ajax_EtceteraEntityMap;
	}

	public void setQuote32155000Ajax_EtceteraEntityMap(
			LinkedHashMap<String, Quote32155000Ajax_EtceteraEntity> quote32155000Ajax_EtceteraEntityMap) {
		this.quote32155000Ajax_EtceteraEntityMap = quote32155000Ajax_EtceteraEntityMap;
	}



}
