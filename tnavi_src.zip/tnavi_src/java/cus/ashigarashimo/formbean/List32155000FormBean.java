/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2018 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.formbean;

import java.util.List;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Data32155000_StudentEntity;

/**
 * <PRE>
 *  ��������(�w���v�^)(�������S���w�Z) FormBean.
 * </PRE>
 *
 * <B>Create</B> 2018.11.22 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List32155000FormBean  {

	/** �N�x */
	private String nendo = "";

	/** �w�N */
	private String grade = "";

	/** �g */
	private String hmrclass = "";

	/** �N���X���� */
	private String hmrname = "";

	/** �N���X�ԍ� */
	private String clsno = "";

	/** ���яo�͎����R�[�h */
	private String gopt_code = "";

	/** ���яo�͎����R�[�h */
	private String stucode = "";

	/** �^�u�̑I����� */
	private Integer activeTabIndex;

	/** ���k���LIST */
	private List<Data32155000_StudentEntity> studentList;

	/** ���k���LIST Count */
	private Integer studentCount;

	/** ���яo�͎��� �v���_�E���p */
	private List<SimpleTagFormBean> termPullDownList;

	/** �w���S�C�t���O */
	private String hroomFlg;

	/** �����\���t���O(�����\���̂ݍŏ��N���X��I����ԂƂ����) */
	private boolean initFlg = false;

	/** �ǂݍ��ݎ�� */
	private String completKind;

	/** �X�V���b�Z�[�W */
	private String message;

	/** �G���[�t�@�C�����݃t���O */
	private boolean hasErrorFile = false;

	/** �G���[�t�@�C�����݃t���O */
	private boolean hasErrorFileSpeact = false;

	/** �G���[�t�@�C�����݃t���O */
	private boolean hasErrorFileComment = false;

	/** �G���[�t�@�C�����݃t���O */
	private boolean hasErrorFileClub = false;

	/** �G���[�t�@�C�����݃t���O */
	private boolean hasErrorFileEtcetera = false;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getHmrclass() {
		return hmrclass;
	}

	public void setHmrclass(String hmrclass) {
		this.hmrclass = hmrclass;
	}

	public String getHmrname() {
		return hmrname;
	}

	public void setHmrname(String hmrname) {
		this.hmrname = hmrname;
	}

	public String getClsno() {
		return clsno;
	}

	public void setClsno(String clsno) {
		this.clsno = clsno;
	}

	public String getGopt_code() {
		return gopt_code;
	}

	public void setGopt_code(String gopt_code) {
		this.gopt_code = gopt_code;
	}

	public String getStucode() {
		return stucode;
	}

	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	public Integer getActiveTabIndex() {
		return activeTabIndex;
	}

	public void setActiveTabIndex(Integer activeTabIndex) {
		this.activeTabIndex = activeTabIndex;
	}

	public List<Data32155000_StudentEntity> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<Data32155000_StudentEntity> studentList) {
		this.studentList = studentList;
	}

	public Integer getStudentCount() {
		return studentCount;
	}

	public void setStudentCount(Integer studentCount) {
		this.studentCount = studentCount;
	}

	public List<SimpleTagFormBean> getTermPullDownList() {
		return termPullDownList;
	}

	public void setTermPullDownList(List<SimpleTagFormBean> termPullDownList) {
		this.termPullDownList = termPullDownList;
	}

	public String getHroomFlg() {
		return hroomFlg;
	}

	public void setHroomFlg(String hroomFlg) {
		this.hroomFlg = hroomFlg;
	}

	public boolean isInitFlg() {
		return initFlg;
	}

	public void setInitFlg(boolean initFlg) {
		this.initFlg = initFlg;
	}

	public String getCompletKind() {
		return completKind;
	}

	public void setCompletKind(String completKind) {
		this.completKind = completKind;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isHasErrorFile() {
		return hasErrorFile;
	}

	public void setHasErrorFile(boolean hasErrorFile) {
		this.hasErrorFile = hasErrorFile;
	}

	public boolean isHasErrorFileSpeact() {
		return hasErrorFileSpeact;
	}

	public void setHasErrorFileSpeact(boolean hasErrorFileSpeact) {
		this.hasErrorFileSpeact = hasErrorFileSpeact;
	}

	public boolean isHasErrorFileComment() {
		return hasErrorFileComment;
	}

	public void setHasErrorFileComment(boolean hasErrorFileComment) {
		this.hasErrorFileComment = hasErrorFileComment;
	}

	public boolean isHasErrorFileClub() {
		return hasErrorFileClub;
	}

	public void setHasErrorFileClub(boolean hasErrorFileClub) {
		this.hasErrorFileClub = hasErrorFileClub;
	}

	public boolean isHasErrorFileEtcetera() {
		return hasErrorFileEtcetera;
	}

	public void setHasErrorFileEtcetera(boolean hasErrorFileEtcetera) {
		this.hasErrorFileEtcetera = hasErrorFileEtcetera;
	}

}
