/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2018  System D inc.,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarashimo.formbean;

import java.util.List;
import jp.co.systemd.tnavi.cus.ashigarashimo.db.entity.Data32155000_CmlguidecommentEntity;

/**
 * <PRE>
 * �ߔN�x�v�^���o�^ - ���Ȑ���(�]��)�o�^�pFormBean.
 * </PRE>
 *
 * <B>Create</B> 2016.11.15 BY SD nishizawa<BR>
 * <B>remark</B><BR>
 *
 * @since 1.0.
 */
public class Regist32155000FormBean {


	/** ���b�Z�[�W */
	private String message = "";

	/** ���Ȑ���(�]��)���List */
	private List<Data32155000_CmlguidecommentEntity> cmlguidecommentEntityList;

	/** ������� */
	private String completKind;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCompletKind() {
		return completKind;
	}

	public void setCompletKind(String completKind) {
		this.completKind = completKind;
	}

	public List<Data32155000_CmlguidecommentEntity> getCmlguidecommentEntityList() {
		return cmlguidecommentEntityList;
	}

	public void setCmlguidecommentEntityList(List<Data32155000_CmlguidecommentEntity> cmlguidecommentEntityList) {
		this.cmlguidecommentEntityList = cmlguidecommentEntityList;
	}

}
