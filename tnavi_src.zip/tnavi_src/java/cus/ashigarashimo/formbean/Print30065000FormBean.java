package jp.co.systemd.tnavi.cus.ashigarashimo.formbean;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.entity.CodeEntity;
import jp.co.systemd.tnavi.common.db.entity.UserHistoryEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_CareerInfoEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_CmlguideAdressInfoEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_HroomInfoEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_PrincipalHistoryEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_RegisterInfoEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_StaffEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_StuSchoolInfoEntity;
import jp.co.systemd.tnavi.junior.aff.db.entity.Data30065000_StudentInfoEntity;

/**
 * <PRE>
 * ���k�w���v�^�l��1(COReports��) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2016.03.17 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print30065000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �����R�[�h */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �N�x(yyyy) */
	private String nendoSeireki = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �N�x�I���� */
	private String nendoEndYmd = DEFALUT_VALUE;

	/**COReports�o�͎� �l��1 �t�H�[���t�@�C��*/
	private String coFormPath_yosiki1 = DEFALUT_VALUE;

	/**�ݐЊJ�n�E�I�����t�Ǘ��P��*/
	private String crrymdFlg = DEFALUT_VALUE;

	/** ���k�����E�w�Z�� */
	private Data30065000_StuSchoolInfoEntity stuSchoolInfo;

	/** �o�͑Ώ۔N�x�܂ł̃z�[�����[�����̃��X�g */
	private List<Data30065000_HroomInfoEntity> hroomInfoList;

	/** �������k���i�[Entity */
	private Data30065000_StudentInfoEntity studentInfo;

	/** ���w�O�̌o�����i�[Entity */
	private Data30065000_CareerInfoEntity careerInfo;

	/** �O�ЍZ�̏�� */
	private String cr2_preinfo = DEFALUT_VALUE;

	/** �]�ފw�����Entity */
	private Data30065000_RegisterInfoEntity registerInfo;

	/** ���Ɠ� */
	private String graduateDate = DEFALUT_VALUE;

	/** �i�w�擙���Entity */
	private Data30065000_CmlguideAdressInfoEntity cmlguideAdressInfo;

	/** �A�E�擙��� */
	private String jobInfo = DEFALUT_VALUE;

	/** �w�Z���Entity */
	private UserHistoryEntity userHistoryInfo;

	/** �{�Z���Entity(���������������Z�̏ꍇ�̂ݎ擾) */
	private UserHistoryEntity honkouHistoryInfo;

	/** �w�Z�������������Map[key:�w�N value:�w�Z�������������EntityList] */
	private LinkedHashMap<String, List<Data30065000_StaffEntity>> principalHistoryMap;

	/** �w���S�C�����������Map[key:�w�N value:�w���S�C�����������EntityList] */
	private LinkedHashMap<String, List<Data30065000_StaffEntity>> staffHistoryMap;

	/** �w���S�C�����������Map ���l�y�[�W�p [key:�w�N value:�w���S�C�����������EntityList] */
	private LinkedHashMap<String, List<Data30065000_StaffEntity>> staffHistoryRemarkMap;

	/** �w���S�C�̈�e�摜�i�[Map */
	private Map<String, byte[]> principalStampMap;

	/** �w�Z���̈�e�摜�i�[Map */
	private Map<String, byte[]> tanninStampMap;

	/** �������k�E�ی�҂̎����E�Z���ύX�����i�[Map */
	Map<String, String> stuHistoryMap;

	/** �w�b�_���w�����̏o�͌`��(true:�z�[�����[������ false:�g) */
	private boolean isHeaderOutputHroomName = false;

	/** ���t�̘a��ϊ������p�̃R�[�h���X�g */
	List<CodeEntity> codeList;

	/** �������̏o�͗L��*/
	private boolean watermark_on = false;

	/** �����E�Z���̈󎚓��e�̑I��*/
	private String nameAddrOutputMode = DEFALUT_VALUE;

	/** �����E�Z���̗����y�[�W�̏o�͗L��*/
	private boolean outputHistoryPage = false;

	/** �Z���E�S�C�����̊��ԏo�͗L��*/
	private boolean outputTeacherHistoryTerm = false;

	/** �Z���E�S�C�����̏o�͏� �ŐV�������\���ifalse:�ŐV���~���\���j */
	private boolean outputTeacherHistoryOrderAsc = false;

	/** �����E�Z���̗����o�͌`�� */
	private String outputhistoryFormat = DEFALUT_VALUE;

	/** �l��1�^�C�g���ɕt�����鎩���̖�(�������S���w�Z�J�X�^�}�C�Y)*/
	private String localGovNm = DEFALUT_VALUE;

	/** ���l�̋��E�������ɕ\������Z����񃊃X�g */
	private List<Data30065000_PrincipalHistoryEntity> principalHistoryRemarkList;

	/**
	 * @return userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode the userCode to set
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	/**
	 * @return nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo the nendo to set
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return nendoSeireki
	 */
	public String getNendoSeireki() {
		return nendoSeireki;
	}

	/**
	 * @param nendoSeireki the nendoSeireki to set
	 */
	public void setNendoSeireki(String nendoSeireki) {
		this.nendoSeireki = nendoSeireki;
	}

	/**
	 * @return outputDate
	 */
	public String getOutputDate() {
		return outputDate;
	}

	/**
	 * @param outputDate the outputDate to set
	 */
	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	/**
	 * @return nendoEndYmd
	 */
	public String getNendoEndYmd() {
		return nendoEndYmd;
	}

	/**
	 * @param nendoEndYmd the nendoEndYmd to set
	 */
	public void setNendoEndYmd(String nendoEndYmd) {
		this.nendoEndYmd = nendoEndYmd;
	}

	/**
	 * @return coFormPath_yosiki1
	 */
	public String getCoFormPath_yosiki1() {
		return coFormPath_yosiki1;
	}

	/**
	 * @param coFormPath_yosiki1 the coFormPath_yosiki1 to set
	 */
	public void setCoFormPath_yosiki1(String coFormPath_yosiki1) {
		this.coFormPath_yosiki1 = coFormPath_yosiki1;
	}

	/**
	 * @return crrymdFlg
	 */
	public String getCrrymdFlg() {
		return crrymdFlg;
	}

	/**
	 * @param crrymdFlg the crrymdFlg to set
	 */
	public void setCrrymdFlg(String crrymdFlg) {
		this.crrymdFlg = crrymdFlg;
	}

	/**
	 * @return stuSchoolInfo
	 */
	public Data30065000_StuSchoolInfoEntity getStuSchoolInfo() {
		return stuSchoolInfo;
	}

	/**
	 * @param stuSchoolInfo the stuSchoolInfo to set
	 */
	public void setStuSchoolInfo(Data30065000_StuSchoolInfoEntity stuSchoolInfo) {
		this.stuSchoolInfo = stuSchoolInfo;
	}

	/**
	 * @return hroomInfoList
	 */
	public List<Data30065000_HroomInfoEntity> getHroomInfoList() {
		return hroomInfoList;
	}

	/**
	 * @param hroomInfoList the hroomInfoList to set
	 */
	public void setHroomInfoList(List<Data30065000_HroomInfoEntity> hroomInfoList) {
		this.hroomInfoList = hroomInfoList;
	}

	/**
	 * @return studentInfo
	 */
	public Data30065000_StudentInfoEntity getStudentInfo() {
		return studentInfo;
	}

	/**
	 * @param studentInfo the studentInfo to set
	 */
	public void setStudentInfo(Data30065000_StudentInfoEntity studentInfo) {
		this.studentInfo = studentInfo;
	}

	/**
	 * @return careerInfo
	 */
	public Data30065000_CareerInfoEntity getCareerInfo() {
		return careerInfo;
	}

	/**
	 * @param careerInfo the careerInfo to set
	 */
	public void setCareerInfo(Data30065000_CareerInfoEntity careerInfo) {
		this.careerInfo = careerInfo;
	}

	/**
	 * @return cr2_preinfo
	 */
	public String getCr2_preinfo() {
		return cr2_preinfo;
	}

	/**
	 * @param cr2_preinfo the cr2_preinfo to set
	 */
	public void setCr2_preinfo(String cr2_preinfo) {
		this.cr2_preinfo = cr2_preinfo;
	}

	/**
	 * @return registerInfo
	 */
	public Data30065000_RegisterInfoEntity getRegisterInfo() {
		return registerInfo;
	}

	/**
	 * @param registerInfo the registerInfo to set
	 */
	public void setRegisterInfo(Data30065000_RegisterInfoEntity registerInfo) {
		this.registerInfo = registerInfo;
	}

	/**
	 * @return graduateDate
	 */
	public String getGraduateDate() {
		return graduateDate;
	}

	/**
	 * @param graduateDate the graduateDate to set
	 */
	public void setGraduateDate(String graduateDate) {
		this.graduateDate = graduateDate;
	}

	/**
	 * @return cmlguideAdressInfo
	 */
	public Data30065000_CmlguideAdressInfoEntity getCmlguideAdressInfo() {
		return cmlguideAdressInfo;
	}

	/**
	 * @param cmlguideAdressInfo the cmlguideAdressInfo to set
	 */
	public void setCmlguideAdressInfo(
			Data30065000_CmlguideAdressInfoEntity cmlguideAdressInfo) {
		this.cmlguideAdressInfo = cmlguideAdressInfo;
	}

	/**
	 * @return jobInfo
	 */
	public String getJobInfo() {
		return jobInfo;
	}

	/**
	 * @param jobInfo the jobInfo to set
	 */
	public void setJobInfo(String jobInfo) {
		this.jobInfo = jobInfo;
	}

	/**
	 * @return userHistoryInfo
	 */
	public UserHistoryEntity getUserHistoryInfo() {
		return userHistoryInfo;
	}

	/**
	 * @param userHistoryInfo the userHistoryInfo to set
	 */
	public void setUserHistoryInfo(UserHistoryEntity userHistoryInfo) {
		this.userHistoryInfo = userHistoryInfo;
	}

	/**
	 * @return honkouHistoryInfo
	 */
	public UserHistoryEntity getHonkouHistoryInfo() {
		return honkouHistoryInfo;
	}

	/**
	 * @param honkouHistoryInfo the honkouHistoryInfo to set
	 */
	public void setHonkouHistoryInfo(UserHistoryEntity honkouHistoryInfo) {
		this.honkouHistoryInfo = honkouHistoryInfo;
	}

	/**
	 * @return principalHistoryMap
	 */
	public LinkedHashMap<String, List<Data30065000_StaffEntity>> getPrincipalHistoryMap() {
		return principalHistoryMap;
	}

	/**
	 * @param principalHistoryMap the principalHistoryMap to set
	 */
	public void setPrincipalHistoryMap(
			LinkedHashMap<String, List<Data30065000_StaffEntity>> principalHistoryMap) {
		this.principalHistoryMap = principalHistoryMap;
	}

	/**
	 * @return staffHistoryMap
	 */
	public LinkedHashMap<String, List<Data30065000_StaffEntity>> getStaffHistoryMap() {
		return staffHistoryMap;
	}

	/**
	 * @param staffHistoryMap the staffHistoryMap to set
	 */
	public void setStaffHistoryMap(
			LinkedHashMap<String, List<Data30065000_StaffEntity>> staffHistoryMap) {
		this.staffHistoryMap = staffHistoryMap;
	}

	/**
	 * @return staffHistoryRemarkMap
	 */
	public LinkedHashMap<String, List<Data30065000_StaffEntity>> getStaffHistoryRemarkMap() {
		return staffHistoryRemarkMap;
	}

	/**
	 * @param staffHistoryRemarkMap �Z�b�g���� staffHistoryRemarkMap
	 */
	public void setStaffHistoryRemarkMap(LinkedHashMap<String, List<Data30065000_StaffEntity>> staffHistoryRemarkMap) {
		this.staffHistoryRemarkMap = staffHistoryRemarkMap;
	}

	/**
	 * @return principalStampMap
	 */
	public Map<String, byte[]> getPrincipalStampMap() {
		return principalStampMap;
	}

	/**
	 * @param principalStampMap the principalStampMap to set
	 */
	public void setPrincipalStampMap(Map<String, byte[]> principalStampMap) {
		this.principalStampMap = principalStampMap;
	}

	/**
	 * @return tanninStampMap
	 */
	public Map<String, byte[]> getTanninStampMap() {
		return tanninStampMap;
	}

	/**
	 * @param tanninStampMap the tanninStampMap to set
	 */
	public void setTanninStampMap(Map<String, byte[]> tanninStampMap) {
		this.tanninStampMap = tanninStampMap;
	}

	/**
	 * @return stuHistoryMap
	 */
	public Map<String, String> getStuHistoryMap() {
		return stuHistoryMap;
	}

	/**
	 * @param stuHistoryMap the stuHistoryMap to set
	 */
	public void setStuHistoryMap(Map<String, String> stuHistoryMap) {
		this.stuHistoryMap = stuHistoryMap;
	}

	/**
	 * @return isHeaderOutputHroomName
	 */
	public boolean isHeaderOutputHroomName() {
		return isHeaderOutputHroomName;
	}

	/**
	 * @param isHeaderOutputHroomName the isHeaderOutputHroomName to set
	 */
	public void setHeaderOutputHroomName(boolean isHeaderOutputHroomName) {
		this.isHeaderOutputHroomName = isHeaderOutputHroomName;
	}

	/**
	 * @return codeList
	 */
	public List<CodeEntity> getCodeList() {
		return codeList;
	}

	/**
	 * @param codeList the codeList to set
	 */
	public void setCodeList(List<CodeEntity> codeList) {
		this.codeList = codeList;
	}

	/**
	 * @return watermark_on
	 */
	public boolean isWatermark_on() {
		return watermark_on;
	}

	/**
	 * @param watermark_on watermark_on��ݒ肷��
	 */
	public void setWatermark_on(boolean watermark_on) {
		this.watermark_on = watermark_on;
	}

	/**
	 * @return nameAddrOutputMode
	 */
	public String getNameAddrOutputMode() {
		return nameAddrOutputMode;
	}

	/**
	 * @param nameAddrOutputMode nameAddrOutputMode��ݒ肷��
	 */
	public void setNameAddrOutputMode(String nameAddrOutputMode) {
		this.nameAddrOutputMode = nameAddrOutputMode;
	}

	/**
	 * @return outputHistoryPage
	 */
	public boolean isOutputHistoryPage() {
		return outputHistoryPage;
	}

	/**
	 * @param outputHistoryPage outputHistoryPage��ݒ肷��
	 */
	public void setOutputHistoryPage(boolean outputHistoryPage) {
		this.outputHistoryPage = outputHistoryPage;
	}

	/**
	 * @return outputTeacherHistoryTerm
	 */
	public boolean isOutputTeacherHistoryTerm() {
		return outputTeacherHistoryTerm;
	}

	/**
	 * @param outputTeacherHistoryTerm outputTeacherHistoryTerm��ݒ肷��
	 */
	public void setOutputTeacherHistoryTerm(boolean outputTeacherHistoryTerm) {
		this.outputTeacherHistoryTerm = outputTeacherHistoryTerm;
	}

	/**
	 * @return outputTeacherHistoryOrderAsc
	 */
	public boolean isOutputTeacherHistoryOrderAsc() {
		return outputTeacherHistoryOrderAsc;
	}

	/**
	 * @param outputTeacherHistoryOrderAsc �Z�b�g���� outputTeacherHistoryOrderAsc
	 */
	public void setOutputTeacherHistoryOrderAsc(boolean outputTeacherHistoryOrderAsc) {
		this.outputTeacherHistoryOrderAsc = outputTeacherHistoryOrderAsc;
	}

	/**
	 * @return outputhistoryFormat
	 */
	public String getOutputhistoryFormat() {
		return outputhistoryFormat;
	}

	/**
	 * @param outputhistoryFormat �Z�b�g���� outputhistoryFormat
	 */
	public void setOutputhistoryFormat(String outputhistoryFormat) {
		this.outputhistoryFormat = outputhistoryFormat;
	}

	public String getLocalGovNm() {
		return localGovNm;
	}

	public void setLocalGovNm(String localGovNm) {
		this.localGovNm = localGovNm;
	}

	/**
	 * @return principalHistoryRemarkList
	 */
	public List<Data30065000_PrincipalHistoryEntity> getPrincipalHistoryRemarkList() {
		return principalHistoryRemarkList;
	}

	/**
	 * @param principalHistoryRemarkList �Z�b�g���� principalHistoryRemarkList
	 */
	public void setPrincipalHistoryRemarkList(List<Data30065000_PrincipalHistoryEntity> principalHistoryRemarkList) {
		this.principalHistoryRemarkList = principalHistoryRemarkList;
	}


}
