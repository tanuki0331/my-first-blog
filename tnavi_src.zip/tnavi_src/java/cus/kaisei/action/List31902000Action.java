/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.service.List31902000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31902000FormBean;
import jp.co.systemd.tnavi.sbo_common.constants.MessageProperties;
import jp.co.systemd.tnavi.sbo_common.utility.SboMessageOperator;

/**
 * <PRE>
 * ����������ʒʒm�[��� ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.23 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31902000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List31902000Action.class);

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return false;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {
		SboMessageOperator msg = new SboMessageOperator();
		Object[] param = { "�y��ʁz����������ʒʒm�[��� START" };
		log.info(msg.getMessage(MessageProperties.M30026, param));

		List31902000FormBean form = new List31902000FormBean();

		// �����R�[�h
		String userCode = sessionBean.getUserCode();
		form.setUserCode(userCode);
		// �N�x
		String year = sessionBean.getSystemNendoSeireki();
		form.setNendo(year);
		// �N
		String glade = sessionBean.getSelectHroomKey().getGlade();
		form.setGlade(glade);
		// �g
		String hmrClass = sessionBean.getSelectHroomKey().getHmrclass();
		form.setHmrClass(hmrClass);

		// �f�[�^�擾����
		List31902000Service service = new List31902000Service(userCode, year, glade, hmrClass);
		try {
			service.execute();
		} catch (TnaviDbException e) {
			msg.gotoSystemErrorPage(sc, request, response);
			return null;
		}

		// ��ʕ\�����ڈڑ�����
		List31902000FormBean serviceResultBean = service.getList31902000FormBean();
		// �z�[�����[����
		form.setHmrName(serviceResultBean.getHmrName());
		// �o�͎������X�g�ݒ�
		form.setSemesterList(serviceResultBean.getSemesterList());
		form.setSemester(serviceResultBean.getSemester());
		// ���ƕ]���v���ʃ��X�g�ݒ�
		form.setLessonEvaluationPlanTypeList(serviceResultBean.getLessonEvaluationPlanTypeList());
		form.setLessonEvaluationPlanType(serviceResultBean.getLessonEvaluationPlanType());
		// ���{�������Ȗ����W�I�{�^���ݒ�
		form.setImplementationWithoutSubjectNameList(serviceResultBean.getImplementationWithoutSubjectNameList());
		form.setImplementationWithoutSubjectName(serviceResultBean.getImplementationWithoutSubjectName());
		// ���k�ꗗ�ݒ�
		form.setStudentList(serviceResultBean.getStudentList());

		request.setAttribute("FORM_BEAN", form);

		log.info(msg.getMessage(MessageProperties.M30027, param));

		return null;
	}

}
