/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.service.List31904000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31904000FormBean;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Search31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31904000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List31904000Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz���ȕʊϓ_�ʏW�v�\ START");

		// ------------------------------------------------------------------------------------------
		// FormBean����
		// ------------------------------------------------------------------------------------------
		List31904000FormBean listFormBean = (List31904000FormBean)copyRequestParamToFormBean(request, new List31904000FormBean());
		
		// ------------------------------------------------------------------------------------------
		// ��������
		// ------------------------------------------------------------------------------------------
		if (listFormBean.getSelectedGrade().equals("")) {
			//�Z�b�V������bean�Z�b�g
			Search31904000FormBean searchFormBean = (Search31904000FormBean)copyRequestParamToFormBean(request, new Search31904000FormBean());
			sessionBean.getKaiseiSessionBean().setSearch30904000FormBean((Object)searchFormBean);
			//�w�N�E���Ȃ̏����l�Z�b�g
			listFormBean.setSelectedGrade(listFormBean.getGrade());
			listFormBean.setSelectedItem(listFormBean.getItem());
		}

		// ------------------------------------------------------------------------------------------
		// �f�[�^�̎擾����
		// ------------------------------------------------------------------------------------------
		List31904000Service service = new List31904000Service(sessionBean, listFormBean);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", listFormBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz���ȕʊϓ_�ʏW�v�\ END");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}

}
