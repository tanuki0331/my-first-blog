/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.common.formbean.ResultMessage;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.service.List30246000Service;
import jp.co.systemd.tnavi.cus.kaisei.db.service.Regist30246000Service;
import jp.co.systemd.tnavi.junior.aff.formbean.List30246000FormBean;

/**
 * ��������(�w���v�^) �o�^Action.
 *
 * <B>Create</B> 2012.12.4 BY SATO<BR>
 * <B>Modify</B> 2014.08.28 BY SD inasawa<BR>
 * ��IE10�s��Ή�(���s�R�[�h���u\n\n�v���u\r\n�v�ɒu��<BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Regist30246000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist30246000Action.class);

	/** �w���ʒS�C�m��Map */
	private Map<String, Boolean> studentMap = new HashMap<String, Boolean>();

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {
		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz��������(�w���v�^) �o�^���� START");

		// ------------------------------------------------------------------------------------------
		// �p�����[�^�l �擾
		// ------------------------------------------------------------------------------------------

        // �I�����ꂽ�N���X
		HroomKeyFormBean hroomKeyFormBean = sessionBean.getSelectHroomKey();

        // �N�x�擾
        String systemNendoSeireki = sessionBean.getSystemNendoSeireki();

        // staff
        String staffid = sessionBean.getStaffId();

		String[] students = request.getParameterValues("stucodes");
		if (students != null && students.length > 0) {
			Map<String, String> registmap = new HashMap<String, String>();

			for(String student : students) {
				String value = request.getParameter("value@@" + student);
				// 2014.08.28_inasawa
				value = value.replace("\n\n", "\r\n");

				if(request.getParameter("diispLabel@@" + student).equals("true")){
					studentMap.put(student,true);
				}
				else{
					studentMap.put(student,false);
				}
				registmap.put(student, value);
			}

			Regist30246000Service updateService = new Regist30246000Service(registmap, hroomKeyFormBean, systemNendoSeireki, staffid,studentMap);
			updateService.execute();
		}

		// ------------------------------------------------------------------------------------------
		// FormBean����
		// ------------------------------------------------------------------------------------------
		List30246000FormBean formBean = new List30246000FormBean();

        // �I�����ꂽ�N���X
        formBean.setHroomKeyFormBean(hroomKeyFormBean);

		// ------------------------------------------------------------------------------------------
		// �����\���ݒ� - service�Ō�������FormBean�ɒl���Z�b�g
		// ------------------------------------------------------------------------------------------
		List30246000Service service = new List30246000Service(formBean, systemNendoSeireki);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		List<ResultMessage> messageList = new ArrayList<ResultMessage>();
		messageList.add(new ResultMessage(ResultMessage.NORMAL_MESSAGE, "�����i�w���v�^�j���X�V���܂����B"));
		formBean.setAlertMessageList(messageList);

		request.setAttribute("FORM_BEAN", formBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz��������(�w���v�^) �o�^���� END");

		return null;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}
}
