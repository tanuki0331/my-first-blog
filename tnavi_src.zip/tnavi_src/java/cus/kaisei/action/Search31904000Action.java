/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.cus.kaisei.db.service.Search31904000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Search31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Search31904000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Search31904000Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz���ȕʊϓ_�ʏW�v�\ START");
		
		// ------------------------------------------------------------------------------------------
		// FormBean����
		// ------------------------------------------------------------------------------------------
		Search31904000FormBean searchFormBean = (Search31904000FormBean)copyRequestParamToFormBean(request, new Search31904000FormBean());

		// ------------------------------------------------------------------------------------------
		// �����ݒ�
		// ------------------------------------------------------------------------------------------
		if (super.isBackAction()) {
			searchFormBean = (Search31904000FormBean)sessionBean.getKaiseiSessionBean().getSearch30904000FormBean();
		} else if(searchFormBean.getNendo() == null || searchFormBean.getNendo().length() == 0){
			searchFormBean.setNendo(sessionBean.getSystemNendoSeireki());
			// --------------------------------------------------------------------------------------
			// �J�ڔ���
			// --------------------------------------------------------------------------------------
			if (sessionBean.getSubjectChargeFormBean() != null){
				// ���ȒS������̑J�ڂł���B
				searchFormBean.setSubjectStfCode(sessionBean.getSubjectChargeFormBean().getStfCode());
			}else{
				// ���ȒS������̑J�ڂł͂Ȃ��B(��������̑J�ڂł���)
				searchFormBean.setSubjectStfCode("");
			}
		}
		
		DateFormatUtility dateFormatUtility = sessionBean.getDateFormatUtilityForScreen();
		searchFormBean.setDispNendo(dateFormatUtility.formatDate("YYYY", searchFormBean.getNendo()));

		// ------------------------------------------------------------------------------------------
		// �f�[�^�̎擾����
		// ------------------------------------------------------------------------------------------
		Search31904000Service service = new Search31904000Service(sessionBean, searchFormBean);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", searchFormBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz���ȕʊϓ_�ʏW�v�\ END");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}

}
