/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.kaisei.db.service.List31904000Service;
import jp.co.systemd.tnavi.cus.kaisei.db.service.Regist31904000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Regist31904000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List31904000Action.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		// ------------------------------------------------------------------------------------------
		// �����J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz���ȕʊϓ_�ʏW�v�\ START");

		// ------------------------------------------------------------------------------------------
		// FormBean����
		// ------------------------------------------------------------------------------------------
		List31904000FormBean listFormBean = (List31904000FormBean)copyRequestParamToFormBean(request, new List31904000FormBean());
		
		// ------------------------------------------------------------------------------------------
		// ��������
		// ------------------------------------------------------------------------------------------
		if (listFormBean.getSelectedGrade().equals("")) {
			listFormBean.setSelectedGrade(listFormBean.getGrade());
			listFormBean.setSelectedItem(listFormBean.getItem());
		}
		//�`�F�b�N���e���擾
		String[] stu_term_checks   = request.getParameterValues("stu_term_check");

		// ------------------------------------------------------------------------------------------
		// �f�[�^�̍X�V����
		// ------------------------------------------------------------------------------------------
		String today = DateUtility.getSystemDate();
		Regist31904000Service registService = new Regist31904000Service(sessionBean.getUserCode(),
				sessionBean.getStaffId(),today,listFormBean,stu_term_checks);
		registService.execute();

		// ------------------------------------------------------------------------------------------
		// �f�[�^�̎擾����
		// ------------------------------------------------------------------------------------------
		List31904000Service service = new List31904000Service(sessionBean, listFormBean);
		service.execute();
		
		listFormBean.setMessage(registService.getMessage());

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", listFormBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info("�y��ʁz���ȕʊϓ_�ʏW�v�\ END");

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// ���̓`�F�b�N����
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		// �X�L�b�v�Ȃ�
		return false;
	}

}
