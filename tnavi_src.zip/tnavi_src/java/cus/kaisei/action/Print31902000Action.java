package jp.co.systemd.tnavi.cus.kaisei.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_studentEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.service.Print31902000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31902000FormBean;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Print31902000FormBean;
import jp.co.systemd.tnavi.cus.kaisei.print.Print31902000;

/**
 * <PRE>
 * ����������ʒʒm�[��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.24 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31902000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print31902000Action.class);

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("����������ʒʒm�[��� START");

		// ------------------------------------------------------------------------------------------
		// ���FormBean�����ArequestParameter�̎擾
		// ------------------------------------------------------------------------------------------
		List31902000FormBean listFormBean = (List31902000FormBean)copyRequestParamToFormBean(request, new List31902000FormBean());

		// ���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("����������ʒʒm�[");

		try {
			Print31902000Service service = new Print31902000Service(sessionBean, listFormBean);
			service.execute();
			Print31902000FormBean printFormBean = service.getPrintFormBean();

			Print31902000 print = new Print31902000(sessionBean.getUserCode(), printFormBean, service);
			print.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print.execute(printFormBean.getFormFileName());

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("����������ʒʒm�[���  END");

		return null;
	}


	@Override
	protected Log getLogClass() {
		return null;
	}


	/**
	 * ���N�G�X�g��formbean�ɃR�s�[����.
	 * @param request Http���N�G�X�g
	 * @param formBean �t�H�[��Bean
	 * @return �R�s�[�����t�H�[��Bean
	 */
	private List31902000FormBean copyRequestParamToFormBean(HttpServletRequest request, List31902000FormBean bean) {
		bean = (List31902000FormBean)super.copyRequestParamToFormBean(request, bean);
		String[] clsStucode = request.getParameterValues("output_student");
		String[] clsGlade = request.getParameterValues("cls_glade");
		String[] hmrClass = request.getParameterValues("hmr_class");
		String[] clsNumber = request.getParameterValues("cls_number");
		String[] stuName = request.getParameterValues("stu_name");
		String[] studentCodeName = request.getParameterValues("student_code_name");
		String[] codeName;
		int pos = 0;

		bean.setGlade(request.getParameterValues("cls_glade")[0]);
		bean.setHmrClass(request.getParameterValues("hmr_class")[0]);
		List<Data31902000_studentEntity> studentList = new ArrayList<Data31902000_studentEntity>();
		for (int i = 0; i < clsStucode.length; i++) {
			Data31902000_studentEntity student = new Data31902000_studentEntity();
			student.setCls_stucode(clsStucode[i]);
			student.setCls_glade(clsGlade[i]);
			student.setHmr_class(hmrClass[i]);

			for (int j = 0; j < studentCodeName.length; j++) {
				codeName = studentCodeName[j].split(":");
				if (codeName[0].equals(student.getCls_stucode())) {
					pos = j;
					break;
				}
			}

			student.setCls_number(clsNumber[pos]);
			student.setStu_name(stuName[pos]);
			student.setStudent_code_name(studentCodeName[pos]);

			studentList.add(student);
		}
		bean.setStudentList(studentList);

		return bean;
	}

}
