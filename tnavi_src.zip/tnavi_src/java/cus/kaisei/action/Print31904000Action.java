package jp.co.systemd.tnavi.cus.kaisei.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.cus.kaisei.db.service.Print31904000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Search31904000FormBean;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Print31904000FormBean;
import jp.co.systemd.tnavi.cus.kaisei.print.Print31904000;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31904000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print31904000Action.class);
	private static final String FORM_NAME = "cus/kaisei/form31904000.cfx";
	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("���ȕʊϓ_�ʏW�v�\ START");

		// ------------------------------------------------------------------------------------------
		// ���FormBean�����ArequestParameter�̎擾
		// ------------------------------------------------------------------------------------------
		Search31904000FormBean searchFormBean = (Search31904000FormBean)copyRequestParamToFormBean(request, new Search31904000FormBean());

		//-----���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("���ȕʊϓ_�ʏW�v�\");

		try{
			Print31904000Service service = new Print31904000Service(sessionBean, searchFormBean);
			service.execute();
			Print31904000FormBean printFormBean = service.getPrintFormBean();
			Print31904000 print = new Print31904000(sessionBean.getUserCode(),printFormBean);
			print.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print.execute(FORM_NAME);

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("���ȕʊϓ_�ʏW�v�\ END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return null;
	}

}
