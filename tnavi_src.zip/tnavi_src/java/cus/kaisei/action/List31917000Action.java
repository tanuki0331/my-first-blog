/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.service.List31917000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31917000FormBean;
import jp.co.systemd.tnavi.sbo_common.constants.MessageProperties;
import jp.co.systemd.tnavi.sbo_common.utility.SboMessageOperator;

/**
 * <PRE>
 * �ϓ_�ʌ��ʈꗗ��� ��� Action�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.07.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31917000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(List31917000Action.class);

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return false;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request,
			SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {
		SboMessageOperator msg = new SboMessageOperator();
		Object[] param = { "�y��ʁz�ϓ_�ʌ��ʈꗗ��� START" };
		// ------------------------------------------------------------------------------------------
		// �J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info(msg.getMessage(MessageProperties.M30026, param));

		// �T�[�r�X�N���X�̐���
		List31917000Service service = new List31917000Service();

		// Request(�ʏ�J�ڂ̏ꍇ) ���� Session(��߂飃{�^�������̏ꍇ)�ɐݒ肳��Ă���l����FormBean���쐬����
		service.execute(request, sessionBean);

		// �쐬����FormBean���擾
		List31917000FormBean formBean = service.getList31917000FormBean();

		// Request��FormBean���Z�b�g����B
		request.setAttribute("FORM_BEAN", formBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info(msg.getMessage(MessageProperties.M30027, param));

		return null;
	}

}
