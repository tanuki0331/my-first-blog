/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD.inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.session;

import jp.co.systemd.tnavi.cus.kaisei.formbean.List30326000FormBean;

/**
 * <PRE>
 * <B><FONT SIZE=3 COLOR=BLUE>
 * �J�������@�\ SessionBean
 * </FONT><BR></B>
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 *
 * @author
 * @since
 */
public class KaiseiSessionBean {

	/** ���ȕʊϓ_�ʏW�v�\ */
	private Object search30904000FormBean;

	/** ���ʊ����̋L�^����(�e�L�X�g�G���A�T�C�Y�ϑΉ���) */
	/** �ꗗFormBean **/
	private List30326000FormBean list30326000FormBean;

	public Object getSearch30904000FormBean() {
		return search30904000FormBean;
	}

	public void setSearch30904000FormBean(Object search30904000FormBean) {
		this.search30904000FormBean = search30904000FormBean;
	}

	public List30326000FormBean getList30326000FormBean() {
		return list30326000FormBean;
	}

	public void setList30326000FormBean(List30326000FormBean list30326000FormBean) {
		this.list30326000FormBean = list30326000FormBean;
	}

}
