package jp.co.systemd.tnavi.cus.kaisei.print;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.object.CrText;
import jp.co.systemd.tnavi.common.exception.TnaviPrintException;
import jp.co.systemd.tnavi.common.print.AbstractPdfManagerAdditionPagesCR;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31917000_evalEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31917000_scoreEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31917000_studentEntity;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Print31917000FormBean;

/**
 * <PRE>
 * �ϓ_�ʌ��ʈꗗ���  �o�̓N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.07.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31917000 extends AbstractPdfManagerAdditionPagesCR {

	/**log4j*/
	private final Log log = LogFactory.getLog(Print31917000.class);

	/** ���C���I�u�W�F�N�g */
	private static final String LAYER_BASE = "Layer_Base";
	private static final String LAYER_SCORE = "Layer_Score";

	/** ���C�A�E�g�I�u�W�F�N�g */
	private static final String SCORE_LIST1_SCORE = "ScoreList1_Score";
	private static final String SCORE_LIST2_SCORE = "ScoreList2_Score";
	private static final String STUDENT_CLASS1_SCORE = "StudentClass1_Score";
	private static final String STUDENT_CLASS2_SCORE = "StudentClass2_Score";
	private static final String STUDENT_GRADE1_SCORE = "StudentGrade1_Score";
	private static final String STUDENT_GRADE2_SCORE = "StudentGrade2_Score";
	private static final String STUDENT_NAME1_SCORE = "StudentName1_Score";
	private static final String STUDENT_NAME2_SCORE = "StudentName2_Score";
	private static final String STUDENT_NUM1_SCORE = "StudentNum1_Score";
	private static final String STUDENT_NUM2_SCORE = "StudentNum2_Score";

	/** �Y���f�[�^�Ȃ�����\���ɂ���I�u�W�F�N�g */
	private static final String BOX4 = "Box4";
	private static final String LABEL4 = "Label4";
	private static final String LABEL5 = "Label5";
	private static final String LABEL6 = "Label6";
	private static final String LINE15 = "Line15";
	private static final String LINE16 = "Line16";
	private static final String LINE17 = "Line17";
	private static final String LINE18 = "Line18";
	private static final String LINE19 = "Line19";
	private static final String LINE20 = "Line20";
	private static final String LINE21 = "Line21";
	private static final String LINE22 = "Line22";
	private static final String LINE23 = "Line23";
	private static final String LINE24 = "Line24";
	private static final String LINE25 = "Line25";
	private static final String LINE26 = "Line26";
	private static final String LINE27 = "Line27";

	/** ���ȃR�[�h */
	private static final String CODE_KOKUGO = "02";
	private static final String CODE_SHAKAI = "04";
	private static final String CODE_SUGAKU = "06";
	private static final String CODE_RIKA = "08";
	private static final String CODE_ONGAKU = "10";
	private static final String CODE_BIJUTU = "12";
	private static final String CODE_HOTAI = "14";
	private static final String CODE_GIKA = "16";
	private static final String CODE_EIGO = "18";

	/** ���ȏo�͈ʒu */
	private static final int POS_KOKUGO = 3;
	private static final int POS_SHAKAI = 9;
	private static final int POS_SUGAKU = 14;
	private static final int POS_RIKA = 19;
	private static final int POS_ONGAKU = 24;
	private static final int POS_BIJUTU = 29;
	private static final int POS_HOTAI = 34;
	private static final int POS_GIKA = 39;
	private static final int POS_EIGO = 44;

	/** ���ȍő�ϓ_�� */
	private static final int VIEWPOINT_COUNT_KOKUGO = 5;
	private static final int VIEWPOINT_COUNT_SHAKAI = 4;
	private static final int VIEWPOINT_COUNT_SUGAKU = 4;
	private static final int VIEWPOINT_COUNT_RIKA = 4;
	private static final int VIEWPOINT_COUNT_ONGAKU = 4;
	private static final int VIEWPOINT_COUNT_BIJUTU = 4;
	private static final int VIEWPOINT_COUNT_HOTAI = 4;
	private static final int VIEWPOINT_COUNT_GIKA = 4;
	private static final int VIEWPOINT_COUNT_EIGO = 4;

	/** ���ȃR�[�h */
	private static String[] item = new String[]{
			CODE_KOKUGO,
			CODE_SHAKAI,
			CODE_SUGAKU,
			CODE_RIKA,
			CODE_ONGAKU,
			CODE_BIJUTU,
			CODE_HOTAI,
			CODE_GIKA,
			CODE_EIGO
	};
	/** ���Ȃ̏o�͈ʒu */
	private static Integer[] position = new Integer[]{
			POS_KOKUGO,
			POS_SHAKAI,
			POS_SUGAKU,
			POS_RIKA,
			POS_ONGAKU,
			POS_BIJUTU,
			POS_HOTAI,
			POS_GIKA,
			POS_EIGO
	};
	/** ���Ȃ̍ő�ϓ_�� */
	private static Integer[] maxViewpointCount = new Integer[]{
			VIEWPOINT_COUNT_KOKUGO,
			VIEWPOINT_COUNT_SHAKAI,
			VIEWPOINT_COUNT_SUGAKU,
			VIEWPOINT_COUNT_RIKA,
			VIEWPOINT_COUNT_ONGAKU,
			VIEWPOINT_COUNT_BIJUTU,
			VIEWPOINT_COUNT_HOTAI,
			VIEWPOINT_COUNT_GIKA,
			VIEWPOINT_COUNT_EIGO
	};

	/** ���FormBean */
	private Print31917000FormBean printFormBean;

	/**
	 * printFormBean ��ݒ肷��B
	 * @param printFormBean �Z�b�g���� printFormBean
	 */
	public final void setPrintFormBean(Print31917000FormBean printFormBean) {
		this.printFormBean = printFormBean;
	}

	@Override
	protected void doPrint() throws TnaviPrintException {

		try {
			// �f�[�^�o��
			outputData();

		} catch (Exception e) {
			log.error("��O�����@�ϓ_�ʌ��ʈꗗ���  �o�͎��s",e);
			throw new TnaviPrintException(e);
		}
	}

	/**
	 * ��������o�͂���.
	 */
	private void outputData() {

		try {
			// ���k���
			List<Data31917000_studentEntity> studentList = printFormBean.getStudentList();
			if ((studentList == null) || (studentList.isEmpty())) {
				return;
			}

			// �ϓ_�ʌ��� �]��
			List<Data31917000_scoreEntity> scoreList = printFormBean.getScoreList();
			// �ϓ_�ʌ��� �]��
			List<Data31917000_evalEntity> evalList = printFormBean.getEvalList();

			Map<String, Integer> subjectStartPosMap = new HashMap<String, Integer>();
			Map<String, Integer> maxViewPointCountMap = new HashMap<String, Integer>();
			for (int i = 0; i < item.length; i++) {
				subjectStartPosMap.put(item[i], position[i]);
				maxViewPointCountMap.put(item[i], maxViewpointCount[i]);
			}

			for (int i = 0; i <  studentList.size(); i++) {
				getCrLayerSetVisibleAtPrint(LAYER_BASE, false);
				getCrLayerSetVisibleAtPrint(LAYER_SCORE, true);

				Data31917000_studentEntity student = studentList.get(i);
				String gridId = SCORE_LIST1_SCORE;		// �ϓ_�O���b�h
				String gradeId = STUDENT_GRADE1_SCORE;	// �w�N
				String classId = STUDENT_CLASS1_SCORE;	// �g
				String numId = STUDENT_NUM1_SCORE;		// ��
				String nameId = STUDENT_NAME1_SCORE;	// ����
				if ((i % 2) != 0) {
					gridId = SCORE_LIST2_SCORE;
					gradeId = STUDENT_GRADE2_SCORE;
					classId = STUDENT_CLASS2_SCORE;
					numId = STUDENT_NUM2_SCORE;
					nameId = STUDENT_NAME2_SCORE;
				}
				getFieldSetData(gradeId, student.getClsGlade());	// �w�N
				getFieldSetData(classId, student.getHmrClass());	// �g
				getFieldSetData(numId, student .getClsNumber());	// ��
				getFieldSetData(nameId, student.getStuName());		// ����

				// �o�͎���
				CrText[][] scoreListGrid = getListFieldGetColumns(getCrListField(gridId));
				printoutGradeTerm(scoreListGrid);

				String prevItemCd = "";
				int viewpointCount = 0;

				for (Data31917000_scoreEntity score : scoreList) {
					if ((student.getStuCode().equals(score.getClsStucode()))) {
						if (("".equals(prevItemCd) || (!"".equals(prevItemCd) && (!prevItemCd.equals(score.getItemCd()))))) {
							// ���Ȗ�
							setListFieldData(scoreListGrid, subjectStartPosMap.get(score.getItemCd()), 0, score.getItemName());

							// �]�茩�o��(�Œ蕶�� "�]��")
							setListFieldData(scoreListGrid, subjectStartPosMap.get(score.getItemCd()) + maxViewPointCountMap.get(score.getItemCd()), 1, "�]��");

							// �]��
							for (Data31917000_evalEntity eval : evalList) {
								if (student.getStuCode().equals(eval.getClsStucode()) && score.getItemCd().equals(eval.getItemCd())) {
									int row = getOutputRow(printFormBean.getOutputTarget(), eval.getGrade(), eval.getTerm());
									setListFieldData(scoreListGrid, subjectStartPosMap.get(score.getItemCd()) + maxViewPointCountMap.get(score.getItemCd()), row, eval.getRevlDisplay());
								}
							}

							viewpointCount = 0;
						}
						int maxViewpoint = maxViewPointCountMap.get(score.getItemCd());
						if (viewpointCount < maxViewpoint) {
							// �ϓ_
							int pos = subjectStartPosMap.get(score.getItemCd());
							setListFieldData(scoreListGrid, pos + viewpointCount, 1, score.getRivtRivtname());

							// �]��
							int row = getOutputRow(printFormBean.getOutputTarget(), score.getGrade(), score.getTerm());
							setListFieldData(scoreListGrid, pos + viewpointCount, row, score.getRvpeReportdisplay());

							viewpointCount++;
						}
					}

					prevItemCd = score.getItemCd();
				}

				if ((i % 2) != 0) {
					doOutput();
				} else if (i == (studentList.size() - 1)) {
					hideSecondRecord();	// �ŏI�f�[�^
				}
			}

			if ((studentList.size() % 2) != 0) {
				doOutput();
			}

		} catch (Exception e) {
			log.error("��O�����@���ȕʊϓ_�ʏW�v�\�@���ʍ��� �o�̓G���[",e);
			throw new TnaviPrintException(e);
		}
	}

	/**
	 * �O���b�h�̊w�N�������o�͂���.
	 * @param scoreListGrid
	 * @throws Exception
	 */
	private void printoutGradeTerm(CrText[][] scoreListGrid) throws Exception {
		Map<String, String> gradeMap = new HashMap<String, String>();
		for (int i = 1; i <= 3; i++) {
			gradeMap.put(Integer.toString(i), i + "�N");
		}

		// �o�͎���
		Map<String, String> termMap = new HashMap<String, String>();
		termMap.put("01", "1�w��");
		termMap.put("02", "2�w��");
		termMap.put("99", "3�w��");

		String outputTarget = printFormBean.getOutputTarget();
		String[] gradeTermArray = outputTarget.split(",");
		for (int i = 0; i < gradeTermArray.length; i++) {
			String gradeTerm = gradeTermArray[i];
			String[] workArray = gradeTerm.split("_");
			String grade = gradeMap.get(workArray[0]);
			String term = termMap.get(workArray[1]);
			setListFieldData(scoreListGrid, 0, i + 2, grade + term);
		}
	}

	/**
	 * 2���ڂ̕\���G���A���\���Ƃ���.
	 */
	private void hideSecondRecord() {
		String[] targetItemNames = new String[]{
				STUDENT_GRADE2_SCORE,
				LABEL4,	// �N
				STUDENT_CLASS2_SCORE,
				LABEL5,	// �g
				STUDENT_NUM2_SCORE,
				LABEL6,	// ��
				STUDENT_NAME2_SCORE,
				BOX4,	// �O���b�h�g��
				LINE15,
				LINE16,
				LINE17,
				LINE18,
				LINE19,
				LINE20,
				LINE21,
				LINE22,
				LINE23,
				LINE24,
				LINE25,
				LINE26,
				LINE27,
				SCORE_LIST2_SCORE
		};
		for (String tagetName : targetItemNames) {
			form.getCrObject(tagetName).setVisible(false);
		}
	}

	/**
	 * �w�N�A�o�͎�������O���b�h��̏o�͍s���擾����.
	 * @param outputTarget �o�͎����S��
	 * @param grade �w�N
	 * @param term ����
	 * @return �o�͍s
	 */
	private int getOutputRow(String outputTarget, String grade, String term) {
		int row = 0;

		String[] gradeTermArray = outputTarget.split(",");
		for (int i = 0; i < gradeTermArray.length; i++) {
			String gradeTerm = gradeTermArray[i];
			String[] workArray = gradeTerm.split("_");
			if (grade.equals(workArray[0]) && term.equals(workArray[1])) {
				row = i + 2;
				break;
			}
		}

		return row;
	}

	/**
	 * ���[�o�͂��s���t�H�[��������������.
	 * @throws Exception
	 */
	private void doOutput() throws Exception {
		// �o��
		form.printOut();
		//�t�H�[��������
		form.initialize();
	}
}
