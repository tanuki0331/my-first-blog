package jp.co.systemd.tnavi.cus.kaisei.print;

import java.util.List;

import jp.co.hos.coreports.object.CrListField;
import jp.co.hos.coreports.object.CrText;
import jp.co.systemd.tnavi.common.exception.TnaviPrintException;
import jp.co.systemd.tnavi.common.print.AbstractPdfManagerAdditionPagesCR;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Print31904000Entity;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Print31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\  �o�̓N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31904000 extends AbstractPdfManagerAdditionPagesCR {

	/**log4j*/
	private final Log log = LogFactory.getLog(Print31904000.class);

	/** ���C���I�u�W�F�N�g */
	private static final String LAYER_BASE = "Layer_Base";
	private static final String LAYER_MAIN = "Layer_Main";

	/** ���C�A�E�g�I�u�W�F�N�g */
	private static final String TITLE = "Title";			// �^�C�g��
	private static final String ITEMNAME = "ItemName";		// ����
	private static final String STFNAME = "StfName";		// ���ȒS�C

	private static final String VIEWDATA = "ViewData";		// �ϓ_���W�v
	private static final String VIEWLEFT = "ViewLeft";		// �ϓ_��񍶁i�g�j
	private static final String VIEWHEAD = "ViewHead";		// �ϓ_����i�ϓ_�]���j
	private static final String AVERAGE = "Average";		// �]�蕽��
	private static final String VIEWTITLE = "ViewTitle";	// �ϓ_�^�C�g��
	
	/** ���FormBean */
	private Print31904000FormBean printFormBean;

	public Print31904000(String userCode, Print31904000FormBean printFormBean) {
		this.printFormBean = printFormBean;
	}

	@Override
	protected void doPrint() throws TnaviPrintException {

		try {
			form.initialize();//�t�H�[��������
			getCrLayerSetVisibleAtPrint(LAYER_BASE, true);
			getCrLayerSetVisibleAtPrint(LAYER_MAIN+"_"+printFormBean.getUseLayer(), true);
			getCrLayerSetVisibleAtPrint(LAYER_MAIN+"_"+printFormBean.getNotUseLayer(), false);
			
			// �f�[�^�o��
			outputData();

			//�@�I������
			form.printOut();
		} catch (Exception e) {
			log.error("��O�����@���ȕʊϓ_�ʏW�v�\  �o�͎��s",e);
			throw new TnaviPrintException(e);
		}
	}

	/**
	 * ��������o�͂���
	 */
	private void outputData(){
		
		try{
			//�^�C�g��
			getFieldSetData(TITLE, printFormBean.getTitle());
			
			//����
			getFieldSetData(ITEMNAME, printFormBean.getItemName());
			
			//���ȒS�C
			getFieldSetData(STFNAME, printFormBean.getStaffName());
			
			//�ϓ_�i�P�`�T�܂Ń��[�v�j
			for (int i = 0; i < printFormBean.getViewpointNameList().size(); i++) {
				int listPoint = i+1;
				Print31904000Entity entity = printFormBean.getViewpointNameList().get(i);
				//�ϓ_�^�C�g��
				getFieldSetData(VIEWTITLE+listPoint+"_"+printFormBean.getUseLayer(), entity.getValue());
				
				//�ϓ_���
				List<List<String>> listValue = printFormBean.getViewpointListListMap().get(entity.getCode());
				outputListData(listPoint,listValue,printFormBean.getViewpointEstimateList());
			}
			
			//�]��
			outputListData(6,printFormBean.getEvalListList(),printFormBean.getScorptEvalList());
			
			//�]�蕽��
			getFieldSetData(AVERAGE+"_"+printFormBean.getUseLayer(), printFormBean.getEvalAverage());
			
		} catch (Exception e) {
			log.error("��O�����@���ȕʊϓ_�ʏW�v�\�@���ʍ��� �o�̓G���[",e);
			throw new TnaviPrintException(e);
		}
	}

	/**
	 * �ϓ_�����o�͂���
	 * @param student
	 */
	private void outputListData(int listPoint,List<List<String>> listValue,List<Print31904000Entity> headerList){
		
		try {
			//�ϓ_����i�ϓ_�]���j
			CrListField headerListField = getCrListField(VIEWHEAD+listPoint+"_"+printFormBean.getUseLayer());
			CrText[][] headerListFieldColumns = getListFieldGetColumns(headerListField);
			for (int i = 0; i < headerList.size(); i++) {
				Print31904000Entity entity =  headerList.get(i);
				setListFieldData(headerListFieldColumns, i, 0, entity.getValue());
			}
			
			//�ϓ_��񍶁i�g�j
			CrListField leftListField = getCrListField(VIEWLEFT+listPoint+"_"+printFormBean.getUseLayer());
			CrText[][] leftListFieldColumns = getListFieldGetColumns(leftListField);
			for (int i = 0; i < printFormBean.getHroomList().size(); i++) {
				Print31904000Entity entity =  printFormBean.getHroomList().get(i);
				if (entity.getValue() != null && !entity.getValue().equals("")) {
					setListFieldData(leftListFieldColumns, 0, i, entity.getValue());
					setListFieldData(leftListFieldColumns, 1, i, "�g");
				}
			}
			
			if (listValue != null) {
				//�W�v�f�[�^
				CrListField dataListField = getCrListField(VIEWDATA+listPoint+"_"+printFormBean.getUseLayer());
				CrText[][] dataListFieldColumns = getListFieldGetColumns(dataListField);
				for (int i = 0; i < listValue.size(); i++) {
					List<String> valueList =  listValue.get(i);
					for (int j = 0; j < valueList.size(); j++) {
						setListFieldData(dataListFieldColumns, j, i, valueList.get(j));
					}
				}
			}
		} catch (Exception e) {
			log.error("��O�����@���ȕʊϓ_�ʏW�v�\�@�w�K�̋L�^�o�̓G���[",e);
			throw new TnaviPrintException(e);
		}
	}
}
