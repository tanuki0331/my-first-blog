package jp.co.systemd.tnavi.cus.kaisei.print;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.Format;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.object.CrListField;
import jp.co.hos.coreports.object.CrText;
import jp.co.hos.coreports.object.IField;
import jp.co.systemd.tnavi.common.exception.TnaviPrintException;
import jp.co.systemd.tnavi.common.print.AbstractPdfManagerAdditionPagesCR;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_averageEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_indivisualScoreEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_studentEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_subjectEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.service.Print31902000Service;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Print31902000FormBean;

/**
 * <PRE>
 * ����������ʒʒm�[���  �o�̓N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.24 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31902000 extends AbstractPdfManagerAdditionPagesCR {

	/**log4j*/
	private final Log log = LogFactory.getLog(Print31902000.class);

	/** ���C�A�E�g�I�u�W�F�N�g */
	private static final String TITLE_GRADE = "titleGrade";
	private static final String TITLE_SEMESTER = "titleSemester";
	private static final String TITLE_RESULT_NOTIFICATION = "titleResultNotification";
	private static final String INDIVISUAL_SUBJECT = "indivisualSubject";
	private static final String SCORE_ART1 = "scoreArt1";
	private static final String SCORE_ART2 = "scoreArt2";
	private static final String SCORE_ENGLISH1 = "scoreEnglish1";
	private static final String SCORE_ENGLISH2 = "scoreEnglish2";
	private static final String SCORE_HEALTH_AND_PHYSICAL_EDUCATION1 = "scoreHealthAndPhysicalEducation1";
	private static final String SCORE_HEALTH_AND_PHYSICAL_EDUCATION2 = "scoreHealthAndPhysicalEducation2";
	private static final String SCORE_LIST1 = "scoreList1";
	private static final String SCORE_LIST2 = "scoreList2";
	private static final String SCORE_MATHEMATICS1 = "scoreMathematics1";
	private static final String SCORE_MATHEMATICS2 = "scoreMathematics2";
	private static final String SCORE_MUSIC1 = "scoreMusic1";
	private static final String SCORE_MUSIC2 = "scoreMusic2";
	private static final String SCORE_NATIONAL_LANGUAGE1 = "scoreNationalLanguage1";
	private static final String SCORE_NATIONAL_LANGUAGE2 = "scoreNationalLanguage2";
	private static final String SCORE_SCIENCE1 = "scoreScience1";
	private static final String SCORE_SCIENCE2 = "scoreScience2";
	private static final String SCORE_SOCIETY1 = "scoreSociety1";
	private static final String SCORE_SOCIETY2 = "scoreSociety2";
	private static final String SCORE_TECHNOLOGY_HOME_ECONOMICS1 = "scoreTechnologyHomeEconomics1";
	private static final String SCORE_TECHNOLOGY_HOME_ECONOMICS2 = "scoreTechnologyHomeEconomics2";
	private static final String STUDENT_INFO1 = "studentInfo1";
	private static final String STUDENT_INFO2 = "studentInfo2";
	private static final String SCORE1 = "score1";
	private static final String SUBJECT = "subject";
	private static final String COUNT_LABEL = "countLabel";
	private static final String SUM_LABEL = "sumLabel";

	/** �ő�Ȗڐ� */
	private static final int SUBJECT_COLUMN_MAX_COUNT = 9;

	/** ���o�� -- ���_ */
	private static final String[] SCORE_TITLE = new String[]{
			"100",
			"95�`99",
			"90�`94",
			"85�`89",
			"80�`84",
			"75�`79",
			"70�`74",
			"65�`69",
			"60�`64",
			"55�`59",
			"50�`54",
			"45�`49",
			"40�`44",
			"35�`39",
			"30�`34",
			"25�`29",
			"20�`24",
			"20�_����"
	};

	/** ���{�������Ȗ��o�͗L�� */
	private static final String IMPLEMENTATION_WITHOUT_SUBJECT_OUTPUT_ON = "1";

	/** ���FormBean */
	private Print31902000FormBean printFormBean;

	/** ���Service */
	private Print31902000Service service;

	/** ���t���[�e�B���e�B */
	private DateFormatUtility dfu;

	/** ���l�ϊ����� */
	private Format decimalFormat;

	public Print31902000(String userCode, Print31902000FormBean printFormBean, Print31902000Service service) {
		this.printFormBean = printFormBean;
		this.service = service;
		this.dfu = new DateFormatUtility(userCode);
		dfu.setZeroToSpace(true);
		this.decimalFormat = new DecimalFormat("##0.0");
	}

	@Override
	protected void doPrint() throws TnaviPrintException {

		try {
			Map<String, Map<String, List<Integer>>> scoreDistributionTable = printFormBean.getScoreDistributionTable();
			boolean isFirst = true;
			for (Data31902000_studentEntity student : printFormBean.getStudentList()) {
				if (!isFirst) {
					form.initialize();
				}

				// ���[�^�C�g���A�N�E�g�E�ԁE�����i���o���ƍ��[�̏c�����j���o�͂���
				doPrintTitleAndHeader(student);

				// �l���� ���o�����o�͂���
				doPrintIndivisualScoreTitle();

				// �l���� 5�v�A���v�������������o�͂���
				doPrintIndivisualScore(student);

				// �l���� 5�v�A���v�������o�͂���
				doPrintIndivisualScoreTotal(student);

				// ���_���z�\�o��
				doPrintDistributionTable(student, scoreDistributionTable);

				isFirst = false;
				form.printOut();
			}
		} catch (Exception e) {
			log.error("����������ʒʒm�[���  �o�͎��s", e);
			throw new TnaviPrintException(e);
		}
	}

	/**
	 * ���[�^�C�g���A�N�E�g�E�ԁE�����i���o���ƍ��[�̏c�����j���o�͂���
	 * @param student �o�͑Ώۂ̐��k���
	 * @throws Exception �o�͎���O
	 */
	private void doPrintTitleAndHeader(Data31902000_studentEntity student) throws Exception {
		// ���[�^�C�g��
		getFieldSetData(TITLE_GRADE, printFormBean.getTitleGlade());
		getFieldSetData(TITLE_SEMESTER, printFormBean.getTitleSemester());
		getFieldSetData(TITLE_RESULT_NOTIFICATION, "���ʒʒm");

		// �N�E�g�E�ԁE����
		CrListField studentInfo1List = getCrListField(STUDENT_INFO1);
		CrText[][] studentInfo1 = getListFieldGetColumns(studentInfo1List);
		int col = 0;
		setListFieldData(studentInfo1, col++, 0, student.getCls_glade());	// �N
		setListFieldData(studentInfo1, col++, 0, "�N");
		setListFieldData(studentInfo1, col++, 0, student.getHmr_class());	// �g
		setListFieldData(studentInfo1, col++, 0, "�g");
		setListFieldData(studentInfo1, col++, 0, student.getCls_number());	// �ԍ�
		setListFieldData(studentInfo1, col++, 0, "��");
		setListFieldData(studentInfo1, col++, 0, student.getStu_name());	// ���O

		// �ԁE�����i���[�̏c�����j
		CrListField studentInfo2List = getCrListField(STUDENT_INFO2);
		CrText[][] studentInfo2 = getListFieldGetColumns(studentInfo2List);
		int row = 0;
		setListFieldData(studentInfo2, 0, row++, student.getCls_number());	// �ԍ�
		setListFieldData(studentInfo2, 0, row++, "��");
		setListFieldData(studentInfo2, 0, row++, student.getStu_name());	// ���O
	}

	/**
	 * �l���ь��o���o��
	 * @throws Exception �o�͎���O
	 */
	private void doPrintIndivisualScoreTitle() throws Exception {
		CrListField indivisualScore1List = getCrListField(SCORE1);
		CrText[][] indivisualScore1 = getListFieldGetColumns(indivisualScore1List);
		String score01[] = new String[]{"", "�f�_", "���ϓ_"};
		int row = 0;
		for (int i = 0; i < score01.length; i++) {
			setListFieldData(indivisualScore1, 0, row++, score01[i]);
		}
	}

	/**
	 * �l���� 5�v�A���v�����������o��
	 * @param student �o�͑Ώۂ̐��k���
	 * @throws Exception �o�͎���O
	 */
	private void doPrintIndivisualScore(Data31902000_studentEntity student) throws Exception {
		List<Data31902000_subjectEntity> subjects = printFormBean.getSubjectList();
		for (int i = 0; (i < subjects.size() - 2) && (i < SUBJECT_COLUMN_MAX_COUNT); i++) {
			// �l���сF�Ȗ� �ݒ�
			Data31902000_subjectEntity subject = subjects.get(i);

			int colPos = colPosition(subject.getSubjectCd()) / 2;
			CrListField indivisualSubjectList = getCrListField(INDIVISUAL_SUBJECT + (colPos + 1));
			CrText[][] indivisualSubject = getListFieldGetColumns(indivisualSubjectList);
			setListFieldData(indivisualSubject, 0, 0, subject.getSubjectName());

			// �l���сF�f�_ �ݒ�
			List<Data31902000_indivisualScoreEntity> rawScoreList = student.getRawScoreList();
			for (Data31902000_indivisualScoreEntity indivisualScoreEntity : rawScoreList) {
				Integer score = indivisualScoreEntity.getScoreMap().get(subject.getSubjectCd());
				setListFieldData(indivisualSubject, 0, 1, score);
				break;
			}

			// �l���сF���ϓ_ �ݒ�
			List<Data31902000_averageEntity> averageScoreList = printFormBean.getAverageScoreList();
			for (Data31902000_averageEntity averageEntity : averageScoreList) {
				if(subject.getSubjectCd().equals(averageEntity.getItem())) {
					BigDecimal average = averageEntity.getAverage();
					if (average != null) {
						setListFieldData(indivisualSubject, 0, 2, decimalFormat.format(average));
					}
					break;
				}
			}
		}
		// ���{�������Ȗ��o��
		if (IMPLEMENTATION_WITHOUT_SUBJECT_OUTPUT_ON.equals(printFormBean.getImplementationWithoutSubjectName())) {
			for (int i = 1; i <= SUBJECT_COLUMN_MAX_COUNT; i++) {
				CrListField indivisualSubjectList = getCrListField(INDIVISUAL_SUBJECT + i);
				CrText[][] indivisualSubject = getListFieldGetColumns(indivisualSubjectList);
				if (StringUtils.isBlank(indivisualSubject[0][0].getText())) {
					String subjectCd = service.getSubjectKeys()[i - 1];
					String subjectName = service.getSubjectName(subjectCd);
					setListFieldData(indivisualSubject, 0, 0, subjectName);
				}
			}
		} else {
			for (int i = 1; (i <= SUBJECT_COLUMN_MAX_COUNT) && (i < subjects.size()); i++) {
				Data31902000_subjectEntity subject = subjects.get(i);
				if ((subject.getCnt() == null) || (subject.getCnt().intValue() == 0)) {
					// CNT��0�̋��Ȃ͏o�͂��Ȃ�
					String subjectCd = subject.getSubjectCd();
					int index = 0;
					for (int j = 0; j < service.getSubjectKeys().length; j++) {
						if (service.getSubjectKeys()[j].equals(subjectCd)) {
							index = j;
							break;
						}
					}
					if ((index > 0) && (index <= SUBJECT_COLUMN_MAX_COUNT)) {
						CrListField indivisualSubjectList = getCrListField(INDIVISUAL_SUBJECT + index);
						CrText[][] indivisualSubject = getListFieldGetColumns(indivisualSubjectList);
						setListFieldData(indivisualSubject, 0, 0, "");
					}
				}
			}
		}

	}

	/**
	 * �l���� 5�v�A���v�����o��
	 * @param student �o�͑Ώۂ̐��k���
	 * @throws Exception �o�͎���O
	 */
	private void doPrintIndivisualScoreTotal(Data31902000_studentEntity student) throws Exception {
		int j = 10;
		int k = 0;
		String[] subjectCds = new String[]{Print31902000Service.FIVE_SUBJECTS_TOTAL,
				Print31902000Service.ALL_SUBJECTS_TOTAL};
		List<Data31902000_subjectEntity> subjects = printFormBean.getSubjectList();
		// �l���� 5�v�A���v �Ȗڐݒ�
		for (int i = subjects.size() - 2; i < subjects.size(); i++) {
			Data31902000_subjectEntity subject = subjects.get(i);
			CrListField indivisualSubjectList = getCrListField(INDIVISUAL_SUBJECT + (j++));
			CrText[][] indivisualSubject = getListFieldGetColumns(indivisualSubjectList);
			setListFieldData(indivisualSubject, 0, 0, subject.getSubjectName());
			// �l���� �f�_ 5�v�A���v�o��
			if ((student.getRawScoreList() != null) && (!student.getRawScoreList().isEmpty()) && (subjects.size() > 2)) {
				// ���_������A�Ȗڐ���5�v�A���v�ȊO�̏ꍇ�ɏo�͂���
				Data31902000_indivisualScoreEntity indivisualScoreEntity = student.getRawScoreList().get(0);
				Integer score = indivisualScoreEntity.getScoreMap().get(subjectCds[k++]);
				setListFieldData(indivisualSubject, 0, 1, score);
			}
		}
		// �l���� ���ϓ_ 5�v�A���v�o��
		int n = 10;
		for (String subjectCd : subjectCds) {
			if ((printFormBean.getAverageScoreList() != null) && (!printFormBean.getAverageScoreList().isEmpty())) {
				for (Data31902000_averageEntity averageEntity : printFormBean.getAverageScoreList()) {
					if (subjectCd.equals(averageEntity.getItem())) {
						CrListField indivisualSubjectList = getCrListField(INDIVISUAL_SUBJECT + (n++));
						CrText[][] indivisualSubject = getListFieldGetColumns(indivisualSubjectList);
						BigDecimal average = averageEntity.getAverage();
						if (average != null) {
							setListFieldData(indivisualSubject, 0, 2, decimalFormat.format(average));
						}
					}
				}
			}
		}
	}

	/**
	 * ���_���z�\�o��
	 * @param student �o�͑Ώۂ̐��k���
	 * @param scoreDistributionTable ���_���z�\�f�[�^
	 * @throws Exception �o�͎���O
	 */
	private void doPrintDistributionTable(Data31902000_studentEntity student,
			Map<String, Map<String, List<Integer>>> scoreDistributionTable) throws Exception {
		// ���_���z�\
		// ���o�� -- ���_
		CrListField score1List = getCrListField(SCORE_LIST1);
		CrListField score2List = getCrListField(SCORE_LIST2);
		CrText[][] score1 = getListFieldGetColumns(score1List);
		CrText[][] score2 = getListFieldGetColumns(score2List);
		int row = 0;
		for (int i = 0; i < SCORE_TITLE.length; i++) {
			setListFieldData(score1, 0, row, SCORE_TITLE[i]);
			setListFieldData(score2, 0, row++, SCORE_TITLE[i]);
		}
		// �Ȗ�
		List<Data31902000_subjectEntity> subjects = printFormBean.getSubjectList();
		for (int i = 0; i < subjects.size() - 2; i++) {
			int colPos = colPosition(subjects.get(i).getSubjectCd()) / 2;
			getFieldSetData(SUBJECT + (colPos + 1), subjects.get(i).getSubjectName());
		}

		if (IMPLEMENTATION_WITHOUT_SUBJECT_OUTPUT_ON.equals(printFormBean.getImplementationWithoutSubjectName())) {
			for (int i = 0; i < SUBJECT_COLUMN_MAX_COUNT; i++) {
				CrListField subjectList = getCrListField(INDIVISUAL_SUBJECT + (i + 1));
				CrText[][] subject =  getListFieldGetColumns(subjectList);
				String subjectName = subject[0][0].getText();

				CrText subjectTitle = form.getCrObject(SUBJECT + (i + 1));
				if (StringUtils.isBlank(subjectTitle.getText())) {
					setFieldData((IField)subjectTitle, subjectName);
				}
			}
		} else {
			for (int i = 0; i < SUBJECT_COLUMN_MAX_COUNT; i++) {
				// �l�����x�����\��
				form.getCrObject(COUNT_LABEL + (i + 1)).setVisible(false);
				// �݌v���x�����\��
				form.getCrObject(SUM_LABEL + (i + 1)).setVisible(false);
			}
			for (int i = 0; i < SUBJECT_COLUMN_MAX_COUNT; i++) {
				CrText subjectTitle = form.getCrObject(SUBJECT + (i + 1));
				if (StringUtils.isNotBlank(subjectTitle.getText())) {
					// �l�����x����\��
					form.getCrObject(COUNT_LABEL + (i + 1)).setVisible(true);
					// �݌v���x����\��
					form.getCrObject(SUM_LABEL + (i + 1)).setVisible(true);
				}
			}
		}
		// ���_���z�\�f�[�^
		CrListField[] distributionTableCols = new CrListField[]{
				getCrListField(SCORE_NATIONAL_LANGUAGE1),
				getCrListField(SCORE_NATIONAL_LANGUAGE2),
				getCrListField(SCORE_SOCIETY1),
				getCrListField(SCORE_SOCIETY2),
				getCrListField(SCORE_MATHEMATICS1),
				getCrListField(SCORE_MATHEMATICS2),
				getCrListField(SCORE_SCIENCE1),
				getCrListField(SCORE_SCIENCE2),
				getCrListField(SCORE_MUSIC1),
				getCrListField(SCORE_MUSIC2),
				getCrListField(SCORE_ART1),
				getCrListField(SCORE_ART2),
				getCrListField(SCORE_HEALTH_AND_PHYSICAL_EDUCATION1),
				getCrListField(SCORE_HEALTH_AND_PHYSICAL_EDUCATION2),
				getCrListField(SCORE_TECHNOLOGY_HOME_ECONOMICS1),
				getCrListField(SCORE_TECHNOLOGY_HOME_ECONOMICS2),
				getCrListField(SCORE_ENGLISH1),
				getCrListField(SCORE_ENGLISH2)
		};

		// �l���A�݌v�o��
		for (int i = 0; i < subjects.size() - 2; i++) {
			String subject = subjects.get(i).getSubjectCd();
			int colPos = colPosition(subject);
			for (int m = 0; m < Print31902000Service.SCORE_KEYS.length; m++) {
				CrText[][] tableCountCol = getListFieldGetColumns(distributionTableCols[colPos]);
				CrText[][] tableSumCol = getListFieldGetColumns(distributionTableCols[colPos + 1]);
				Integer count = scoreDistributionTable.get(subject).get(Print31902000Service.SCORE_KEYS[m]).get(0);
				Integer sum = scoreDistributionTable.get(subject).get(Print31902000Service.SCORE_KEYS[m]).get(1);
				if ((count != null) && (count > 0)) {
					setListFieldData(tableCountCol, 0, m, count);
					setListFieldData(tableSumCol, 0, m, sum);
				}
			}
		}
	}


	/**
	 * �ȖڃR�[�h����o�͏����擾����B
	 * @param subject
	 * @return �o�͏�
	 */
	private int colPosition(String subject) {
		int col = 0;
		Map<String, Integer> map = new HashMap<String, Integer>();
		for (int i = 0; i < service.getSubjectKeys().length; i++) {
			map.put(service.getSubjectKeys()[i], i * 2);
		}
		if (map.containsKey(subject)) {
			col = map.get(subject);
		}
		return col;
	}

}
