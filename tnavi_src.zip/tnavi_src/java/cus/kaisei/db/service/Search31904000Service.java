/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.service;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CodeEntity;
import jp.co.systemd.tnavi.common.db.entity.HRoomEntity;
import jp.co.systemd.tnavi.common.db.service.GladeCodeTagService;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Search31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\  ��� Service�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Search31904000Service extends AbstractExecuteQuery{

	/** log4j */
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(Search31904000Service.class);

	/** �����R�[�h */
	private String userCode;

	/** ���FormBean */
	private Search31904000FormBean searchFormBean;

	/** ���sSQL */
	private static final String EXEC_SQL_ITEM_LIST = "cus/kaisei/getData31904000_item.sql";


	public Search31904000Service(SystemInfoBean sessionBean, Search31904000FormBean searchFormBean) {
		this.userCode = sessionBean.getUserCode();
		this.searchFormBean = searchFormBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {
		searchFormBean.setItemList(getItemList());
	}


	/**
	 * ���Ȉꗗ���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<SimpleTagFormBean> getItemList() {

		//�w�N���I���̏ꍇ�����l���擾
		String grade = searchFormBean.getGrade();
		if (grade == null || grade.equals("")) {
			List<HRoomEntity> gladeList = new ArrayList<HRoomEntity>();
			GladeCodeTagService tag = new GladeCodeTagService(this.userCode,
					searchFormBean.getNendo());
	
			// �N�G�����s
			tag.execute();
	
			// ���ʎ擾
			gladeList = (List<HRoomEntity>) tag.getObj();
			if (gladeList != null && !gladeList.isEmpty()) {
				grade = gladeList.get(0).getHmr_glade();
			}
		}
		
		String stfCode = searchFormBean.getSubjectStfCode();
		
		// �ǉ�SQL��
		StringBuffer plusSQL = new StringBuffer();

		// ���ȒS���J��
		if(stfCode != null && stfCode.length() > 0){
			plusSQL.append(" AND ISNULL(chr_stfcode,'') != '' ");
		}

		// ORDER BY��
		plusSQL.append(" ORDER BY cod_value2, cod_code ");
		
		Object[] param = {searchFormBean.getNendo(),grade,
				searchFormBean.getSubjectStfCode(),userCode};
		QueryManager qm = new QueryManager(EXEC_SQL_ITEM_LIST, param, CodeEntity.class);
		qm.setPlusSQL(plusSQL.toString());

		List<CodeEntity> entityList = (List<CodeEntity>) this.executeQuery(qm);
		List<SimpleTagFormBean> itemList = new ArrayList<SimpleTagFormBean>();
		for (CodeEntity entity : entityList) {
			itemList.add(new SimpleTagFormBean(entity.getCod_code(),entity.getCod_name1()));
		}

		return itemList;
	}
}

