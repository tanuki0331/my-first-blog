/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.service;

import java.util.StringTokenizer;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.db.QueryUpdateManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\  �X�V Service�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Regist31904000Service extends AbstractExecuteQuery{

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist31904000Service.class);

	/** �����R�[�h */
	private String userCode;
	/** ���O�C�����[�U */
	private String staffid;
	/** ���ݓ��t */
	private String today;

	/** ���FormBean */
	private List31904000FormBean listFormBean;
	
	private String[] stu_term_checks;
	private String message;

	/** ���sSQL */
	private static final String EXEC_SQL_INSERT = "cus/kaisei/insertCannotEstimate.sql";
	private static final String EXEC_SQL_DELETE = "cus/kaisei/deleteCannotEstimateByUserYear.sql";


	public Regist31904000Service(String userCode,String staffid,String today,
			List31904000FormBean listFormBean,String[] stu_term_checks ) {
		this.userCode = userCode;
		this.listFormBean = listFormBean;
		this.stu_term_checks = stu_term_checks;
		this.staffid = staffid;
		this.today = today;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {
		QueryUpdateBatchManager insertQm = new QueryUpdateBatchManager(EXEC_SQL_INSERT);
		this.initialBatchUpdate(insertQm);
		try {
			//���ѕ]���s�\�ҍ폜
			deleteCannotEstimate();
			//���ѕ]���s�\�ғo�^
			insertCannotEstimate(insertQm);
			
			this.commit();
			message = "�X�V���������܂����B";
			
		} catch (Exception e) {
			// ���[���o�b�N
			super.rollback();
			log.error("���ѕ]���s�\�� �o�^�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			if (insertQm != null) {
				this.closeBatchUpdate(insertQm);
				insertQm = null;
			}
		}
	}

	/**
	 * ���ѕ]���s�\�ҍ폜
	 * @return
	 */
	private void deleteCannotEstimate() {
		
		Object[] param = {userCode,listFormBean.getNendo(),listFormBean.getSelectedItem(),listFormBean.getSelectedGrade()};
		QueryUpdateManager qm = new QueryUpdateManager(EXEC_SQL_DELETE, param);
		qm.setPlusSQL(" AND cne_item = ? ");
		qm.setPlusSQL(" AND EXISTS(SELECT * FROM tbl_class inner join tbl_hroom ON cls_user = hmr_user AND cls_year = hmr_year ");
		qm.setPlusSQL(" AND cls_clsno = hmr_clsno WHERE cls_user = cne_user AND cls_year = cne_year AND cls_stucode = cne_stucode ");
		qm.setPlusSQL(" AND cls_glade = ? ");
		String hmrClass = listFormBean.getSelectedClass();
		if (hmrClass != null && !hmrClass.equals("")) {
			qm.setPlusSQL(" AND hmr_class = '"+ hmrClass +"' ");
		}
		qm.setPlusSQL(" ) ");

		this.executeUpdate(qm);
		
		return;
	}

	/**
	 * ���ѕ]���s�\�ғo�^
	 * @return
	 */
	private void insertCannotEstimate(QueryUpdateBatchManager insertQm) {
		if (stu_term_checks != null) {
			for (String stuTerm: stu_term_checks) {
				StringTokenizer stStuTerm = new StringTokenizer(stuTerm,"_");
				String stucode = stStuTerm.nextToken();
				String term = stStuTerm.nextToken();
				this.executeBatchUpdate(insertQm,new String[]{userCode,listFormBean.getNendo(),term,
						listFormBean.getSelectedItem(),stucode,today,staffid});
			}
		}
		return;
	}

	public String getMessage() {
		return message;
	}
	
}

