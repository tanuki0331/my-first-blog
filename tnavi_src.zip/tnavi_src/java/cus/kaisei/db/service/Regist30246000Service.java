/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.formbean.HroomKeyFormBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;

/**
 * <PRE>
 * ��������(�w���v�^) �o�^���� Service.
 * </PRE>
 *
 * <B>Create</B> 2012.12.4 BY SATO<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Regist30246000Service extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(Regist30246000Service.class);

	/** ���O�C�����[�U */
	private String staffid;

	/** �o�^�f�[�^ <�w�Дԍ��A�]���� */
	private Map<String, String> registmap;

    /** �I�����ꂽ�N���X */
	private HroomKeyFormBean hroomKeyFormBean;

	/** �V�X�e���N�x */
	private String systemNendoSeireki;

	/** �V�X�e�����t */
	private String today;

	/** �w���ʒS�C�m��Map */
	private Map<String, Boolean> studentMap = new HashMap<String, Boolean>();

	/**
	 * �R���X�g���N�^
	 *
	 */
	public Regist30246000Service(Map<String, String> registmap, HroomKeyFormBean hroomKeyFormBean, String systemNendoSeireki, String staffid ,Map<String, Boolean> studentMap) {
		this.staffid = staffid;
		this.registmap = registmap;
		this.systemNendoSeireki = systemNendoSeireki;
		this.hroomKeyFormBean = hroomKeyFormBean;
		this.studentMap = studentMap;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		try {
			today = DateUtility.getSystemDate();

			QueryUpdateBatchManager delete = new QueryUpdateBatchManager("junior/aff/delete30246000.sql");
			QueryUpdateBatchManager insert = new QueryUpdateBatchManager("junior/aff/insert30246000.sql");
			this.initialBatchUpdate(delete);
			this.initialBatchUpdate(insert);

			for(String stucode : this.registmap.keySet()) {
				// �]��
				String value = this.registmap.get(stucode);

				// �폜
				Object[] deleteParam = {
						  this.hroomKeyFormBean.getUser()
						, this.hroomKeyFormBean.getGlade()
						, stucode
				};
				this.executeBatchUpdate(delete, deleteParam);

				// ���͂̂�����̂ɑ΂��ēo�^���s���B
				String trim = StringUtils.trim(value);
				if (StringUtils.isEmpty(trim)) {
					continue;
				}
				// �o�^
				Object[] insertParam = {
						  this.hroomKeyFormBean.getUser()
						, this.systemNendoSeireki
						, this.hroomKeyFormBean.getGlade()
						, stucode
						, value
						, this.today
						, this.staffid
				};
				this.executeBatchUpdate(insert, insertParam);
			}

			super.commit();

		} catch (Exception e) {
			// ���[���o�b�N
			super.rollback();
			log.error(e.getLocalizedMessage(), e);
			throw new TnaviException(e);
		}
	}

}
