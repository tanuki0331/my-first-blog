package jp.co.systemd.tnavi.cus.kaisei.db.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanPredicate;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.PredicateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data30326000Entity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.List30326000_02Entity;

public class GetBelong30326000Service extends AbstractExecuteQuery {
	private static final Log log = LogFactory.getLog(GetBelong30326000Service.class);


	/** �����R�[�h **/
	private String user;
	/** �N�x **/
	private String year;
	/** �w�N **/
	private String grade;
	/** �N���X�ԍ� **/
	private String clsno;
	/** �C�� **/
	private String belongTerm;
	/** �ۊO�����敪1 **/
	private String gsatKind1;
	/** �ۊO�����敪2 **/
	private String gsatKind2;
	/** �������ꗗList **/
	private List<Data30326000Entity> belongInfoList;
	/** �����E���kList **/
	private List<List30326000_02Entity> studentList;


	/**
	 * �R���X�g���N�^
	 * @param user
	 * @param year
	 * @param grade
	 * @param clsno
	 * @param belongTerm
	 * @param kind1
	 * @param kind2
	 * @param studentList
	 */
	public GetBelong30326000Service(String user, String year, String grade, String clsno, String belongTerm, String kind1, String kind2, List<List30326000_02Entity> studentList) {
		this.user 			= user;
		this.year 			= year;
		this.grade 			= grade;
		this.clsno 			= clsno;
		this.belongTerm 	= belongTerm;
		this.gsatKind1 		= kind1;
		this.gsatKind2 		= kind2;
		this.studentList	= studentList;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {
		try {

			belongInfoList = new ArrayList<Data30326000Entity>();

			// ------------------------------------------------------
			// �������擾
			// ------------------------------------------------------
			// �p�����[�^����
			Object[] param = {belongTerm, gsatKind1, gsatKind2, user, year, grade, clsno};
			// QueryManager����
			QueryManager queryManager = new QueryManager("cus/kaisei/getData30326000.sql", param, Data30326000Entity.class);
			// �N�G�����s
			List<Data30326000Entity> stuBelongList = (List<Data30326000Entity>)this.executeQuery(queryManager);

			// ------------------------------------------------------
			// ���p�����񐶐�
			// ------------------------------------------------------
			for(List30326000_02Entity stuEntity : studentList)
			{
				// ���o�f�[�^�i�[List
				List<Data30326000Entity> tempList = new ArrayList<Data30326000Entity>();
				// �����f�[�^Entity
				Data30326000Entity belongEntity = new Data30326000Entity();
				// ���p������
				StringBuilder belongStr = new StringBuilder();

				// --- ���p�����񐶐�
				// ���o�����ݒ�(�w�Дԍ�)
				BeanPredicate predicate = new BeanPredicate("cls_stucode", PredicateUtils.equalPredicate(stuEntity.getCls_stucode()));
				// ���o
				tempList.addAll(CollectionUtils.select(stuBelongList, predicate));

				for(int belongIdx = 0; belongIdx < tempList.size(); belongIdx++)
				{
					// ��������
					String extName = tempList.get(belongIdx).getExt_name() == null ? "": tempList.get(belongIdx).getExt_name();
					// ��E����
					String pstName = tempList.get(belongIdx).getPst_name() == null ? "": tempList.get(belongIdx).getPst_name();

					// --- ��E�L
					if(!pstName.equals(""))
					{
						if(belongIdx == tempList.size() -1)
						{
							belongStr.append(extName + "(" + pstName + ")");
						}
						else {
							belongStr.append(extName + "(" + pstName + ")\n");
						}
					}
					// --- ��E��
					else
					{
						if(belongIdx == tempList.size() -1)
						{
							belongStr.append(extName);
						}
						else {
							belongStr.append(extName + "\n");
						}
					}
				}

				// --- Entity�ɃZ�b�g
				belongEntity.setCls_stucode(stuEntity.getCls_stucode());
				belongEntity.setCls_number(stuEntity.getCls_number());
				belongEntity.setExt_name(belongStr.toString());
				// --- List��Entity�Z�b�g
				belongInfoList.add(belongEntity);
			}


		} catch (Exception e) {
			log.error("���ʊ����̋L�^����(�ʒm�\) DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
	}

	/**
	 * ������񃊃X�g �擾
	 * @return
	 */
	public List<Data30326000Entity> getBelongInfoList() {
		return belongInfoList;
	}



}
