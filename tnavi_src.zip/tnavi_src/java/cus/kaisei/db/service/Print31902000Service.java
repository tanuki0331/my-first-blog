/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CrlayoutEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_averageEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_indivisualScoreEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_scoreEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_studentEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_subjectEntity;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31902000FormBean;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Print31902000FormBean;


/**
 * <PRE>
 * ����������ʒʒm�[��� Service�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.24 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31902000Service extends AbstractExecuteQuery{

	/** log4j */
	private static final Log log = LogFactory.getLog(Print31902000Service.class);

	/** �����R�[�h */
	private String userCode;

	/** ���FormBean */
	private List31902000FormBean listFormBean;

	/** ���FormBean */
	private Print31902000FormBean printFormBean;

	/** 5�v��\���R�[�h */
	public static final String FIVE_SUBJECTS_TOTAL = "FIVE_SUBJECTS_TOTAL";

	/** ���v��\���R�[�h */
	public static final String ALL_SUBJECTS_TOTAL = "ALL_SUBJECTS_TOTAL";

	/** �ΏۉȖڂ�\���R�[�h */
	private static final String ITD_ITEM = "itd_item";

	/** �ȖڃR�[�h */
	private String[] subjectKeys;

	/** �Ȗږ� */
	private String [] subjectNames;

	/** �Ȗڃ}�b�v(key:�ȖڃR�[�h value:�Ȗږ�)  */
	private Map<String, String> subjectMap;

	/** ���_�L�[ */
	public static final String[] SCORE_KEYS = new String[] {
			"100", // 100
			"95",  // 95-99
			"90",  // 90-84
			"85",  // 85-89
			"80",  // 80-84
			"75",  // 75-79
			"70",  // 70-74
			"65",  // 65-69
			"60",  // 60-64
			"55",  // 55-59
			"50",  // 50-54
			"45",  // 45-49
			"40",  // 40-44
			"35",  // 35-39
			"30",  // 30-34
			"25",  // 25-29
			"20",  // 20-24
			"0",   //  0-19
	};


	/** �@�\ID */
	private static final String KINO_ID = "31902000";

	/** �f�t�H���g��COReports�t�H�[���t�@�C�� */
	private static final String DEFAULT_LAYOUT_NAME = "cus/kaisei/form31902000.cfx";

	/** ���sSQL */
	private static final String EXEC_SQL_SUBJECT = "cus/kaisei/list31902000_04.sql";						// �o�͑ΏۉȖ�
	private static final String EXEC_SQL_INDIVISUAL_SCORE = "cus/kaisei/list31902000_05.sql";				// �l���� �f�_
	private static final String EXEC_SQL_INDIVISUAL_SCORE_TOTAL5 = "cus/kaisei/list31902000_06.sql";		// �W�v�ΏۉȖ�
	private static final String EXEC_SQL_INDIVISUAL_SCORE_AVERAGE = "cus/kaisei/list31902000_07.sql";		// �l���� ���ϓ_
	private static final String EXEC_SQL_SUBJECT_ORDER = "cus/kaisei/list31902000_08.sql";					// �Ȗ�
	private static final String EXEC_SQL_FORMFILENAME 	= "common/getCrlayoutByUserAndKinoid.sql";			// �t�H�[���t�@�C����

	/** �R���X�g���N�^ */
	public Print31902000Service(SystemInfoBean sessionBean, List31902000FormBean listFormBean) {
		userCode = sessionBean.getUserCode();
		this.listFormBean = listFormBean;
		printFormBean = new Print31902000FormBean();
		printFormBean.setClsGlade(listFormBean.getGlade());		// �N
		printFormBean.setHmrClass(listFormBean.getHmrClass());	// �g
		printFormBean.setStudentList(listFormBean.getStudentList()); // ���k���X�g
		printFormBean.setImplementationWithoutSubjectName(listFormBean.getImplementationWithoutSubjectName()); // ���{�������Ȗ����W�I�{�^�� �I��l

	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}


	@Override
	protected void doQuery() throws TnaviDbException {

		// �Ȗڂ�ݒ�
		setupSubjectMap();

		// �w�b�_�ݒ�
		setupHeader();

		// �l���� �Ȗڐݒ�
		setupSubject();

		// �l���� �f�_�A���ϓ_�ݒ�
		setupIndivisualScore();

		// ���_���z�\�ݒ�
		setupScoreDistributionTable();

		// ���C�A�E�g�t�H�[����
		printFormBean.setFormFileName(getFormFileName());

	}

	/**
	 * CoRports�t�H�[���t�@�C�������擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String getFormFileName() {

		Object[] params = {userCode, KINO_ID};

		QueryManager qm = new QueryManager(EXEC_SQL_FORMFILENAME, params, CrlayoutEntity.class);
		qm.setPlusSQL(" AND crl_layoutid = '" + listFormBean.getCrlayout() + "' ");

		List<CrlayoutEntity> layoutList = (List<CrlayoutEntity>) this.executeQuery(qm);

		if(layoutList.size() > 0){
			return layoutList.get(0).getCrl_form();
		}else{
			return DEFAULT_LAYOUT_NAME;
		}
	}

	/**
	 * �����Ŏw�肳�ꂽ���p�w�N���l(1,2,3)��S�p�w�N���l�ɕϊ������l��Ԃ��B<br/>
	 * �ϊ��ł��Ȃ��ꍇ�͈����̒l�����̂܂ܕԂ��B<br/>
	 * @param formBean �ꗗ��ʃt�H�[��
	 * @return
	 */
	private String getReportTitleGlade(List31902000FormBean formBean) {
		String glade = formBean.getGlade();
		if (StringUtils.isBlank(glade)) {
			return "";
		}
		Map<String, String> valMap = new HashMap<String, String>();
		valMap.put("1", "�P");
		valMap.put("2", "�Q");
		valMap.put("3", "�R");
		String value = glade;
		if (valMap.containsKey(glade)) {
			value = valMap.get(glade);
		}

		return String.format("��%s�w�N", value);
	}

	/**
	 * �w�b�_�ݒ�
	 */
	private void setupHeader() {
		// �^�C�g���擾
		String titleGlade = getReportTitleGlade(listFormBean);
		String titleLessonEvaluationPlanTypeNm = listFormBean.getLessonEvaluationPlanTypeName().trim();

		printFormBean.setTitleGlade(titleGlade);
		printFormBean.setTitleSemester(titleLessonEvaluationPlanTypeNm);
	}

	/**
	 * �Ȗڐݒ�
	 */
	private void setupSubject() {
		// �e�[�u�����ΏۉȖڂ��擾
		List<Data31902000_subjectEntity> subjects = getSubjectList();

		// �Œ�l:5�v�A���v��2���ڂ�ǉ�
		String[] subjectNames = new String[]{"5�v", "���v"};
		for (String subjectName : subjectNames) {
			Data31902000_subjectEntity subject = new Data31902000_subjectEntity();
			subject.setSubjectName(subjectName);
			subjects.add(subject);
		}

		printFormBean.setSubjectList(subjects);
	}

	/**
	 * �l���ѐݒ�
	 */
	private void setupIndivisualScore() {
		// �f�_�ݒ� �Ȗڂ���
		List<Data31902000_indivisualScoreEntity> indivisualScore = getIndivisualScore();

		for (Data31902000_studentEntity student : printFormBean.getStudentList()) {
			for (Data31902000_indivisualScoreEntity score : indivisualScore) {
				if (student.getCls_stucode().equals(score.getCls_stucode())) {
					student.getRawScoreList().add(score);
					break;
				}
			}
		}

		// ���_���z�p�f�[�^�ۑ�
		for (Data31902000_indivisualScoreEntity score : indivisualScore) {
			Data31902000_studentEntity student = new Data31902000_studentEntity();
			student.getRawScoreList().add(score);
			printFormBean.getAllStudentList().add(student);
		}

		// �f�_�ݒ� 5�v
		setIndivisualScoreTotal5(printFormBean.getStudentList());

		// �f�_�ݒ� ���v
		setIndivisualScoreTotalAll(printFormBean.getStudentList());

		// ���ϓ_�ݒ� �Ȗڂ���
		List<Data31902000_averageEntity> indivisualAverage = getIndivisualAverageScore();
		printFormBean.setAverageScoreList(indivisualAverage);

		// ���ϓ_�ݒ� 5�v
		Data31902000_averageEntity fiveAverage = getIndivisualAverageFive(indivisualAverage);
		printFormBean.getAverageScoreList().add(fiveAverage);
		// ���ϓ_�ݒ� ���v
		Data31902000_averageEntity allAverage = getIndivisualAverageAll(indivisualAverage);
		printFormBean.getAverageScoreList().add(allAverage);
	}

	/**
	 * ���_���z�\�ݒ�
	 */
	private void setupScoreDistributionTable() {
		Map<String, Map<String, List<Integer>>> scoreDistributionMap = new HashMap<String, Map<String, List<Integer>>>();

		// ���_���z�\�����l�ݒ�
		for (int i = 0; i < subjectKeys.length; i++) {
			Map<String, List<Integer>> scoreMap = new HashMap<String, List<Integer>>();
			for (int j = 0; j < SCORE_KEYS.length; j++) {
				List<Integer> count = Arrays.asList(new Integer[]{0, 0});
				scoreMap.put(SCORE_KEYS[j], count);
			}
			scoreDistributionMap.put(subjectKeys[i], scoreMap);
		}

		// �Ȗڂ��Ƃ̗݌v������
		Map<String, Map<String, List<Integer>>> subjectTotal = new HashMap<String, Map<String, List<Integer>>>();
		for (int i = 0; i < subjectKeys.length; i++) {
			Map<String, List<Integer>> rankCountMap = new HashMap<String, List<Integer>>();
			for (int j = 0; j < SCORE_KEYS.length; j++) {
				List<Integer> counts = new ArrayList<Integer>();
				for (int k = 0; k < 2; k++) {
					counts.add(Integer.valueOf(0));
				}
				rankCountMap.put(SCORE_KEYS[j], counts);
			}
			subjectTotal.put(subjectKeys[i], rankCountMap);
		}

		List<Data31902000_studentEntity> studentList = printFormBean.getAllStudentList();
		for (Data31902000_studentEntity student : studentList) {
			List<Data31902000_indivisualScoreEntity> rawScoreList = student.getRawScoreList();
			for (Data31902000_indivisualScoreEntity rawScore : rawScoreList) {
				Map<String, Integer> scoreMap = rawScore.getScoreMap();
				for (Map.Entry<String, Integer> scoreEntry : scoreMap.entrySet()) {
					String subject = scoreEntry.getKey();
					Integer score = scoreEntry.getValue();
					// ���_�̏o�͍s(�����N)�擾
					int numberRow = getRowFromScore(score);
					if (FIVE_SUBJECTS_TOTAL.equals(subject) || ALL_SUBJECTS_TOTAL.equals(subject)
							|| (numberRow < 0)) { // �Ȗڂ�5�v�A���v�܂��͓��_���͈͊O�̏ꍇ�͏������Ȃ�
						continue;
					}
					String scoreKey = SCORE_KEYS[numberRow];
					// �l���J�E���g
					int ninzu = scoreDistributionMap.get(subject).get(scoreKey).get(0);
					scoreDistributionMap.get(subject).get(scoreKey).set(0, ++ninzu);
					// �Ώۓ��_�ȉ��̗݌v�ݒ�
					for (int k = numberRow; k < SCORE_KEYS.length; k++) {
						int ruikei = 0;
						if (k > 0) {
							ruikei = subjectTotal.get(subject).get(SCORE_KEYS[k - 1]).get(1);
						}
						ruikei += scoreDistributionMap.get(subject).get(SCORE_KEYS[k]).get(0);
						subjectTotal.get(subject).get(SCORE_KEYS[k]).set(1, ruikei);
						scoreDistributionMap.get(subject).get(SCORE_KEYS[k]).set(1, ruikei);
					}
				}
			}
		}

		printFormBean.setScoreDistributionTable(scoreDistributionMap);
	}

	/**
	 * �Ȗڎ擾
	 * @return �Ȗڃ��X�g
	 */
	private List<Data31902000_subjectEntity> getSubjectList() {
		Object[] params = {listFormBean.getNendo(), printFormBean.getClsGlade(),
				listFormBean.getLessonEvaluationPlanType(), listFormBean.getSemester(), userCode};

		QueryManager qm = new QueryManager(EXEC_SQL_SUBJECT, params, Data31902000_subjectEntity.class);
		List<Data31902000_subjectEntity> subject = (List<Data31902000_subjectEntity>)this.executeQuery(qm);

		return subject;
	}

	/**
	 * �l���� �f�_ �擾
	 * @return �l���т̉Ȗ�(5�v�A���v����)���Ƃ̑f�_���X�g
	 */
	private List<Data31902000_indivisualScoreEntity> getIndivisualScore() {
		Object[] params = {
				listFormBean.getSemester(), listFormBean.getLessonEvaluationPlanType(), userCode,
				listFormBean.getNendo(), listFormBean.getGlade()};

		QueryManager qm = new QueryManager(EXEC_SQL_INDIVISUAL_SCORE, params, Data31902000_scoreEntity.class);
		List<Data31902000_scoreEntity> list = (List<Data31902000_scoreEntity>)this.executeQuery(qm);
		List<Data31902000_indivisualScoreEntity> scoreList = new ArrayList<Data31902000_indivisualScoreEntity>();

		// �l����(���k�A�Ȗ�)�𐶓k����(���k�A�Ȗ�Map)�ɏW�񂷂�
		if ((list != null) && (!list.isEmpty())) {
			String previousStuCode = "";
			Map<String, Integer> scoreMap = new HashMap<String, Integer>();
			Data31902000_indivisualScoreEntity indivisualScore = null;
			for (Data31902000_scoreEntity score : list) {
				if (!previousStuCode.equals(score.getRscStucode())) {
					if (indivisualScore != null) {
						scoreList.add(indivisualScore);
					}
					indivisualScore = new Data31902000_indivisualScoreEntity();
					indivisualScore.setCls_stucode(score.getRscStucode());
					scoreMap = new HashMap<String, Integer>();
					indivisualScore.setScoreMap(scoreMap);
				}
				indivisualScore.getScoreMap().put(score.getItem(), score.getScoreSum());
				previousStuCode = score.getRscStucode();
			}
			indivisualScore.setScoreMap(scoreMap);
			scoreList.add(indivisualScore);
		}

		return scoreList;
	}

	/**
	 * 5�v�̑ΏۉȖڂ��擾����B
	 * @return 5�v�̑ΏۉȖ�
	 */
	private List<Map> getTargetSubjects() {
		Object[] params = {userCode, listFormBean.getNendo()};
		QueryManager qm = new QueryManager(EXEC_SQL_INDIVISUAL_SCORE_TOTAL5, params);
		List<Map> list = (List<Map>)this.executeQuery(qm);

		return list;
	}

	/**
	 * �l���� �f�_ 5�v �ݒ�<br/>
	 * ���ȃZ�b�g����}�X�^���Q�Ƃ��đΏۂ̉Ȗڂ��擾���A
	 * �����Ŏw�肳�ꂽ���k�̌l���� �f�_ 5�v���W�v����B
	 * @param ���k���X�g
	 */
	private void setIndivisualScoreTotal5(List<Data31902000_studentEntity> studentList) {
		// �ΏۉȖڎ擾
		List<Map> list = getTargetSubjects();

		// �W�v����
		for (Data31902000_studentEntity student : studentList) {
			Integer scoreTotal = Integer.valueOf(0);
			for (Data31902000_indivisualScoreEntity rawScore : student.getRawScoreList()) {
				for (Map subjectCdMap : list) {
					String subjectCd = (String)subjectCdMap.get(ITD_ITEM);
					Integer score = rawScore.getScoreMap().get(subjectCd);
					if (score != null) {
						scoreTotal = scoreTotal +  score;
					}
				}
				rawScore.getScoreMap().put(FIVE_SUBJECTS_TOTAL, scoreTotal);
			}
		}
	}

	/**
	 * �l���� �f�_ ���v �ݒ�<br/>
	 * �����Ŏw�肳�ꂽ���k�̌l���� �f�_ ���v���W�v����B
	 * @param ���k���X�g
	 */
	private void setIndivisualScoreTotalAll(List<Data31902000_studentEntity> studentList) {
		for (Data31902000_studentEntity student : studentList) {
			Integer scoreTotal = Integer.valueOf(0);

			for (Data31902000_indivisualScoreEntity rawScore : student.getRawScoreList()) {
				for (Map.Entry<String, Integer> entry : rawScore.getScoreMap().entrySet()) {
					if ((entry.getValue() != null) && (!entry.getKey().equals(FIVE_SUBJECTS_TOTAL))) {
						scoreTotal = scoreTotal + entry.getValue();
					}
				}
				rawScore.getScoreMap().put(ALL_SUBJECTS_TOTAL, scoreTotal);
			}
		}
	}

	/**
	 * �l���� ���ϓ_ �擾
	 * @return �l���т̉Ȗ�(5�v�A���v�܂�)���Ƃ̕��ϓ_���X�g
	 */
	private List<Data31902000_averageEntity> getIndivisualAverageScore() {
		Object[] params = {
				listFormBean.getSemester(), listFormBean.getLessonEvaluationPlanType(), userCode,
				listFormBean.getNendo(), listFormBean.getGlade()
		};
		QueryManager qm = new QueryManager(EXEC_SQL_INDIVISUAL_SCORE_AVERAGE, params, Data31902000_averageEntity.class);
		List<Data31902000_averageEntity> list = (List<Data31902000_averageEntity>)this.executeQuery(qm);

		return list;
	}

	/**
	 * �����Ŏw�肳�ꂽ�Ȗڕ��ϓ_���X�g����
	 * ���ϓ_�ݒ� 5�v���Z�o����B
	 * @param indivisualAverage
	 * @return ���ϓ_�ݒ� 5�v
	 */
	private Data31902000_averageEntity getIndivisualAverageFive(List<Data31902000_averageEntity> indivisualAverage) {
		BigDecimal average = BigDecimal.ZERO;
		List<Map> subjectList = getTargetSubjects();
		for (Map subjectCdMap : subjectList) {
			String subjectCd = (String)subjectCdMap.get(ITD_ITEM);
			for (Data31902000_averageEntity averageEntity : indivisualAverage) {
				if (subjectCd.equals(averageEntity.getItem())) {
					BigDecimal score = averageEntity.getAverage();
					if (score != null) {
						average = average.add(score);
					}
				}
			}
		}
		Data31902000_averageEntity fiveAverage = new Data31902000_averageEntity();
		fiveAverage.setItem(FIVE_SUBJECTS_TOTAL);
		fiveAverage.setAverage(average);

		return fiveAverage;
	}

	/**
	 * �����Ŏw�肳�ꂽ�Ȗڕ��ϓ_���X�g����
	 * ���ϓ_�ݒ� ���v���Z�o����B
	 * @param indivisualAverage
	 * @return ���ϓ_�ݒ� ���v
	 */
	private Data31902000_averageEntity getIndivisualAverageAll(List<Data31902000_averageEntity> indivisualAverage) {
		BigDecimal average = BigDecimal.ZERO;
		for (Data31902000_averageEntity averageEntity : indivisualAverage) {
			BigDecimal score = averageEntity.getAverage();
			if ((score != null) && (!FIVE_SUBJECTS_TOTAL.equals(averageEntity.getItem()))) {
				average = average.add(score);
			}
		}
		Data31902000_averageEntity allAverage = new Data31902000_averageEntity();
		allAverage.setItem(ALL_SUBJECTS_TOTAL);
		allAverage.setAverage(average);

		return allAverage;
	}

	/**
	 * �����̓��_����o�͂���s���擾����B
	 * @param score ���_
	 * @return ���_���z�\�̏o�͍s
	 */
	private int getRowFromScore(Integer score) {
		final int lastRow = 17;
		final int maxScore = 100;
		final int minScore = 20;
		final int scoreStep = 5;
		int val = -1;
		if (score == null) {
			return val;
		} else {
			int scoreVal = score.intValue();
			if (scoreVal >= maxScore) {
				val = 0;
			} else if (scoreVal < minScore) {
				val = lastRow;
			} else {
				for (int i = 0; i < lastRow; i++) {
					if (scoreVal >= (maxScore - scoreStep * (i + 1))) {
						val = i + 1;
						break;
					}
				}
			}
		}
		return val;
	}

	/**
	 * �ȖڃR�[�h����Ȗږ����擾����B
	 * @param subjectCd �ȖڃR�[�h
	 * @return �Ȗږ�
	 */
	public String getSubjectName(String subjectCd) {
		return subjectMap.get(subjectCd);
	}


	/**
	 * �Ȗڂ��e�[�u������擾���āA�ȖڃR�[�h�A�Ȗږ��A<br/>
	 * �Ȗڃ}�b�v(key:�ȖڃR�[�h value:�Ȗږ�)
	 * �������ɐݒ肷��B
	 */
	private void setupSubjectMap() {
		Object[] params = {userCode};

		QueryManager qm = new QueryManager(EXEC_SQL_SUBJECT_ORDER, params, Data31902000_subjectEntity.class);
		List<Data31902000_subjectEntity> subjectList = (List<Data31902000_subjectEntity>)this.executeQuery(qm);

		subjectMap = new HashMap<String, String>();
		subjectKeys = new String[0];
		subjectNames = new String[0];
		if ((subjectList != null) && (!subjectList.isEmpty())) {
			subjectKeys = new String[subjectList.size()];
			subjectNames = new String[subjectList.size()];

			for (int i = 0; i < subjectList.size(); i++) {
				Data31902000_subjectEntity subject = subjectList.get(i);
				subjectKeys[i] = subject.getSubjectCd();
				subjectNames[i] = subject.getSubjectName();
				subjectMap.put(subjectKeys[i], subjectNames[i]);
			}
		}
	}

	public Print31902000FormBean getPrintFormBean() {
		return printFormBean;
	}

	/**
	 * @return subjectKeys
	 */
	public final String[] getSubjectKeys() {
		return subjectKeys;
	}

	/**
	 * @param subjectKeys �Z�b�g���� subjectKeys
	 */
	public final void setSubjectKeys(String[] subjectKeys) {
		this.subjectKeys = subjectKeys;
	}

	/**
	 * @return subjectNames
	 */
	public final String[] getSubjectNames() {
		return subjectNames;
	}

	/**
	 * @param subjectNames �Z�b�g���� subjectNames
	 */
	public final void setSubjectNames(String[] subjectNames) {
		this.subjectNames = subjectNames;
	}

	/**
	 * @return subjectMap
	 */
	public final Map<String, String> getSubjectMap() {
		return subjectMap;
	}

	/**
	 * @param subjectMap �Z�b�g���� subjectMap
	 */
	public final void setSubjectMap(Map<String, String> subjectMap) {
		this.subjectMap = subjectMap;
	}

}

