/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.HRoomEntity;
import jp.co.systemd.tnavi.common.db.entity.OutputTermEntity;
import jp.co.systemd.tnavi.common.db.entity.ScorptitemviewpointtitleEntity;
import jp.co.systemd.tnavi.common.db.entity.StaffEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Print31904000Entity;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Print31904000FormBean;
import jp.co.systemd.tnavi.cus.kaisei.formbean.Search31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ ��� Service�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.04.10 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31904000Service extends AbstractExecuteQuery{

	/** log4j */
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(Print31904000Service.class);

	/** �����R�[�h */
	private String userCode;

	/** ���FormBean */
	private Search31904000FormBean searchFormBean;

	/** ���FormBean */
	private Print31904000FormBean printFormBean;

	/** ���sSQL */
	private static final String EXEC_SQL_STAFF 	= "cus/kaisei/getData31904000_staff.sql";					// ���ȒS��
	private static final String EXEC_SQL_CLASS 	= "common/getClassCodeTagByNonSpSupportClass.sql";
	private static final String EXEC_SQL_TERM 	= "common/getOutputTermCodeTag.sql";						// �]������
	private static final String EXEC_SQL_SCORPTVIEW = "cus/kaisei/getData31904000_scorptviewpointestimate.sql";	// �ϓ_�]��
	private static final String EXEC_SQL_SCORPTEVAL = "cus/kaisei/getData31904000_scorpteval.sql";				// �]��]��
	private static final String EXEC_SQL_VIEWPOINTTITLE1 	= "cus/kaisei/getData31904000_viewpoint1.sql";	// �ϓ_�^�C�g��
	private static final String EXEC_SQL_VIEWPOINTTITLE2 	= "cus/kaisei/getData31904000_viewpoint2.sql";	// �ϓ_�^�C�g��(�i�H�p)
	private static final String EXEC_SQL_VIEWPOINTSUM 	= "cus/kaisei/getData31904000_viewpointsum.sql";	// �ϓ_�W�v
	private static final String EXEC_SQL_EVALSUM 	= "cus/kaisei/getData31904000_evalsum.sql";				// �]��W�v

	private static final String CANT_CODE = "999999";// �������p�R�[�h
	private static final String CANT_NAME = "������";// �������p�\����
	private static final int CLASS_CNT1 = 5;// �N���X�J�E���g1
	private static final int CLASS_CNT2 = 8;// �N���X�J�E���g2
	
	public Print31904000Service(SystemInfoBean sessionBean, Search31904000FormBean searchFormBean) {
		this.userCode = sessionBean.getUserCode();
		this.searchFormBean = searchFormBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}


	@Override
	protected void doQuery() throws TnaviDbException {
		this.printFormBean = new Print31904000FormBean();
		//�^�C�g���Z�b�g
		String title = searchFormBean.getDispNendo()
				+ "�N�x "
				+ searchFormBean.getGrade()
				+ "�N"
				+ searchFormBean.getTermName()
				+ " �ϓ_�ʊw�K�󋵋y�ѕ]��̐l���W�v�\�@(�_�ސ����)";
		printFormBean.setTitle(title);
		
		//���ȃZ�b�g
		printFormBean.setItemName(searchFormBean.getItemName());
		
		//���ȒS�C�擾�A����
		printFormBean.setStaffName(getStaffName());
		
		//�ϓ_���擾
		printFormBean.setViewpointNameList(getViewpointNameList());
		
		//�g�擾
		printFormBean.setHroomList(getHroomList());
		
		//�ϓ_�]���l�擾
		printFormBean.setViewpointEstimateList(getViewpointEstimateList());
		
		//�]��]���擾
		printFormBean.setScorptEvalList(getScorptEvalList());
		
		//�ϓ_���Ƃ̏W�v�l�擾
		printFormBean.setViewpointListListMap(getViewpointListListMap());
		
		//�]��W�v�l�擾
		printFormBean.setEvalListList(getEvalListList());
		
		//�]�蕽�ϒl�擾
		printFormBean.setEvalAverage(getEvalAverage());
	}

	/**
	 * ���ȒS�C�����擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String getStaffName() {
		String ret = "";
		Object[] params = {userCode, searchFormBean.getNendo(),searchFormBean.getItem(),searchFormBean.getGrade()};

		QueryManager qm = new QueryManager(EXEC_SQL_STAFF, params, StaffEntity.class);

		List<StaffEntity> entityList = (List<StaffEntity>) this.executeQuery(qm);

		for (StaffEntity entity: entityList) {
			if (!ret.equals("")) ret += "�A";
			ret += entity.getStf_name_w();
		}
		return ret;
	}
	
	/**
	 * �ϓ_�����擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Print31904000Entity> getViewpointNameList() {
		List<Print31904000Entity> retList = new ArrayList<Print31904000Entity>();
		QueryManager qm = null;
		
		//�o�͎�������(���їp�̏ꍇ�Ƃ���ȊO�Ŋϓ_���擾SQL��ؑ�)
		Object[] termParam = {userCode,searchFormBean.getNendo(),searchFormBean.getGoptcode()};
		QueryManager termQm = new QueryManager(EXEC_SQL_TERM, termParam, OutputTermEntity.class);
		termQm.setPlusSQL(" AND gopt_goptcode = ? ");
		termQm.setPlusSQL(" AND gopt_tempeval_flg = '1' ");
		List<OutputTermEntity> termList = (List<OutputTermEntity>) this.executeQuery(termQm);
		if (termList.size() > 0) {
			Object[] params = {searchFormBean.getGrade(),userCode, searchFormBean.getNendo(),
					searchFormBean.getItem(),};
			qm = new QueryManager(EXEC_SQL_VIEWPOINTTITLE2, params, ScorptitemviewpointtitleEntity.class);
		} else {
			Object[] params = {userCode, searchFormBean.getNendo(),searchFormBean.getGrade(),
					searchFormBean.getGoptcode(),searchFormBean.getItem()};
			qm = new QueryManager(EXEC_SQL_VIEWPOINTTITLE1, params, ScorptitemviewpointtitleEntity.class);
		}
		List<ScorptitemviewpointtitleEntity> entityList = (List<ScorptitemviewpointtitleEntity>) this.executeQuery(qm);
		
		for (int i = 0; i < 5; i++) {
			if (entityList.size()>i) {
				ScorptitemviewpointtitleEntity entity = entityList.get(i);
				retList.add(new Print31904000Entity(entity.getRivt_rivtcode(),entity.getRivt_rivtname()));
			} else {
				retList.add(new Print31904000Entity("","(���g�p)"));
			}
		}
		
		return retList;
	}

	/**
	 * �g���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Print31904000Entity> getHroomList() {
		List<Print31904000Entity> retList = new ArrayList<Print31904000Entity>();
		Object[] param = {userCode,searchFormBean.getNendo(),searchFormBean.getGrade()};
		QueryManager qm = new QueryManager(EXEC_SQL_CLASS, param, HRoomEntity.class);

		List<HRoomEntity> entityList = (List<HRoomEntity>) this.executeQuery(qm);
		//�g�̌����ŗ��p���C���𔻒�
		int classRow = CLASS_CNT1;
		if (entityList.size() > CLASS_CNT1) {
			classRow = CLASS_CNT2;
			printFormBean.setNotUseLayer(CLASS_CNT1);
		} else {
			printFormBean.setNotUseLayer(CLASS_CNT2);
		}
		printFormBean.setUseLayer(classRow);
		
		for (int i = 0; i < classRow; i++) {
			if (entityList.size() > i) {
				HRoomEntity entity = entityList.get(i);
				retList.add(new Print31904000Entity(entity.getHmr_class(),entity.getHmr_class()));
			} else {
				retList.add(new Print31904000Entity("",""));
			}
		}
		return retList;
	}
	
	/**
	 * �ϓ_�]���l���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Print31904000Entity> getViewpointEstimateList() {
		List<Print31904000Entity> retList = new ArrayList<Print31904000Entity>();
		Object[] param = {userCode,searchFormBean.getNendo(),searchFormBean.getGrade()};
		QueryManager qm = new QueryManager(EXEC_SQL_SCORPTVIEW, param, Print31904000Entity.class);

		List<Print31904000Entity> entityList = (List<Print31904000Entity>) this.executeQuery(qm);
		for (int i = 0; i < 5; i++) {
			if (entityList.size()>i) {
				Print31904000Entity entity = entityList.get(i);
				retList.add(entity);
			} else {
				retList.add(new Print31904000Entity("",""));
			}
		}
		retList.add(new Print31904000Entity(CANT_CODE,CANT_NAME));
		return retList;
	}
	
	/**
	 * �]��]���l���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Print31904000Entity> getScorptEvalList() {
		List<Print31904000Entity> retList = new ArrayList<Print31904000Entity>();
		Object[] param = {userCode,searchFormBean.getNendo(),searchFormBean.getGrade()};
		QueryManager qm = new QueryManager(EXEC_SQL_SCORPTEVAL, param, Print31904000Entity.class);

		List<Print31904000Entity> entityList = (List<Print31904000Entity>) this.executeQuery(qm);
		for (int i = 0; i < 5; i++) {
			if (entityList.size()>i) {
				Print31904000Entity entity = entityList.get(i);
				retList.add(entity);
			} else {
				retList.add(new Print31904000Entity("",""));
			}
		}
		retList.add(new Print31904000Entity(CANT_CODE,CANT_NAME));
		return retList;
	}
	
	/**
	 * �ϓ_�ʕ]���̏W�v�l���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, List<List<String>>> getViewpointListListMap() {
		Map<String, List<List<String>>> viewpointListListMap = new HashMap<String, List<List<String>>>();
		//�ϓ_���Ɏ擾
		for (Print31904000Entity entity: printFormBean.getViewpointNameList()) {
			
			//�ϓ_���ݒ肳��Ă���ꍇ�̂ݏ���
			if (!"".equals(entity.getCode())) {
				Object[] param = {searchFormBean.getGoptcode(),searchFormBean.getItem(),entity.getCode(),
						userCode,searchFormBean.getNendo(),searchFormBean.getGrade(),searchFormBean.getGoptcode(),
						searchFormBean.getItem(),CANT_NAME,CANT_CODE,searchFormBean.getGoptcode(),
						searchFormBean.getItem(),userCode,searchFormBean.getNendo(),searchFormBean.getGrade()};
				QueryManager qm = new QueryManager(EXEC_SQL_VIEWPOINTSUM, param, Print31904000Entity.class);
				List<Print31904000Entity> sumList = (List<Print31904000Entity>) this.executeQuery(qm);
				List<List<String>> retListList = createSumData(sumList,printFormBean.getViewpointEstimateList());
				viewpointListListMap.put(entity.getCode(),retListList);
			}
		}
		return viewpointListListMap;
	}
	
	/**
	 * �]��]���̏W�v�l���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<List<String>> getEvalListList() {
		Object[] param = {searchFormBean.getGoptcode(),searchFormBean.getItem(),
				userCode,searchFormBean.getNendo(),searchFormBean.getGrade(),searchFormBean.getGoptcode(),
				searchFormBean.getItem(),CANT_NAME,CANT_CODE,searchFormBean.getGoptcode(),
				searchFormBean.getItem(),userCode,searchFormBean.getNendo(),searchFormBean.getGrade()};
		QueryManager qm = new QueryManager(EXEC_SQL_EVALSUM, param, Print31904000Entity.class);
		List<Print31904000Entity> sumList = (List<Print31904000Entity>) this.executeQuery(qm);
		
		List<List<String>> retListList = createSumData(sumList,printFormBean.getScorptEvalList());
		
		return retListList;
	}
	
	/**
	 * �W�v�l�𒠕[�o�͗p�ɐ��`����
	 * @return
	 */
	private List<List<String>> createSumData(List<Print31904000Entity> sumList,List<Print31904000Entity> colList) {
		List<List<String>> retListList = new ArrayList<List<String>>();
		Map<String,String> sumMap = new HashMap<String,String>();
		//�W�v���ʂ�MAP�i�[
		for (Print31904000Entity sumEntity: sumList) {
			sumMap.put(sumEntity.getCode(), sumEntity.getValue());
		}
		if (sumList.size() > 0) {
			//��W�v�p
			Integer[] colSum = new Integer[colList.size()+1];
					
			//�g���ɏ���
			for (int i = 0; i < printFormBean.getHroomList().size(); i++) {
				Print31904000Entity hroomEntity = printFormBean.getHroomList().get(i);
				List<String> retList = new ArrayList<String>();
				if (!"".equals(hroomEntity.getCode())) {
					//�s�W�v�p
					int rowSum = 0;
					//�]�����ɏ���
					for (int j = 0; j < colList.size(); j++) {
						Print31904000Entity viewpointEntity = colList.get(j);
						if (!"".equals(viewpointEntity.getCode())) {
							if (i == 0) {//�񖈏W�v�̏����l�Z�b�g
								colSum[j] = 0;
							}
							String key = hroomEntity.getCode()+"_"+viewpointEntity.getCode();
							String value = sumMap.get(key);
							if (value != null) {
								retList.add(value);
								rowSum += Integer.parseInt(value);
								colSum[j] += Integer.parseInt(value);
							}
						} else {
							retList.add("");
						}
					}
					//�s�W�v�l���Z�b�g
					retList.add(String.valueOf(rowSum));
					if (i == 0) {//�񖈏W�v�̏����l�Z�b�g
						colSum[colList.size()] = 0;
					}
					colSum[colList.size()] += rowSum;
				}
				//�s����ǉ�
				retListList.add(retList);
			}
			//�ŏI�s�̏W�v�l��ǉ�
			List<String> retList = new ArrayList<String>();
			for (Integer sum: colSum) {
				String value = (sum==null?"":String.valueOf(sum));
				retList.add(value);
			}
			retListList.add(retList);
		}
		return retListList;
	}
	/**
	 * �]�蕽�ς��Z�o����
	 * @return
	 */
	private String getEvalAverage() {
		String ret = "";
		//�Ώې��т��Ƃ̐l�������Z
		int evalSum = 0;
		int countSum = 0;
		//�]��ŏI�s���擾
		List<String> evalCountList = printFormBean.getEvalListList().get(printFormBean.getEvalListList().size()-1);
		for (int j = 0; j < printFormBean.getScorptEvalList().size()-1; j++) {
			Print31904000Entity evalEntity = printFormBean.getScorptEvalList().get(j);
			if (!"".equals(evalEntity.getValue())) {
				try {
					//�]���l�𐔒l�ϊ�
					int eval = cnuvNumber(evalEntity.getValue());
					//���v�s�̐l���Ɗ|�����킹
					String count = evalCountList.get(j);
					if (count != null && !"".equals(count)) {
						int intCnt = Integer.parseInt(count);
						countSum += intCnt;
						evalSum += (eval*intCnt);
					}
				} catch (Exception e) {
					//�������Ȃ�
				}
			}
		}
		//�Ώېl���Ŋ����Ďl�̌ܓ�
		if (countSum != 0) {
			BigDecimal bdEvalSum = new BigDecimal(evalSum).setScale(2);
			BigDecimal bdCountSum = new BigDecimal(countSum).setScale(2);
			ret = (bdEvalSum.divide(bdCountSum,2,BigDecimal.ROUND_HALF_UP)).toString();
		}
		
		return ret;
	}
	
	private int cnuvNumber(String val) throws Exception{
		int ret = 0;
		
		if (val != null && val.length() == 1) {
			int c = (int) val.charAt(0);
			if (c >= 0xFF10 && c <= 0xFF19) {
				ret = Integer.parseInt(String.valueOf((char)(c - 0xFEE0)));
			} else {
				ret = Integer.parseInt(val);
			}
		}
		
		return ret;
	}

	public Print31904000FormBean getPrintFormBean() {
		return printFormBean;
	}
	
	
}

