/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CodeEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31904000_outputTermEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31904000_studentEntity;
import jp.co.systemd.tnavi.cus.kaisei.formbean.List31904000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\  ��� Service�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31904000Service extends AbstractExecuteQuery{

	/** log4j */
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(List31904000Service.class);

	/** �����R�[�h */
	private String userCode;

	/** ���FormBean */
	private List31904000FormBean listFormBean;

	/** ���sSQL */
	private static final String EXEC_SQL_ITEM_LIST = "cus/kaisei/getData31904000_item.sql";
	private static final String EXEC_SQL_TERM_LIST = "cus/kaisei/getData31904000_outputterm.sql";
	private static final String EXEC_SQL_STUDENT_LIST1 = "cus/kaisei/getData31904000_student.sql";				// ���k�ꗗ
	private static final String EXEC_SQL_STUDENT_LIST2 = "cus/kaisei/getData31904000_cannnotEstimate.sql";		// �]���s�\�҈ꗗ


	public List31904000Service(SystemInfoBean sessionBean, List31904000FormBean listFormBean) {
		this.userCode = sessionBean.getUserCode();
		this.listFormBean = listFormBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {
		//���ȃ��X�g�擾
		listFormBean.setItemList(getItemList());
		//�]�������擾
		setTermList();
		//���k�ꗗ�擾
		listFormBean.setStuList(getStuList());
		//�]���s�\�҈ꗗ
		setStuAllList();
	}

	/**
	 * ���Ȉꗗ���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<SimpleTagFormBean> getItemList() {

		//�w�N���I���̏ꍇ�����l���擾
		String stfCode = listFormBean.getSubjectStfCode();
		
		// �ǉ�SQL��
		StringBuffer plusSQL = new StringBuffer();

		// ���ȒS���J��
		if(stfCode != null && stfCode.length() > 0){
			plusSQL.append(" AND ISNULL(chr_stfcode,'') != '' ");
		}
		// ORDER BY��
		plusSQL.append(" ORDER BY cod_value2, cod_code ");
		
		Object[] param = {listFormBean.getNendo(),listFormBean.getSelectedGrade(),
				listFormBean.getSubjectStfCode(),userCode};
		QueryManager qm = new QueryManager(EXEC_SQL_ITEM_LIST, param, CodeEntity.class);
		qm.setPlusSQL(plusSQL.toString());

		List<CodeEntity> entityList = (List<CodeEntity>) this.executeQuery(qm);
		List<SimpleTagFormBean> itemList = new ArrayList<SimpleTagFormBean>();
		for (CodeEntity entity : entityList) {
			itemList.add(new SimpleTagFormBean(entity.getCod_code(),entity.getCod_name1()));
		}

		return itemList;
	}
	
	/**
	 * �o�͊w���ꗗ���擾�E�ݒ肷��
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private void setTermList() {
		
		Object[] param = {userCode,listFormBean.getNendo()};
		QueryManager qm = new QueryManager(EXEC_SQL_TERM_LIST, param, Data31904000_outputTermEntity.class);
		qm.setPlusSQL(" ORDER BY gopt_order ");

		List<Data31904000_outputTermEntity> entityList = (List<Data31904000_outputTermEntity>) this.executeQuery(qm);
		List<SimpleTagFormBean> termList = new ArrayList<SimpleTagFormBean>();
		List<SimpleTagFormBean> termList2 = new ArrayList<SimpleTagFormBean>();
		for (Data31904000_outputTermEntity entity : entityList) {
			//�\����������4�����Ő؂�̂�
			String name = entity.getGopt_name();
			if (name != null && name.length() > 4) {
				name = name.substring(0,4);
			}
			//3�N�ȊO�͐i�H�p�ΏۊO������ǉ�
			if ("3".equals(listFormBean.getSelectedGrade()) || !"1".equals(entity.getGopt_tempeval_flg())) {
				termList.add(new SimpleTagFormBean(entity.getGopt_goptcode(),name));
			}
			//�]���s�\�҂̐ݒ��Ԃł͏�ɕ\��
			termList2.add(new SimpleTagFormBean(entity.getGopt_goptcode(),name));
		}
		//�]�������ݒ�
		listFormBean.setTermList(termList);
		listFormBean.setTermList2(termList2);
	}

	/**
	 * ���k�ꗗ���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Data31904000_studentEntity> getStuList() {
		
		Object[] param = {userCode,listFormBean.getNendo(),listFormBean.getSelectedGrade(),
				listFormBean.getSelectedClass(),listFormBean.getSelectedClass()};
		QueryManager qm = new QueryManager(EXEC_SQL_STUDENT_LIST1, param, Data31904000_studentEntity.class);

		List<Data31904000_studentEntity> entityList = (List<Data31904000_studentEntity>) this.executeQuery(qm);

		return entityList;
	}
	

	/**
	 * �]���s�\�҈ꗗ���擾����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private void setStuAllList() {
		
		Object[] param = {listFormBean.getSelectedItem(),userCode,listFormBean.getNendo()};
		QueryManager qm = new QueryManager(EXEC_SQL_STUDENT_LIST2, param, Data31904000_studentEntity.class);

		List<Data31904000_studentEntity> entityList = (List<Data31904000_studentEntity>) this.executeQuery(qm);

		//�擾�S�����w�Дԍ�_�����R�[�h��MAP�i�[���ă`�F�b�N�E���\������ɗ��p�A�Ώې��k�͏d�����Ȃ��悤�Ƀ��X�g�i�[
		String oldStucode = "";
		List<Data31904000_studentEntity> stuAllList = new ArrayList<Data31904000_studentEntity>();
		Map<String, String> stuTermMap = new HashMap<String, String>();
		for (Data31904000_studentEntity entity: entityList) {
			stuTermMap.put(entity.getCls_stucode()+"_"+entity.getCne_goptcode(), "1");
			if (!oldStucode.equals(entity.getCls_stucode())) {
				stuAllList.add(entity);
			}
			oldStucode = entity.getCls_stucode();
		}
		listFormBean.setStuAllList(stuAllList);
		listFormBean.setStuTermMap(stuTermMap);
		
		return;
	}
}

