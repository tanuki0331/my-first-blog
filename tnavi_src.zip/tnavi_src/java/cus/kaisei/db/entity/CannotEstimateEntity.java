/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;


/**
 * <PRE>
 * ���ѕ]���s�\�҃e�[�u�� Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class CannotEstimateEntity{

    /**
     * �e�[�u����
     */
    public String TABLE_NAME = "tbl_cannot_estimate";

    /** 
     * �����R�[�h
     */
    private String cne_user;
    /** 
     * �N�x
     */
    private String cne_year;
    /** 
     * �o�͎����R�[�h
     */
    private String cne_goptcode;
    /** 
     * ���ȃR�[�h
     */
    private String cne_item;
    /** 
     * �w�Дԍ�
     */
    private String cne_stucode;
    /** 
     * �X�V��
     */
    private String cne_update;
    /** 
     * �X�V��
     */
    private String cne_upuser;

    /**
     * ���ѕ]���s�\�҃e�[�u���p
     */
    public Object[] getCannotEstimateParameter() {
    
        Object[] obj = {
            this.cne_user == null ? null:new String(this.cne_user),
            this.cne_year == null ? null:new String(this.cne_year),
            this.cne_goptcode == null ? null:new String(this.cne_goptcode),
            this.cne_item == null ? null:new String(this.cne_item),
            this.cne_stucode == null ? null:new String(this.cne_stucode),
            this.cne_update == null ? null:new String(this.cne_update),
            this.cne_upuser == null ? null:new String(this.cne_upuser)
        };
    
        return obj;
    }

	public String getCne_user() {
		return cne_user;
	}

	public void setCne_user(String cne_user) {
		this.cne_user = cne_user;
	}

	public String getCne_year() {
		return cne_year;
	}

	public void setCne_year(String cne_year) {
		this.cne_year = cne_year;
	}

	public String getCne_goptcode() {
		return cne_goptcode;
	}

	public void setCne_goptcode(String cne_goptcode) {
		this.cne_goptcode = cne_goptcode;
	}

	public String getCne_item() {
		return cne_item;
	}

	public void setCne_item(String cne_item) {
		this.cne_item = cne_item;
	}

	public String getCne_stucode() {
		return cne_stucode;
	}

	public void setCne_stucode(String cne_stucode) {
		this.cne_stucode = cne_stucode;
	}

	public String getCne_update() {
		return cne_update;
	}

	public void setCne_update(String cne_update) {
		this.cne_update = cne_update;
	}

	public String getCne_upuser() {
		return cne_upuser;
	}

	public void setCne_upuser(String cne_upuser) {
		this.cne_upuser = cne_upuser;
	}

}
