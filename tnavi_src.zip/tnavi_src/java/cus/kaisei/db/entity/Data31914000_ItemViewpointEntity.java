package jp.co.systemd.tnavi.cus.kaisei.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.21 BY  nagaoka #8210 31914000 ���ђʒm�[���(�J����_���w�Z) �V�K�쐬<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31914000_ItemViewpointEntity {

	/**
	 * ���ȃR�[�h
	 */
	private String item_code;

	/**
	 * �\����
	 */
	private String item_order;

	/**
	 * ���Ȗ���
	 */
	private String item_name;

	/**
	 * ���ȕʊϓ_�A��
	 */
	private String rivt_rivtcode;

	/**
	 * ����
	 */
	private String rivt_rivtname;

	/**
	 * �ϓ_�̎�|�E�w�K�̂߂���
	 */
	private String rivt_purpose;

	/**
	 * @return the item_code
	 */
	public String getItem_code() {
		return item_code;
	}

	/**
	 * @param item_code the item_code to set
	 */
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	/**
	 * @return the item_order
	 */
	public String getItem_order() {
		return item_order;
	}

	/**
	 * @param item_order the item_order to set
	 */
	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	/**
	 * @return the item_name
	 */
	public String getItem_name() {
		return item_name;
	}

	/**
	 * @param item_name the item_name to set
	 */
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	/**
	 * @return the rivt_rivtcode
	 */
	public String getRivt_rivtcode() {
		return rivt_rivtcode;
	}

	/**
	 * @param rivt_rivtcode the rivt_rivtcode to set
	 */
	public void setRivt_rivtcode(String rivt_rivtcode) {
		this.rivt_rivtcode = rivt_rivtcode;
	}

	/**
	 * @return the rivt_rivtname
	 */
	public String getRivt_rivtname() {
		return rivt_rivtname;
	}

	/**
	 * @param rivt_rivtname the rivt_rivtname to set
	 */
	public void setRivt_rivtname(String rivt_rivtname) {
		this.rivt_rivtname = rivt_rivtname;
	}

	/**
	 * @return the rivt_purpose
	 */
	public String getRivt_purpose() {
		return rivt_purpose;
	}

	/**
	 * @param rivt_purpose the rivt_purpose to set
	 */
	public void setRivt_purpose(String rivt_purpose) {
		this.rivt_purpose = rivt_purpose;
	}
}
