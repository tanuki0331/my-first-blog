/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import java.util.Map;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ����������ʒʒm��� �l���� Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.05.27 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31902000_indivisualScoreEntity implements CommonConstantsUseable{

	/**
	 * �w�N
	 */
	private String cls_glade;

	/**
	 * �g
	 */
	private String hmr_class;

	/**
	 * ��
	 */
	private String cls_number;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �f�_�}�b�v(key:���ȃR�[�h, value:�f�_)
	 */
	private Map<String, Integer> scoreMap;

	/**
	 * ���ϓ_�}�b�v(key:���ȃR�[�h, value:���ϓ_)
	 */
	private Map<String, Integer> averageMap;

	/**
	 * @return cls_glade
	 */
	public final String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade �Z�b�g���� cls_glade
	 */
	public final void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return hmr_class
	 */
	public final String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class �Z�b�g���� hmr_class
	 */
	public final void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return cls_number
	 */
	public final String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number �Z�b�g���� cls_number
	 */
	public final void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	/**
	 * @return cls_stucode
	 */
	public final String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public final void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return scoreMap
	 */
	public final Map<String, Integer> getScoreMap() {
		return scoreMap;
	}

	/**
	 * @param scoreMap �Z�b�g���� scoreMap
	 */
	public final void setScoreMap(Map<String, Integer> scoreMap) {
		this.scoreMap = scoreMap;
	}

	/**
	 * @return averageMap
	 */
	public final Map<String, Integer> getAverageMap() {
		return averageMap;
	}

	/**
	 * @param averageMap �Z�b�g���� averageMap
	 */
	public final void setAverageMap(Map<String, Integer> averageMap) {
		this.averageMap = averageMap;
	}
}
