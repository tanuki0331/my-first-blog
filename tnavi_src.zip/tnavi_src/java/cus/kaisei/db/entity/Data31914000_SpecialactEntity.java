package jp.co.systemd.tnavi.cus.kaisei.db.entity;

/**
 * <PRE>
 * ���ʊ����̋L�^(�ϓ_�A�]��)Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.21 BY  nagaoka #8210 31914000 ���ђʒm�[���(�J����_���w�Z) �V�K�쐬<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31914000_SpecialactEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �o�͎���ID
	 */
	private String rsav_term;

	/**
	 * ���e�R�[�h
	 * */
	private String rsav_rsatcode;

	/**
	 * ���e
	 */
	private String rsat_rsatname;

	/**
	 * �\����
	 */
	private String rsat_order;

	/**
	 * �w�Z�����̋L�^
	 */
	private String rsav_record;

	/** �]���l�R�[�h*/
	private String rsav_rsaecode;

	/** �\���p�]���l*/
	private String rsae_display;

	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return rsav_term
	 */
	public String getRsav_term() {
		return rsav_term;
	}

	/**
	 * @param rsav_term �Z�b�g���� rsav_term
	 */
	public void setRsav_term(String rsav_term) {
		this.rsav_term = rsav_term;
	}

	/**
	 * @return rsav_rsatcode
	 */
	public String getRsav_rsatcode() {
		return rsav_rsatcode;
	}

	/**
	 * @param rsav_rsatcode �Z�b�g���� rsav_rsatcode
	 */
	public void setRsav_rsatcode(String rsav_rsatcode) {
		this.rsav_rsatcode = rsav_rsatcode;
	}

	/**
	 * @return rsat_rsatname
	 */
	public String getRsat_rsatname() {
		return rsat_rsatname;
	}

	/**
	 * @param rsat_rsatname �Z�b�g���� rsat_rsatname
	 */
	public void setRsat_rsatname(String rsat_rsatname) {
		this.rsat_rsatname = rsat_rsatname;
	}

		/**
	 * @return rsat_order
	 */
	public String getRsat_order() {
		return rsat_order;
	}

	/**
	 * @param rsat_order �Z�b�g���� rsat_order
	 */
	public void setRsat_order(String rsat_order) {
		this.rsat_order = rsat_order;
	}

	/**
	 * @return rsav_record
	 */
	public String getRsav_record() {
		return rsav_record;
	}

	/**
	 * @param rsav_record �Z�b�g���� rsav_record
	 */
	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}

	/**
	 * @return rsav_rsaecode
	 */
	public String getRsav_rsaecode() {
		return rsav_rsaecode;
	}

	/**
	 * @param rsav_rsaecode �Z�b�g���� rsav_rsaecode
	 */
	public void setRsav_rsaecode(String rsav_rsaecode) {
		this.rsav_rsaecode = rsav_rsaecode;
	}

	/**
	 * @return rsae_display
	 */
	public String getRsae_display() {
		return rsae_display;
	}

	/**
	 * @param rsae_display �Z�b�g���� rsae_display
	 */
	public void setRsae_display(String rsae_display) {
		this.rsae_display = rsae_display;
	}
}
