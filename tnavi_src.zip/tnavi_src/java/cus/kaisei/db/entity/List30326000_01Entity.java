/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ���ʊ����̋L�^����(�ʒm�\) �ꗗ�w�b�_�[Entity.
 * </PRE>
 *
 * <B>Create</B> 2014.05.07 BY SD inasawa<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List30326000_01Entity implements CommonConstantsUseable {


	/**
	 * �A��
	 */
	private String rsatRsatcode;
	/**
	 * ����
	 */
	private String rsatRsatname;
	/**
	 * ����
	 */
	private String rsatRsatname2;

	/**
	 * �ۊO�����敪1
	 */
	private String gsatKind1;

	/**
	 * �ۊO�����敪2
	 */
	private String gsatKind2;

	/**
	 * �\����
	 */
	private String rsatOrder;


	// ----------------------------------------------------
	// getter & setter
	// ----------------------------------------------------
	public String getRsatRsatcode() {
		return rsatRsatcode;
	}

	public void setRsatRsatcode(String rsatRsatcode) {
		this.rsatRsatcode = rsatRsatcode;
	}

	public String getRsatRsatname() {
		return rsatRsatname;
	}

	public void setRsatRsatname(String rsatRsatname) {
		this.rsatRsatname = rsatRsatname;
	}

	public String getRsatRsatname2() {
		return rsatRsatname2;
	}

	public void setRsatRsatname2(String rsatRsatname2) {
		this.rsatRsatname2 = rsatRsatname2;
	}

	public String getGsatKind1() {
		return gsatKind1;
	}

	public void setGsatKind1(String gsatKind1) {
		this.gsatKind1 = gsatKind1;
	}

	public String getGsatKind2() {
		return gsatKind2;
	}

	public void setGsatKind2(String gsatKind2) {
		this.gsatKind2 = gsatKind2;
	}

	public String getRsatOrder() {
		return rsatOrder;
	}

	public void setRsatOrder(String rsatOrder) {
		this.rsatOrder = rsatOrder;
	}
}