package jp.co.systemd.tnavi.cus.kaisei.db.entity;

/**
 * <PRE>
 * �ϓ_���Ƃ̐���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.21 BY  nagaoka #8210 31914000 ���ђʒm�[���(�J����_���w�Z) �V�K�쐬<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31914000_ViewpointValueEntity {

	/**
	 * �w�Дԍ�
	 */
    private String rvpv_stucode;

    /**
     * ���яo�͎���ID
     */
    private String rvpv_goptcode;

    /**
     * ���ȃR�[�h
     */
    private String rvpv_item;

    /**
     * �ϓ_�R�[�h
     */
    private String rvpv_rivtcode;

    /**
     * �蓮�l�i�m�萬�сj�̕]���R�[�h
     */
    private String rvpv_manualrevpecode;

    /**
     * �ϓ_�ʕ]���̕\���p�̒l
     */
    private String rvpe_reportdisplay;

	public String getRvpv_stucode() {
		return rvpv_stucode;
	}

	public void setRvpv_stucode(String rvpv_stucode) {
		this.rvpv_stucode = rvpv_stucode;
	}

	public String getRvpv_goptcode() {
		return rvpv_goptcode;
	}

	public void setRvpv_goptcode(String rvpv_goptcode) {
		this.rvpv_goptcode = rvpv_goptcode;
	}

	public String getRvpv_item() {
		return rvpv_item;
	}

	public void setRvpv_item(String rvpv_item) {
		this.rvpv_item = rvpv_item;
	}

	public String getRvpv_rivtcode() {
		return rvpv_rivtcode;
	}

	public void setRvpv_rivtcode(String rvpv_rivtcode) {
		this.rvpv_rivtcode = rvpv_rivtcode;
	}

	public String getRvpv_manualrevpecode() {
		return rvpv_manualrevpecode;
	}

	public void setRvpv_manualrevpecode(String rvpv_manualrevpecode) {
		this.rvpv_manualrevpecode = rvpv_manualrevpecode;
	}

	/**
	 * @return rvpe_reportdisplay
	 */
	public String getRvpe_reportdisplay() {
		return rvpe_reportdisplay;
	}

	/**
	 * @param rvpe_reportdisplay �Z�b�g���� rvpe_reportdisplay
	 */
	public void setRvpe_reportdisplay(String rvpe_reportdisplay) {
		this.rvpe_reportdisplay = rvpe_reportdisplay;
	}


}
