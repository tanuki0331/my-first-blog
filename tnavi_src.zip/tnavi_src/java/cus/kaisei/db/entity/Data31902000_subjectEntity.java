/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ����������ʒʒm��� �Ȗ� Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.05.27 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31902000_subjectEntity implements CommonConstantsUseable{

	/**
	 * �����R�[�h
	 */
	private String codUser;

	/**
	 * �N�x
	 */
	private String gstYear;

	/**
	 * ���ȃR�[�h
	 */
	private String subjectCd;

	/**
	 * �w�N
	 */
	private String clsGlade;

	/**
	 * ���Ȗ���
	 */
	private String subjectName;

	/**
	 * ���ȕ��я�
	 */
	private String sortOrder;

	/**
	 * ����
	 */
	private Integer cnt;

	/**
	 * @return codUser
	 */
	public final String getCodUser() {
		return codUser;
	}

	/**
	 * @param codUser �Z�b�g���� codUser
	 */
	public final void setCodUser(String codUser) {
		this.codUser = codUser;
	}

	/**
	 * @return gstYear
	 */
	public final String getGstYear() {
		return gstYear;
	}

	/**
	 * @param gstYear �Z�b�g���� gstYear
	 */
	public final void setGstYear(String gstYear) {
		this.gstYear = gstYear;
	}

	/**
	 * @return subjectCd
	 */
	public final String getSubjectCd() {
		return subjectCd;
	}

	/**
	 * @param subjectCd �Z�b�g���� subjectCd
	 */
	public final void setSubjectCd(String subjectCd) {
		this.subjectCd = subjectCd;
	}

	/**
	 * @return clsGlade
	 */
	public final String getClsGlade() {
		return clsGlade;
	}

	/**
	 * @param clsGlade �Z�b�g���� clsGlade
	 */
	public final void setClsGlade(String clsGlade) {
		this.clsGlade = clsGlade;
	}

	/**
	 * @return subjectName
	 */
	public final String getSubjectName() {
		return subjectName;
	}

	/**
	 * @param subjectName �Z�b�g���� subjectName
	 */
	public final void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	/**
	 * @return sortOrder
	 */
	public final String getSortOrder() {
		return sortOrder;
	}

	/**
	 * @param sortOrder �Z�b�g���� sortOrder
	 */
	public final void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * @return cnt
	 */
	public final Integer getCnt() {
		return cnt;
	}

	/**
	 * @param cnt �Z�b�g���� cnt
	 */
	public final void setCnt(Integer cnt) {
		this.cnt = cnt;
	}

}
