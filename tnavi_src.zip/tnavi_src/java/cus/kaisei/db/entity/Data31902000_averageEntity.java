/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import java.math.BigDecimal;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ����������ʒʒm��� ���ϓ_ Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.05.30 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31902000_averageEntity implements CommonConstantsUseable{

	/**
	 * ���ȃR�[�h
	 */
	private String item;

	/**
	 * ���ϓ_
	 */
	private BigDecimal average;

	/**
	 * @return item
	 */
	public final String getItem() {
		return item;
	}

	/**
	 * @param item �Z�b�g���� item
	 */
	public final void setItem(String item) {
		this.item = item;
	}

	/**
	 * @return average
	 */
	public final BigDecimal getAverage() {
		return average;
	}

	/**
	 * @param average �Z�b�g���� average
	 */
	public final void setAverage(BigDecimal average) {
		this.average = average;
	}

}
