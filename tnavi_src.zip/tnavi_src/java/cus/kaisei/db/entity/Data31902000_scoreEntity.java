/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ����������ʒʒm��� �f�_ Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.05.27 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31902000_scoreEntity implements CommonConstantsUseable{

	/**
	 * �w�Дԍ�
	 */
	private String rscStucode;

	/**
	 * ���ȃR�[�h
	 */
	private String item;

	/**
	 * �f�_
	 */
	private Integer scoreSum;

	/**
	 * @return rscStucode
	 */
	public final String getRscStucode() {
		return rscStucode;
	}

	/**
	 * @param rscStucode �Z�b�g���� rscStucode
	 */
	public final void setRscStucode(String rscStucode) {
		this.rscStucode = rscStucode;
	}

	/**
	 * @return item
	 */
	public final String getItem() {
		return item;
	}

	/**
	 * @param item �Z�b�g���� item
	 */
	public final void setItem(String item) {
		this.item = item;
	}

	/**
	 * @return scoreSum
	 */
	public final Integer getScoreSum() {
		return scoreSum;
	}

	/**
	 * @param scoreSum �Z�b�g���� scoreSum
	 */
	public final void setScoreSum(Integer scoreSum) {
		this.scoreSum = scoreSum;
	}

}
