/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\  ����p Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31904000Entity implements CommonConstantsUseable{

	/**
	 * �R�[�h
	 */
	private String code;

	/**
	 * �\���l
	 */
	private String value;

	public Print31904000Entity() {
	}
	public Print31904000Entity(String code, String value) {
		this.code = code;
		this.value = value;
	}
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
}
