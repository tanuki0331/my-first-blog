/**------------------------------------------------------------**
 * Te@cherNavi
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;


/**
 * <PRE>
 * �o�����R���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.21 BY  nagaoka #8210 31914000 ���ђʒm�[���(�J����_���w�Z) �V�K�쐬<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD.Inc,
 * @since 1.0.
 */
public class Data31914000_AttendCommentEntity{

	public final static String DEFALUT_VALUE = "";

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;
	/**
	 * �N����
	 */
	private String att_date;
	/**
	 * �o���敪
	 */
	private String att_attendkind;
	/**
	 * �o���敪�R�[�h
	 */
	private String akj_code;
	/**
	 * �o���敪����
	 */
	private String akj_name;
	/**
	 * �o���敪�\����
	 */
	private String akj_order;
	/**
	 * ���Ȉ���
	 */
	private Integer akj_absenceflg;
	/**
	 * �x������
	 */
	private Integer akj_lateflg;
	/**
	 * ���ވ���
	 */
	private Integer akj_leaveflg;
	/**
	 * �o�����������
	 */
	private Integer akj_schoolkind;
	/**
	 * ���ꓮ��t���O
	 */
	private String akj_special;
	/**
	 * �o�����R�\����
	 */
	private String arj_order;
	/**
	 * �A��
	 */
	private String arj_serial;
	/**
	 * ���R
	 */
	private String arj_reason;
	/**
	 * �W�v�O���[�v�R�[�h
	 */
	private String atrg_grpcode;
	/**
	 * �W�v�O���[�v����
	 */
	private String arg_grpname;
	/**
	 * ��
	 */
	private int count;

	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}
	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	/**
	 * @return att_date
	 */
	public String getAtt_date() {
		return att_date;
	}
	/**
	 * @param att_date �Z�b�g���� att_date
	 */
	public void setAtt_date(String att_date) {
		this.att_date = att_date;
	}
	/**
	 * @return att_attendkind
	 */
	public String getAtt_attendkind() {
		return att_attendkind;
	}
	/**
	 * @param att_attendkind �Z�b�g���� att_attendkind
	 */
	public void setAtt_attendkind(String att_attendkind) {
		this.att_attendkind = att_attendkind;
	}
	/**
	 * @return akj_code
	 */
	public String getAkj_code() {
		return akj_code;
	}
	/**
	 * @param akj_code �Z�b�g���� akj_code
	 */
	public void setAkj_code(String akj_code) {
		this.akj_code = akj_code;
	}
	/**
	 * @return akj_name
	 */
	public String getAkj_name() {
		return akj_name;
	}
	/**
	 * @param akj_name �Z�b�g���� akj_name
	 */
	public void setAkj_name(String akj_name) {
		this.akj_name = akj_name;
	}
	/**
	 * @return akj_order
	 */
	public String getAkj_order() {
		return akj_order;
	}
	/**
	 * @param akj_order �Z�b�g���� akj_order
	 */
	public void setAkj_order(String akj_order) {
		this.akj_order = akj_order;
	}
	/**
	 * @return akj_absenceflg
	 */
	public Integer getAkj_absenceflg() {
		return akj_absenceflg;
	}
	/**
	 * @param akj_absenceflg �Z�b�g���� akj_absenceflg
	 */
	public void setAkj_absenceflg(Integer akj_absenceflg) {
		this.akj_absenceflg = akj_absenceflg;
	}
	/**
	 * @return akj_lateflg
	 */
	public Integer getAkj_lateflg() {
		return akj_lateflg;
	}
	/**
	 * @param akj_lateflg �Z�b�g���� akj_lateflg
	 */
	public void setAkj_lateflg(Integer akj_lateflg) {
		this.akj_lateflg = akj_lateflg;
	}
	/**
	 * @return akj_leaveflg
	 */
	public Integer getAkj_leaveflg() {
		return akj_leaveflg;
	}
	/**
	 * @param akj_leaveflg �Z�b�g���� akj_leaveflg
	 */
	public void setAkj_leaveflg(Integer akj_leaveflg) {
		this.akj_leaveflg = akj_leaveflg;
	}
	/**
	 * @return akj_schoolkind
	 */
	public Integer getAkj_schoolkind() {
		return akj_schoolkind;
	}
	/**
	 * @param akj_schoolkind �Z�b�g���� akj_schoolkind
	 */
	public void setAkj_schoolkind(Integer akj_schoolkind) {
		this.akj_schoolkind = akj_schoolkind;
	}
	/**
	 * @return akj_special
	 */
	public String getAkj_special() {
		return akj_special;
	}
	/**
	 * @param akj_special �Z�b�g���� akj_special
	 */
	public void setAkj_special(String akj_special) {
		this.akj_special = akj_special;
	}
	/**
	 * @return arj_order
	 */
	public String getArj_order() {
		return arj_order;
	}
	/**
	 * @param arj_order �Z�b�g���� arj_order
	 */
	public void setArj_order(String arj_order) {
		this.arj_order = arj_order;
	}
	/**
	 * @return arj_serial
	 */
	public String getArj_serial() {
		return arj_serial;
	}
	/**
	 * @param arj_serial �Z�b�g���� arj_serial
	 */
	public void setArj_serial(String arj_serial) {
		this.arj_serial = arj_serial;
	}
	/**
	 * @return arj_reason
	 */
	public String getArj_reason() {
		return arj_reason;
	}
	/**
	 * @param arj_reason �Z�b�g���� arj_reason
	 */
	public void setArj_reason(String arj_reason) {
		this.arj_reason = arj_reason;
	}
	/**
	 * @return atrg_grpcode
	 */
	public String getAtrg_grpcode() {
		return atrg_grpcode;
	}
	/**
	 * @param atrg_grpcode �Z�b�g���� atrg_grpcode
	 */
	public void setAtrg_grpcode(String atrg_grpcode) {
		this.atrg_grpcode = atrg_grpcode;
	}
	/**
	 * @return arg_grpname
	 */
	public String getArg_grpname() {
		return arg_grpname;
	}
	/**
	 * @param arg_grpname �Z�b�g���� arg_grpname
	 */
	public void setArg_grpname(String arg_grpname) {
		this.arg_grpname = arg_grpname;
	}
	/**
	 * @return count
	 */
	public int getCount() {
		return count;
	}
	/**
	 * @param count �Z�b�g���� count
	 */
	public void setCount(int count) {
		this.count = count;
	}
	}
