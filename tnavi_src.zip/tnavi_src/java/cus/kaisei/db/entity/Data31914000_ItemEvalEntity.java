package jp.co.systemd.tnavi.cus.kaisei.db.entity;

/**
 * <PRE>
 * �]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.21 BY  nagaoka #8210 31914000 ���ђʒm�[���(�J����_���w�Z) �V�K�쐬<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31914000_ItemEvalEntity {
	/**
	 * �w�Дԍ�
	 */
	private String rev_stucode;

	/**
	 * �o�͎���ID
	 */
	private String rev_goptcode;

	/**
	 * ����
	 */
	private String rev_item;

	/**
	 * �]�_
	 */
	private String revl_display;

	public String getRev_stucode() {
		return rev_stucode;
	}

	public void setRev_stucode(String rev_stucode) {
		this.rev_stucode = rev_stucode;
	}

	public String getRev_goptcode() {
		return rev_goptcode;
	}

	public void setRev_goptcode(String rev_goptcode) {
		this.rev_goptcode = rev_goptcode;
	}

	public String getRev_item() {
		return rev_item;
	}

	public void setRev_item(String rev_item) {
		this.rev_item = rev_item;
	}

	public String getRevl_display() {
		return revl_display;
	}

	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}

}
