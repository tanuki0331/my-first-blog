/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ����������ʒʒm��� ���_���z�\ Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.05.27 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31902000_scoreDistributionEntity implements CommonConstantsUseable{

	/**
	 * �w�N
	 */
	private String cls_glade;

	/**
	 * �g
	 */
	private String hmr_class;

	/**
	 * ��
	 */
	private String cls_number;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * ���_���z���X�g
	 * ���_���z���}�b�v(key:�ȖڃR�[�h,value:���X�g(0:�l���A1:�݌v))�̃��X�g
	 */
	private List<Map<String, List<Integer>>> scoreDistribution;

	/**
	 * @return cls_glade
	 */
	public final String getCls_glade() {
		return cls_glade;
	}

	/**
	 * @param cls_glade �Z�b�g���� cls_glade
	 */
	public final void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	/**
	 * @return hmr_class
	 */
	public final String getHmr_class() {
		return hmr_class;
	}

	/**
	 * @param hmr_class �Z�b�g���� hmr_class
	 */
	public final void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	/**
	 * @return cls_number
	 */
	public final String getCls_number() {
		return cls_number;
	}

	/**
	 * @param cls_number �Z�b�g���� cls_number
	 */
	public final void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	/**
	 * @return cls_stucode
	 */
	public final String getCls_stucode() {
		return cls_stucode;
	}

	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public final void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	/**
	 * @return scoreDistribution
	 */
	public final List<Map<String, List<Integer>>> getScoreDistribution() {
		return scoreDistribution;
	}

	/**
	 * @param scoreDistribution �Z�b�g���� scoreDistribution
	 */
	public final void setScoreDistribution(List<Map<String, List<Integer>>> scoreDistribution) {
		this.scoreDistribution = scoreDistribution;
	}
}
