/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;


/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\  �o�͎����p Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31904000_outputTermEntity{

    /**
     * �e�[�u����
     */
    public String TABLE_NAME = "mst_cmlguideoutputterm";

    /** 
     * �����R�[�h
     */
    private String gopt_user;
    /** 
     * �N�x
     */
    private String gopt_year;
    /** 
     * �o�͎����h�c
     */
    private String gopt_goptcode;
    /** 
     * �o�͎�������
     */
    private String gopt_name;
    /** 
     * ���ёΏۊJ�n�c�s
     */
    private String gopt_score_start;
    /** 
     * ���ёΏۏI���c�s
     */
    private String gopt_score_end;
    /** 
     * �o���ΏۊJ�n�c�s
     */
    private String gopt_attend_start;
    /** 
     * �o���ΏۏI���c�s
     */
    private String gopt_attend_end;
    /** 
     * �N�x�����уt���O
     */
    private String gopt_score_flg;
    /** 
     * �X�V��
     */
    private String gopt_update;
    /** 
     * �X�V��
     */
    private String gopt_upuser;
    /** 
     * ���ѓ��͊��ԊJ�nDT
     */
    private String gopt_input_start;
    /** 
     * ���ѓ��͊��ԏI��DT
     */
    private String gopt_input_end;
    /** 
     * �\����
     */
    private Integer gopt_order;
    /** 
     * ���]��t���O
     */
    private String gopt_tempeval_flg;
	public String getGopt_user() {
		return gopt_user;
	}
	public void setGopt_user(String gopt_user) {
		this.gopt_user = gopt_user;
	}
	public String getGopt_year() {
		return gopt_year;
	}
	public void setGopt_year(String gopt_year) {
		this.gopt_year = gopt_year;
	}
	public String getGopt_goptcode() {
		return gopt_goptcode;
	}
	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}
	public String getGopt_name() {
		return gopt_name;
	}
	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}
	public String getGopt_score_start() {
		return gopt_score_start;
	}
	public void setGopt_score_start(String gopt_score_start) {
		this.gopt_score_start = gopt_score_start;
	}
	public String getGopt_score_end() {
		return gopt_score_end;
	}
	public void setGopt_score_end(String gopt_score_end) {
		this.gopt_score_end = gopt_score_end;
	}
	public String getGopt_attend_start() {
		return gopt_attend_start;
	}
	public void setGopt_attend_start(String gopt_attend_start) {
		this.gopt_attend_start = gopt_attend_start;
	}
	public String getGopt_attend_end() {
		return gopt_attend_end;
	}
	public void setGopt_attend_end(String gopt_attend_end) {
		this.gopt_attend_end = gopt_attend_end;
	}
	public String getGopt_score_flg() {
		return gopt_score_flg;
	}
	public void setGopt_score_flg(String gopt_score_flg) {
		this.gopt_score_flg = gopt_score_flg;
	}
	public String getGopt_update() {
		return gopt_update;
	}
	public void setGopt_update(String gopt_update) {
		this.gopt_update = gopt_update;
	}
	public String getGopt_upuser() {
		return gopt_upuser;
	}
	public void setGopt_upuser(String gopt_upuser) {
		this.gopt_upuser = gopt_upuser;
	}
	public String getGopt_input_start() {
		return gopt_input_start;
	}
	public void setGopt_input_start(String gopt_input_start) {
		this.gopt_input_start = gopt_input_start;
	}
	public String getGopt_input_end() {
		return gopt_input_end;
	}
	public void setGopt_input_end(String gopt_input_end) {
		this.gopt_input_end = gopt_input_end;
	}
	public Integer getGopt_order() {
		return gopt_order;
	}
	public void setGopt_order(Integer gopt_order) {
		this.gopt_order = gopt_order;
	}
	public String getGopt_tempeval_flg() {
		return gopt_tempeval_flg;
	}
	public void setGopt_tempeval_flg(String gopt_tempeval_flg) {
		this.gopt_tempeval_flg = gopt_tempeval_flg;
	}

}
