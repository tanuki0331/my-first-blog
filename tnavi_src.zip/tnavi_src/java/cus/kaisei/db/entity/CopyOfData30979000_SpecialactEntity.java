package jp.co.systemd.tnavi.cus.kaisei.db.entity;

/**
 * <PRE>
 * ���ʊ����̋L�^(�ϓ_���]��)Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.99 BY nagaoka<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class CopyOfData30979000_SpecialactEntity {

	/**
	 * �w�Дԍ�
	 */
	private String rsav_stucode;

	/**
	 * �o�͎���ID
	 */
	private String rsav_term;

	/**
	 * �w�Z�����̋L�^
	 */
	private String rsav_record;

	public String getRsav_stucode() {
		return rsav_stucode;
	}

	public void setRsav_stucode(String rsav_stucode) {
		this.rsav_stucode = rsav_stucode;
	}

	public String getRsav_term() {
		return rsav_term;
	}

	public void setRsav_term(String rsav_term) {
		this.rsav_term = rsav_term;
	}

	public String getRsav_record() {
		return rsav_record;
	}

	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}


}
