/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.db.entity;

import java.util.List;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ���ʊ����̋L�^����(�ʒm�\) �ꗗ����Entity.
 * </PRE>
 *
 * <B>Create</B> 2012.07.27 BY SD inasawa<BR>
 * <B>remark</B><BR>
 *
 * @author APSIS Corp.
 * @since 1.0.
 */
public class List30326000_02Entity implements CommonConstantsUseable {

	/** �w�N **/
	private String cls_glade;

	/** �g **/
	private String hmr_class;

	/** �����ԍ� **/
	private String cls_stucode;

	/** �o�Ȕԍ� **/
	private String cls_number;

	/** �������� **/
	private String st4_name;
	/**
	 * �Ǎ��f�[�^���݃t���O
	 */
	private String hasReadData;
	/** �]��List **/
	private List<List30326000_03Entity> evalList;

	//----------------------------------------------
	// getter & setter
	//----------------------------------------------

	public String getCls_glade() {
		return cls_glade;
	}

	public String getHmr_class() {
		return hmr_class;
	}

	public String getCls_stucode() {
		return cls_stucode;
	}

	public String getCls_number() {
		return cls_number;
	}

	public String getSt4_name() {
		return st4_name;
	}

	public String getHasReadData() {
		return hasReadData;
	}

	public List<List30326000_03Entity> getEvalList() {
		return evalList;
	}

	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}

	public void setHmr_class(String hmr_class) {
		this.hmr_class = hmr_class;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}

	public void setSt4_name(String st4_name) {
		this.st4_name = st4_name;
	}

	public void setHasReadData(String hasReadData) {
		this.hasReadData = hasReadData;
	}

	public void setEvalList(List<List30326000_03Entity> evalList) {
		this.evalList = evalList;
	}
}