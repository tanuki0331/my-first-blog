package jp.co.systemd.tnavi.cus.kaisei.formbean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_ItemEvalEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_SpecialactEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_EtceteraEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_TotalactEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_ViewpointValueEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31914000_AttendEntity;

/**
 * <PRE>
 * ���ђʒm�\���(�J����_���w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2016.06.21 BY  nagaoka #8210 31914000 ���ђʒm�[���(�J����_���w�Z) �V�K�쐬<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31914000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C���N����*/
	private String gradeFinishDate = DEFALUT_VALUE;

	/** �Z�̓C���[�W */
	byte[] schoolStampImage;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �S�C���� */
	private String teacherName = DEFALUT_VALUE;

	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;

	/** �w�Z�������� */
	private String schoolName_s = DEFALUT_VALUE;

	/** ���l useh_remark */
	private String useh_remark = DEFALUT_VALUE;

	/** ���ȕʊϓ_�̃��X�g */
	List<List<Data31914000_ItemViewpointEntity>> itemViewpointListList;

	/** ���k���̃f�[�^ */
	private List<Data31914000FormBean> dataFormBeanList;

	/** �w�K�̋L�^�̋��ȃR�[�h�ɑΉ�����s�ԍ����i�[����Map */
	private Map<String, Integer> viewpointItemMap;

	/** �w�K�̋L�^�̊ϓ_�ɑΉ�����s�ԍ����i�[����Map */
	private Map<String, Integer> viewpointMap;

	/** �w�K�̋L�^�̊w���R�[�h�ɑΉ������ԍ����i�[����Map */
	private Map<String, Integer> viewpointTermMap;

	/** �ϓ_�ʕ]���̃��X�g */
	private Map<String,List<Data31914000_ViewpointValueEntity>> viewpointValueEntityMap;

	/** ���ȕʊϓ_�̃��X�g */
	private List<Data31914000_ItemEvalEntity> itemEvalEntityList;

	/** �����I�Ȋw�K�̎��Ԃ̃��X�g  */
	private List<Data31914000_TotalactEntity> totalactEntityList;

	/** �s���̋L�^�̃��X�g  */
	private Map<String, List<Data31914000_ActViewpointEntity>> actViewpointEntityListListMap;

	/** ���ʊ����̋L�^(�ϓ_�E�]��)�̃��X�g */
	private Map<String, List<Data31914000_SpecialactEntity>> specialactEntityListMap;

	/** ���������̃��X�g */
	private List<Data31914000_EtceteraEntity> etceteraEntityList;

	/** �o���̋L�^�̃��X�g */
	private HashMap<String,HashMap<String,Data31914000_AttendEntity>> attendHasMapList;

	/** ���k�ʂ̏o���̋L�^���l�n�b�V��	 */
	private  HashMap<String, String> attendCommentHasMap;

	/** ����y�[�W�\���E�C���� */
	private boolean output_page1;

	/** ����y�[�W���� */
	private boolean output_page2;

	/**
	 * �o�͈ʒu�����F�c
	 */
	private String pos_y;

	/**
	 * �o�͈ʒu�����F��
	 */
	private String pos_x;

	/** �o�͑Ώۂ̏o���̋L�^�̏o�͎����R�[�h���X�g*/
	private String[] attendTermArray;

	/**
	 * @return the userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode the userCode to set
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	/**
	 * @return the nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo the nendo to set
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return the termName
	 */
	public String getTermName() {
		return termName;
	}

	/**
	 * @param termName the termName to set
	 */
	public void setTermName(String termName) {
		this.termName = termName;
	}

	/**
	 * @return the outputDate
	 */
	public String getOutputDate() {
		return outputDate;
	}

	/**
	 * @param outputDate the outputDate to set
	 */
	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	/**
	 * @return the principalName
	 */
	public String getPrincipalName() {
		return principalName;
	}

	/**
	 * @param principalName the principalName to set
	 */
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	/**
	 * @return the teacherName
	 */
	public String getTeacherName() {
		return teacherName;
	}

	/**
	 * @param teacherName the teacherName to set
	 */
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	/**
	 * @return the itemViewpointListList
	 */
	public List<List<Data31914000_ItemViewpointEntity>> getItemViewpointListList() {
		return itemViewpointListList;
	}

	/**
	 * @param itemViewpointListList the itemViewpointListList to set
	 */
	public void setItemViewpointListList(
			List<List<Data31914000_ItemViewpointEntity>> itemViewpointListList) {
		this.itemViewpointListList = itemViewpointListList;
	}

	/**
	 * @return the dataFormBeanList
	 */
	public List<Data31914000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	/**
	 * @param dataFormBeanList the dataFormBeanList to set
	 */
	public void setDataFormBeanList(List<Data31914000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	/**
	 * @return the viewpointItemMap
	 */
	public Map<String, Integer> getViewpointItemMap() {
		return viewpointItemMap;
	}

	/**
	 * @param viewpointItemMap the viewpointItemMap to set
	 */
	public void setViewpointItemMap(Map<String, Integer> viewpointItemMap) {
		this.viewpointItemMap = viewpointItemMap;
	}

	/**
	 * @return the viewpointTermMap
	 */
	public Map<String, Integer> getViewpointTermMap() {
		return viewpointTermMap;
	}

	/**
	 * @param viewpointTermMap the viewpointTermMap to set
	 */
	public void setViewpointTermMap(Map<String, Integer> viewpointTermMap) {
		this.viewpointTermMap = viewpointTermMap;
	}

	public Map<String, List<Data31914000_ViewpointValueEntity>> getViewpointValueEntityMap() {
		return viewpointValueEntityMap;
	}

	public void setViewpointValueEntityMap(
			Map<String, List<Data31914000_ViewpointValueEntity>> viewpointValueEntityMap) {
		this.viewpointValueEntityMap = viewpointValueEntityMap;
	}

	/**
	 * @return the totalactEntityList
	 */
	public List<Data31914000_TotalactEntity> getTotalactEntityList() {
		return totalactEntityList;
	}

	/**
	 * @param totalactEntityList the totalactEntityList to set
	 */
	public void setTotalactEntityList(
			List<Data31914000_TotalactEntity> totalactEntityList) {
		this.totalactEntityList = totalactEntityList;
	}

	public boolean isOutput_page1() {
		return output_page1;
	}

	public void setOutput_page1(boolean output_page1) {
		this.output_page1 = output_page1;
	}

	public boolean isOutput_page2() {
		return output_page2;
	}

	public void setOutput_page2(boolean output_page2) {
		this.output_page2 = output_page2;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolName_s() {
		return schoolName_s;
	}

	public void setSchoolName_s(String schoolName_s) {
		this.schoolName_s = schoolName_s;
	}

	public String getUseh_remark() {
		return useh_remark;
	}

	public void setUseh_remark(String useh_remark) {
		this.useh_remark = useh_remark;
	}

	public Map<String, List<Data31914000_ActViewpointEntity>> getActViewpointEntityListMap() {
		return actViewpointEntityListListMap;
	}

	public void setActViewpointEntityListMap(
			Map<String, List<Data31914000_ActViewpointEntity>> tmpActEntityListMap) {
		this.actViewpointEntityListListMap = tmpActEntityListMap;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public Map<String, Integer> getViewpointMap() {
		return viewpointMap;
	}

	public void setViewpointMap(Map<String, Integer> viewpointMap) {
		this.viewpointMap = viewpointMap;
	}

	public List<Data31914000_ItemEvalEntity> getItemEvalEntityList() {
		return itemEvalEntityList;
	}

	public void setItemEvalEntityList(
			List<Data31914000_ItemEvalEntity> itemEvalEntityList) {
		this.itemEvalEntityList = itemEvalEntityList;
	}

	/**
	 * @return gradeFinishDate
	 */
	public String getGradeFinishDate() {
		return gradeFinishDate;
	}

	/**
	 * @param gradeFinishDate �Z�b�g���� gradeFinishDate
	 */
	public void setGradeFinishDate(String gradeFinishDate) {
		this.gradeFinishDate = gradeFinishDate;
	}

	/**
	 * @return specialactEntityListMap
	 */
	public Map<String, List<Data31914000_SpecialactEntity>> getSpecialactEntityListMap() {
		return specialactEntityListMap;
	}

	/**
	 * @param specialactEntityListMap �Z�b�g���� specialactEntityListMap
	 */
	public void setSpecialactEntityListMap(Map<String, List<Data31914000_SpecialactEntity>> specialactEntityListMap) {
		this.specialactEntityListMap = specialactEntityListMap;
	}

	/**
	 * @return pos_y
	 */
	public String getPos_y() {
		return pos_y;
	}

	/**
	 * @param pos_y �Z�b�g���� pos_y
	 */
	public void setPos_y(String pos_y) {
		this.pos_y = pos_y;
	}

	/**
	 * @return pos_x
	 */
	public String getPos_x() {
		return pos_x;
	}

	/**
	 * @param pos_x �Z�b�g���� pos_x
	 */
	public void setPos_x(String pos_x) {
		this.pos_x = pos_x;
	}

	/**
	 * @return etceteraEntityList
	 */
	public List<Data31914000_EtceteraEntity> getEtceteraEntityList() {
		return etceteraEntityList;
	}

	/**
	 * @param etceteraEntityList �Z�b�g���� etceteraEntityList
	 */
	public void setEtceteraEntityList(List<Data31914000_EtceteraEntity> etceteraEntityList) {
		this.etceteraEntityList = etceteraEntityList;
	}

	/**
	 * @return attendHasMapList
	 */
	public HashMap<String,HashMap<String,Data31914000_AttendEntity>> getAttendHasMapList() {
		return attendHasMapList;
	}

	/**
	 * @param attendHasMapList �Z�b�g���� attendHasMapList
	 */
	public void setAttendHasMapList(HashMap<String,HashMap<String,Data31914000_AttendEntity>> attendHasMapList) {
		this.attendHasMapList = attendHasMapList;
	}

	/**
	 * @return attendTermArray
	 */
	public String[] getAttendTermArray() {
		return attendTermArray;
	}

	/**
	 * @param attendTermArray �Z�b�g���� attendTermArray
	 */
	public void setAttendTermArray(String[] attendTermArray) {
		this.attendTermArray = attendTermArray;
	}

	/**
	 * @return attendCommentHasMap
	 */
	public HashMap<String, String> getAttendCommentHasMap() {
		return attendCommentHasMap;
	}

	/**
	 * @param attendCommentHasMap �Z�b�g���� attendCommentHasMap
	 */
	public void setAttendCommentHasMap(HashMap<String, String> attendCommentHasMap) {
		this.attendCommentHasMap = attendCommentHasMap;
	}


}
