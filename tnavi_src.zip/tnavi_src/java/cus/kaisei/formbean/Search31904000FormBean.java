/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ ��� FormBean�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Search31904000FormBean {

	/**
	 * �����l
	 */
	public final static String DEFALUT_VALUE = "";

	/**
	 * �N�x
	 */
	private String nendo = DEFALUT_VALUE;
	
	/**
	 * �\���p�N�x
	 */
	private String dispNendo = DEFALUT_VALUE;

	/**
	 * �w�N
	 */
	private String grade = DEFALUT_VALUE;

	/**
	 * ����
	 */
	private String item = null;
	/**
	 * ���ȕ\����
	 */
	private String itemName = null;
	
	/**
	 * �o�͎���
	 */
	private String goptcode = DEFALUT_VALUE;
	
	/**
	 * �o�͎����\����
	 */
	private String termName = DEFALUT_VALUE;
	
	/**
	 * ���ȒS�������R�[�h
	 */
	private String subjectStfCode = DEFALUT_VALUE;
	
	/**
	 * ���ȃ��X�g
	 */
	private List<SimpleTagFormBean> itemList = new ArrayList<SimpleTagFormBean>();

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getGoptcode() {
		return goptcode;
	}

	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}

	public List<SimpleTagFormBean> getItemList() {
		return itemList;
	}

	public void setItemList(List<SimpleTagFormBean> itemList) {
		this.itemList = itemList;
	}

	public String getSubjectStfCode() {
		return subjectStfCode;
	}

	public void setSubjectStfCode(String subjectStfCode) {
		this.subjectStfCode = subjectStfCode;
	}

	public String getDispNendo() {
		return dispNendo;
	}

	public void setDispNendo(String dispNendo) {
		this.dispNendo = dispNendo;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	
}
