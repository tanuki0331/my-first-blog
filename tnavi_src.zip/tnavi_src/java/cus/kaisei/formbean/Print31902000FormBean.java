/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.formbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_averageEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_studentEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_subjectEntity;

/**
 * <PRE>
 * ����������ʒʒm�[��� FormBean�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.05.24 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31902000FormBean {

	// -- �萔
	/** �����l */
	public final static String DEFALUT_VALUE = "";
	/** �Ȗ� ���� */
	public final static String NATIONAL_LANGUAGE = "nationalLanguage";
	/** �Ȗ� �Љ� */
	public final static String SOCIETY = "society";
	/** �Ȗ� ���w */
	public final static String MATHEMATICS = "mathematics";
	/** �Ȗ� ���� */
	public final static String SCIENCE = "science";
	/** �Ȗ� ���y */
	public final static String MUSIC = "music";
	/** �Ȗ� ���p */
	public final static String ART = "art";
	/** �Ȗ� �ۑ� */
	public final static String HEALTH_AND_PHYSICAL_EDUCATION = "healthAndPhysicalEducation";
	/** �Ȗ� �Z�� */
	public final static String TECHNOLOGY_HOME_ECONOMICS = "technologyHomeEconomics";
	/** �Ȗ� �p�� */
	public final static String ENGLISH = "english";
	/** �Ȗ� 5�v */
	public final static String TOTAL_FIVE = "total5";
	/** �Ȗ� ���v */
	public final static String TOTAL_ALL = "totalAll";

	/** �l�� */
	public final static String NUM = "num";
	/** �݌v */
	public final static String CUMLATIVE = "cumulative";

	/** �^�C�g�� ���ʒʒm */
	public static final String TITLE_RESULT_NOTIFICATION = "���ʒʒm";


	/** �^�C�g�� �w�N */
	private String titleGlade = DEFALUT_VALUE;

	/** �^�C�g�� �o�͎��� */
	private String titleSemester = DEFALUT_VALUE;

	/** ���k���X�g */
	private List<Data31902000_studentEntity> studentList = new ArrayList<Data31902000_studentEntity>();

	/** �N */
	private String clsGlade;

	/** �g */
	private String hmrClass;

	/** ���{�������Ȗ����W�I�{�^�� �I��l */
	private String implementationWithoutSubjectName;

	/** �l���� �Ȗ� */
	private List<Data31902000_subjectEntity> subjectList = new ArrayList<Data31902000_subjectEntity>();

	/** �l���� ���ϓ_ */
	private List<Data31902000_averageEntity> averageScoreList = new ArrayList<Data31902000_averageEntity>();

	/** ���_���z�\ */
	private Map<String, Map<String, List<Integer>>> scoreDistributionTable = new HashMap<String, Map<String, List<Integer>>>();

	/** ���_���z�p ���k���X�g */
	private List<Data31902000_studentEntity> allStudentList = new ArrayList<Data31902000_studentEntity>();

	/**
	 * CoReports�t�H�[���t�@�C����
	 */
	private String formFileName = DEFALUT_VALUE;


	/**
	 * @return titleGlade
	 */
	public final String getTitleGlade() {
		return titleGlade;
	}

	/**
	 * @param titleGlade �Z�b�g���� titleGlade
	 */
	public final void setTitleGlade(String titleGlade) {
		this.titleGlade = titleGlade;
	}

	/**
	 * @return titleSemester
	 */
	public final String getTitleSemester() {
		return titleSemester;
	}

	/**
	 * @param titleSemester �Z�b�g���� titleSemester
	 */
	public final void setTitleSemester(String titleSemester) {
		this.titleSemester = titleSemester;
	}

	/**
	 * @return studentList
	 */
	public final List<Data31902000_studentEntity> getStudentList() {
		return studentList;
	}

	/**
	 * @param studentList �Z�b�g���� studentList
	 */
	public final void setStudentList(List<Data31902000_studentEntity> studentList) {
		this.studentList = studentList;
	}

	/**
	 * @return clsGlade
	 */
	public final String getClsGlade() {
		return clsGlade;
	}

	/**
	 * @param clsGlade �Z�b�g���� clsGlade
	 */
	public final void setClsGlade(String clsGlade) {
		this.clsGlade = clsGlade;
	}

	/**
	 * @return hmrClass
	 */
	public final String getHmrClass() {
		return hmrClass;
	}

	/**
	 * @param hmrClass �Z�b�g���� hmrClass
	 */
	public final void setHmrClass(String hmrClass) {
		this.hmrClass = hmrClass;
	}

	/**
	 * @return implementationWithoutSubjectName
	 */
	public final String getImplementationWithoutSubjectName() {
		return implementationWithoutSubjectName;
	}

	/**
	 * @param implementationWithoutSubjectName �Z�b�g���� implementationWithoutSubjectName
	 */
	public final void setImplementationWithoutSubjectName(String implementationWithoutSubjectName) {
		this.implementationWithoutSubjectName = implementationWithoutSubjectName;
	}

	/**
	 * @return subjectList
	 */
	public final List<Data31902000_subjectEntity> getSubjectList() {
		return subjectList;
	}

	/**
	 * @param subjectList �Z�b�g���� subjectList
	 */
	public final void setSubjectList(List<Data31902000_subjectEntity> subjectList) {
		this.subjectList = subjectList;
	}

	/**
	 * @return averageScoreList
	 */
	public final List<Data31902000_averageEntity> getAverageScoreList() {
		return averageScoreList;
	}

	/**
	 * @param averageScoreList �Z�b�g���� averageScoreList
	 */
	public final void setAverageScoreList(List<Data31902000_averageEntity> averageScoreList) {
		this.averageScoreList = averageScoreList;
	}

	/**
	 * @return scoreDistributionTable
	 */
	public final Map<String, Map<String, List<Integer>>> getScoreDistributionTable() {
		return scoreDistributionTable;
	}

	/**
	 * @param scoreDistributionTable �Z�b�g���� scoreDistributionTable
	 */
	public final void setScoreDistributionTable(Map<String, Map<String, List<Integer>>> scoreDistributionTable) {
		this.scoreDistributionTable = scoreDistributionTable;
	}

	/**
	 * @return allStudentList
	 */
	public final List<Data31902000_studentEntity> getAllStudentList() {
		return allStudentList;
	}

	/**
	 * @param allStudentList �Z�b�g���� allStudentList
	 */
	public final void setAllStudentList(List<Data31902000_studentEntity> allStudentList) {
		this.allStudentList = allStudentList;
	}

	public String getFormFileName() {
		return formFileName;
	}

	public void setFormFileName(String formFileName) {
		this.formFileName = formFileName;
	}

}
