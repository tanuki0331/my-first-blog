/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.formbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31904000_studentEntity;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ ��� FormBean�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31904000FormBean {
	
	/**
	 * �����l
	 */
	public final static String DEFALUT_VALUE = "";
	/**
	 * ���b�Z�[�W
	 */
	private String message = DEFALUT_VALUE;
	/**
	 * �N�x
	 */
	private String nendo = DEFALUT_VALUE;
	
	/**
	 * �\���p�N�x
	 */
	private String dispNendo = DEFALUT_VALUE;

	/**
	 * �w�N
	 */
	private String grade = DEFALUT_VALUE;

	/**
	 * ����
	 */
	private String item = null;

	/**
	 * �o�͎���
	 */
	private String goptcode = DEFALUT_VALUE;
	
	/**
	 * ���ȒS�������R�[�h
	 */
	private String subjectStfCode = DEFALUT_VALUE;
	
	/**
	 * �I���w�N
	 */
	private String selectedGrade = DEFALUT_VALUE;
	/**
	 * �I��g
	 */
	private String selectedClass = DEFALUT_VALUE;
	/**
	 * �I������
	 */
	private String selectedItem = DEFALUT_VALUE;
	
	/**
	 * ���ȃ��X�g
	 */
	private List<SimpleTagFormBean> itemList = new ArrayList<SimpleTagFormBean>();
	
	/**
	 * �]���������X�g
	 */
	private List<SimpleTagFormBean> termList = new ArrayList<SimpleTagFormBean>();
	
	/**
	 * �]���������X�g2(�]���s�\�҂̐ݒ��ԗp)
	 */
	private List<SimpleTagFormBean> termList2 = new ArrayList<SimpleTagFormBean>();
	
	/**
	 * �Ώۊw�����X�g
	 */
	private List<Data31904000_studentEntity> stuList = new ArrayList<Data31904000_studentEntity>();
	
	/**
	 * �]���s�\�w�����X�g
	 */
	private List<Data31904000_studentEntity> stuAllList = new ArrayList<Data31904000_studentEntity>();
	
	/**
	 * �]���s�\�w�Дԍ��Q�w���R�[�h�}�b�v
	 */
	private Map<String,String> stuTermMap = new HashMap<String,String>();

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getDispNendo() {
		return dispNendo;
	}

	public void setDispNendo(String dispNendo) {
		this.dispNendo = dispNendo;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getGoptcode() {
		return goptcode;
	}

	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}

	public String getSubjectStfCode() {
		return subjectStfCode;
	}

	public void setSubjectStfCode(String subjectStfCode) {
		this.subjectStfCode = subjectStfCode;
	}

	public List<SimpleTagFormBean> getItemList() {
		return itemList;
	}

	public void setItemList(List<SimpleTagFormBean> itemList) {
		this.itemList = itemList;
	}

	public List<SimpleTagFormBean> getTermList() {
		return termList;
	}

	public void setTermList(List<SimpleTagFormBean> termList) {
		this.termList = termList;
	}

	public List<Data31904000_studentEntity> getStuList() {
		return stuList;
	}

	public void setStuList(List<Data31904000_studentEntity> stuList) {
		this.stuList = stuList;
	}

	public List<Data31904000_studentEntity> getStuAllList() {
		return stuAllList;
	}

	public void setStuAllList(List<Data31904000_studentEntity> stuAllList) {
		this.stuAllList = stuAllList;
	}

	public Map<String, String> getStuTermMap() {
		return stuTermMap;
	}

	public void setStuTermMap(Map<String, String> stuTermMap) {
		this.stuTermMap = stuTermMap;
	}

	public String getSelectedGrade() {
		return selectedGrade;
	}

	public void setSelectedGrade(String selectedGrade) {
		this.selectedGrade = selectedGrade;
	}

	public String getSelectedClass() {
		return selectedClass;
	}

	public void setSelectedClass(String selectedClass) {
		this.selectedClass = selectedClass;
	}

	public String getSelectedItem() {
		return selectedItem;
	}

	public void setSelectedItem(String selectedItem) {
		this.selectedItem = selectedItem;
	}

	public List<SimpleTagFormBean> getTermList2() {
		return termList2;
	}

	public void setTermList2(List<SimpleTagFormBean> termList2) {
		this.termList2 = termList2;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getTermListSize() {
		return termList.size();
	}
	public Integer getTermList2Size() {
		return termList2.size();
	}
}
