/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.formbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.kaisei.db.entity.Print31904000Entity;

/**
 * <PRE>
 * ���ȕʊϓ_�ʏW�v�\ ��� FormBean�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.06.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31904000FormBean {

	
	/**
	 * �^�C�g��
	 */
	private String title = "";
	
	/**
	 * ���Ȗ�
	 */
	private String itemName = "";
	
	/**
	 * ���ȒS�C
	 */
	private String staffName = "";
	
	/**
	 * �ϓ_�����X�g
	 */
	private List<Print31904000Entity> viewpointNameList = new ArrayList<Print31904000Entity>();
	
	/**
	 * �g���X�g
	 */
	private List<Print31904000Entity> hroomList = new ArrayList<Print31904000Entity>();
	
	/**
	 * �ϓ_�]���l���X�g
	 */
	private List<Print31904000Entity> viewpointEstimateList = new ArrayList<Print31904000Entity>();
	
	/**
	 * �]��]���l���X�g
	 */
	private List<Print31904000Entity> scorptEvalList = new ArrayList<Print31904000Entity>();

	/**
	 * �ϓ_���ƕ]���l�W�v���X�g���X�g
	 */
	private Map<String,List<List<String>>> viewpointListListMap = new HashMap<String,List<List<String>>>();

	/**
	 * �]��W�v���X�g
	 */
	private List<List<String>> evalListList = new ArrayList<List<String>>();
	
	/**
	 * �]�蕽��
	 */
	private String evalAverage = "";
	
	/**
	 * �g�p���C��
	 */
	private int useLayer;
	/**
	 * �s�g�p���C��
	 */
	private int notUseLayer;


	public List<Print31904000Entity> getViewpointNameList() {
		return viewpointNameList;
	}

	public void setViewpointNameList(List<Print31904000Entity> viewpointNameList) {
		this.viewpointNameList = viewpointNameList;
	}

	public List<Print31904000Entity> getHroomList() {
		return hroomList;
	}

	public void setHroomList(List<Print31904000Entity> hroomList) {
		this.hroomList = hroomList;
	}

	public List<Print31904000Entity> getViewpointEstimateList() {
		return viewpointEstimateList;
	}

	public void setViewpointEstimateList(
			List<Print31904000Entity> viewpointEstimateList) {
		this.viewpointEstimateList = viewpointEstimateList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public List<Print31904000Entity> getScorptEvalList() {
		return scorptEvalList;
	}

	public void setScorptEvalList(List<Print31904000Entity> scorptEvalList) {
		this.scorptEvalList = scorptEvalList;
	}

	public Map<String, List<List<String>>> getViewpointListListMap() {
		return viewpointListListMap;
	}

	public void setViewpointListListMap(
			Map<String, List<List<String>>> viewpointListListMap) {
		this.viewpointListListMap = viewpointListListMap;
	}

	public List<List<String>> getEvalListList() {
		return evalListList;
	}

	public void setEvalListList(List<List<String>> evalListList) {
		this.evalListList = evalListList;
	}

	public String getEvalAverage() {
		return evalAverage;
	}

	public void setEvalAverage(String evalAverage) {
		this.evalAverage = evalAverage;
	}

	public int getUseLayer() {
		return useLayer;
	}

	public void setUseLayer(int useLayer) {
		this.useLayer = useLayer;
	}

	public int getNotUseLayer() {
		return notUseLayer;
	}

	public void setNotUseLayer(int notUseLayer) {
		this.notUseLayer = notUseLayer;
	}
	
}
