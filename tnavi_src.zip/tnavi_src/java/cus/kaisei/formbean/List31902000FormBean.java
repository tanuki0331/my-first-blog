package jp.co.systemd.tnavi.cus.kaisei.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31902000_studentEntity;
/**
 * <PRE>
 * ����������ʒʒm�[���FormBean�N���X.
 * </PRE>
 *
 * <B>Create</B> 2014.01.15 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List31902000FormBean implements CommonConstantsUseable {

	/** �����l */
	public final static String DEFALUT_VALUE = "";

	/** �N�x */
	private String nendo;

	/** ���� */
	private String userCode;

	/** �N */
	private String glade;

	/** �g */
	private String hmrClass;

	/** �z�[�����[���� */
	private String hmrName;

	/** �o�͎������X�g */
	private List<SimpleTagFormBean> semesterList = new ArrayList<SimpleTagFormBean>();

	/** �o�͎������X�g �I��l */
	private String semester;

	/** ���ƕ]���v���� */
	private List<SimpleTagFormBean> lessonEvaluationPlanTypeList = new ArrayList<SimpleTagFormBean>();

	/** ���ƕ]���v���� �I��l(�R�[�h) */
	private String lessonEvaluationPlanType;

	/** ���ƕ]���v���� �I��l(����) */
	private String lessonEvaluationPlanTypeName;

	/** ���{�������Ȗ����W�I�{�^���p���X�g */
	private List<SimpleTagFormBean> implementationWithoutSubjectNameList = new ArrayList<SimpleTagFormBean>();

	/** ���{�������Ȗ����W�I�{�^�� �I��l */
	private String implementationWithoutSubjectName;

	/** ���k���X�g */
	private List<Data31902000_studentEntity> studentList = new ArrayList<Data31902000_studentEntity>();

	/**
	 * CoReports���C�A�E�g
	 */
	private String crlayout = DEFALUT_VALUE;

	/**
	 * @return nendo
	 */
	public final String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo �Z�b�g���� nendo
	 */
	public final void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return userCode
	 */
	public final String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode �Z�b�g���� userCode
	 */
	public final void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	/**
	 * @return studentList
	 */
	public final List<Data31902000_studentEntity> getStudentList() {
		return studentList;
	}

	/**
	 * @param studentList �Z�b�g���� studentList
	 */
	public final void setStudentList(List<Data31902000_studentEntity> studentList) {
		this.studentList = studentList;
	}

	/**
	 * @return hmrClass
	 */
	public final String getHmrClass() {
		return hmrClass;
	}

	/**
	 * @param hmrClass �Z�b�g���� hmrClass
	 */
	public final void setHmrClass(String hmrClass) {
		this.hmrClass = hmrClass;
	}

	/**
	 * @return hmrName
	 */
	public final String getHmrName() {
		return hmrName;
	}

	/**
	 * @param hmrName �Z�b�g���� hmrName
	 */
	public final void setHmrName(String hmrName) {
		this.hmrName = hmrName;
	}

	/**
	 * @return glade
	 */
	public final String getGlade() {
		return glade;
	}

	/**
	 * @param glade �Z�b�g���� glade
	 */
	public final void setGlade(String glade) {
		this.glade = glade;
	}

	/**
	 * @return semesterList
	 */
	public final List<SimpleTagFormBean> getSemesterList() {
		return semesterList;
	}

	/**
	 * @param semesterList �Z�b�g���� semesterList
	 */
	public final void setSemesterList(List<SimpleTagFormBean> semesterList) {
		this.semesterList = semesterList;
	}

	/**
	 * @return lessonEvaluationPlanTypeList
	 */
	public final List<SimpleTagFormBean> getLessonEvaluationPlanTypeList() {
		return lessonEvaluationPlanTypeList;
	}

	/**
	 * @param lessonEvaluationPlanTypeList �Z�b�g���� lessonEvaluationPlanTypeList
	 */
	public final void setLessonEvaluationPlanTypeList(List<SimpleTagFormBean> lessonEvaluationPlanTypeList) {
		this.lessonEvaluationPlanTypeList = lessonEvaluationPlanTypeList;
	}

	/**
	 * @return implementationWithoutSubjectNameList
	 */
	public final List<SimpleTagFormBean> getImplementationWithoutSubjectNameList() {
		return implementationWithoutSubjectNameList;
	}

	/**
	 * @param implementationWithoutSubjectNameList �Z�b�g���� implementationWithoutSubjectNameList
	 */
	public final void setImplementationWithoutSubjectNameList(
			List<SimpleTagFormBean> implementationWithoutSubjectNameList) {
		this.implementationWithoutSubjectNameList = implementationWithoutSubjectNameList;
	}

	/**
	 * @return semester
	 */
	public final String getSemester() {
		return semester;
	}

	/**
	 * @param semester �Z�b�g���� semester
	 */
	public final void setSemester(String semester) {
		this.semester = semester;
	}

	/**
	 * @return lessonEvaluationPlanType
	 */
	public final String getLessonEvaluationPlanType() {
		return lessonEvaluationPlanType;
	}

	/**
	 * @param lessonEvaluationPlanType �Z�b�g���� lessonEvaluationPlanType
	 */
	public final void setLessonEvaluationPlanType(String lessonEvaluationPlanType) {
		this.lessonEvaluationPlanType = lessonEvaluationPlanType;
	}

	/**
	 * @return lessonEvaluationPlanTypeName
	 */
	public final String getLessonEvaluationPlanTypeName() {
		return lessonEvaluationPlanTypeName;
	}

	/**
	 * @param lessonEvaluationPlanTypeName �Z�b�g���� lessonEvaluationPlanTypeName
	 */
	public final void setLessonEvaluationPlanTypeName(String lessonEvaluationPlanTypeName) {
		this.lessonEvaluationPlanTypeName = lessonEvaluationPlanTypeName;
	}

	/**
	 * @return implementationWithoutSubjectName
	 */
	public final String getImplementationWithoutSubjectName() {
		return implementationWithoutSubjectName;
	}

	/**
	 * @param implementationWithoutSubjectName �Z�b�g���� implementationWithoutSubjectName
	 */
	public final void setImplementationWithoutSubjectName(String implementationWithoutSubjectName) {
		this.implementationWithoutSubjectName = implementationWithoutSubjectName;
	}

	public String getCrlayout() {
		return crlayout;
	}

	public void setCrlayout(String crlayout) {
		this.crlayout = crlayout;
	}


}