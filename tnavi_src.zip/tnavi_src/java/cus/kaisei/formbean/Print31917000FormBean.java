/**------------------------------------------------------------**
 * Te@cherNavi
 * Copyright(C) 2016 System D, Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.kaisei.formbean;

import java.util.List;

import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31917000_evalEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31917000_scoreEntity;
import jp.co.systemd.tnavi.cus.kaisei.db.entity.Data31917000_studentEntity;

/**
 * <PRE>
 * �ϓ_�ʌ��ʈꗗ ��� FormBean�N���X.
 * </PRE>
 *
 * <B>Create</B> 2016.07.06 BY aivick<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31917000FormBean {
	/** �o�͑Ώ� */
	private String outputTarget;

	/** ���k��� */
	private List<Data31917000_studentEntity> studentList;

	/** �ϓ_�ʌ��� �]�� */
	private List<Data31917000_scoreEntity> scoreList;

	/** �ϓ_�ʌ��� �]�� */
	private List<Data31917000_evalEntity> evalList;

	/**
	 * outputTarget ���擾����B
	 * @return outputTarget
	 */
	public final String getOutputTarget() {
		return outputTarget;
	}

	/**
	 * outputTarget ��ݒ肷��B
	 * @param outputTarget �Z�b�g���� outputTarget
	 */
	public final void setOutputTarget(String outputTarget) {
		this.outputTarget = outputTarget;
	}

	/**
	 * studentList ���擾����B
	 * @return studentList
	 */
	public final List<Data31917000_studentEntity> getStudentList() {
		return studentList;
	}

	/**
	 * studentList ��ݒ肷��B
	 * @param studentList �Z�b�g���� studentList
	 */
	public final void setStudentList(List<Data31917000_studentEntity> studentList) {
		this.studentList = studentList;
	}

	/**
	 * scoreList ���擾����B
	 * @return scoreList
	 */
	public final List<Data31917000_scoreEntity> getScoreList() {
		return scoreList;
	}

	/**
	 * scoreList ��ݒ肷��B
	 * @param scoreList �Z�b�g���� scoreList
	 */
	public final void setScoreList(List<Data31917000_scoreEntity> scoreList) {
		this.scoreList = scoreList;
	}

	/**
	 * evalList ���擾����B
	 * @return evalList
	 */
	public final List<Data31917000_evalEntity> getEvalList() {
		return evalList;
	}

	/**
	 * evalList ��ݒ肷��B
	 * @param evalList �Z�b�g���� evalList
	 */
	public final void setEvalList(List<Data31917000_evalEntity> evalList) {
		this.evalList = evalList;
	}

}
