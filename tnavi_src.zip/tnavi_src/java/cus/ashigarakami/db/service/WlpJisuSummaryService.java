/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarakami.db.service;


import java.math.BigDecimal;
import java.util.List;

import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.tim.db.entity.WlpJisuSumEntity;

/**
 * <PRE>
 * �T�ĕ�V2 �T�ꗗ �����W�v���擾 Service�N���X ������S�p.
 * <PRE>
 *
 * <B>Create</B> 2019.01.06 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class WlpJisuSummaryService extends jp.co.systemd.tnavi.tim.db.service.WlpJisuSummaryService {

	/** SQL **/
	private static final String SEL_JISUSUM_EXEC_SQL = "cus/ashigarakami/getWlpJisuSum.sql";

	/**
	 * �W�v���̎擾�Ǝ����Z�o���s��
	 * @param unitPer1Jisu
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void createSummary(BigDecimal unitPer1Jisu) {
		// --- �����W�v���擾
		Object[] param;
		QueryManager qm;

//		param = new Object[]
//				{
//						kijunWeekStartDate, kijunWeekStartDate, kijunWeekStartDate,
//						unitkind, clsno, user, nendo,
//						unitkind, stfcode, user, nendo,
//						unitkind, clsno,
//						user, nendo, kijunWeekStartDate
//				};
		param = new Object[] { user, nendo, kijunWeekStartDate, unitkind, clsno, stfcode };

		qm = new QueryManager(SEL_JISUSUM_EXEC_SQL, param, WlpJisuSumEntity.class);
		List<WlpJisuSumEntity> jisuSumEntList = (List<WlpJisuSumEntity>) this.executeQuery(qm);

		// --- �擾��������bean�֊i�[����
		calcAndEditJisuBean(jisuSumEntList, unitPer1Jisu);
	}

}