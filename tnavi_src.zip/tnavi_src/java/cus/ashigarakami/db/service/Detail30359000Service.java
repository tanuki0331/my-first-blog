/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarakami.db.service;

import java.util.List;

import jp.co.systemd.tnavi.tim.formbean.WlpJisuSumFormBean;

/**
 * <PRE>
 * �T�ĕ����(V2) �T�\��Service ������S�p.
 * </PRE>
 *
 * <B>Create</B> 2018.01.06 BY hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Detail30359000Service extends jp.co.systemd.tnavi.tim.db.service.Detail30359000Service {

	/**
	 * �����W�v�����擾
	 * @param user
	 * @param nendo
	 * @param weekStartDate
	 * @param dispUnitKind
	 * @param dispPlanKind
	 * @param clsno
	 * @param stfcode
	 * @param calcMode
	 * @return �����W�v���BeanList
	 */
	@Override
	protected List<WlpJisuSumFormBean> executeWlpSumService(String user, String nendo, String weekStartDate,
			String dispUnitKind, String dispPlanKind, String clsno, String stfcode, String calcMode) {

		WlpJisuSummaryService wlpSumService = new WlpJisuSummaryService();
		wlpSumService.setParameter(user, nendo, weekStartDate, dispUnitKind, dispPlanKind, clsno, stfcode);
		wlpSumService.setCalcMode(calcMode); // �[���������[�h
		wlpSumService.execute();

		// �Z�o���ꂽ�����W�v����Ԃ�
		return wlpSumService.getJisuSumBeanList();
	}

}
