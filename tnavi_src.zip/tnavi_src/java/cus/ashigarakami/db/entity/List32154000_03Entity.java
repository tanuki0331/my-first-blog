/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD, inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarakami.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * �s���̂̋L�^(�ʒm�\)(������S���w�Z�O��������) (�]���]����)Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.10.14 BY SD fukuda<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD, Inc.
 * @since 1.0.
 */
public class List32154000_03Entity implements CommonConstantsUseable{

	/** �N���X�ԍ�*/
	private String cls_clsno;
	/** �o�Ȕԍ�*/
	private String cls_number;
	/** �w�Дԍ�*/
	private String cls_stucode;
	/** �v�^�p�ϓ_�R�[�h*/
	private String gavt_gavtcode;
	/** �v�^�p�ϓ_���я�*/
	private String gavt_order;
	/** �v�^�p�ϓ_�o�͏�*/
	private String gopt_goptcode;
	/** �v�^�p�ϓ_���я�*/
	private String gopt_order;
	/** �o�͎���*/
	private String ravt_term;
	/** �ʒm�\�p�ϓ_�R�[�h*/
	private String ravt_ravtcode;
	/** �ʒm�\�p�ϓ_���я�*/
	private String ravt_order;
	/** �\�p�ϓ_�]���l�R�[�h*/
	private String ravv_ravtcode;
	/** �]���l�R�[�h*/
	private String ravv_racecode;
	/** �]���l�\���p�l*/
	private String race_display;
	/** �v�^�p�ϓ_�Ɍ��ѕt���ʒm�\�p�ϓ_���������邩(rowspan�p)*/
	private String ravtgavtCount;
	/**�v�^�p�ϓ_�R�[�h*/
	private String gavv_gavtcode;
	/**�v�^�p�]���l�R�[�h*/
	private String gavv_gacecode;
	/**�v�^�p�\���l*/
	private String gace_display;
	/**�v�^�p�O�N�x�\���l*/
	private String before_gace_display;
	/**
	 * @param cls_clsno �Z�b�g���� cls_clsno
	 */
	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}
	/**
	 * @return cls_clsno
	 */
	public String getCls_clsno() {
		return cls_clsno;
	}
	/**
	 * @param cls_number �Z�b�g���� cls_number
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	/**
	 * @return cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}
	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}
	/**
	 * @param gavt_gavtcode �Z�b�g���� gavt_gavtcode
	 */
	public void setGavt_gavtcode(String gavt_gavtcode) {
		this.gavt_gavtcode = gavt_gavtcode;
	}
	/**
	 * @return gavt_gavtcode
	 */
	public String getGavt_gavtcode() {
		return gavt_gavtcode;
	}
	/**
	 * @param gavt_order �Z�b�g���� gavt_order
	 */
	public void setGavt_order(String gavt_order) {
		this.gavt_order = gavt_order;
	}
	/**
	 * @return gavt_order
	 */
	public String getGavt_order() {
		return gavt_order;
	}
	/**
	 * @param gopt_goptcode �Z�b�g���� gopt_goptcode
	 */
	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}
	/**
	 * @return gopt_goptcode
	 */
	public String getGopt_goptcode() {
		return gopt_goptcode;
	}
	/**
	 * @param gopt_order �Z�b�g���� gopt_order
	 */
	public void setGopt_order(String gopt_order) {
		this.gopt_order = gopt_order;
	}
	/**
	 * @return gopt_order
	 */
	public String getGopt_order() {
		return gopt_order;
	}
	/**
	 * @param ravt_term �Z�b�g���� ravt_term
	 */
	public void setRavt_term(String ravt_term) {
		this.ravt_term = ravt_term;
	}
	/**
	 * @return ravt_term
	 */
	public String getRavt_term() {
		return ravt_term;
	}
	/**
	 * @param ravt_ravtcode �Z�b�g���� ravt_ravtcode
	 */
	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}
	/**
	 * @return ravt_ravtcode
	 */
	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}
	/**
	 * @param ravt_order �Z�b�g���� ravt_order
	 */
	public void setRavt_order(String ravt_order) {
		this.ravt_order = ravt_order;
	}
	/**
	 * @return ravt_order
	 */
	public String getRavt_order() {
		return ravt_order;
	}
	/**
	 * @param ravv_ravtcode �Z�b�g���� ravv_ravtcode
	 */
	public void setRavv_ravtcode(String ravv_ravtcode) {
		this.ravv_ravtcode = ravv_ravtcode;
	}
	/**
	 * @return ravv_ravtcode
	 */
	public String getRavv_ravtcode() {
		return ravv_ravtcode;
	}
	/**
	 * @param ravv_racecode �Z�b�g���� ravv_racecode
	 */
	public void setRavv_racecode(String ravv_racecode) {
		this.ravv_racecode = ravv_racecode;
	}
	/**
	 * @return ravv_racecode
	 */
	public String getRavv_racecode() {
		return ravv_racecode;
	}
	/**
	 * @param race_display �Z�b�g���� race_display
	 */
	public void setRace_display(String race_display) {
		this.race_display = race_display;
	}
	/**
	 * @return race_display
	 */
	public String getRace_display() {
		return race_display;
	}
	/**
	 * @param ravtgavtCount �Z�b�g���� ravtgavtCount
	 */
	public void setRavtgavtCount(String ravtgavtCount) {
		this.ravtgavtCount = ravtgavtCount;
	}
	/**
	 * @return ravtgavtCount
	 */
	public String getRavtgavtCount() {
		return ravtgavtCount;
	}
	/**
	 * @param gavv_gavtcode �Z�b�g���� gavv_gavtcode
	 */
	public void setGavv_gavtcode(String gavv_gavtcode) {
		this.gavv_gavtcode = gavv_gavtcode;
	}
	/**
	 * @return gavv_gavtcode
	 */
	public String getGavv_gavtcode() {
		return gavv_gavtcode;
	}
	/**
	 * @param gavv_gacecode �Z�b�g���� gavv_gacecode
	 */
	public void setGavv_gacecode(String gavv_gacecode) {
		this.gavv_gacecode = gavv_gacecode;
	}
	/**
	 * @return gavv_gacecode
	 */
	public String getGavv_gacecode() {
		return gavv_gacecode;
	}
	/**
	 * @param gace_display �Z�b�g���� gace_display
	 */
	public void setGace_display(String gace_display) {
		this.gace_display = gace_display;
	}
	/**
	 * @return gace_display
	 */
	public String getGace_display() {
		return gace_display;
	}
	/**
	 * @param before_gace_display �Z�b�g���� before_gace_display
	 */
	public void setBefore_gace_display(String before_gace_display) {
		this.before_gace_display = before_gace_display;
	}
	/**
	 * @return before_gace_display
	 */
	public String getBefore_gace_display() {
		return before_gace_display;
	}
}
