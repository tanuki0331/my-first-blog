/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD, inc. All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarakami.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * ���ʊ����̋L�^(������S���w�Z�O��������) (�]�����)Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.10.13 BY SD fukuda<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD, Inc.
 * @since 1.0.
 */
public class List32153000_03Entity implements CommonConstantsUseable{

	/** �N���X�ԍ�*/
	private String cls_clsno;
	/** �o�Ȕԍ�*/
	private String cls_number;
	/** �w�Дԍ�*/
	private String cls_stucode;
	/** �w���v�̃R�[�h*/
	private String gst_curcode;
	/** �v�^�p ���e�R�[�h*/
	private String gsat_gsatcode;
	/** �v�^�p�@���e��*/
	private String gsat_gsatname;
	/** �v�^�p�@���e����*/
	private String gsat_gsatname2;
	/** �v�^�p�@�\����*/
	private String gsat_order;
	/** �o�͎����R�[�h*/
	private String gopt_goptcode;
	/** �o�͎�����*/
	private String gopt_name;
	/** �o�͎����\����*/
	private String gopt_order;
	/** �ʒm�\�p�@���e�R�[�h*/
	private String rsat_rsatcode;
	/** �ʒm�\�p ���e��*/
	private String rsat_rsatname;
	/** �ʒm�\�p�@���e����*/
	private String rsat_rsatname2;
	/** �ʒm�\�p�@��|�E�߂���*/
	private String rsat_pointview;
	/** �ʒm�\�p�@�\����*/
	private String rsat_order;
	/** �ʒm�\�p�@�]��*/
	private String rsav_rsaecode;
	/** �ʒm�\�p�@���R�[�h*/
	private String rsav_record;
	/** �ʒm�\�p�@�]���̕\���l*/
	private String rsae_display;
	/** �v�^�p�@�]��*/
	private String gsav_gsaecode;
	/** �v�^�p�@�]���̕\���l*/
	private String gsae_display;
	/** �v�^�̊ϓ_���Ƃ̒ʒm�\�p�ϓ_��*/
	private String gsat_rsat_Count;
	/** �O�N�x�v�^�f�[�^*/
	private String before_gsav_gsaecode;
	/**�O�N�x�v�^ �\���l*/
	private String before_gsae_display;
	/**
	 * @param cls_clsno �Z�b�g���� cls_clsno
	 */
	public void setCls_clsno(String cls_clsno) {
		this.cls_clsno = cls_clsno;
	}
	/**
	 * @return cls_clsno
	 */
	public String getCls_clsno() {
		return cls_clsno;
	}
	/**
	 * @param cls_number �Z�b�g���� cls_number
	 */
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	/**
	 * @return cls_number
	 */
	public String getCls_number() {
		return cls_number;
	}
	/**
	 * @param cls_stucode �Z�b�g���� cls_stucode
	 */
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	/**
	 * @return cls_stucode
	 */
	public String getCls_stucode() {
		return cls_stucode;
	}
	/**
	 * @param gst_curcode �Z�b�g���� gst_curcode
	 */
	public void setGst_curcode(String gst_curcode) {
		this.gst_curcode = gst_curcode;
	}
	/**
	 * @return gst_curcode
	 */
	public String getGst_curcode() {
		return gst_curcode;
	}
	/**
	 * @param gsat_gsatcode �Z�b�g���� gsat_gsatcode
	 */
	public void setGsat_gsatcode(String gsat_gsatcode) {
		this.gsat_gsatcode = gsat_gsatcode;
	}
	/**
	 * @return gsat_gsatcode
	 */
	public String getGsat_gsatcode() {
		return gsat_gsatcode;
	}
	/**
	 * @param gsat_gsatname �Z�b�g���� gsat_gsatname
	 */
	public void setGsat_gsatname(String gsat_gsatname) {
		this.gsat_gsatname = gsat_gsatname;
	}
	/**
	 * @return gsat_gsatname
	 */
	public String getGsat_gsatname() {
		return gsat_gsatname;
	}
	/**
	 * @param gsat_gsatname2 �Z�b�g���� gsat_gsatname2
	 */
	public void setGsat_gsatname2(String gsat_gsatname2) {
		this.gsat_gsatname2 = gsat_gsatname2;
	}
	/**
	 * @return gsat_gsatname2
	 */
	public String getGsat_gsatname2() {
		return gsat_gsatname2;
	}
	/**
	 * @param gsat_order �Z�b�g���� gsat_order
	 */
	public void setGsat_order(String gsat_order) {
		this.gsat_order = gsat_order;
	}
	/**
	 * @return gsat_order
	 */
	public String getGsat_order() {
		return gsat_order;
	}
	/**
	 * @param gopt_goptcode �Z�b�g���� gopt_goptcode
	 */
	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}
	/**
	 * @return gopt_goptcode
	 */
	public String getGopt_goptcode() {
		return gopt_goptcode;
	}
	/**
	 * @param gopt_name �Z�b�g���� gopt_name
	 */
	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}
	/**
	 * @return gopt_name
	 */
	public String getGopt_name() {
		return gopt_name;
	}
	/**
	 * @param gopt_order �Z�b�g���� gopt_order
	 */
	public void setGopt_order(String gopt_order) {
		this.gopt_order = gopt_order;
	}
	/**
	 * @return gopt_order
	 */
	public String getGopt_order() {
		return gopt_order;
	}
	/**
	 * @param rsat_rsatcode �Z�b�g���� rsat_rsatcode
	 */
	public void setRsat_rsatcode(String rsat_rsatcode) {
		this.rsat_rsatcode = rsat_rsatcode;
	}
	/**
	 * @return rsat_rsatcode
	 */
	public String getRsat_rsatcode() {
		return rsat_rsatcode;
	}
	/**
	 * @param rsat_rsatname �Z�b�g���� rsat_rsatname
	 */
	public void setRsat_rsatname(String rsat_rsatname) {
		this.rsat_rsatname = rsat_rsatname;
	}
	/**
	 * @return rsat_rsatname
	 */
	public String getRsat_rsatname() {
		return rsat_rsatname;
	}
	/**
	 * @param rsat_rsatname2 �Z�b�g���� rsat_rsatname2
	 */
	public void setRsat_rsatname2(String rsat_rsatname2) {
		this.rsat_rsatname2 = rsat_rsatname2;
	}
	/**
	 * @return rsat_rsatname2
	 */
	public String getRsat_rsatname2() {
		return rsat_rsatname2;
	}
	/**
	 * @param rsat_pointview �Z�b�g���� rsat_pointview
	 */
	public void setRsat_pointview(String rsat_pointview) {
		this.rsat_pointview = rsat_pointview;
	}
	/**
	 * @return rsat_pointview
	 */
	public String getRsat_pointview() {
		return rsat_pointview;
	}
	/**
	 * @param rsat_order �Z�b�g���� rsat_order
	 */
	public void setRsat_order(String rsat_order) {
		this.rsat_order = rsat_order;
	}
	/**
	 * @return rsat_order
	 */
	public String getRsat_order() {
		return rsat_order;
	}
	/**
	 * @param rsav_rsaecode �Z�b�g���� rsav_rsaecode
	 */
	public void setRsav_rsaecode(String rsav_rsaecode) {
		this.rsav_rsaecode = rsav_rsaecode;
	}
	/**
	 * @return rsav_rsaecode
	 */
	public String getRsav_rsaecode() {
		return rsav_rsaecode;
	}
	/**
	 * @param rsav_record �Z�b�g���� rsav_record
	 */
	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}
	/**
	 * @return rsav_record
	 */
	public String getRsav_record() {
		return rsav_record;
	}
	/**
	 * @param rsae_display �Z�b�g���� rsae_display
	 */
	public void setRsae_display(String rsae_display) {
		this.rsae_display = rsae_display;
	}
	/**
	 * @return rsae_display
	 */
	public String getRsae_display() {
		return rsae_display;
	}
	/**
	 * @param gsav_gsaecode �Z�b�g���� gsav_gsaecode
	 */
	public void setGsav_gsaecode(String gsav_gsaecode) {
		this.gsav_gsaecode = gsav_gsaecode;
	}
	/**
	 * @return gsav_gsaecode
	 */
	public String getGsav_gsaecode() {
		return gsav_gsaecode;
	}
	/**
	 * @param gsae_display �Z�b�g���� gsae_display
	 */
	public void setGsae_display(String gsae_display) {
		this.gsae_display = gsae_display;
	}
	/**
	 * @return gsae_display
	 */
	public String getGsae_display() {
		return gsae_display;
	}
	/**
	 * @param gsat_rsat_Count �Z�b�g���� gsat_rsat_Count
	 */
	public void setGsat_rsat_Count(String gsat_rsat_Count) {
		this.gsat_rsat_Count = gsat_rsat_Count;
	}
	/**
	 * @return gsat_rsat_Count
	 */
	public String getGsat_rsat_Count() {
		return gsat_rsat_Count;
	}
	/**
	 * @param before_gsav_gsaecode �Z�b�g���� before_gsav_gsaecode
	 */
	public void setBefore_gsav_gsaecode(String before_gsav_gsaecode) {
		this.before_gsav_gsaecode = before_gsav_gsaecode;
	}
	/**
	 * @return before_gsav_gsaecode
	 */
	public String getBefore_gsav_gsaecode() {
		return before_gsav_gsaecode;
	}
	/**
	 * @param before_gsae_display �Z�b�g���� before_gsae_display
	 */
	public void setBefore_gsae_display(String before_gsae_display) {
		this.before_gsae_display = before_gsae_display;
	}
	/**
	 * @return before_gsae_display
	 */
	public String getBefore_gsae_display() {
		return before_gsae_display;
	}

}
