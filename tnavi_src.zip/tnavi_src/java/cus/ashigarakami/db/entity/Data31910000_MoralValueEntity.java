package jp.co.systemd.tnavi.cus.ashigarakami.db.entity;

/**
 * <PRE>
 * �]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.01.26 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31910000_MoralValueEntity {
	/** �����R�[�h */
	private String rmrl_user;

	/** �N�x */
	private String rmrl_year;

	/** �w�� */
	private String rmrl_term;

	/** �w�N */
	private String rmrl_grade;

	/** �w�ЃR�[�h */
	private String rmrl_stucode;

	/** �]�� */
	private String rmrl_value;

	public String getRmrl_user() {
		return rmrl_user;
	}

	public void setRmrl_user(String rmrl_user) {
		this.rmrl_user = rmrl_user;
	}

	public String getRmrl_year() {
		return rmrl_year;
	}

	public void setRmrl_year(String rmrl_year) {
		this.rmrl_year = rmrl_year;
	}

	public String getRmrl_term() {
		return rmrl_term;
	}

	public void setRmrl_term(String rmrl_term) {
		this.rmrl_term = rmrl_term;
	}

	public String getRmrl_grade() {
		return rmrl_grade;
	}

	public void setRmrl_grade(String rmrl_grade) {
		this.rmrl_grade = rmrl_grade;
	}

	public String getRmrl_stucode() {
		return rmrl_stucode;
	}

	public void setRmrl_stucode(String rmrl_stucode) {
		this.rmrl_stucode = rmrl_stucode;
	}

	public String getRmrl_value() {
		return rmrl_value;
	}

	public void setRmrl_value(String rmrl_value) {
		this.rmrl_value = rmrl_value;
	}


}
