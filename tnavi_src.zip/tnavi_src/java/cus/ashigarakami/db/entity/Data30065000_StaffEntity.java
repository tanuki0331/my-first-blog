package jp.co.systemd.tnavi.cus.ashigarakami.db.entity;

/**
 * <PRE>
* ���E�������������(������S)Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.10.11 fukuda<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data30065000_StaffEntity {

	public final static String DEFALUT_VALUE = "";

	/** �A�C�� */
	private String stf_start = DEFALUT_VALUE;

	/** �ޔC�� */
	private String stf_end = DEFALUT_VALUE;

	/** �ޔC��(�o�^�l ��̏ꍇ�͂��̂܂ܒl�Ŏ擾)*/
	private String stfh_end_registered_value = DEFALUT_VALUE;

	/** ���E���R�[�h */
	private String stf_stfcode = DEFALUT_VALUE;

	/** ���E������(�ː�) */
	private String stf_name = DEFALUT_VALUE;

	/** ���E������(�ʏ�) */
	private String stf_name_w = DEFALUT_VALUE;

	/** ��e�o�C�i��*/
    private byte[] stp_stampfile;

    /** ���ʎx���w���t���O*/
    private String hmr_spsupport_flg;

    /** stfh_kind���̏o�͒S�C��*/
    private Integer stfhcnt = 0;

	/**
	 * @return stf_start
	 */
	public String getStf_start() {
		return stf_start;
	}

	/**
	 * @param stf_start the stf_start to set
	 */
	public void setStf_start(String stf_start) {
		this.stf_start = stf_start;
	}

	/**
	 * @return stf_end
	 */
	public String getStf_end() {
		return stf_end;
	}

	/**
	 * @param stf_end the stf_end to set
	 */
	public void setStf_end(String stf_end) {
		this.stf_end = stf_end;
	}

	/**
	 * @return stfh_end_registered_value
	 */
	public String getStfh_end_registered_value() {
		return stfh_end_registered_value;
	}

	/**
	 * @param stfh_end_registered_value �Z�b�g���� stfh_end_registered_value
	 */
	public void setStfh_end_registered_value(String stfh_end_registered_value) {
		this.stfh_end_registered_value = stfh_end_registered_value;
	}

	/**
	 * @return stf_stfcode
	 */
	public String getStf_stfcode() {
		return stf_stfcode;
	}

	/**
	 * @param stf_stfcode the stf_stfcode to set
	 */
	public void setStf_stfcode(String stf_stfcode) {
		this.stf_stfcode = stf_stfcode;
	}

	/**
	 * @return stf_name
	 */
	public String getStf_name() {
		return stf_name;
	}

	/**
	 * @param stf_name the stf_name to set
	 */
	public void setStf_name(String stf_name) {
		this.stf_name = stf_name;
	}

	public String getStf_name_w() {
		return stf_name_w;
	}

	public void setStf_name_w(String stf_name_w) {
		this.stf_name_w = stf_name_w;
	}

	/**
	 * @return stp_stampfile
	 */
	public byte[] getStp_stampfile() {
		return stp_stampfile;
	}

	/**
	 * @param stp_stampfile the stp_stampfile to set
	 */
	public void setStp_stampfile(byte[] stp_stampfile) {
		this.stp_stampfile = stp_stampfile;
	}

	public String getHmr_spsupport_flg() {
		return hmr_spsupport_flg;
	}

	public void setHmr_spsupport_flg(String hmr_spsupport_flg) {
		this.hmr_spsupport_flg = hmr_spsupport_flg;
	}

	public Integer getStfhcnt() {
		return stfhcnt;
	}

	public void setStfhcnt(Integer stfhcnt) {
		this.stfhcnt = stfhcnt;
	}


}
