/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarakami.action;

import javax.servlet.http.HttpServletRequest;

import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ashigarakami.db.service.Print30359000Service;
import jp.co.systemd.tnavi.tim.formbean.Print30359000FormBean;

/**
 * �T�ĕ�V2 Excel�o�� Action  ������S�p
 *
 * <B>Create</B> 2019.01.06 BY hirata<BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print30359000Action extends jp.co.systemd.tnavi.tim.action.Print30359000Action {

	/**
	 * ���[�o�͏��̎擾
	 * @param request
	 * @param sessionBean
	 * @return ���[�o�͏��i�[Bean
	 */
	@Override
	protected Print30359000FormBean executeService(HttpServletRequest request, SystemInfoBean sessionBean) {
		Print30359000Service service = new Print30359000Service();
		service.execute(request, sessionBean);
		return service.getPrintFormBean();
	}

}
