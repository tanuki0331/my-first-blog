/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD inc,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.ashigarakami.action;

import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ashigarakami.db.service.Detail30359000Service;
import jp.co.systemd.tnavi.tim.formbean.Detail30359000FormBean;

/**
 * <PRE>
 * �T�ĕ�V2 �T�ꗗ ���W���[���ړ��E���ʁE�폜 �X�VAction ������S�p.
 * </PRE>
 *
 * <B>Create</B> 2019.01.06 BY hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Regist30359001Action extends jp.co.systemd.tnavi.tim.action.Regist30359001Action {

	/**
	 * �T�[�r�X�N���X�̎��s��Bean�̎擾
	 * @param sessionBean
	 * @param detailFormBean
	 * @return Service���s���ʏ��i�[Bean
	 */
	@Override
	protected Detail30359000FormBean executeService(SystemInfoBean sessionBean, Detail30359000FormBean detailFormBean) {

		Detail30359000Service detail30359000Service = new Detail30359000Service();
		// Service�ɃZ�b�g
		detail30359000Service.setDetail30359000FormBean(detailFormBean);
		detail30359000Service.setLoginStaffId(sessionBean.getStaffId());

		// Service�̏������s
		detail30359000Service.execute(sessionBean);

		return detail30359000Service.getDetail30359000FormBean();
	}

}
