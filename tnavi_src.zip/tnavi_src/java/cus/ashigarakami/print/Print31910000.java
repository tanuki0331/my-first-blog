package jp.co.systemd.tnavi.cus.ashigarakami.print;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.CrLayer;
import jp.co.hos.coreports.CrLayers;
import jp.co.hos.coreports.object.CrImageField;
import jp.co.hos.coreports.object.CrListField;
import jp.co.hos.coreports.object.CrText;
import jp.co.systemd.tnavi.common.exception.TnaviPrintException;
import jp.co.systemd.tnavi.common.print.AbstractPdfManagerAdditionPagesCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.cus.ashigarakami.constants.AshigarakamiConstantsUseable;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_AttendEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_EffortMercenaryEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_EvalEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_ForeignLanguageEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_IntegratedStudyEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_MoralValueEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_SchoolLifeEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_ScoreEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.db.entity.Data31910000_SpecialAppearanceEntity;
import jp.co.systemd.tnavi.cus.ashigarakami.formbean.Data31910000FormBean;
import jp.co.systemd.tnavi.cus.ashigarakami.formbean.Print31910000FormBean;

/**
 * ���ђʒm�[���(������S_���w�Z) �o�̓N���X.
 *
 * <B>Create</B> 2016.06.17 BY AIVICK <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31910000 extends AbstractPdfManagerAdditionPagesCR {

	/**log4j*/
	private final Log log = LogFactory.getLog(Print31910000.class);

	/** ���C�A�E�g�I�u�W�F�N�g */
	private static final String LAYER_COVER = "layer_hyoushi";			// �\������
	private static final String LAYER_COMLETE = "layer_complete";		// �\���C����

	/** �o�̓I�u�W�F�N�g */
	// �\��
	private static final String ITEM_ATTENDANCE_ABSENT = "attendanceAbsent";	// �o���Ȃ̏�
	private static final String ITEM_STU_NAME1 = "stu_name1";					// ����
	private static final String ITEM_GRADE1 = "grade1";							// �C���؂̊w�N
	private static final String ITEM_COMPLETION_DATE = "completionDate";		// �C���N����
	private static final String ITEM_GRA_MASTER_TITLE1 = "gra_master_title1";	// �w�Z���^�C�g��
	private static final String ITEM_GRA_MASTER_NAME1 = "gra_master_name1";		// �w�Z����
	private static final String ITEM_NENDO = "nendo";							// �N�x
	private static final String ITEM_STU_NUMBER = "stu_number";					// �o�Ȕԍ�
	private static final String ITEM_IMAGE_FIELD1 = "ImageField1";				// �u����݁v�w�Z��̓e�[�u���ɓo�^����Ă���C���[�W
	private static final String ITEM_GRADE2 = "grade2";							// �w�N
	private static final String ITEM_CLASS = "class";							// �g
	private static final String ITEM_STU_NAME = "stu_name";						// ��������
	private static final String ITEM_TEACHER = "teacher";						// �Z�������A�S�C����
	private static final String ITEM_SCHOOL_NAME = "school_name";				// �w�Z��

	// ���ѕ\
	private static final String ITEM_SCORE_INFO = "score_info";							// ���Ȃ̊w�K
	private static final String ITEM_STUDENT_INFO = "student_info";						// �o�Ȕԍ����O
	private static final String ITEM_SPECIAL_ACTIVITY = "special_activity";				// ���ʊ���
	private static final String ITEM_SCHOOL_LIFE = "school_life";						// �w�Z����
	private static final String ITEM_SCHOOL_LIFE_LINE = "school_life_line";				// �w�Z�����r��
	private static final String ITEM_EFFORT = "effort";									// �w�̗͂l�q�E�߂���
	private static final String ITEM_VERY_GOOD_BOX = "veryGoodBox";						// ��ς悢
	private static final String ITEM_HYOKA_COMMENT = "HyokaComment";					// �]��������
	private static final String ITEM_SPECIAL_STUDY = "special_study";					// �����I�Ȋw�K�̎���
	private static final String ITEM_ACTIVITY_CONTENT_BOARD = "activityContent_board";	// �������
	private static final String ITEM_ACTIVITY_CONTENT_CLUB = "activityContent_club";	// �N���u����
	private static final String ITEM_MORAL_VALUE = "moral";								// �����̕]��

	// 2�w��������
	private static final String ITEM_ZENKI_HYOSI = "termName2";

	private static final String ITEM_ZENKI_1_2_12 = "zenki1_2_12";
	private static final String ITEM_ZENKI2_2_12 = "zenki2_2_12";
	private static final String ITEM_ZENKI3_2_12 = "zenki3_2_12";
	private static final String ITEM_ZENKI4_2_12 = "zenki4_2_12";

	private static final String ITEM_ZENKI1_2_3 = "zenki1_2_3";
	private static final String ITEM_ZENKI2_2_3 = "zenki2_2_3";
	private static final String ITEM_ZENKI3_2_3 = "zenki3_2_3";
	private static final String ITEM_ZENKI4_2_3 = "zenki4_2_3";
	private static final String ITEM_ZENKI5_2_3 = "zenki5_2_3";

	private static final String ITEM_ZENKI1_2_4 = "zenki1_2_4";
	private static final String ITEM_ZENKI2_2_4 = "zenki2_2_4";
	private static final String ITEM_ZENKI3_2_4 = "zenki3_2_4";
	private static final String ITEM_ZENKI4_2_4 = "zenki4_2_4";
	private static final String ITEM_ZENKI5_2_4 = "zenki5_2_4";

	private static final String ITEM_ZENKI1_2_56 = "zenki1_2_56";
	private static final String ITEM_ZENKI2_2_56 = "zenki2_2_56";
	private static final String ITEM_ZENKI3_2_56 = "zenki3_2_56";
	private static final String ITEM_ZENKI4_2_56 = "zenki4_2_56";
	private static final String ITEM_ZENKI5_2_56 = "zenki5_2_56";

	// ��w�N�̕]���i�K��������
	private static final String ITEM_HYOKACOMMENT2_12 = "HyokaComment2_12";
	private static final String HYOKACOMMENT2_12_BASE_STRING = "1�N����term�̕]���́C�u�悢�v�u���������v��2�i�K";
	private static final String HYOKACOMMENT2_12_REPLACE_TARGETVAL = "term";

	private static final Integer COL_SCORE_ITEM = 0;							// ���ȗ�
	private static final Integer COL_SCORE_POINTVIEW = 1;						// �ϓ_��
	private static final Integer COL_SCORE_CONTENT = 2;							// ���e��

	private static final Integer COL_SCORE_ZENKI = 3;							// �O��
	private static final Integer COL_SCORE_KOUKI = 4;							// ���
	private static final Integer COL_SCORE_ICHI = 3;							// 1�w��
	private static final Integer COL_SCORE_NI = 4;								// 2�w��
	private static final Integer COL_SCORE_SAN = 5;								// 3�w��




	/** �w�N1�N */
	private static final String GRADE1 = "1";
	/** �w�N2�N */
	private static final String GRADE2 = "2";
	/** �w�N3�N */
	private static final String GRADE3 = "3";
	/** �w�N4�N */
	private static final String GRADE4 = "4";
	/** �w�N5�N */
	private static final String GRADE5 = "5";
	/** �w�N6�N */
	private static final String GRADE6 = "6";
	/** �w�N1�N2�N */
	private static final String GRADE12 = "12";
	/** �w�N5�N6�N */
	private static final String GRADE56 = "56";

	/** 2�w����12�N */
	private static final String TERM2_GRADE12 = "2_12";
	/** 2�w����3�N */
	private static final String TERM2_GRADE3 = "2_3";
	/** 2�w����4�N */
	private static final String TERM2_GRADE4 = "2_4";
	/** 2�w����56�N */
	private static final String TERM2_GRADE56 = "2_56";
	/** 3�w����12�N */
	private static final String TERM3_GRADE12 = "3_12";
	/** 3�w����3�N */
	private static final String TERM3_GRADE3 = "3_3";
	/** 3�w����4�N */
	private static final String TERM3_GRADE4 = "3_4";
	/** 3�w����56�N */
	private static final String TERM3_GRADE56 = "3_56";

	// ���ȃR�[�h
	/** ����@402 */
	private static final String ITEM_CODE_KOKUGO = "402";
	/** �Љ�@404�@*/
	private static final String ITEM_CODE_SHAKAI = "404";
	/** �Z���@406�@*/
	private static final String ITEM_CODE_SANSU = "406";
	/** ���ȁ@408�@*/
	private static final String ITEM_CODE_RIKA = "408";
	/** �����@410�@*/
	private static final String ITEM_CODE_SEIKATSU = "410";
	/** ���y�@412�@*/
	private static final String ITEM_CODE_ONGAKU = "412";
	/** �}��H��@414�@*/
	private static final String ITEM_CODE_ZUGAKOUSAKU = "414";
	/** �ƒ�@416 */
	private static final String ITEM_CODE_KATEI = "416";
	/** �̈�@418�@*/
	private static final String ITEM_CODE_TAIIKU = "418";

	/** ���C���[����p�萔 */
	private static final String LAYER_TEACHER = "layer_teacher";
	private static final String LAYER_SCORE = "layer_score";

	/** ���t�����ݒ� */
	private DateFormatUtility dfu = null;

	/** �o�����̗�ʒu���i�[����Map */
	private Map<String, Integer> monthColMap = new HashMap<String, Integer>();

	/** ���FormBean */
	private Print31910000FormBean printFormBean;


	/** �R���X�g���N�^ */
	public Print31910000(SystemInfoBean sessionBean) {
		dfu = sessionBean.getDateFormatUtility();
		dfu.setZeroToSpace(true);

		int colCount = 0;
		for(int i=4; i<=12; i++){
			monthColMap.put(String.format("%02d", i), colCount++);
		}
		for(int i=1; i<=3; i++){
			monthColMap.put(String.format("%02d", i), colCount++);
		}
	}

	@Override
	protected void doPrint() throws TnaviPrintException {
		try {
			for (Data31910000FormBean student : printFormBean.getDataFormBeanList()) {
				if (printFormBean.isOutput_cover()) {
					// �\�����C���o��
					printOutputCover(student);
				}
				if (printFormBean.isOutput_page1()) {
					// ���у��C���o��
					printOutputEval1(student);
				}
			}

		} catch (Exception e) {
			log.error("��O�����@���[�쐬���s",e);
			throw new TnaviPrintException(e);
		}
	}

	/**
	 * ���FormBean��ݒ肷��.
	 * @param printFormBean the printFormBean to set
	 */
	public void setPrintFormBean(Print31910000FormBean printFormBean) {
		this.printFormBean = printFormBean;
	}

	/**
	 * �\���̏o�͂��s��.
	 * @param student ���k���
	 */
	private void printOutputCover(Data31910000FormBean student) throws Exception {
		// �\�����郌�C���[���擾
		String termCount = printFormBean.getTermCount();
		String layerId = LAYER_TEACHER + termCount;
		// �S���C���[���\��
		setVisibleAtPrintForAllLayout(false);
		// �\�����ʃ��C���[�\��
		getCrLayerSetVisibleAtPrint(LAYER_COVER, true);
		// �S�C�F�󃌃C���[�\��
		getCrLayerSetVisibleAtPrint(layerId, true);

		// �E�y�[�W�|�N�x
		getExistsFieldSetData(ITEM_NENDO, dfu.formatDate("YYYY�N", 1, printFormBean.getNendo()) + "�x");

		// �E�y�[�W�|No.
		getExistsFieldSetData(ITEM_STU_NUMBER, student.getStuNumber());

		// �E�y�[�W�|�����
		// �w�Z��
		if(objectExists(ITEM_IMAGE_FIELD1)){
			CrImageField imageField = (CrImageField)form.getCrObject(ITEM_IMAGE_FIELD1);
			if(printFormBean.getStampImage() != null){
				imageField.setData(printFormBean.getStampImage());
			}
		}

		// �E�y�[�W�|�w�N
		getExistsFieldSetData(ITEM_GRADE2, student.getStuGrade());

		// �E�y�[�W�|�g
		getExistsFieldSetData(ITEM_CLASS, student.getStuClass());

		// �E�y�[�W�|��������
		getExistsFieldSetData(ITEM_STU_NAME, student.getStuStuname());

		// �E�y�[�W�|�Z�������A�w���S�C
		if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputTeacherName())) {
			CrListField teacherList = getCrListField(ITEM_TEACHER);
			CrText[][] teacherInfo = getListFieldGetColumns(teacherList);
			setListFieldData(teacherInfo, 0, 0, printFormBean.getPrincipalName());			// �Z��
			setListFieldData(teacherInfo, 1, 0, printFormBean.getFormerPrincipalName());	// �Z������
			setListFieldData(teacherInfo, 0, 1, printFormBean.getTeacherName());			// �S�C
			setListFieldData(teacherInfo, 1, 1, printFormBean.getFormerTeacherName());		// �S�C����
		}

		// �E�y�[�W�|�w�Z��
		getExistsFieldSetData(ITEM_SCHOOL_NAME, printFormBean.getSchoolNameO());

		// ���y�[�W�|�o���ȏ�
		printOutputCoverAttendanceAbsent(student);

		// ���y�[�W�|�C����
		if ((!GRADE6.equals(student.getStuGrade()))
				&& Integer.valueOf(printFormBean.getTerm()).intValue() ==
					Integer.valueOf(printFormBean.getTermCount()).intValue()) {
			getCrLayerSetVisibleAtPrint(LAYER_COMLETE, true);
			printOutputCoverCompletionInfo(student);
		} else {
			getCrLayerSetVisibleAtPrint(LAYER_COMLETE, false);
		}

		// �E�y�[�W2�w�����̖���
		if (printFormBean.getTwoTermName() != null) {
			CrListField termZenkiList = getCrListField(ITEM_ZENKI_HYOSI);
			CrText[][] termZenki = getListFieldGetColumns(termZenkiList);
			for (int i = 0; i < 2; i++) {
				setListFieldData(termZenki, i, 0, printFormBean.getTwoTermName()[i]);
			}
		}

		// �o��
		form.printOut();
		// �t�H�[��������
		form.initialize();
	}

	/**
	 * �\�����o���Ȃ̏󋵁��̏o�͂��s��.
	 * @param student
	 * @throws Exception
	 */
	private void printOutputCoverAttendanceAbsent(Data31910000FormBean student) throws Exception {



		List<Data31910000_AttendEntity> attendEntityList = printFormBean.getAttendEntityList();

		Integer sum[] = new Integer[]{0, 0, 0, 0, 0};
		int rowCount = 0;
		CrListField attendanceAbsentList = getCrListField(ITEM_ATTENDANCE_ABSENT);
		CrText[][] attendanceAbsent = getListFieldGetColumns(attendanceAbsentList);
		for (Data31910000_AttendEntity entity : attendEntityList) {
			if (student.getStuStucode().equals(entity.getAtt_stucode())) {
				Integer xPoint = monthColMap.get(entity.getEnf_month());
				setListFieldData(attendanceAbsent, xPoint, rowCount++, formatOutputMonth(entity.getEnf_month()));	// ��
				setListFieldData(attendanceAbsent, xPoint, rowCount++, entity.getEnf_count());	// ���Ɠ���
				setListFieldData(attendanceAbsent, xPoint, rowCount++, entity.getAtt_stop());		// �o���������
				setListFieldData(attendanceAbsent, xPoint, rowCount++, entity.getAtt_must());		// �o�Ȃ��ׂ�����
				setListFieldData(attendanceAbsent, xPoint, rowCount++, entity.getAtt_absence());	// ���ȓ���
				setListFieldData(attendanceAbsent, xPoint, rowCount, entity.getAtt_attend());	// �o�ȓ���
				rowCount = 0;

				if (entity.getEnf_count() != null) {
					sum[0] += entity.getEnf_count();
				}
				if (entity.getAtt_stop() != null) {
					sum[1] += entity.getAtt_stop();
				}
				if (entity.getAtt_must() != null) {
					sum[2] += entity.getAtt_must();
				}
				if (entity.getAtt_absence() != null) {
					sum[3] += entity.getAtt_absence();
				}
				if (entity.getAtt_attend() != null) {
					sum[4] += entity.getAtt_attend();
				}
			}
		}
		// �v
		setListFieldData(attendanceAbsent, 12, 0, "�v");
		for (int i = 0; i < sum.length; i++) {
			setListFieldData(attendanceAbsent, 12, i + 1, sum[i]);
		}
	}

	/**
	 * �\��<�C����>�̏o�͂��s��.
	 * @param student
	 * @throws Exception
	 */
	private void printOutputCoverCompletionInfo(Data31910000FormBean student) throws Exception {
		// ���k����
		getExistsFieldSetData(ITEM_STU_NAME1, student.getStuStuname());
		// �w�N
		getExistsFieldSetData(ITEM_GRADE1, student.getStuGrade());
		// �C���N����
		getExistsFieldSetData(ITEM_COMPLETION_DATE, dfu.formatDate("YYYY�NMM��DD��", 1, printFormBean.getOutputDate()));
		// �w�Z���^�C�g��
		if (StringUtils.isNotBlank(printFormBean.getSchoolNameO())) {
			getExistsFieldSetData(ITEM_GRA_MASTER_TITLE1, printFormBean.getSchoolNameO() + "��");
		}
		// �w�Z����
		getExistsFieldSetData(ITEM_GRA_MASTER_NAME1, printFormBean.getPrincipalName());

	}

	/**
	 * ���т̏o�͂��s��.
	 * @param student ���k���
	 * @throws �o�͎���O
	 */
	private void printOutputEval1(Data31910000FormBean student) throws Exception {
		// �w�N����\�����郌�C���[���擾
		String termCount = printFormBean.getTermCount();
		String grade = printFormBean.getDataFormBeanList().get(0).getStuGrade();
		String addName = getAddName(termCount, grade);
		String layerId = LAYER_SCORE + addName;

		// �S���C���[���\��
		setVisibleAtPrintForAllLayout(false);
		// ���т�\��
		getCrLayerSetVisibleAtPrint(layerId, true);

		// 2�w�����̏ꍇ�̊w�����̂�ݒ肷��
		if (AshigarakamiConstantsUseable.TWO_TERM.equals(termCount)) {
			setTwoTermName(addName);
			// ��w�N�̕]���̒i�K�Ɋւ������������ݒ�
			setHyokaExplain();
		}

		// ���т̍��ڐݒ�
		printOutputEval(termCount, student, addName, printFormBean.getNoOutputEval());

		// �o��
		form.printOut();
		// �t�H�[��������
		form.initialize();
	}

	/**
	 * ���т̏o�͂��s��.
	 * @param termCount �w����
	 * @param student ���k���
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @param noOutputEval �]���]��o�͖���
	 * @throws �o�͎���O
	 */
	private void printOutputEval(String termCount, Data31910000FormBean student, String addName,
			String noOutputEval) throws Exception {
		// �o�Ȕԍ��A����
		CrListField studentInfoList = getCrListField(ITEM_STUDENT_INFO + addName);
		CrText[][] tudentInfo = getListFieldGetColumns(studentInfoList);
		int colIndex = 0;
		setListFieldData(tudentInfo, colIndex++, 0, student.getStuNumber());		// �o�Ȕԍ��i�𗬁j
		setListFieldData(tudentInfo, colIndex, 0, student.getStuStuname());			// ���O�i�ʏ́j


		// �����Ȃ̊w�K��
		initViewpointList(student, termCount, addName);
		outputViewpointList(student, termCount, addName);

		// �������I�Ȋw�K�̎��ԁ�
		outputSpecialStudy(student, termCount, addName);

		// �������I�Ȋw�K�̎��ԁE�O���ꊈ����
		outputSpecialStudyForeignLanguage(student, termCount, addName);

		// �����ʊ�����
		outputSpecialActivityList(student, termCount, addName);

		// �����ʊ������������e
		outputSpecialActivityContentList(student, termCount, addName);

		// ���w�Z������
		outputSchoolLife(student, termCount, addName);

		// ���w�̗͂l�q�E�߂��ā�
		outputEffort(student, termCount, addName);

		// �����ʂ̋��� ������
		outputMoralValue(student, termCount, addName);

	}

	/**
	 * �ϓ_�ʕ]�������\���l���o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void initViewpointList(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		// ���ȕʊϓ_�A�]���̏o�̓G���A
		CrListField viewpointListField = getCrListField(ITEM_SCORE_INFO + addName);
		CrText [][] viewpointList = getListFieldGetColumns(viewpointListField);

		int maxRow = viewpointList[0].length;

		String initValue = "�E�|�E�|�E";
		for(int i=0; i<maxRow; i++){
			if("2".equals(termCount)){
				setListFieldData(viewpointList, COL_SCORE_ZENKI, i, initValue);
				setListFieldData(viewpointList, COL_SCORE_KOUKI, i, initValue);
			}else{
				setListFieldData(viewpointList, COL_SCORE_ICHI, i, initValue);
				setListFieldData(viewpointList, COL_SCORE_NI,   i, initValue);
				setListFieldData(viewpointList, COL_SCORE_SAN,  i, initValue);

			}
		}
	}

	/**
	 * �ϓ_�ʕ]���E�]��̍��ڂ��o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputViewpointList(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		String grade = dataFormBean.getStuGrade();
		// 1�w�N�̂݋��Ȃ̊w�K��1�w��(�O��)�́u��ς悢�v��̔w�i���O���[�ɐݒ�
		if(objectExists(ITEM_VERY_GOOD_BOX + addName)){
			form.getCrObject(ITEM_VERY_GOOD_BOX + addName).setVisible(GRADE1.equals(grade));
		}

		// 1�w�N�̂�1�w���̕]����������\��
		if(objectExists(ITEM_HYOKA_COMMENT + addName)){
			form.getCrObject(ITEM_HYOKA_COMMENT + addName).setVisible(GRADE1.equals(grade));
		}

		// ���ȕʊϓ_�A�]���̏o�̓G���A
		CrListField viewpointListField = getCrListField(ITEM_SCORE_INFO + addName);
		CrText [][] viewpointList = getListFieldGetColumns(viewpointListField);

		// ���Ȃ̊w�K
		Map<String, List<Data31910000_ItemViewpointEntity>> viewpointEntityMap = printFormBean.getViewpointEntityMap();
		if (viewpointEntityMap == null) {
			return;
		}

		// �]���A�]����擾
		Map<String, Map<String, Data31910000_ScoreEntity>> scoreEntityMapMap = printFormBean.getScoreEntityMapMap();
		Map<String, Map<String, Data31910000_EvalEntity>> evalEntityMapMap = printFormBean.getEvalEntityMapMap();

		// �]���A�]��̐��k���擾����
		Map<String, Data31910000_ScoreEntity> scoreEntityMap = scoreEntityMapMap.get(dataFormBean.getStuStucode());
		Map<String, Data31910000_EvalEntity>  evalEntityMap  = evalEntityMapMap.get(dataFormBean.getStuStucode());

		// ����o�͓��̍s�ʒu
		int rowNum = 0;

		// �e���Ȃ̍ő�ϓ_��
		int maxItemCount = 0;

		// ���Ȃ��Ƃ̃��[�v
		for (Map.Entry<String, List<Data31910000_ItemViewpointEntity>> entry : viewpointEntityMap.entrySet()) {
			List<Data31910000_ItemViewpointEntity> itemViewpointEntityList = entry.getValue();
			if (itemViewpointEntityList != null) {
				String itemCode = "";
				int startRow = rowNum ; // �Z���}�[�W�p�Ɋe���Ȃ̊J�n�s��ێ�����B

				String prevItemCode = "";
				int itemViewpointCounter = 0;

				// ���Ȃ��Ɗϓ_�̃��[�v
				for (Data31910000_ItemViewpointEntity itemViewpointEntity : itemViewpointEntityList) {
					itemCode = itemViewpointEntity.getItem_code();

					// �w�N�A�Ȗڂ̊ϓ_���ڍs����ݒ�
					if (!StringUtils.equals(prevItemCode, itemCode)) {
						maxItemCount = getMaxItemCount(termCount, addName, itemCode);
						itemViewpointCounter = 0;
					}
					if (itemViewpointCounter >= maxItemCount) {
						continue;
					}

					// ���Ȃ̊w�K ����
					setListFieldData(viewpointList, COL_SCORE_ITEM, rowNum, itemViewpointEntity.getItem_name());
					// ���Ȃ̊w�K �ϓ_
					setListFieldData(viewpointList, COL_SCORE_POINTVIEW, rowNum, itemViewpointEntity.getRivt_rivtname());
					// ���Ȃ̊w�K ���e
					setListFieldData(viewpointList, COL_SCORE_CONTENT, rowNum, itemViewpointEntity.getRivt_purpose());

					String term = printFormBean.getTerm();

					if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
						// ������{�L�[���g�p���ĕ]�����擾�ݒ肷��
						// ������{�L�[�̍쐬
						String scoreKey = itemCode + "_" + itemViewpointEntity.getRivt_rivtcode() + "_";
						if (AshigarakamiConstantsUseable.TWO_TERM.equals(termCount)) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(term)) {
								// 2�w������2�w��
								setListFieldData(viewpointList, COL_SCORE_ZENKI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_01));
								setListFieldData(viewpointList, COL_SCORE_KOUKI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_02));
							} else {
								// 2�w������1�w��
								setListFieldData(viewpointList, COL_SCORE_ZENKI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_01));
							}
						} else {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(term)) {
								// 3�w������3�w��
								setListFieldData(viewpointList, COL_SCORE_ICHI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_01));
								setListFieldData(viewpointList, COL_SCORE_NI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_02));
								setListFieldData(viewpointList, COL_SCORE_SAN, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_03));
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(term)) {
								// 3�w������2�w��
								setListFieldData(viewpointList, COL_SCORE_ICHI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_01));
								setListFieldData(viewpointList, COL_SCORE_NI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_02));
							} else {
								// 3�w������1�w��
								setListFieldData(viewpointList, COL_SCORE_ICHI, rowNum,
										getScore(scoreEntityMap, scoreKey + AshigarakamiConstantsUseable.GOPT_GOPTCODE_01));
							}
						}

						// ������{�L�[���g�p���ĕ]����擾�ݒ肷��
						String evalKey = itemCode + "_" ;
						// �]�� 12�N�͍��ڂȂ�
						String grade12 = termCount + "_" + GRADE12;
						if (!grade12.equals(addName)) {
							String eval = getEval(evalEntityMap, evalKey + term);
							int evalCol = 5;
							if (AshigarakamiConstantsUseable.TWO_TERM.equals(termCount)) {
								evalCol = 5;
							} else if (AshigarakamiConstantsUseable.THREE_TERM.equals(termCount)) {
								evalCol = 6;
							}
							setListFieldData(viewpointList, evalCol, rowNum, eval);
						}
					}

					prevItemCode = itemCode;
					rowNum++;
					itemViewpointCounter++;
				}

				// �ϓ_���ڂ̐ݒ肪�ő�s���ȉ��̏ꍇ�́A�u�����N�s��ǉ�����B
				for (int i = itemViewpointEntityList.size(); i < maxItemCount ; i++) {
					// ����
					setListFieldData(viewpointList, COL_SCORE_ITEM, rowNum, "");
					// �ϓ_
					setListFieldData(viewpointList, COL_SCORE_POINTVIEW, rowNum, "");

					int lastCol;
					if (AshigarakamiConstantsUseable.TWO_TERM.equals(termCount)) {
						//12 1:�ϓ_�A2:���e�A3:�O���A4:���
						lastCol = 5;
						//3-6 1:�ϓ_�A2:���e�A3:�O���A4:����A5:�]��
						if (GRADE1.equals(grade) || GRADE2.equals(grade)) {
							lastCol = 4;
						}
					} else {
						//12 1:�ϓ_�A2:���e�A3:1�w���A4:2�w���A5:3�w��
						//3-6 1:�ϓ_�A2:���e�A3:1�w���A4:2�w���A5:3�w���A6:�]��
						lastCol = 6;
						if (GRADE1.equals(grade) || GRADE2.equals(grade)) {
							lastCol = 5;
						}
					}
					for (int col = 1; col <= lastCol; col++) {
						setListFieldData(viewpointList, col, rowNum, "");
					}
				}
				// ���ȗ��̌���
				listFieldMergeCell(viewpointListField, COL_SCORE_ITEM, startRow, COL_SCORE_ITEM,
						startRow + maxItemCount - 1);

				// �w�N�]�藓�̌��� 2�w�����A3�w�����Ƃ�12�N�͍��ڂȂ�
				if (!(GRADE1.equals(grade) || GRADE2.equals(grade))) {
					int mergeColIndex = 5;
					if (AshigarakamiConstantsUseable.TWO_TERM.equals(termCount)) {
						// 2�w���� �]���index�F5
						mergeColIndex = 5;
					} else {
						// 3�w���� �]���index�F6
						mergeColIndex = 6;
					}
					listFieldMergeCell(viewpointListField, mergeColIndex, startRow, mergeColIndex,
							startRow + maxItemCount - 1);
				}
			}
		}
	}

	/**
	 * �����I�Ȋw�K�̎��Ԃ̍��ڂ��o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputSpecialStudy(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		// �����I�Ȋw�K�̊��Ԃ̏o�̓G���A
		try {
			form.getCrObject(ITEM_SPECIAL_STUDY + addName);
    	} catch (Exception e) {
    		//�I�u�W�F�N�g���Ȃ��ꍇ�͏o�͂��Ȃ����C�A�E�g�̂��߁A�������I������
    		return;
    	}
		CrListField specialStudyListField = getCrListField(ITEM_SPECIAL_STUDY + addName);
		CrText [][] specialStudyListColumns = getListFieldGetColumns(specialStudyListField);

		List<Data31910000_IntegratedStudyEntity> integratedStudyList = printFormBean.getIntegratedStudyList();

		if ((integratedStudyList == null) || integratedStudyList.isEmpty()) {
			return;
		}

		if (AshigarakamiConstantsUseable.PATTERN_STUDENT.equals(printFormBean.getOutputPattern())) {
			for (Data31910000_IntegratedStudyEntity studyEntity : integratedStudyList) {
				if (dataFormBean.getStuStucode().equals(studyEntity.getRev_stucode())) {
					int rowIndex = 0;
					if(AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(studyEntity.getRtat_term())) {
						rowIndex = 0;
					} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(studyEntity.getRtat_term())) {
						rowIndex = 1;
					} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(studyEntity.getRtat_term())) {
						rowIndex = 2;
					}
					if (GRADE3.equals(dataFormBean.getStuGrade())) {
						setListFieldData(specialStudyListColumns, 1, rowIndex, studyEntity.getRtat_act());		// �w�K����
						setListFieldData(specialStudyListColumns, 3, rowIndex, studyEntity.getRtat_value());	// �w�K�̗l�q
					} else if (GRADE4.equals(dataFormBean.getStuGrade())) {
						setListFieldData(specialStudyListColumns, 1, rowIndex, studyEntity.getRtat_act());		// �w�K����
						setListFieldData(specialStudyListColumns, 3, rowIndex, studyEntity.getRtat_value());	// �w�K�̗l�q
					} else if (GRADE5.equals(dataFormBean.getStuGrade()) || GRADE6.equals(dataFormBean.getStuGrade())) {
						setListFieldData(specialStudyListColumns, 0, rowIndex, studyEntity.getRtat_act());		// �w�K����
						setListFieldData(specialStudyListColumns, 1, rowIndex, studyEntity.getRtat_value());	// �w�K�̗l�q
					}
				}
			}
		} else {
			Data31910000_IntegratedStudyEntity studyEntity = integratedStudyList.get(0);
			int rowIndex = 0;
			if(AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(studyEntity.getRtat_term())) {
				rowIndex = 0;
			} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(studyEntity.getRtat_term())) {
				rowIndex = 1;
			} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(studyEntity.getRtat_term())) {
				rowIndex = 2;
			}
			if (GRADE3.equals(dataFormBean.getStuGrade())) {
				setListFieldData(specialStudyListColumns, 1, rowIndex, studyEntity.getRtat_act());		// �w�K����
				setListFieldData(specialStudyListColumns, 3, rowIndex, studyEntity.getRtat_value());	// �w�K�̗l�q
			} else if (GRADE4.equals(dataFormBean.getStuGrade())) {
				setListFieldData(specialStudyListColumns, 1, rowIndex, studyEntity.getRtat_act());		// �w�K����
				setListFieldData(specialStudyListColumns, 3, rowIndex, studyEntity.getRtat_value());	// �w�K�̗l�q
			} else if (GRADE5.equals(dataFormBean.getStuGrade()) || GRADE6.equals(dataFormBean.getStuGrade())) {
				setListFieldData(specialStudyListColumns, 0, rowIndex, studyEntity.getRtat_act());		// �w�K����
				setListFieldData(specialStudyListColumns, 1, rowIndex, studyEntity.getRtat_value());	// �w�K�̗l�q
			}
		}
	}

	/**
	 * �O���ꊈ�����o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputSpecialStudyForeignLanguage(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		if (dataFormBean.getStuGrade().compareTo(GRADE5) < 0) { // 5�N�������͊Y�����ڂȂ�
			return;
		}
		// �����I�Ȋw�K�̊��Ԃ̏o�̓G���A
		CrListField specialStudyListField = getCrListField(ITEM_SPECIAL_STUDY + addName);
		CrText [][] specialStudyListColumns = getListFieldGetColumns(specialStudyListField);

		List<Data31910000_ForeignLanguageEntity> foreignLanguageList = printFormBean.getForeignLanguageList();
		for (Data31910000_ForeignLanguageEntity entity : foreignLanguageList) {
			if (dataFormBean.getStuStucode().equals(entity.getRfla_stucode())) {
				int rowIndex = 0;
				if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(entity.getRfla_term())) {
					rowIndex = 0;
				} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(entity.getRfla_term())) {
					rowIndex = 1;
				} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(entity.getRfla_term())) {
					rowIndex = 2;
				}
				setListFieldData(specialStudyListColumns, 2, rowIndex, entity.getRfla_eval());
			}
		}
	}

	/**
	 * ���ʊ����̍��ڂ��o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputSpecialActivityList(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		// ���ʊ����̏o�̓G���A
		CrListField specialActivityListField = getCrListField(ITEM_SPECIAL_ACTIVITY + addName);
		CrText [][] specialActivityColumns = getListFieldGetColumns(specialActivityListField);

		List<Data31910000_SpecialAppearanceEntity> specialActivityList = printFormBean.getSpecialActivityList();
		for (Data31910000_SpecialAppearanceEntity specialAppearanceEntity : specialActivityList) {
			if (dataFormBean.getStuStucode().equals(specialAppearanceEntity.getRsav_stucode())) {
				String pattern = getGradePattern(dataFormBean.getStuGrade());
				String rsatcode = specialAppearanceEntity.getRsat_rsatcode();
				if (GRADE12.equals(pattern)) {
					if ("0001".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 0, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 0, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 0, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 0, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0002".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 1, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 1, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 1, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 1, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0003".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 2, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 2, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 2, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 2, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0004".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 3, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 3, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 3, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 3, specialAppearanceEntity.getRsae_display());
							}
						}
					}
				} else if (GRADE3.equals(pattern)) {
					if ("0001".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 0, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 0, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 0, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 0, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0002".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 1, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 1, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 1, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 1, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0004".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 2, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 2, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 2, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 2, specialAppearanceEntity.getRsae_display());
							}
						}
					}
				} else if (GRADE4.equals(pattern) || GRADE56.equals(pattern)) {
					if ("0001".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 0, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 0, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 0, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 0, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0002".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 1, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 1, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 1, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 1, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0003".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 2, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 2, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 2, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 2, specialAppearanceEntity.getRsae_display());
							}
						}
					} else if ("0004".equals(rsatcode)) {
						setListFieldData(specialActivityColumns, 0, 3, specialAppearanceEntity.getRsat_pointview());
						if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
							if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 1, 3, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 2, 3, specialAppearanceEntity.getRsae_display());
							} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(specialAppearanceEntity.getRsat_term())) {
								setListFieldData(specialActivityColumns, 3, 3, specialAppearanceEntity.getRsae_display());
							}
						}
					}
				}
			}
		}
	}

	/**
	 * �����ʊ������������e���o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputSpecialActivityContentList(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		if (dataFormBean.getStuGrade().compareTo(GRADE4) < 0) { // 4�N�������͊Y�����ڂȂ�
			return;
		}
		StringBuilder jido = new StringBuilder();
		StringBuilder club = new StringBuilder();
		List<Data31910000_SpecialAppearanceEntity> specialActivityContentList = printFormBean.getSpecialActivityContentList();
		for (Data31910000_SpecialAppearanceEntity specialActivityContentEntity : specialActivityContentList) {
			if (dataFormBean.getStuStucode().equals(specialActivityContentEntity.getRsav_stucode())) {
				if (AshigarakamiConstantsUseable.SPECIAL_ACTIVITY_JIDO1.equals(specialActivityContentEntity.getPos_kind())
						|| AshigarakamiConstantsUseable.SPECIAL_ACTIVITY_JIDO2.equals(specialActivityContentEntity.getPos_kind())) {
					if (jido.length() > 0) {
						jido.append("�C");
					}
					jido.append(specialActivityContentEntity.getExtname());
				} else if (AshigarakamiConstantsUseable.SPECIAL_ACTIVITY_CLUB.equals(specialActivityContentEntity.getPos_kind())) {
					if (club.length() > 0) {
						club.append("�C");
					}
					club.append(specialActivityContentEntity.getExtname());
				}
			}
		}

		// ��������̏o�̓G���A
		getExistsFieldSetData(ITEM_ACTIVITY_CONTENT_BOARD + addName, "�i" + jido.toString() + "�j");
		// �N���u�����̏o�̓G���A
		getExistsFieldSetData(ITEM_ACTIVITY_CONTENT_CLUB + addName, "�i" + club.toString() + "�j");
	}

	/**
	 * �w�Z�����̍��ڂ��o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputSchoolLife(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		// �w�Z�����̏o�̓G���A
		CrListField schoolLifeListField = getCrListField(ITEM_SCHOOL_LIFE + addName);
		CrText [][] schoolLifeColumns = getListFieldGetColumns(schoolLifeListField);
		// �w�Z�����̌r��
		CrListField schoolLifeLineListField = getCrListField(ITEM_SCHOOL_LIFE_LINE + addName);

		List<Data31910000_SchoolLifeEntity> schoolLifeList = printFormBean.getSchoolLifeList();

		int rowCount = 0;
		String prevViewPoint = "";	// �ϓ_
		String prevPurpose = "";	// ����
		int mergeRow = 0;
		int startRow = 0;

		int maxCol = 4;
		if(AshigarakamiConstantsUseable.THREE_TERM.equals(termCount)) {
			maxCol = 5;
		}

		for (Data31910000_SchoolLifeEntity schoolLifeEntity : schoolLifeList) {
			if (!dataFormBean.getStuStucode().equals(schoolLifeEntity.getRavv_stucode())) {
				continue;
			}
			if (StringUtils.isNotBlank(prevViewPoint) && !prevViewPoint.equals(schoolLifeEntity.getGavt_gavtcode())) {
				// ����ϓ_�̊ϓ_�Z������������
				if (!prevViewPoint.equals(schoolLifeEntity.getGavt_gavtcode())) {
					if(mergeRow > 0){
						listFieldMergeCell(schoolLifeListField, 0, startRow, 0, startRow + mergeRow);
						for (int col = 0; col < maxCol; col++) {
							listFieldMergeCell(schoolLifeLineListField, col, startRow, col, startRow + mergeRow);
						}
					}
					mergeRow = 0;
				}
				// �ϓ_�ύX
				rowCount++;
				startRow = rowCount;
				setListFieldData(schoolLifeColumns, 0, rowCount, schoolLifeEntity.getGavt_gavtname());
			} else if (StringUtils.isNotBlank(prevPurpose) && !prevPurpose.equals(schoolLifeEntity.getRavt_purpose())) {
				// ���ڕύX
				rowCount++;
				mergeRow++;
			}

			if (rowCount == 0) {
				setListFieldData(schoolLifeColumns, 0, rowCount, schoolLifeEntity.getGavt_gavtname());
			}
			setListFieldData(schoolLifeColumns, 1, rowCount, schoolLifeEntity.getRavt_purpose());
			if (!AshigarakamiConstantsUseable.NO_OUTPUT.equals(printFormBean.getNoOutputEval())) {
				if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(schoolLifeEntity.getRavt_term())) {
					setListFieldData(schoolLifeColumns, 2, rowCount, schoolLifeEntity.getRace_reportdisplay());
				} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(schoolLifeEntity.getRavt_term())) {
					setListFieldData(schoolLifeColumns, 3, rowCount, schoolLifeEntity.getRace_reportdisplay());
				} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(schoolLifeEntity.getRavt_term())) {
					setListFieldData(schoolLifeColumns, 4, rowCount, schoolLifeEntity.getRace_reportdisplay());
				}
			}
			prevViewPoint = schoolLifeEntity.getGavt_gavtcode();
			prevPurpose = schoolLifeEntity.getRavt_purpose();
		}
		if (mergeRow > 0) {
			listFieldMergeCell(schoolLifeListField, 0, startRow, 0, startRow + mergeRow);
			for (int col = 0; col < maxCol; col++) {
				listFieldMergeCell(schoolLifeLineListField, col, startRow, col, startRow + mergeRow);
			}
		}
	}

	/**
	 * �w�̗͂l�q�E�߂��Ă̍��ڂ��o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputEffort(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {
		// �w�̗͂l�q�E�߂��Ă̏o�̓G���A
		CrListField effortListField = getCrListField(ITEM_EFFORT + addName);
		CrText [][] effortColumns = getListFieldGetColumns(effortListField);

		List<Data31910000_EffortMercenaryEntity> effortMercenaryEntityList = printFormBean.getEffortMercenaryEntityList();


		for (Data31910000_EffortMercenaryEntity effortMercenaryEntity : effortMercenaryEntityList) {
			if (dataFormBean.getStuStucode().equals(effortMercenaryEntity.getRcom_stucode())) {
				if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(printFormBean.getTerm())) {
					if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(effortMercenaryEntity.getRcom_term())) {
						setListFieldData(effortColumns, 0, 0, effortMercenaryEntity.getRcom_comment());
					}
				} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(printFormBean.getTerm())) {
					if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(effortMercenaryEntity.getRcom_term())) {
						setListFieldData(effortColumns, 0, 0, effortMercenaryEntity.getRcom_comment());
					} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(effortMercenaryEntity.getRcom_term())) {
						setListFieldData(effortColumns, 1, 0, effortMercenaryEntity.getRcom_comment());
					}
				} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(printFormBean.getTerm())) {
					if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_01.equals(effortMercenaryEntity.getRcom_term())) {
						setListFieldData(effortColumns, 0, 0, effortMercenaryEntity.getRcom_comment());
					} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_02.equals(effortMercenaryEntity.getRcom_term())) {
						setListFieldData(effortColumns, 1, 0, effortMercenaryEntity.getRcom_comment());
					} else if (AshigarakamiConstantsUseable.GOPT_GOPTCODE_03.equals(effortMercenaryEntity.getRcom_term())) {
						setListFieldData(effortColumns, 2, 0, effortMercenaryEntity.getRcom_comment());
					}
				}
			}
		}
	}

	/**
	 * ���ʂ̋��ȓ����̕]�����o�͂���.
	 * @param dataFormBean ���k���
	 * @param termCount �w����
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws �o�͎���O
	 */
	private void outputMoralValue(Data31910000FormBean dataFormBean, String termCount, String addName) throws Exception {

		// �����̕]��
		List<Data31910000_MoralValueEntity> moralValueEntityList = printFormBean.getMoralValueEntityList();
		for (Data31910000_MoralValueEntity moralValueEntity : moralValueEntityList) {
			if (dataFormBean.getStuStucode().equals(moralValueEntity.getRmrl_stucode())) {
				getExistsFieldSetData(ITEM_MORAL_VALUE + addName, moralValueEntity.getRmrl_value());
			}
		}
	}

	/**
	 * 2�w�����̏ꍇ�̊w�����̂�ݒ肷��.
	 * @param addName �t�B�[���h�ɕt�����鎯�ʖ�
	 * @throws Exeption
	 */
	private void setTwoTermName(String addName) throws Exception {
		String[] terget = new String[]{};
		if (TERM2_GRADE12.equals(addName)) {
			terget = new String[]{
					ITEM_ZENKI_1_2_12,
					ITEM_ZENKI2_2_12,
					ITEM_ZENKI3_2_12,
					ITEM_ZENKI4_2_12};
		} else if (TERM2_GRADE3.equals(addName)) {
			terget = new String[]{
					ITEM_ZENKI1_2_3,
					ITEM_ZENKI2_2_3,
					ITEM_ZENKI3_2_3,
					ITEM_ZENKI4_2_3,
					ITEM_ZENKI5_2_3};
		} else if (TERM2_GRADE4.equals(addName)) {
			terget = new String[]{
					ITEM_ZENKI1_2_4,
					ITEM_ZENKI2_2_4,
					ITEM_ZENKI3_2_4,
					ITEM_ZENKI4_2_4,
					ITEM_ZENKI5_2_4};
		} else if (TERM2_GRADE56.equals(addName)) {
			terget = new String[]{
					ITEM_ZENKI1_2_56,
					ITEM_ZENKI2_2_56,
					ITEM_ZENKI3_2_56,
					ITEM_ZENKI4_2_56,
					ITEM_ZENKI5_2_56};
		}
		for (String item : terget) {
			getExistsFieldSetData(item, printFormBean.getTwoTermName()[0]);
		}
	}


	/**
	 * 2�w���� ��w�N�̕]���i�K��������
	 * @throws Exception
	 */
	private void setHyokaExplain() throws Exception {

		if (!objectExists(ITEM_HYOKACOMMENT2_12)) {
			return;
		}

		// ���������̏o�͎������̊Y���ӏ���u�����l���Z�b�g
		String newText = HYOKACOMMENT2_12_BASE_STRING.replaceFirst(HYOKACOMMENT2_12_REPLACE_TARGETVAL, printFormBean.getTwoTermName()[0]);
		getFieldSetData(ITEM_HYOKACOMMENT2_12, newText);
	}

	/**
	 * �w�����A�w�N�ɉ������Y�������擾����.
	 * @param termCount �w����(2,3)
	 * @param grade �w�N(1-6)
	 * @return 2_12, 2_3, 2_4, 2_56, 3_12, 3_3, 3_4, 3_56
	 */
	private String getAddName(String termCount, String grade) {
		String addName = "";
		if (AshigarakamiConstantsUseable.TWO_TERM.equals(termCount)) {
			if (GRADE1.equals(grade) || GRADE2.equals(grade)) {
				addName = TERM2_GRADE12;
			} else if(GRADE3.equals(grade)) {
				addName = TERM2_GRADE3;
			} else if(GRADE4.equals(grade)) {
				addName = TERM2_GRADE4;
			} else {
				addName = TERM2_GRADE56;
			}
		} else {
			if (GRADE1.equals(grade) || GRADE2.equals(grade)) {
				addName = TERM3_GRADE12;
			} else if (GRADE3.equals(grade)) {
				addName = TERM3_GRADE3;
			} else if (GRADE4.equals(grade)) {
				addName = TERM3_GRADE4;
			} else {
				addName = TERM3_GRADE56;
			}
		}

		return addName;
	}

	/**
	 * �I�u�W�F�N�g�̑��݃`�F�b�N��ɒl���Z�b�g����
	 * @param objectName �I�u�W�F�N�g��
	 * @param value	�o�͂���l
	 * @throws Exception
	 */
	private void getExistsFieldSetData(String objectName, Object value) throws Exception{
		if(objectExists(objectName)){
			getFieldSetData(objectName, value);
		}
	}

	/**
	 * �S���C����\���E��\���ɂ���
	 * @param flag�@�\���E��\���t���O
	 */
	private void setVisibleAtPrintForAllLayout(boolean flag) {
		CrLayers crLayers = form.getCrLayers();
		for(Iterator<CrLayer> i = crLayers.iterator(); i.hasNext();){
			CrLayer layer = i.next();
			layer.setVisibleAtPrint(flag);
		}
	}

	/**
	 * �o���Ȓ��󋵂̌�������������D<br/>
	 * 0�l�߂���Ă���l��0����菜��.
	 * @param month ����������Ώۂ̌�
	 * @return
	 */
	private String formatOutputMonth(String month) {
		String result = month;
		Integer value = null;
		try {
			value = Integer.valueOf(month);
			result = value.toString();
		} catch (NumberFormatException e) {
			result = month;
		}
		return result;
	}

	/**
	 * �w�����A�w�N�A�Ȗڂ��ϓ_�o�͍s�����擾����.
	 * @param termCount �w����
	 * @param paramAddName ���C�A�E�g�w�N
	 * @param paramItemCd �Ȗ�
	 * @return
	 */
	private int getMaxItemCount(String termCount, String paramAddName, String paramItemCd) {
		String[] grade = new String[]{
				GRADE12,
				GRADE12,
				GRADE3,
				GRADE4,
				GRADE56,
				GRADE56
		};
		String[] item = new String[]{
				ITEM_CODE_KOKUGO,
				ITEM_CODE_SHAKAI,
				ITEM_CODE_SANSU,
				ITEM_CODE_RIKA,
				ITEM_CODE_SEIKATSU,
				ITEM_CODE_ONGAKU,
				ITEM_CODE_ZUGAKOUSAKU,
				ITEM_CODE_KATEI,
				ITEM_CODE_TAIIKU
		};
		Integer[][] count2 = new Integer[][]{
			{5, 0, 4, 0, 3, 4, 4, 0, 3},
			{5, 0, 4, 0, 3, 4, 4, 0, 3},
			{5, 4, 4, 4, 0, 4, 4, 0, 4},
			{5, 4, 4, 4, 0, 4, 4, 0, 4},
			{5, 4, 4, 4, 0, 4, 4, 4, 4},
			{5, 4, 4, 4, 0, 4, 4, 4, 4}
		};
		Integer[][] count3 = new Integer[][]{
			{5, 0, 4, 0, 3, 4, 4, 0, 3},
			{5, 0, 4, 0, 3, 4, 4, 0, 3},
			{5, 4, 4, 4, 0, 4, 4, 0, 4},
			{5, 4, 4, 4, 0, 4, 4, 0, 4},
			{5, 4, 4, 4, 0, 4, 4, 4, 4},
			{5, 4, 4, 4, 0, 4, 4, 4, 4}
		};

		Integer[][] count = count2;
		if (AshigarakamiConstantsUseable.THREE_TERM.equals(termCount)) {
			count = count3;
		}

		Map<Map<String, String>, Integer> map = new HashMap<Map<String, String>, Integer>();
		for (int i = 0; i < grade.length; i++) {
			for (int j = 0; j < item.length; j++) {
				int maxItemCount = count[i][j];
				Map<String, String> key = new HashMap<String, String>();
				key.put(grade[i], item[j]);
				map.put(key, maxItemCount);
			}
		}

		Map<String, String> key = new HashMap<String, String>();
		String addName = paramAddName.split("_")[1];
		key.put(addName, paramItemCd);
		int maxItemCount = 0;
		if (map.containsKey(key)) {
			maxItemCount = map.get(key);
		}

		return maxItemCount;
	}
	/**
	 * �]��Entity����key�Ŏw�肳�ꂽ���Ȃ̕]�����擾����.
	 * @param scoreEntityMap
	 * @param key
	 * @return
	 */
	private String getScore(Map<String, Data31910000_ScoreEntity> scoreEntityMap, String key){
		Map<String, String> evalMap = new HashMap<String, String>();
		evalMap.put("0001", "���|�E�|�E");
		evalMap.put("0002", "�E�|���|�E");
		evalMap.put("0003", "�E�|�E�|��");
		String retValue = "�E�|�E�|�E";
		if (scoreEntityMap.containsKey(key)) {
			if (evalMap.containsKey(scoreEntityMap.get(key).getRvpe_rvpecode())) {
				retValue = evalMap.get(scoreEntityMap.get(key).getRvpe_rvpecode());
			}
		}

		return retValue ;

	}
	/**
	 * �]��Entity����key�Ŏw�肳�ꂽ���Ȃ̕]�����擾����.
	 * @param evalEntityMap
	 * @param key
	 * @return
	 */
	private String getEval(Map<String, Data31910000_EvalEntity> evalEntityMap, String key ){
		String retValue = "";
		if ((evalEntityMap != null) && (evalEntityMap.containsKey(key))) {
			if (evalEntityMap.get(key).getRevl_display() != null) {
				retValue = evalEntityMap.get(key).getRevl_display();
			}
		}

		return retValue;
	}


	/**
	 * �w�N����w�N�p�^�[�����擾����.
	 * @param grade �w�N
	 * @return 1=>12, 2=>12, 3=>3, 4=>4, 5=>56, 6=>56
	 */
	private String getGradePattern(String grade) {
		String pattern = "";
		Map<String, String> patternMap = new HashMap<String, String>();
		String[] key = new String[]{
				GRADE1,
				GRADE2,
				GRADE3,
				GRADE4,
				GRADE5,
				GRADE6
		};
		String[] value = new String[]{
				GRADE12,
				GRADE12,
				GRADE3,
				GRADE4,
				GRADE56,
				GRADE56
		};
		for (int i = 0; i < key.length; i++) {
			patternMap.put(key[i], value[i]);
		}
		if (patternMap.containsKey(grade)) {
			pattern = patternMap.get(grade);
		}

		return pattern;
	}

}
