/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All rights reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.allkochi.formbean;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import lombok.Getter;
import lombok.Setter;

/**
 * <PRE>
 * �w�Z�������(���m����) �ڍ� FormBean.
 * </PRE>
 *
 * <p>
 * <B>Create</B> 2019.03.19 BY SDC tanaka<BR>
 * </p>
 * @author SDC
 * @since 1.0
 */
public class Detail32175000FormBean {

	/** �����X�g */
	@Getter
	private List<SimpleTagFormBean> monthList = IntStream
			.rangeClosed(1, 12)
			.mapToObj(value -> String.format("%02d", value))
			.map(value -> new SimpleTagFormBean(value, value))
			.collect(Collectors.collectingAndThen(Collectors.toList(), Collections::unmodifiableList));

	/** �����X�g */
	@Getter
	private List<SimpleTagFormBean> dayList = IntStream
			.rangeClosed(1, 31)
			.mapToObj(value -> String.format("%02d", value))
			.map(value -> new SimpleTagFormBean(value, value))
			.collect(Collectors.collectingAndThen(Collectors.toList(), Collections::unmodifiableList));

	/** �o�͑Ώ� FROM */
	@Getter @Setter
	private String outTargetFrom;

	/** �o�͑Ώۓ� TO */
	@Getter @Setter
	private String outTargetTo;
}
