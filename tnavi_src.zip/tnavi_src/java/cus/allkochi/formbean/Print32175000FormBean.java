/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All rights reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.allkochi.formbean;

import java.util.List;

import jp.co.systemd.tnavi.cus.allkochi.db.entity.Data32175000_SchoolDiaryEntity;
import lombok.Getter;
import lombok.Setter;

/**
 * <PRE>
 * �w�Z�������(���m����) ��� FormBean.
 * </PRE>
 *
 * <p>
 * <B>Create</B> 2019.03.19 BY SDC tanaka<BR>
 * </p>
 * @author SDC
 * @since 1.0
 */
public class Print32175000FormBean {

	/** �o�͑Ώ� FROM */
	@Getter @Setter
	private String outTargetFrom;

	/** �o�͑Ώۓ� TO */
	@Getter @Setter
	private String outTargetTo;

	/** �w�Z�������X�g */
	@Getter @Setter
	private List<Data32175000_SchoolDiaryEntity> printList;
}
