/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All rights reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.allkochi.formbean;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import lombok.Getter;
import lombok.Setter;

/**
 * <PRE>
 * �w�Z��������(���m����) �ڍ� FormBean.
 * </PRE>
 *
 * <p>
 * <B>Create</B> 2019.03.19 BY SDC tanaka<BR>
 * </p>
 * @author SDC
 * @since 1.0
 */
public class Detail32174000FormBean {

	/** �����X�g */
	@Getter
	private List<SimpleTagFormBean> monthList = IntStream
			.rangeClosed(1, 12)
			.mapToObj(value -> String.format("%02d", value))
			.map(value -> new SimpleTagFormBean(value, value))
			.collect(Collectors.collectingAndThen(Collectors.toList(), Collections::unmodifiableList));

	/** �����X�g */
	@Getter
	private List<SimpleTagFormBean> dayList = IntStream
			.rangeClosed(1, 31)
			.mapToObj(value -> String.format("%02d", value))
			.map(value -> new SimpleTagFormBean(value, value))
			.collect(Collectors.collectingAndThen(Collectors.toList(), Collections::unmodifiableList));

	/** �����L���� */
	@Getter @Setter
	private String sdbDt;

	/** �j�� */
	@Getter @Setter
	private String sdbDtWeek;

	/** �����L���� */
	@Getter @Setter
	private String sdbStaff;

	/** �L�� */
	@Getter @Setter
	private String article;

	/** �s���� */
	@Getter @Setter
	private String event;

	/** �e�����R�[�h */
	@Getter @Setter
	private String parentUser;

	/** �������ʃ��b�Z�[�W */
	@Getter @Setter
	private String resultMessage;
}
