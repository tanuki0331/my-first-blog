/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All rights reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.allkochi.action;

import java.io.IOException;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAjaxServlet;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.groupware.db.entity.DataGW_SSFromKomu_ResponseItemEntity;
import jp.co.systemd.tnavi.groupware.db.service.DataGW_SSFromKomu_Service;

/**
 * <PRE>
 * �w�Z��������(���m����) �s�����p AjaxAction.
 * </PRE>
 *
 * <p>
 * <B>Create</B> 2019.03.19 BY SDC tanaka<BR>
 * </p>
 * @author SDC
 * @since 1.0
 */
public class Detail32174000AjaxAction extends AbstractAjaxServlet{

	/** log4j */
	private static final Log log = LogFactory.getLog(Detail32174000AjaxAction.class);

	@Override
	protected Object processAjaxRequest(HttpServletRequest request,SystemInfoBean sessionBean) throws IOException, ServletException {

		log.info("�y��ʁz�w�Z��������(���m����) �s�����p START");

		// ���N�G�X�g�p�����[�^�擾
		String sdbDt = request.getParameter("sdbDt");

		// GW�A�g �w�Z�s���擾 ���s
		DataGW_SSFromKomu_Service service = new DataGW_SSFromKomu_Service();
		service.setRequest(request);
		service.setSessionBean(sessionBean);
		service.setKeyword("%�s��%");
		service.setWeekStartDate(sdbDt);
		service.setWeekEndDate(sdbDt);
		service.execute();

		// ���ʎ擾
		Object[] result = new Object[]{"", ""};
		DataGW_SSFromKomu_ResponseItemEntity responsEntity = service.getDataGW_SSFromKomu_ResponseItemEntity();
		if (responsEntity != null) {
			result[0] = responsEntity.getResult_code();
			LinkedHashMap<String, String> responsDataMap = responsEntity.getData();
			if (responsDataMap != null && responsDataMap.containsKey(sdbDt)) {
				result[1] = responsDataMap.get(sdbDt);
			}
		}

		log.info("�y��ʁz�w�Z��������(���m����) �s�����p END");
		return result;
	}

}
