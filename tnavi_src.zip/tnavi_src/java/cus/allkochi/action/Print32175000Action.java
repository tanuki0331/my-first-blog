/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All rights reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.allkochi.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.allkochi.db.service.Print32175000Service;
import jp.co.systemd.tnavi.cus.allkochi.formbean.Print32175000FormBean;
import jp.co.systemd.tnavi.cus.allkochi.print.Print32175000_CR;

/**
 * <PRE>
 * �w�Z�������(���m����) ��� Action.
 * </PRE>
 *
 * <p>
 * <B>Create</B> 2019.03.19 BY SDC tanaka<BR>
 * </p>
 * @author SDC
 * @since 1.0
 */
public class Print32175000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32175000Action.class);

	/** ���[�^�C�g�� */
	private static final String TITLE = "�w�Z�������";

	/** �t�H�[���t�@�C���� */
	private static final String FORM_FILE_01 = "cus/allkochi/form32175000_01.cfx";
	private static final String FORM_FILE_02 = "cus/allkochi/form32175000_02.cfx";

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request, HttpServletResponse response,
			SystemInfoBean sessionBean) {

		log.info("�y��ʁz�w�Z�������(���m����) ��� START");

		// FormBean����
		Print32175000FormBean formBean = (Print32175000FormBean) copyRequestParamToFormBean(request, new Print32175000FormBean());

		// ���[�o�͏����擾
		Print32175000Service service = new Print32175000Service(sessionBean, formBean);
		service.execute();

		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR(TITLE);
		try{
			// ����N���X����
			Print32175000_CR print = new Print32175000_CR(sessionBean, service.getFormBean());
			print.setPdfDocumentBeanCR(pdfDocumentBeanCR);

			// ������s
			print.execute(StringUtils.equals(sessionBean.getUseSchoolkind(), "6") ? FORM_FILE_02 : FORM_FILE_01);
			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("�y��ʁz�w�Z�������(���m����) ��� END");
		return null;
	}

	@Override
	protected Log getLogClass() {
		return log;
	}
}
