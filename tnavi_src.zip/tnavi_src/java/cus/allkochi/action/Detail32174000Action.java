/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2019 SystemD Inc. All rights reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.allkochi.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.allkochi.db.service.Detail32174000Service;
import jp.co.systemd.tnavi.cus.allkochi.formbean.Detail32174000FormBean;;

/**
 * <PRE>
 * �w�Z��������(���m����) �ڍ� Action.
 * </PRE>
 *
 * <p>
 * <B>Create</B> 2019.03.19 BY SDC tanaka<BR>
 * </p>
 * @author SDC
 * @since 1.0
 */
public class Detail32174000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Detail32174000Action.class);

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request, HttpServletResponse response,
			SystemInfoBean sessionBean) {

		log.info("�y��ʁz�w�Z��������(���m����) �ڍ� START");

		// FormBean����
		Detail32174000FormBean formBean = new Detail32174000FormBean();

		// �����L����
		if (request.getParameter("sdbDt") != null) {
			formBean.setSdbDt(request.getParameter("sdbDt"));
		} else {
			formBean.setSdbDt(DateUtility.getSystemDate());
		}

		// ��������
		Detail32174000Service service = new Detail32174000Service(sessionBean, formBean);
		service.execute();

		// FormBean�ݒ�
		request.setAttribute("FORM_BEAN", service.getFormBean());

		log.info("�y��ʁz�w�Z��������(���m����) �ڍ� END");
		return null;
	}

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return false;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return true;
	}
}
