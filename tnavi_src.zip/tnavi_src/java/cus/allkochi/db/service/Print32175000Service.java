package jp.co.systemd.tnavi.cus.allkochi.db.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.allkochi.db.entity.Data32175000_SchoolDiaryEntity;
import jp.co.systemd.tnavi.cus.allkochi.db.entity.Data32175000_StudentCountEntity;
import jp.co.systemd.tnavi.cus.allkochi.db.entity.Data32175000_UserEntity;
import jp.co.systemd.tnavi.cus.allkochi.formbean.Print32175000FormBean;
import lombok.Getter;

/**
 * <PRE>
 * �w�Z�������(���m����) ��� Service.
 * </PRE>
 *
 * <p>
 * <B>Create</B> 2019.03.19 BY SDC tanaka<BR>
 * </p>
 * @author SDC
 * @since 1.0
 */
public class Print32175000Service  extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print32175000Service.class);

	/** �����R�[�h */
	private final String user;

	/** �敪�Q */
	private final String useKind2;

	/** �w�Z��� */
	private final String schoolKind;

	/** �����G���e�B�e�B */
	private final Data32175000_UserEntity userEntity;

	/** �`������t���O */
	private final boolean gimuFlg;

	/** �N�x�J�n���� */
	private final String nendoStartDt;

	/** FormBean */
	@Getter
	private Print32175000FormBean formBean;

	/**
	 * �R���X�g���N�^
	 *
	 * @param sessionBean �Z�b�V����
	 * @param formBean FormBean
	 */
	public Print32175000Service(SystemInfoBean sessionBean, Print32175000FormBean formBean) {
		this.user = sessionBean.getUserCode();
		this.useKind2 = sessionBean.getUseKind2();
		this.schoolKind = sessionBean.getUseSchoolkind();
		this.gimuFlg = StringUtils.equals(this.schoolKind, "6");
		this.userEntity = new Data32175000_UserEntity();
		this.userEntity.setUse_user(this.user);
		this.userEntity.setUse_kind2(this.useKind2);
		this.userEntity.setUse_schoolkind(this.schoolKind);
		this.nendoStartDt = sessionBean.getSystemNendoStartDate().substring(0, 4);
		this.formBean = formBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		try {
			// �����R�[�h
			String user = this.user;
			// �������X�g
			List<Data32175000_UserEntity> userList = new ArrayList<Data32175000_UserEntity>();
			userList.add(this.userEntity);

			// �`������w�Z�̏ꍇ
			if (this.gimuFlg) {
				user = selectSysUserParent();
				userList = selectSysUserChild(user);
			}

			// �w�Z�����e�[�u�� �擾
			List<Data32175000_SchoolDiaryEntity> schoolDiaryList = selectSchoolDiary(user);

			// �o�͑Ώۓ����ƂɌJ��Ԃ�
			List<Data32175000_SchoolDiaryEntity> printList = new ArrayList<Data32175000_SchoolDiaryEntity>();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Calendar calendar = Calendar.getInstance();
	        calendar.setTime(sdf.parse(this.formBean.getOutTargetFrom()));
			while (true) {
				// �Ώۓ�
				String targetDt = sdf.format(calendar.getTime());
				// �N�x
				String nendo = targetDt.substring(4).compareTo(this.nendoStartDt) >= 0 ?
						targetDt.substring(0, 4) : String.valueOf(Integer.parseInt(targetDt.substring(0, 4)) - 1);

				// �w�Z�������X�g���A�Ώۓ��f�[�^�擾
				Data32175000_SchoolDiaryEntity entity = schoolDiaryList.stream()
						.filter(e -> StringUtils.equals(targetDt, e.getSdbDt()))
						.findFirst()
						.orElse(null);

				// �Ώۓ��f�[�^�����݂��Ȃ��ꍇ
				if (entity == null) {
					entity = new Data32175000_SchoolDiaryEntity();
					entity.setSdbDt(targetDt);
				}

				// �]�ғ�
				entity.setMoveIn(selectStudent(userList, nendo, targetDt));
				// �]�ފw
				entity.setMoveOut(selectRegister(userList, nendo, targetDt));
				// ���k�����X�g
				entity.setStudentCountList(selectCount(userList, nendo, targetDt));

				// ������X�g�ɒǉ�
				printList.add(entity);

				// �o�͑Ώۓ�TO�ƈ�v����ΏI��
				if (StringUtils.equals(entity.getSdbDt(), this.formBean.getOutTargetTo())) {
					break;
				}
				// �P�����Z
		        calendar.add(Calendar.DATE, 1);
			}
			this.formBean.setPrintList(printList);

		} catch (Exception e) {
			log.error("�w�Z�������(���m����) ��� DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
	}

	/**
	 * �V�X�e�����[�U�[�Ǘ��}�X�^(�e�����R�[�h) �擾
	 *
	 * @return �e�����R�[�h
	 */
	private String selectSysUserParent() {
		Object[] param = {
				this.user
		};
		QueryManager qm = new QueryManager("cus/allkochi/getData32175000_sysuser.sql", param, String.class);
		return (String) this.executeQuery(qm);
	}

	/**
	 * �V�X�e�����[�U�[�Ǘ��}�X�^(�q����) �擾
	 *
	 * @param user �����R�[�h
	 * @return �q�������X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data32175000_UserEntity> selectSysUserChild(String user) {
		Object[] param = {
				user
		};
		QueryManager qm = new QueryManager("cus/allkochi/getData32175000_sysuserChild.sql", param, Data32175000_UserEntity.class);
		return (List<Data32175000_UserEntity>) this.executeQuery(qm);
	}

	/**
	 * �w�Z�����e�[�u�� �擾
	 *
	 * @param user �����R�[�h
	 * @return �w�Z�������X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data32175000_SchoolDiaryEntity> selectSchoolDiary(String user) {
		Object[] param = {
				user,
				this.formBean.getOutTargetFrom(),
				this.formBean.getOutTargetTo()
		};
		QueryManager qm = new QueryManager("cus/allkochi/getData32175000_schooldiary.sql", param, Data32175000_SchoolDiaryEntity.class);
		return (List<Data32175000_SchoolDiaryEntity>) this.executeQuery(qm);
	}

	/**
	 * ���k�e�[�u���i�]�ғ��j �擾
	 *
	 * @param userList �������X�g
	 * @param nendo �N�x
	 * @param targetDt �Ώۓ�
	 * @return �]�ғ�
	 */
	@SuppressWarnings("unchecked")
	private String selectStudent(List<Data32175000_UserEntity> userList, String nendo, String targetDt) {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		for (Data32175000_UserEntity userEntity : userList) {
			Object[] param = {
					userEntity.getUse_user(),
					nendo,
					targetDt,
					this.gimuFlg && StringUtils.equals(userEntity.getUse_kind2(), "2") ? 6 : 0
			};
			QueryManager qm = new QueryManager("cus/allkochi/getData32175000_student.sql", param);
			List<Map<String, String>> list = (List<Map<String, String>>) this.executeQuery(qm);
			if (list != null) {
				result.addAll(list);
			}
		}
		return result.stream().map(e -> e.get("move")).collect(Collectors.joining("\r\n"));
	}

	/**
	 * �ݐЏ󋵃e�[�u���i�]�ފw�j �擾
	 *
	 * @param userList �������X�g
	 * @param nendo �N�x
	 * @param targetDt �Ώۓ�
	 * @return �]�ފw
	 */
	@SuppressWarnings("unchecked")
	private String selectRegister(List<Data32175000_UserEntity> userList, String nendo, String targetDt) {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		for (Data32175000_UserEntity userEntity : userList) {
			Object[] param = {
					userEntity.getUse_user(),
					nendo,
					targetDt,
					this.gimuFlg && StringUtils.equals(userEntity.getUse_kind2(), "2") ? 6 : 0
			};
			QueryManager qm = new QueryManager("cus/allkochi/getData32175000_register.sql", param);
			List<Map<String, String>> list = (List<Map<String, String>>) this.executeQuery(qm);
			if (list != null) {
				result.addAll(list);
			}
		}
		return result.stream().map(e -> e.get("move")).collect(Collectors.joining("\r\n"));
	}

	/**
	 * �ݐЏ󋵃e�[�u���i���k���j �擾
	 *
	 * @param userList �������X�g
	 * @param nendo �N�x
	 * @param targetDt �Ώۓ�
	 * @return �]�ފw���X�g
	 */
	@SuppressWarnings("unchecked")
	private List<Data32175000_StudentCountEntity> selectCount(List<Data32175000_UserEntity> userList, String nendo, String targetDt) {
		List<Data32175000_StudentCountEntity> result = new ArrayList<Data32175000_StudentCountEntity>();
		for (Data32175000_UserEntity userEntity : userList) {
			Object[] param = {
					userEntity.getUse_user(),
					nendo,
					targetDt,
					this.gimuFlg && StringUtils.equals(userEntity.getUse_kind2(), "2") ? 6 : 0
			};
			QueryManager qm = new QueryManager("cus/allkochi/getData32175000_studentCount.sql", param, Data32175000_StudentCountEntity.class);
			List<Data32175000_StudentCountEntity> list = (List<Data32175000_StudentCountEntity>) this.executeQuery(qm);
			result.addAll(list);
		}
		return result;
	}
}
