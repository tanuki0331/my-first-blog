package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.List;

import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_StudentListEntity;
import lombok.Getter;
import lombok.Setter;

public class List32170000FormBean {

	/** �\���Ώۂ̎������k���List */
	@Getter @Setter
	private List<Data32170000_StudentListEntity> studentList = null;

}
