package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.Map;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z) �ϓ_�E�]���p FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31954000CmlguideFormBean {

	public final static String DEFALUT_VALUE = "";

	/** �ʒm�\�p���Ȗ� */
	private String si_reportname;

	/** ���ȃR�[�h */
	private String si_item;

	/** �ϓ_�R�[�h */
	private String srivt_srivtcode;

	/** �ʊϓ_ */
	private String srvpv_indivivp;

	/** �o�͎����R�[�h */
	private String srivt_goptcode;

	/** �]���l */
	private Map<String, String> srvpe_reportdisplay;

	/** �m��]�� */
	private String srevl_display;

	/** �L�q�]�� */
	private String srev_descript;

	public String getSi_reportname() {
		return si_reportname;
	}

	public void setSi_reportname(String si_reportname) {
		this.si_reportname = si_reportname;
	}

	public String getSi_item() {
		return si_item;
	}

	public void setSi_item(String si_item) {
		this.si_item = si_item;
	}

	public String getSrivt_srivtcode() {
		return srivt_srivtcode;
	}

	public void setSrivt_srivtcode(String srivt_srivtcode) {
		this.srivt_srivtcode = srivt_srivtcode;
	}

	public String getSrvpv_indivivp() {
		return srvpv_indivivp;
	}

	public void setSrvpv_indivivp(String srvpv_indivivp) {
		this.srvpv_indivivp = srvpv_indivivp;
	}

	public String getSrivt_goptcode() {
		return srivt_goptcode;
	}

	public void setSrivt_goptcode(String srivt_goptcode) {
		this.srivt_goptcode = srivt_goptcode;
	}

	public Map<String, String> getSrvpe_reportdisplay() {
		return srvpe_reportdisplay;
	}

	public void setSrvpe_reportdisplay(Map<String, String> srvpe_reportdisplay) {
		this.srvpe_reportdisplay = srvpe_reportdisplay;
	}

	public String getSrevl_display() {
		return srevl_display;
	}

	public void setSrevl_display(String srevl_display) {
		this.srevl_display = srevl_display;
	}

	public String getSrev_descript() {
		return srev_descript;
	}

	public void setSrev_descript(String srev_descript) {
		this.srev_descript = srev_descript;
	}
}
