package jp.co.systemd.tnavi.cus.izunokuni.formbean;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z) �ϓ_�E�]���p FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31953000FindingsFormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �o�͎����R�[�h
	 */
	private String sravt_goptcode;

	/**
	 * ���ڃR�[�h
	 */
	private String sravt_sravtcode;

	/**
	 * �ʍ���
	 */
	private String sravv_indivivp;

	/**
	 * �ʒm�\�\���p�]��
	 */
	private String srace_reportdisplay;

	/**
	 * �L���\������
	 */
	private String srem_em;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getSravt_goptcode() {
		return sravt_goptcode;
	}

	public void setSravt_goptcode(String sravt_goptcode) {
		this.sravt_goptcode = sravt_goptcode;
	}

	public String getSravt_sravtcode() {
		return sravt_sravtcode;
	}

	public void setSravt_sravtcode(String sravt_sravtcode) {
		this.sravt_sravtcode = sravt_sravtcode;
	}

	public String getSravv_indivivp() {
		return sravv_indivivp;
	}

	public void setSravv_indivivp(String sravv_indivivp) {
		this.sravv_indivivp = sravv_indivivp;
	}

	public String getSrace_reportdisplay() {
		return srace_reportdisplay;
	}

	public void setSrace_reportdisplay(String srace_reportdisplay) {
		this.srace_reportdisplay = srace_reportdisplay;
	}

	public String getSrem_em() {
		return srem_em;
	}

	public void setSrem_em(String srem_em) {
		this.srem_em = srem_em;
	}
}
