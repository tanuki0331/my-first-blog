package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.common.formbean.AbstractStudentListFormBean;
import jp.co.systemd.tnavi.common.formbean.StudentListColumnInfo;

public class StudentList32170000FormBean  extends AbstractStudentListFormBean{

	/**
	 * <PRE>
	 * �R���X�g���N�^.
	 * </PRE>
	 */
	public StudentList32170000FormBean(){
		//�w�Дԍ������̐��k�̃L�[�i���ۂ́A�����R�[�h�Ɗw�Дԍ��j
		List<String> keyList = new ArrayList<String>();
		keyList.add("stu_user");
		keyList.add("stu_stucode");

		super.addColumnInfoList(new StudentListColumnInfo("�I��"        ,SELECT_CHECK_COLUMN_NAME_DB     	,keyList,true,"center",true, false,null));
		super.addColumnInfoList(new StudentListColumnInfo("�N"          ,"hmr_glade"                         	,null  ,true,"center" ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("�g"          ,"hmr_class"                     		,null  ,true,"center" ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("��"          ,"cls_number"                    		,keyList,true,"center",false,true,"LI1"));
		super.addColumnInfoList(new StudentListColumnInfo("���k����"    ,"st4_name"                      		,null  ,true, "left"  ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("�ӂ肪��"    ,"st4_hkana"                     		,null  ,true, "left"  ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("����"          ,"stu_sex"                       	,null  ,false,null   ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("����"          ,"stu_sex_name"                  	,null  ,true, "center",false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("���N����"    ,STU_BIRTH_COLUMN_NAME_DB        	,null  ,false, null  ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("���N����"    ,STU_BIRTH_WAREKI_COLUMN_NAME_DB 	,null  ,false, "left"  ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("���k�ԍ�"	,"stu_stucode"							,null	,false,	"center", false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("�w���v�^���","ghc_kind"                     		,null  ,false,null   ,false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("�w���v�^���","ghc_name"          		     		,null  ,false, "center"  , false,false,null));
		super.addColumnInfoList(new StudentListColumnInfo("�����R�[�h"  ,"stu_user"                      		,null  ,false,null   , false,false,null));
	}

}
