package jp.co.systemd.tnavi.cus.izunokuni.formbean;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s ���w�Z) ��� ���k��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.05.26 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31949000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String stuGrade = DEFALUT_VALUE;

	/** �g **/
	private String stuClass = DEFALUT_VALUE;

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String stuNumber = DEFALUT_VALUE;

	/** �w�Дԍ� **/
	private String stuStucode = DEFALUT_VALUE;

	/** ���k�E�������� **/
	private String stuStuname = DEFALUT_VALUE;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getStuGrade() {
		return stuGrade;
	}

	public void setStuGrade(String stuGrade) {
		this.stuGrade = stuGrade;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getStuNumber() {
		return stuNumber;
	}

	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getStuStucode() {
		return stuStucode;
	}

	public void setStuStucode(String stuStucode) {
		this.stuStucode = stuStucode;
	}

	public String getStuStuname() {
		return stuStuname;
	}

	public void setStuStuname(String stuStuname) {
		this.stuStuname = stuStuname;
	}

}
