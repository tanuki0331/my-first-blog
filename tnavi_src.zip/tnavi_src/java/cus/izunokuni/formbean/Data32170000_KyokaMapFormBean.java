package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_KyokaListEntity;
import lombok.Getter;
import lombok.Setter;

public class Data32170000_KyokaMapFormBean {

	@Getter @Setter
	private String itemName = "";

	@Getter @Setter
	private List<Data32170000_KyokaListEntity> kyokaList = new ArrayList<Data32170000_KyokaListEntity>();

	@Getter @Setter
	private int kyokaListSize = 0;
	/** �Q�Ɛ��� �]��ID */
	@Getter @Setter
	private String gevl_gevlcode = "";
	/** �Q�Ɛ��� �]��(�\��) */
	@Getter @Setter
	private String gevl_display = "";
	/** �]��ID */
	@Getter @Setter
	private String sgev_gevlcode = "";
	/** �ύX���R */
	@Getter @Setter
	private String sgev_changememo = "";
	/** ���l */
	@Getter @Setter
	private String sgev_memo = "";
}
