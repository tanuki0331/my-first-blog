package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000EvalEntity;

/**
 * <PRE>
 * ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) ���� FormBean.
 * </PRE>
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Detail31951000ReportFormBean {

	public final static String DEFALUT_VALUE = "";
	
	/**
	 * ���ȃR�[�h
	 */
	private String itemCode = DEFALUT_VALUE;
	
	/**
	 * ���Ȗ�
	 */
	private String reportName = DEFALUT_VALUE;
	
	/**
	 * �L�q�]��
	 */
	private String descript = DEFALUT_VALUE;
	
	/**
	 * ���Ȗ��̊ϓ_�]��
	 */
	private List<Data31951000EvalEntity> evalList = new ArrayList<Data31951000EvalEntity>();
	
	/**
	 * �R���X�g���N�^
	 * @param itemCode ���ȃR�[�h
	 * @param reportName ���Ȗ���
	 * @param descript �L�q�]��
	 */
	public Detail31951000ReportFormBean(String itemCode, String reportName, String descript) {
		super();
		this.itemCode = itemCode;
		this.reportName = reportName;
		this.descript = descript;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getDescript() {
		return descript;
	}

	public void setDescript(String descript) {
		this.descript = descript;
	}

	public List<Data31951000EvalEntity> getEvalList() {
		return evalList;
	}

	public void setEvalList(List<Data31951000EvalEntity> evalList) {
		this.evalList = evalList;
	}

	
	
}