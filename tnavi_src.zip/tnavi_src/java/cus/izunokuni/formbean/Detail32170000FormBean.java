package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_CmlguideattendrecordEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_GavtDataEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_GivtDataEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_GsatDataEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_RefEvaluationListEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_RefRatingListEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_StudentListEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_TextAreaSizeListEntity;
import lombok.Getter;
import lombok.Setter;

public class Detail32170000FormBean {

	public static final String MORAL = "ME";
	public static final String FOREIGNACT = "FE";
	public static final String TOTALACT_CONTENT = "TC";
	public static final String TOTALACT_VP = "TV";
	public static final String TOTALACT_EVAL = "TE";
	public static final String SPECIAL_ACT = "SE";
	public static final String ACT = "BE";
	public static final String COMMENT = "CE";

	/** ���݂̐��k��{��� */
	@Getter @Setter
	private Data32170000_StudentListEntity studentListEntity = null;

	/** ���k���X�g�̃T�C�Y */
	@Getter @Setter
	private int stuListSize = 0;

	/** �N�x(����) */
	@Getter @Setter
	private String year = "";

	/** �w���v�̔N�x */
	@Getter @Setter
	private String shidoyoryoNendo = "";

	/** �w���v�̃R�[�h */
	@Getter @Setter
	private String curcode = "";

	/** �𗬐�w�N */
	@Getter @Setter
	private String exc_glade = "";

	/** �𗬐�g */
	@Getter @Setter
	private String exc_class = "";

	@Getter @Setter
	private int stuIndex = 0;

	/** �������������k��Index **/
	@Getter @Setter
	private int currentStuIndex = 0;

	/** �������������k�̊w�Дԍ� **/
	@Getter @Setter
	private String currentStuCode = "";

	/** ���k�̋C�Â���� */
	@Getter @Setter
	private String comment;

	/** ���ʊ����̋L�^�̊������e */
	@Getter @Setter
	private String viewpoint = "";

	/** ���ȃ}�b�v */
	@Getter @Setter
	private Map<String , Data32170000_KyokaMapFormBean> kyokaMap = new LinkedHashMap<String , Data32170000_KyokaMapFormBean>();

	/** ���ȃ}�b�v�T�C�Y */
	@Getter @Setter
	private int kyokaMapSize = 0;

	/** �Q�Ɛ��ѕ]���}�b�v */
	@Getter @Setter
	private Map<String , Data32170000_RefEvaluationListEntity> refEvaluationMap = new LinkedHashMap<String , Data32170000_RefEvaluationListEntity>();

	/** �Q�Ɛ��ѕ]��}�b�v */
	@Getter @Setter
	private Map<String , Data32170000_RefRatingListEntity> refRatingMap = new LinkedHashMap<String , Data32170000_RefRatingListEntity>();

	@Getter @Setter
	private List<SimpleTagFormBean> estimateList = new ArrayList<SimpleTagFormBean>();

	@Getter @Setter
	private List<SimpleTagFormBean> evalList = new ArrayList<SimpleTagFormBean>();

	@Getter @Setter
	private List<Data32170000_GivtDataEntity> givtLanguageDataList = new ArrayList<Data32170000_GivtDataEntity>();

	@Getter @Setter
	private int givtLanguageDataListSize = 0;

	@Getter @Setter
	private boolean givtSynthesisFlg = false;

	@Getter @Setter
	private List<Data32170000_GsatDataEntity> gsatDataList = new ArrayList<Data32170000_GsatDataEntity>();
	@Getter @Setter
	private int gsatDataListSize = 0;

	@Getter @Setter
	private List<Data32170000_GavtDataEntity> gavtDataList = new ArrayList<Data32170000_GavtDataEntity>();
	@Getter @Setter
	private int gavtDataListSize = 0;

	@Getter @Setter
	private Map<String , Data32170000_TextAreaSizeListEntity> textAreaSizeMap = new LinkedHashMap<String , Data32170000_TextAreaSizeListEntity>();

	@Getter @Setter
	private List<Data32170000_TextAreaSizeListEntity> sgtasItemList = new ArrayList<Data32170000_TextAreaSizeListEntity>();
	@Getter @Setter
	private int sgtasItemListSize = 0;

	/** �s���̋L�^�]���l�@Tag�p */
	@Getter @Setter
	private List<SimpleTagFormBean> actList = new ArrayList<SimpleTagFormBean>();

	/** �e���ȁE���ʊ����E���������̋L�^ */
	@Getter @Setter
	private String sgicDescript = "";

	/** �o���̋L�^(�w���v�^) */
	@Getter @Setter
	private Data32170000_CmlguideattendrecordEntity cmlguideattendrecordEntity = null;

	/** �L�q�]���}�b�v */
	@Getter @Setter
	Map<String, String> hyokaMap = new LinkedHashMap<String, String>();

	@Getter @Setter
	private String resultMessage = "";

	/** �����I�Ȋw�K�̎��Ԃ̋L�^ �ϓ_�ێ��P�� */
	@Getter @Setter
	private String totalActMode = "";

	/** �Q�Ɛ��� �Q�ƌ��̏o�͎������ */
	@Getter @Setter
	private CmlguideoutputtermEntity refOutputterm = null;

}
