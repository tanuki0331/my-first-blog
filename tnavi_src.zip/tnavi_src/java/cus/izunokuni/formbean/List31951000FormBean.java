package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.List;

import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000StudentEntity;

/**
 * <PRE>
 * ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ꗗ FormBean.
 * </PRE>
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class List31951000FormBean {

	public final static String DEFALUT_VALUE = "";
	
	/** 
	 * �o�͎��� 
	 */
	private String goptcode;
	
	/**
	 * �ŏI�̒ʏ�w���t���O
	 */
	private boolean lastTermFlag = false;
	
	/**
	 * ���k���X�g
	 */
	private List<Data31951000StudentEntity> studentList;

	/** 
	 * �Ԏ����b�Z�[�W 
	 */
	private String redMessage = DEFALUT_VALUE;
	
	/** 
	 * �X�V���b�Z�[�W 
	 */
	private String updateMessage = DEFALUT_VALUE;

	public String getGoptcode() {
		return goptcode;
	}

	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}

	public boolean isLastTermFlag() {
		return lastTermFlag;
	}

	public void setLastTermFlag(boolean lastTermFlag) {
		this.lastTermFlag = lastTermFlag;
	}

	public List<Data31951000StudentEntity> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<Data31951000StudentEntity> studentList) {
		this.studentList = studentList;
	}

	public String getRedMessage() {
		return redMessage;
	}

	public void setRedMessage(String redMessage) {
		this.redMessage = redMessage;
	}

	public String getUpdateMessage() {
		return updateMessage;
	}

	public void setUpdateMessage(String updateMessage) {
		this.updateMessage = updateMessage;
	}

}