package jp.co.systemd.tnavi.cus.izunokuni.formbean;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z) �ϓ_�E�]���p FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31954000AttendValueFormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �o�͎����R�[�h
	 */
	private String gopt_goptcode;

	/**
	 * �o�͎�����
	 */
	private String gopt_name;

	/**
	 * �o�͏�
	 */
	private String gopt_order;

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;

	/**
	 * �w�N
	 */
	private String cls_glade;

	/**
	 * �o�Ȕԍ�
	 */
	private String cls_number;

	/**
	 * ���Ɠ���
	 */
	private Integer classcount;

	/**
	 * �o�Ȓ�~�i�o�Ȓ�~�E���������̓����j
	 */
	private Integer schoolkindcount;

	/**
	 * �o�Ȃ��ׂ�����
	 */
	private Integer mustcount;

	/**
	 * ���ȓ���
	 */
	private Integer absencecount;

	/**
	 * �o�ȓ���
	 */
	private Integer attendcount;

	/**
     * �x��
     */
    private Integer latecount;

    /**
     * ����
     */
    private Integer leavecount;

    /** �o�Ȃ̋L�^���l */
	private String rar_memo;

	public String getRar_memo() {
		return rar_memo;
	}

	public void setRar_memo(String rar_memo) {
		this.rar_memo = rar_memo;
	}

	public String getGopt_name() {
		return gopt_name;
	}
	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}
	public String getGopt_goptcode() {
		return gopt_goptcode;
	}
	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}
	public String getGopt_order() {
		return gopt_order;
	}
	public void setGopt_order(String gopt_order) {
		this.gopt_order = gopt_order;
	}
	public String getCls_glade() {
		return cls_glade;
	}
	public void setCls_glade(String cls_glade) {
		this.cls_glade = cls_glade;
	}
	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getCls_number() {
		return cls_number;
	}
	public void setCls_number(String cls_number) {
		this.cls_number = cls_number;
	}
	public Integer getClasscount() {
		return classcount;
	}
	public void setClasscount(Integer classcount) {
		this.classcount = classcount;
	}
	public Integer getSchoolkindcount() {
		return schoolkindcount;
	}
	public void setSchoolkindcount(Integer schoolkindcount) {
		this.schoolkindcount = schoolkindcount;
	}
	public Integer getMustcount() {
		return mustcount;
	}
	public void setMustcount(Integer mustcount) {
		this.mustcount = mustcount;
	}
	public Integer getAbsencecount() {
		return absencecount;
	}
	public void setAbsencecount(Integer absencecount) {
		this.absencecount = absencecount;
	}
	public Integer getAttendcount() {
		return attendcount;
	}
	public void setAttendcount(Integer attendcount) {
		this.attendcount = attendcount;
	}
	public Integer getLatecount() {
		return latecount;
	}
	public void setLatecount(Integer latecount) {
		this.latecount = latecount;
	}
	public Integer getLeavecount() {
		return leavecount;
	}
	public void setLeavecount(Integer leavecount) {
		this.leavecount = leavecount;
	}
}
