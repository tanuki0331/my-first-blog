package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000ScorptattendrecordEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000SpScorptactviewpointvalueEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000StudentEntity;

/**
 * <PRE>
 * ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) ���� FormBean.
 * </PRE>
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Detail31951000FormBean {

	public final static String DEFALUT_VALUE = "";
	
	/**
	 * �A�N�e�B�u�ȃ^�u�̃C���f�b�N�X
	 */
	private String activeTabIndex = "0";

	/**
	 * �o�͎���
	 */
	private String goptcode = DEFALUT_VALUE;
	
	/**
	 * �o�͎�������
	 */
	private String goptname = DEFALUT_VALUE;
	
	/**
	 * ���k���
	 */
	private Data31951000StudentEntity student;
	
	/**
	 * �擪�̐��k�̊w�Дԍ�
	 */
	private String firstStucode = DEFALUT_VALUE;
	
	/**
	 * �ЂƂO�̐��k�̊w�Дԍ�
	 */
	private String prevStucode = DEFALUT_VALUE;
	
	/**
	 * �ЂƂ�̐��k�̊w�Дԍ�
	 */
	private String nextStucode = DEFALUT_VALUE;
	
	/**
	 * �ŏI�̐��k�̊w�Дԍ�
	 */
	private String lastStucode = DEFALUT_VALUE;

	/**
	 * ���Ȗ��̐���Map�i�L�[�F���ȃR�[�h�j
	 */
	private Map<String, Detail31951000ReportFormBean> reportMap = new LinkedHashMap<String, Detail31951000ReportFormBean>();
	
	/**
	 * ���p���Ɏw�肷��w���̃��X�g
	 */
	private List<SimpleTagFormBean> termList = new ArrayList<SimpleTagFormBean>();
	
	/**
	 * ���Ȋϓ_�]���Z���N�g�{�b�N�X�p�̃��X�g
	 */
	private List<SimpleTagFormBean> mstSpScorptviewpointestimateList = new ArrayList<SimpleTagFormBean>();
	
	/**
	 * �s���̂�����̕]���Z���N�g�{�b�N�X�p�̃��X�g
	 */
	private List<SimpleTagFormBean> mstSpScorptactestimateList = new ArrayList<SimpleTagFormBean>();
	
	/**
	 * �������̓��e���i�[����Map�i�L�[�F���ȃR�[�h�j
	 */
	private Map<String, String> spScorptcommentMap = new HashMap<String, String>();
	
	/**
	 * �ꗗ�f�[�^(�s���̂�����A�]��)�̃��X�g
	 */
	private List<Data31951000SpScorptactviewpointvalueEntity> spScorptactviewpointvalueList = new ArrayList<Data31951000SpScorptactviewpointvalueEntity>();
	
	/**
	 * �s���̋L�^�L�q�]��
	 */
	private String srad_descript = DEFALUT_VALUE;
	
	/**
	 * �o�����̃��X�g
	 */
	private List<Data31951000ScorptattendrecordEntity> attendList = new ArrayList<Data31951000ScorptattendrecordEntity>();
	
	/** 
	 * �X�V���b�Z�[�W 
	 */
	private String updateMessage = DEFALUT_VALUE;

	
	public String getActiveTabIndex() {
		return activeTabIndex;
	}

	public void setActiveTabIndex(String activeTabIndex) {
		this.activeTabIndex = activeTabIndex;
	}

	public String getGoptcode() {
		return goptcode;
	}

	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}

	public String getGoptname() {
		return goptname;
	}

	public void setGoptname(String goptname) {
		this.goptname = goptname;
	}

	public Data31951000StudentEntity getStudent() {
		return student;
	}

	public void setStudent(Data31951000StudentEntity student) {
		this.student = student;
	}

	public String getFirstStucode() {
		return firstStucode;
	}

	public void setFirstStucode(String firstStucode) {
		this.firstStucode = firstStucode;
	}

	public String getPrevStucode() {
		return prevStucode;
	}

	public void setPrevStucode(String prevStucode) {
		this.prevStucode = prevStucode;
	}

	public String getNextStucode() {
		return nextStucode;
	}

	public void setNextStucode(String nextStucode) {
		this.nextStucode = nextStucode;
	}

	public String getLastStucode() {
		return lastStucode;
	}

	public void setLastStucode(String lastStucode) {
		this.lastStucode = lastStucode;
	}

	public Map<String, Detail31951000ReportFormBean> getReportMap() {
		return reportMap;
	}

	public void setReportMap(Map<String, Detail31951000ReportFormBean> reportMap) {
		this.reportMap = reportMap;
	}

	public List<SimpleTagFormBean> getTermList() {
		return termList;
	}

	public void setTermList(List<SimpleTagFormBean> termList) {
		this.termList = termList;
	}

	public List<SimpleTagFormBean> getMstSpScorptviewpointestimateList() {
		return mstSpScorptviewpointestimateList;
	}

	public void setMstSpScorptviewpointestimateList(List<SimpleTagFormBean> mstSpScorptviewpointestimateList) {
		this.mstSpScorptviewpointestimateList = mstSpScorptviewpointestimateList;
	}

	public List<SimpleTagFormBean> getMstSpScorptactestimateList() {
		return mstSpScorptactestimateList;
	}

	public void setMstSpScorptactestimateList(List<SimpleTagFormBean> mstSpScorptactestimateList) {
		this.mstSpScorptactestimateList = mstSpScorptactestimateList;
	}

	public Map<String, String> getSpScorptcommentMap() {
		return spScorptcommentMap;
	}

	public void setSpScorptcommentMap(Map<String, String> spScorptcommentMap) {
		this.spScorptcommentMap = spScorptcommentMap;
	}

	public List<Data31951000SpScorptactviewpointvalueEntity> getSpScorptactviewpointvalueList() {
		return spScorptactviewpointvalueList;
	}

	public void setSpScorptactviewpointvalueList(
			List<Data31951000SpScorptactviewpointvalueEntity> spScorptactviewpointvalueList) {
		this.spScorptactviewpointvalueList = spScorptactviewpointvalueList;
	}

	public String getSrad_descript() {
		return srad_descript;
	}

	public void setSrad_descript(String srad_descript) {
		this.srad_descript = srad_descript;
	}

	public List<Data31951000ScorptattendrecordEntity> getAttendList() {
		return attendList;
	}

	public void setAttendList(List<Data31951000ScorptattendrecordEntity> attendList) {
		this.attendList = attendList;
	}

	public String getUpdateMessage() {
		return updateMessage;
	}

	public void setUpdateMessage(String updateMessage) {
		this.updateMessage = updateMessage;
	}
	
	
}