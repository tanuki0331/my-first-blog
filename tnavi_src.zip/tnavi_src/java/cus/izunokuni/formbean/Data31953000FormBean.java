package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_ItemViewScoreEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_ScorptcommontextEntity;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z���ʎx���w��) ��� ���k��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31953000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String stuGrade = DEFALUT_VALUE;

	/** �g **/
	private String stuClass = DEFALUT_VALUE;

	/** �N���X�ԍ� */
	private String stuClsno = DEFALUT_VALUE;

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String stuNumber = DEFALUT_VALUE;

	/** �w�Дԍ� **/
	private String stuStucode = DEFALUT_VALUE;

	/** ���k�E�������� **/
	private String stuStuname = DEFALUT_VALUE;

	/** ���k�E��������(�C����) **/
	private String stuStunameDeed = DEFALUT_VALUE;

	/** ���N���� **/
	private String stuBirth = DEFALUT_VALUE;

	/** ����ڕW (tbl_scorptcommontext) */
	private List<Data31953000_ScorptcommontextEntity> scorptCommontextEntityList;

	/** �ϓ_���FormBean */
	private Map<String,Data31953000CmlguideFormBean> cmlguideFormBeanList;
	/** ���ȕʊϓ_�f�[�^List */
	private List<Data31953000_ItemViewScoreEntity> itemViewScoreList;

	/** �����]�� */
	private String srcom_comment_G1;
	private String srcom_comment_G2;
	private String srcom_comment_G3;

	/** �������FormBean */
	private List<Data31953000FindingsFormBean> findingFormBeanList;

	/** �o�ȏ�� */
	private Map<String,Data31953000AttendValueFormBean> attendValueFormBeanList;

	/** �s���̂�����(�L��) */
	private String manifestActionMemo = DEFALUT_VALUE;

	/** �S�C���� */
	private List<String> teacherNameList;

	/** �L���\������ */
	private String srem_em = DEFALUT_VALUE;

	public List<String> getTeacherNameList() {
		return teacherNameList;
	}

	public void setTeacherNameList(List<String> teacherNameList) {
		this.teacherNameList = teacherNameList;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getStuGrade() {
		return stuGrade;
	}

	public void setStuGrade(String stuGrade) {
		this.stuGrade = stuGrade;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getStuClsno() {
		return stuClsno;
	}

	public void setStuClsno(String stuClsno) {
		this.stuClsno = stuClsno;
	}

	public String getStuNumber() {
		return stuNumber;
	}

	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getStuStucode() {
		return stuStucode;
	}

	public void setStuStucode(String stuStucode) {
		this.stuStucode = stuStucode;
	}

	public String getStuStuname() {
		return stuStuname;
	}

	public void setStuStuname(String stuStuname) {
		this.stuStuname = stuStuname;
	}

	public String getStuStunameDeed() {
		return stuStunameDeed;
	}

	public void setStuStunameDeed(String stuStunameDeed) {
		this.stuStunameDeed = stuStunameDeed;
	}

	public String getStuBirth() {
		return stuBirth;
	}

	public void setStuBirth(String stuBirth) {
		this.stuBirth = stuBirth;
	}

	public List<Data31953000_ScorptcommontextEntity> getScorptCommontextEntityList() {
		return scorptCommontextEntityList;
	}

	public void setScorptCommontextEntityList(List<Data31953000_ScorptcommontextEntity> scorptCommontextEntityList) {
		this.scorptCommontextEntityList = scorptCommontextEntityList;
	}

	public Map<String, Data31953000CmlguideFormBean> getCmlguideFormBeanList() {
		return cmlguideFormBeanList;
	}

	public void setCmlguideFormBeanList(Map<String, Data31953000CmlguideFormBean> cmlguideFormBeanList) {
		this.cmlguideFormBeanList = cmlguideFormBeanList;
	}

	public String getSrcom_comment_G1() {
		return srcom_comment_G1;
	}

	public void setSrcom_comment_G1(String srcom_comment_G1) {
		this.srcom_comment_G1 = srcom_comment_G1;
	}

	public String getSrcom_comment_G2() {
		return srcom_comment_G2;
	}

	public void setSrcom_comment_G2(String srcom_comment_G2) {
		this.srcom_comment_G2 = srcom_comment_G2;
	}

	public String getSrcom_comment_G3() {
		return srcom_comment_G3;
	}

	public void setSrcom_comment_G3(String srcom_comment_G3) {
		this.srcom_comment_G3 = srcom_comment_G3;
	}

	public List<Data31953000_ItemViewScoreEntity> getItemViewScoreList() {
		return itemViewScoreList;
	}

	public void setItemViewScoreList(List<Data31953000_ItemViewScoreEntity> itemViewScoreList) {
		this.itemViewScoreList = itemViewScoreList;
	}

	public List<Data31953000FindingsFormBean> getFindingFormBeanList() {
		return findingFormBeanList;
	}

	public void setFindingFormBeanList(List<Data31953000FindingsFormBean> findingFormBeanList) {
		this.findingFormBeanList = findingFormBeanList;
	}

	public Map<String, Data31953000AttendValueFormBean> getAttendValueFormBeanList() {
		return attendValueFormBeanList;
	}

	public void setAttendValueFormBeanList(Map<String, Data31953000AttendValueFormBean> attendValueFormBeanList) {
		this.attendValueFormBeanList = attendValueFormBeanList;
	}

	public String getManifestActionMemo() {
		return manifestActionMemo;
	}

	public void setManifestActionMemo(String manifestActionMemo) {
		this.manifestActionMemo = manifestActionMemo;
	}

	public String getSrem_em() {
		return srem_em;
	}

	public void setSrem_em(String srem_em) {
		this.srem_em = srem_em;
	}
}
