package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.List;
import java.util.Map;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchhi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31954000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C�����t */
	private String endDate = DEFALUT_VALUE;

	/** ����i�\���j�\���t���O */
	private boolean output_cover;

	/** ����i�w�K�̂�����j�\���t���O */
	private boolean output_page1;

	/** ����i�������j�\���t���O */
	private boolean output_page2;

	/** ����i���\���j�\���t���O */
	private boolean output_page3;

	/** �I���؏��\���t���O */
	private boolean output_deed;

	/** �o�͑Ώې��k���List */
	private String[] stucodeArray;

	/** ���k���̐��k��� */
	private Map<String,Data31954000FormBean> studentMap;

	/** �Z�̓C���[�W */
	byte[] schoolStampImage;

	/** �Z����C���[�W */
	byte[] schoolPrincipalStampImage;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;
	/** �Z������ */
	private String principalNameDeed = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameO = DEFALUT_VALUE;

	/** �S�C���� */
	private List<String> teacherNameList;

	/** ����p���k��� */
	private List<Data31954000FormBean> data31954000FormBeanList;

	/** ���X�g */
	private List<String> termArray;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_page1() {
		return output_page1;
	}

	public void setOutput_page1(boolean output_page1) {
		this.output_page1 = output_page1;
	}

	public boolean isOutput_page2() {
		return output_page2;
	}

	public void setOutput_page2(boolean output_page2) {
		this.output_page2 = output_page2;
	}

	public boolean isOutput_page3() {
		return output_page3;
	}

	public void setOutput_page3(boolean output_page3) {
		this.output_page3 = output_page3;
	}

	public boolean isOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(boolean output_deed) {
		this.output_deed = output_deed;
	}

	public Map<String, Data31954000FormBean> getStudentMap() {
		return studentMap;
	}

	public void setStudentMap(Map<String, Data31954000FormBean> studentMap) {
		this.studentMap = studentMap;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getSchoolNameO() {
		return schoolNameO;
	}

	public void setSchoolNameO(String schoolNameO) {
		this.schoolNameO = schoolNameO;
	}

	public List<String> getTeacherNameList() {
		return teacherNameList;
	}

	public void setTeacherNameList(List<String> teacherNameList) {
		this.teacherNameList = teacherNameList;
	}

	public List<Data31954000FormBean> getData31954000FormBeanList() {
		return data31954000FormBeanList;
	}

	public void setData31954000FormBeanList(List<Data31954000FormBean> data31954000FormBeanList) {
		this.data31954000FormBeanList = data31954000FormBeanList;
	}

	public String[] getStucodeArray() {
		return stucodeArray;
	}

	public void setStucodeArray(String[] stucodeArray) {
		this.stucodeArray = stucodeArray;
	}

	public String getPrincipalNameDeed() {
		return principalNameDeed;
	}

	public void setPrincipalNameDeed(String principalNameDeed) {
		this.principalNameDeed = principalNameDeed;
	}

	public List<String> getTermArray() {
		return termArray;
	}

	public void setTermArray(List<String> termArray) {
		this.termArray = termArray;
	}

	public byte[] getSchoolPrincipalStampImage() {
		return schoolPrincipalStampImage;
	}

	public void setSchoolPrincipalStampImage(byte[] schoolPrincipalStampImage) {
		this.schoolPrincipalStampImage = schoolPrincipalStampImage;
	}


}
