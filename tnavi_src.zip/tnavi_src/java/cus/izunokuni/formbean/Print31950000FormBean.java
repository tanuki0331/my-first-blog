package jp.co.systemd.tnavi.cus.izunokuni.formbean;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_AttendEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_AttendMemoEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_ClubActivityEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_MoralEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_MstScorptactviewpointtitleEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_SchoolMemoEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_ScoreEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_ScorptcommontextEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_SpecialActivityEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31950000_TotalactEntity;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.05.24 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31950000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C�����t */
	private String endDate = DEFALUT_VALUE;

	/** �\���\���t���O */
	private boolean output_cover;

	/** ����y�[�W�P�\���t���O */
	private boolean output_page1;

	/** ����y�[�W�Q�\���t���O */
	private boolean output_page2;

	/** �ؖ����\���t���O */
	private boolean output_deed;



	/** �Z�̓C���[�W */
	byte[] schoolStampImage;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �Z������(�C����) */
	private String principalNameDeed = DEFALUT_VALUE;

	/** �S�C���� */
	private String teacherName = DEFALUT_VALUE;

	/** �w�Z�� */
	private String schoolName = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameS = DEFALUT_VALUE;

	/** �w�Z��(����) */
	private String schoolNameO = DEFALUT_VALUE;

	/** ���k���̐��k��� */
	private List<Data31950000FormBean> dataFormBeanList;

	/** ����ڕW tbl_scorptcommontext*/
	private List<Data31950000_ScorptcommontextEntity> scorptCommontextEntityList;

	/** ���ȕʊϓ_���i�[����Map */
	private LinkedHashMap<String, LinkedList<Data31950000_ItemViewpointEntity> > itemViewpointEntityListMap ;

	/** �]���E�]��̌��ʃ��X�g */
	private Map<String, Map<String, Data31950000_ScoreEntity>> scoreEntityMapMap;

	/** �s���̋L�^�̃��X�g  */
	private List<Data31950000_MstScorptactviewpointtitleEntity> mst_ScorptactviewpointtitleEntityList ;

	/** �s���̋L�^ �]���̌��ʃ��X�g  */
	private Map<String, Map<String, Data31950000_ActViewpointEntity>> actViewpointEntityMapMap;

	/** �o���̋L�^�̃��X�g */
	private Map<String, Map<String, Data31950000_AttendEntity>> attendEntityMapMap;

	/** �o���̋L�^���l�̃��X�g */
	private Map<String, Map<String, Data31950000_AttendMemoEntity>> attendMemoEntityMapMap;

	/** �����I�Ȋw�K�̎��Ԃ̃��X�g  */
	private List<Data31950000_TotalactEntity> totalactEntityList;

	/** �����̕]���̃��X�g  */
	private List<Data31950000_MoralEntity> moralEntityList;

	/** ���ʊ����̋L�^���X�g */
	private List<Data31950000_SpecialActivityEntity> specialActivityEntityList;

	/** �N���u�����̋L�^ */
	private List<Data31950000_ClubActivityEntity> clubActivityEntityList;

	/** �ʐM��(�w�Z����) */
	private List<Data31950000_SchoolMemoEntity> schoolMemoEntityList;


	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_page1() {
		return output_page1;
	}

	public void setOutput_page1(boolean output_page1) {
		this.output_page1 = output_page1;
	}

	public boolean isOutput_page2() {
		return output_page2;
	}

	public void setOutput_page2(boolean output_page2) {
		this.output_page2 = output_page2;
	}

	public boolean isOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(boolean output_deed) {
		this.output_deed = output_deed;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}

	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getPrincipalNameDeed() {
		return principalNameDeed;
	}

	public void setPrincipalNameDeed(String principalNameDeed) {
		this.principalNameDeed = principalNameDeed;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolNameS() {
		return schoolNameS;
	}

	public void setSchoolNameS(String schoolNameS) {
		this.schoolNameS = schoolNameS;
	}

	public String getSchoolNameO() {
		return schoolNameO;
	}

	public void setSchoolNameO(String schoolNameO) {
		this.schoolNameO = schoolNameO;
	}

	public List<Data31950000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}

	public void setDataFormBeanList(List<Data31950000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	public List<Data31950000_ScorptcommontextEntity> getScorptCommontextEntityList() {
		return scorptCommontextEntityList;
	}

	public void setScorptCommontextEntityList(List<Data31950000_ScorptcommontextEntity> scorptCommontextEntityList) {
		this.scorptCommontextEntityList = scorptCommontextEntityList;
	}

	public LinkedHashMap<String, LinkedList<Data31950000_ItemViewpointEntity>> getItemViewpointEntityListMap() {
		return itemViewpointEntityListMap;
	}

	public void setItemViewpointEntityListMap(
			LinkedHashMap<String, LinkedList<Data31950000_ItemViewpointEntity>> itemViewpointEntityListMap) {
		this.itemViewpointEntityListMap = itemViewpointEntityListMap;
	}

	public Map<String, Map<String, Data31950000_ScoreEntity>> getScoreEntityMapMap() {
		return scoreEntityMapMap;
	}

	public void setScoreEntityMapMap(
			Map<String, Map<String, Data31950000_ScoreEntity>> scoreEntityMapMap) {
		this.scoreEntityMapMap = scoreEntityMapMap;
	}

	public List<Data31950000_MstScorptactviewpointtitleEntity> getMst_ScorptactviewpointtitleEntityList() {
		return mst_ScorptactviewpointtitleEntityList;
	}

	public void setMst_ScorptactviewpointtitleEntityList(
			List<Data31950000_MstScorptactviewpointtitleEntity> mst_ScorptactviewpointtitleEntityList) {
		this.mst_ScorptactviewpointtitleEntityList = mst_ScorptactviewpointtitleEntityList;
	}

	public Map<String, Map<String, Data31950000_ActViewpointEntity>> getActViewpointEntityMapMap() {
		return actViewpointEntityMapMap;
	}

	public void setActViewpointEntityMapMap(
			Map<String, Map<String, Data31950000_ActViewpointEntity>> actViewpointEntityMapMap) {
		this.actViewpointEntityMapMap = actViewpointEntityMapMap;
	}

	public Map<String, Map<String, Data31950000_AttendEntity>> getAttendEntityMapMap() {
		return attendEntityMapMap;
	}

	public void setAttendEntityMapMap(
			Map<String, Map<String, Data31950000_AttendEntity>> attendEntityMapMap) {
		this.attendEntityMapMap = attendEntityMapMap;
	}

	public Map<String, Map<String, Data31950000_AttendMemoEntity>> getAttendMemoEntityMapMap() {
		return attendMemoEntityMapMap;
	}

	public void setAttendMemoEntityMapMap(
			Map<String, Map<String, Data31950000_AttendMemoEntity>> attendMemoEntityMapMap) {
		this.attendMemoEntityMapMap = attendMemoEntityMapMap;
	}

	public List<Data31950000_TotalactEntity> getTotalactEntityList() {
		return totalactEntityList;
	}

	public void setTotalactEntityList(
			List<Data31950000_TotalactEntity> totalactEntityList) {
		this.totalactEntityList = totalactEntityList;
	}

	public List<Data31950000_MoralEntity> getMoralEntityList() {
		return moralEntityList;
	}

	public void setMoralEntityList(List<Data31950000_MoralEntity> moralEntityList) {
		this.moralEntityList = moralEntityList;
	}

	public List<Data31950000_SpecialActivityEntity> getSpecialActivityEntityList() {
		return specialActivityEntityList;
	}

	public void setSpecialActivityEntityList(
			List<Data31950000_SpecialActivityEntity> specialActivityEntityList) {
		this.specialActivityEntityList = specialActivityEntityList;
	}

	public List<Data31950000_ClubActivityEntity> getClubActivityEntityList() {
		return clubActivityEntityList;
	}

	public void setClubActivityEntityList(
			List<Data31950000_ClubActivityEntity> clubActivityEntityList) {
		this.clubActivityEntityList = clubActivityEntityList;
	}

	public List<Data31950000_SchoolMemoEntity> getSchoolMemoEntityList() {
		return schoolMemoEntityList;
	}

	public void setSchoolMemoEntityList(
			List<Data31950000_SchoolMemoEntity> schoolMemoEntityList) {
		this.schoolMemoEntityList = schoolMemoEntityList;
	}



}
