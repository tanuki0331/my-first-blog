package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CmlguideactviewpointvalueEntity;
import jp.co.systemd.tnavi.common.db.entity.CmlguidecommentEntity;
import jp.co.systemd.tnavi.common.db.entity.CmlguidemoralEntity;
import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.db.entity.CmlguidespeactvalueEntity;
import jp.co.systemd.tnavi.common.db.entity.CmlguidetotalactvalueEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.common.utility.DateFormatUtility;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_CmlguideattendrecordEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_CmlguidetotalacttitleEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_EstimateListEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_EvalListEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_ExchangeClassEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_GavtDataEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_GivtDataEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_GsatDataEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_HyokaEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_KyokaListEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_TextAreaSizeListEntity;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data32170000_KyokaMapFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Detail32170000FormBean;
import jp.co.systemd.tnavi.junior.common.db.entity.CmlguideactestimateEntity;
import jp.co.systemd.tnavi.sco.db.entity.StuProvideInfo_01AjaxEntity;
import jp.co.systemd.tnavi.sco.db.entity.StuProvideInfo_06AjaxEntity;

/**
 * <PRE>
 * �w���v�^����(���ʎx�� �ɓ��̍��s�E���쒬) �ڍ� Service.
 * </PRE>
 *
 * <B>Create</B> 2019.01.11 BY SD hirata<BR>
 * <B>Modify</B> 2019.03.26 BY SD yamazaki�@�����I�Ȋw�K�̎��Ԃ̋L�^ �ϓ_�ێ��P�ʂ̎擾 [�ėp�}�X�^ kind:606 code:005]�̐ݒ�Ɋ֌W�Ȃ��Atbl_cmlguidetotalactvalue�̊w�K�����E�ϓ_�E�]�����擾<BR>
 * <B>remark</B><BR>
 *
 * @author System D, Inc.
 * @since 1.0.
 */
public class Detail32170000Service  extends AbstractExecuteQuery {

	private String user = "";
	private String nendoStartMD = "";
	private String nendoEndMD = "";
	private Detail32170000FormBean formBean = null;

	private final String H4_TAG = "<h4 style=\"background: #AFEEEE; border-left: 5px solid #87CEFA; margin: 0 0 3px 0; padding: 2px 3px;\">";

	/**
	 * �R���X�g���N�^
	 * @param user �����R�[�h
	 * @param nendoStartDate
	 * @param nendoEndDate
	 * @param formBean
	 */
	public Detail32170000Service(String user, String nendoStartMD, String nendoEndMD, Detail32170000FormBean formBean) {
		this.user = user;
		this.nendoStartMD = nendoStartMD;
		this.nendoEndMD = nendoEndMD;
		this.formBean = formBean;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {

		String year = formBean.getYear();
		String stucode = formBean.getStudentListEntity().getStu_stucode();
		String grade = formBean.getStudentListEntity().getHmr_glade();

		//�w���v�̔N�x
		Object[] param = new Object[] {user, year, stucode};
		QueryManager queryManager = new QueryManager("cus/izunokuni/getData32170000_ShidoyoryoNendo.sql", param, String.class);
		String shidoyoryoNendo = (String) this.executeQuery(queryManager);
		if(shidoyoryoNendo != null && shidoyoryoNendo.length() > 0){
			formBean.setShidoyoryoNendo(shidoyoryoNendo);
		}

		//�w���v�̃R�[�h
		param = new Object[] {user, year, grade};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_Curcode.sql", param, String.class);
		formBean.setCurcode( (String) this.executeQuery(queryManager) );

		//�����󋵓�
//		doQueryForComment(year, stucode);

		//�e�L�X�g�G���A�̃T�C�Y�擾
		List<Data32170000_TextAreaSizeListEntity> textAreaSizeList = editTextAreaSizeMap(year, grade);

		//�o���̋L�^(�w���v�^)
		param = new Object[] {user, year, stucode, grade};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguideattendrecord.sql", param, Data32170000_CmlguideattendrecordEntity.class);
		List<Data32170000_CmlguideattendrecordEntity> cmlguideattendrecordList = (List<Data32170000_CmlguideattendrecordEntity>)  this.executeQuery(queryManager);
		if(cmlguideattendrecordList != null && cmlguideattendrecordList.size() > 0){
			formBean.setCmlguideattendrecordEntity(cmlguideattendrecordList.get(0));
		}

		doQueryForOther(year, stucode, grade, textAreaSizeList);
	}

	/**
	 * @param nendo
	 * @param grade
	 * @return
	 */
	private List<Data32170000_TextAreaSizeListEntity> editTextAreaSizeMap(String nendo, String grade) {
		Object[] param;
		QueryManager queryManager;
		param = new Object[] {user, nendo, grade};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_TextAreaSizeList.sql", param, Data32170000_TextAreaSizeListEntity.class);
		List<Data32170000_TextAreaSizeListEntity> textAreaSizeList = (List<Data32170000_TextAreaSizeListEntity>) this.executeQuery(queryManager);
		if(textAreaSizeList != null && textAreaSizeList.size() > 0){
			Map<String , Data32170000_TextAreaSizeListEntity> textAreaSizeMap = new LinkedHashMap<String , Data32170000_TextAreaSizeListEntity>();
			for(Data32170000_TextAreaSizeListEntity textAreaSize : textAreaSizeList){
				textAreaSizeMap.put(textAreaSize.getCtas_item(), textAreaSize);
			}
			formBean.setTextAreaSizeMap(textAreaSizeMap);
		}
		return textAreaSizeList;
	}

	/**
	 * �����󋵓����擾����N�G�������s����
	 * @param year
	 * @param stucode
	 */
	private void doQueryForComment(String year, String stucode){

		// ---- ��N�x
		String lastNendo = String.valueOf(Integer.valueOf(year) - 1);
		// ���N�x�̔N�x�J�n�����A�N�x�I������
		String lastStart = lastNendo + nendoStartMD;
		String lastEnd = "";
		if(nendoEndMD.compareTo(nendoStartMD) <= 0){
			lastEnd = String.valueOf(Integer.valueOf(lastNendo) + 1) + nendoEndMD;
		} else {
			lastEnd = lastNendo + nendoEndMD;
		}

		// ---- ���N�x
		String morelastNendo = String.valueOf(Integer.valueOf(year) - 2);
		// ���N�x�̔N�x�J�n�����A�N�x�I������
		String morelastStart = morelastNendo + nendoStartMD;
		String morelastEnd = "";
		if(nendoEndMD.compareTo(nendoStartMD) <= 0){
			morelastEnd = String.valueOf(Integer.valueOf(morelastNendo) + 1) + nendoEndMD;
		} else {
			morelastEnd = morelastNendo + nendoEndMD;
		}

		// �N�x�J�n�����A�N�x�I������
		String start = year + nendoStartMD;
		String end = "";
		if(nendoEndMD.compareTo(nendoStartMD) <= 0){
			end = String.valueOf(Integer.valueOf(year) + 1) + nendoEndMD;
		} else {
			end = year + nendoEndMD;
		}

		// ���N�x�́u���ʊ����v�̏����擾����(�ψ���E�������E�W������)
		Object[] param = new Object[] { user, stucode, morelastNendo, user, stucode, morelastStart, morelastEnd, morelastStart, morelastEnd};
		QueryManager queryManager = new QueryManager("sco/getDataStuProvideInfo_01Ajax.sql", param, StuProvideInfo_01AjaxEntity.class);
		List<StuProvideInfo_01AjaxEntity> listSpeactMoreLast = (List<StuProvideInfo_01AjaxEntity>) this.executeQuery(queryManager);

		// �O�N�x�́u���ʊ����v�̏����擾����(�ψ���E�������E�W������)
		param = new Object[] { user, stucode, lastNendo, user, stucode, lastStart, lastEnd, lastStart, lastEnd};
		queryManager = new QueryManager("sco/getDataStuProvideInfo_01Ajax.sql", param, StuProvideInfo_01AjaxEntity.class);
		List<StuProvideInfo_01AjaxEntity> listSpeactLast = (List<StuProvideInfo_01AjaxEntity>) this.executeQuery(queryManager);

		// ���N�x�́u���ʊ����v�̏����擾����(�ψ���E�������E�W������)
		param = new Object[] { user, stucode, year, user, stucode, start, end, start, end};
		queryManager = new QueryManager("sco/getDataStuProvideInfo_01Ajax.sql", param, StuProvideInfo_01AjaxEntity.class);
		List<StuProvideInfo_01AjaxEntity> listSpeact = (List<StuProvideInfo_01AjaxEntity>) this.executeQuery(queryManager);

		// �u�C�Â����v�̏����擾����
		param = new Object[] { user, stucode };
		queryManager = new QueryManager("sco/getDataStuProvideInfo_06Ajax.sql", param, StuProvideInfo_06AjaxEntity.class);
		List<StuProvideInfo_06AjaxEntity> listStuNotice = (List<StuProvideInfo_06AjaxEntity>) this.executeQuery(queryManager);

		formBean.setComment(createComment(listSpeactMoreLast, listSpeactLast, listSpeact, listStuNotice));

	}

	/**
	 * �����󋵓����擾����N�G�������s����
	 * @param year
	 * @param stucode
	 * @param textAreaSizeList
	 */
	private void doQueryForOther(String year, String stucode, String glade, List<Data32170000_TextAreaSizeListEntity> textAreaSizeList){

		Object[] param = null;
		QueryManager queryManager = null;

		// �Q�ƌ��̏o�͎��������擾
		//�u�O���ꊈ���̋L�^�v�̍��ڔ���
		param = new Object[] {user, year};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_RefOutputterm.sql", param, CmlguideoutputtermEntity.class);
		List<CmlguideoutputtermEntity> outputtermList = (List<CmlguideoutputtermEntity>) this.executeQuery(queryManager);
		formBean.setRefOutputterm(outputtermList.get(0));

		//���ȁE�ϓ_�ʕ]���E�]��
		String goptcode = (0 < outputtermList.size()) ? outputtermList.get(0).getGopt_goptcode() : "";
		param = new Object[] {user, year, stucode, glade, goptcode};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_KyokaList.sql", param, Data32170000_KyokaListEntity.class);
		List<Data32170000_KyokaListEntity> kyokaList = (List<Data32170000_KyokaListEntity>) this.executeQuery(queryManager);
		if(kyokaList != null && kyokaList.size() > 0){
			setKyokaMapData(kyokaList);
		}

		//�𗬐�̊w�N�A�g
		param = new Object[] {user, year, stucode};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_ExchangeClass.sql", param, Data32170000_ExchangeClassEntity.class);
		List<Data32170000_ExchangeClassEntity> exchangeClassList = (List<Data32170000_ExchangeClassEntity>) this.executeQuery(queryManager);
		if(exchangeClassList != null && exchangeClassList.size() > 0){
			formBean.setExc_glade(exchangeClassList.get(0).getExc_glade());
			formBean.setExc_class(exchangeClassList.get(0).getExc_class());
		}

		//�]�����X�g�̍쐬
		formBean.setEstimateList(editEstimateList(year));

		//�]�胊�X�g�̍쐬
		formBean.setEvalList(editEvalList(year));

		//�u�O���ꊈ���̋L�^�v�̍��ڔ���
		param = new Object[] {user, year, glade, "3"};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_RowCount.sql", param, Integer.class);
		Integer rowCount1 = (Integer) this.executeQuery(queryManager);
		if(rowCount1 > 0){
			param = new Object[] {"3", user, year, glade};
			//���ȕʊϓ_�}�X�^(�w���v�^)����擾
			queryManager = new QueryManager("cus/izunokuni/getData32170000_GivtDataList.sql", param, Data32170000_GivtDataEntity.class);
			List<Data32170000_GivtDataEntity> givtLanguageDataList = (List<Data32170000_GivtDataEntity>) this.executeQuery(queryManager);
			if(givtLanguageDataList != null){
				formBean.setGivtLanguageDataList(givtLanguageDataList);
				formBean.setGivtLanguageDataListSize(givtLanguageDataList.size());
			}
		}

		//�u�����I�Ȋw�K�̎��Ԃ̋L�^�v�̍��ڔ���
		param = new Object[] {user, year, glade, "5"};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_RowCount.sql", param, Integer.class);
		Integer rowCount2 = (Integer) this.executeQuery(queryManager);
		formBean.setGivtSynthesisFlg(rowCount2 > 0);

		//�u���ʊ����̋L�^�v�̊ϓ_(�w�������A���������)���擾
		param = new Object[] {user, year, glade};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_GsatDataList.sql", param, Data32170000_GsatDataEntity.class);
		List<Data32170000_GsatDataEntity> gsatDataList = (List<Data32170000_GsatDataEntity>) this.executeQuery(queryManager);
		if(gsatDataList != null){
			formBean.setGsatDataList(gsatDataList);
			formBean.setGsatDataListSize(gsatDataList.size());
		}

		//�u�s���̋L�^�v�̊ϓ_���擾
		param = new Object[] {user, year, glade};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_GavtDataList.sql", param, Data32170000_GavtDataEntity.class);
		List<Data32170000_GavtDataEntity> gavtDataList = (List<Data32170000_GavtDataEntity>) this.executeQuery(queryManager);
		if(gsatDataList != null){
			formBean.setGavtDataList(gavtDataList);
			formBean.setGavtDataListSize(gavtDataList.size());
		}

		//���ʊ����̋L�^�̊������e
		param = new Object[]{user, year, stucode};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_Viewpoint.sql", param, String.class);
		String viewpoint = (String) this.executeQuery(queryManager);
		if(viewpoint != null){
			formBean.setViewpoint(viewpoint.replaceAll("\r\n", "<br>"));
		}

		//���ʊ����A�s�����̕]������
		param = new Object[]{year, glade, user};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_cmlguideActEstimate.sql", param, CmlguideactestimateEntity.class);
		List<CmlguideactestimateEntity> cmlguideactestimateList = (List<CmlguideactestimateEntity>) this.executeQuery(queryManager);
		if(cmlguideactestimateList != null){
			formBean.setActList(getGuideActEstimatEntityList(cmlguideactestimateList));
		}

		//�L�q�]���A���ʊ����̋L�^�i�K�]���A�s���̋L�^�i�K�]�����擾
		editHyokaMap(year, glade, stucode);
	}

	/**
	 * �O���ꊈ���̋L�^�A�����I�Ȋw�K�̎��Ԃ̋L�^�A���ʊ����̋L�^�A�s���̋L�^
	 * ���������y�юw����Q�l�ƂȂ鏔�����̕]�����擾����
	 * @param nendo �N�x
	 * @param stucode �w�Дԍ�
	 */
	private void editHyokaMap(String nendo, String grade, String stucode) {

		Object[] param;
		QueryManager qm;
		List<Data32170000_HyokaEntity> entList = null;
		Map<String, String> hyokaMap = new HashMap<String, String>();

		// ���������y�юw����Q�l�ƂȂ鏔����
		param = new Object[] {user, nendo, stucode};
		qm = new QueryManager("cus/izunokuni/getData32170000_Cmlguidemoral.sql", param, CmlguidemoralEntity.class);
		List<CmlguidemoralEntity> meValEntList = (List<CmlguidemoralEntity>) this.executeQuery(qm);
		for (CmlguidemoralEntity ent : meValEntList) {
			putValueToHyokaMap(Detail32170000FormBean.MORAL, hyokaMap, ent.getGmrl_value());
		}

		// �O���ꊈ���̋L�^
		param = new Object[] {user, nendo, stucode};
		qm = new QueryManager("cus/izunokuni/getData32170000_ForeignlangAct.sql", param, Data32170000_HyokaEntity.class);
		entList = (List<Data32170000_HyokaEntity>) this.executeQuery(qm);
		for (Data32170000_HyokaEntity ent : entList) {
			putValueToHyokaMap(Detail32170000FormBean.FOREIGNACT, hyokaMap, ent.getValue(), ent.getVpCode());
		}

		// �����I�Ȋw�K�̎��Ԃ̋L�^ �w�K�����E�ϓ_
		param = new Object[] {user, nendo, stucode};
		qm = new QueryManager("cus/izunokuni/getData32170000_CmlguidetotalactContents.sql", param, Data32170000_CmlguidetotalacttitleEntity.class);
		List<Data32170000_CmlguidetotalacttitleEntity> taContentEntList = (List<Data32170000_CmlguidetotalacttitleEntity>) this.executeQuery(qm);
		if (taContentEntList != null && 0 < taContentEntList.size()) {
			// �w�K����
			putValueToHyokaMap(Detail32170000FormBean.TOTALACT_CONTENT, hyokaMap, taContentEntList.get(0).getGtat_act());
			// �ϓ_
			putValueToHyokaMap(Detail32170000FormBean.TOTALACT_VP, hyokaMap, taContentEntList.get(0).getGtat_pointview());
		}

		// �����I�Ȋw�K�̎��Ԃ̋L�^ �]��
		param = new Object[] {user, nendo, stucode};
		qm = new QueryManager("cus/izunokuni/getData32170000_Cmlguidetotalactvalue.sql", param, CmlguidetotalactvalueEntity.class);
		List<CmlguidetotalactvalueEntity> taValEntList = (List<CmlguidetotalactvalueEntity>) this.executeQuery(qm);
		for (CmlguidetotalactvalueEntity ent : taValEntList) {
			putValueToHyokaMap(Detail32170000FormBean.TOTALACT_EVAL, hyokaMap, ent.getGtav_value());
		}

		// ���ʊ����̋L�^
		param = new Object[] {user, nendo, stucode};
		qm = new QueryManager("cus/izunokuni/getData32170000_Cmlguidespeactvalue.sql", param, CmlguidespeactvalueEntity.class);
		List<CmlguidespeactvalueEntity> saValEntList = (List<CmlguidespeactvalueEntity>) this.executeQuery(qm);
		for (CmlguidespeactvalueEntity ent : saValEntList) {
			putValueToHyokaMap(Detail32170000FormBean.SPECIAL_ACT, hyokaMap, ent.getGsav_gsaecode(), ent.getGsav_gsatcode());
		}

		// �s���̋L�^
		param = new Object[] {user, nendo, stucode};
		qm = new QueryManager("cus/izunokuni/getData32170000_Cmlguideactviewpointvalue.sql", param, CmlguideactviewpointvalueEntity.class);
		List<CmlguideactviewpointvalueEntity> actValEntList = (List<CmlguideactviewpointvalueEntity>) this.executeQuery(qm);
		for (CmlguideactviewpointvalueEntity ent : actValEntList) {
			putValueToHyokaMap(Detail32170000FormBean.ACT, hyokaMap, ent.getGavv_gacecode(), ent.getGavv_gavtcode());
		}

		// ���������y�юw����Q�l�ƂȂ鏔����
		param = new Object[] {user, nendo, stucode};
		qm = new QueryManager("cus/izunokuni/getData32170000_Cmlguidecomment.sql", param, CmlguidecommentEntity.class);
		List<CmlguidecommentEntity> ceValEntList = (List<CmlguidecommentEntity>) this.executeQuery(qm);
		for (CmlguidecommentEntity ent : ceValEntList) {
			putValueToHyokaMap(Detail32170000FormBean.COMMENT, hyokaMap, ent.getGcom_comment());
		}

		formBean.setHyokaMap(hyokaMap);
	}

	private void putValueToHyokaMap(String itemKind, Map<String, String> hyokaMap, String value) {
		putValueToHyokaMap(itemKind, hyokaMap, value, "");
	}

	private void putValueToHyokaMap(String itemKind, Map<String, String> hyokaMap, String value, String vpcode) {

		String key = itemKind;
		if(StringUtils.isNotEmpty(vpcode)){
			key += "_" + vpcode;
		}
		hyokaMap.put(key, value);
	}

	/**
	 * �]��v���_�E���p�̏����擾��List�𐶐�����
	 * @param nendo
	 * @return �]��v���_�E���p��List
	 */
	private List<SimpleTagFormBean> editEvalList(String nendo) {

		List<SimpleTagFormBean> evalList = new ArrayList<SimpleTagFormBean>();
		Object[] param;
		QueryManager queryManager;
		param = new Object[] {user, nendo};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_EvalList.sql", param, Data32170000_EvalListEntity.class);
		List<Data32170000_EvalListEntity> tempEvalList = (List<Data32170000_EvalListEntity>) this.executeQuery(queryManager);

		for(Data32170000_EvalListEntity tempEval : tempEvalList){
			evalList.add(new SimpleTagFormBean(tempEval.getGevl_gevlcode(), tempEval.getGevl_display()));
		}
		return evalList;
	}

	/**
	 * �ϓ_�ʕ]���v���_�E���p�̏����擾��List�𐶐�����
	 * @param nendo
	 * @return �ϓ_�ʕ]���v���_�E���p��List
	 */
	private List<SimpleTagFormBean> editEstimateList(String nendo) {

		List<SimpleTagFormBean> evalList = new ArrayList<SimpleTagFormBean>();
		Object[] param;
		QueryManager queryManager;
		param = new Object[] {user, nendo};
		queryManager = new QueryManager("cus/izunokuni/getData32170000_EstimateList.sql", param, Data32170000_EstimateListEntity.class);
		List<Data32170000_EstimateListEntity> tempList = (List<Data32170000_EstimateListEntity>) this.executeQuery(queryManager);

		for(Data32170000_EstimateListEntity tempVal : tempList){
			evalList.add(new SimpleTagFormBean(tempVal.getGvpe_gvpecode(), tempVal.getGvpe_display()));
		}

		return evalList;
	}

	/**
	 * SQL�Ŏ擾�����f�[�^��A�z�z��ɕω����āAFormBean�ɐݒ肷��
	 * @param quoteList
	 */
	private void setKyokaMapData(List<Data32170000_KyokaListEntity> kyokaList) {

		Map<String , Data32170000_KyokaMapFormBean> kyokaMap = new LinkedHashMap<String , Data32170000_KyokaMapFormBean>();

		for(Data32170000_KyokaListEntity kyoka : kyokaList){

			String givt_item = kyoka.getCod_code();

			if(!kyokaMap.containsKey(givt_item)){

				Data32170000_KyokaMapFormBean kyokaMapObj = new Data32170000_KyokaMapFormBean();
				kyokaMapObj.setItemName(kyoka.getCod_name1());
				kyokaMapObj.setGevl_gevlcode(kyoka.getGevl_gevlcode());
				kyokaMapObj.setGevl_display(kyoka.getGevl_display());
				kyokaMapObj.setSgev_gevlcode(kyoka.getSgev_gevlcode());
				kyokaMapObj.setSgev_changememo(kyoka.getSgev_changememo());
				kyokaMapObj.setSgev_memo(kyoka.getSgev_memo());
				kyokaMap.put(givt_item, kyokaMapObj);
			}

			kyokaMap.get(givt_item).getKyokaList().add(kyoka);
			int listSize = kyokaMap.get(givt_item).getKyokaListSize() + 1;
			kyokaMap.get(givt_item).setKyokaListSize(listSize);
		}

		formBean.setKyokaMap(kyokaMap);
		formBean.setKyokaMapSize(kyokaMap.size());

	}

	/**
	 * ���k�̊����󋵂⏊�����g�ݗ���
	 *
	 * @param listSpeactMoreLast
	 * @param listSpeactLast
	 * @param listSpeact
	 * @param listStuNotice
	 */
	protected String createComment(List<StuProvideInfo_01AjaxEntity> listSpeactMoreLast, List<StuProvideInfo_01AjaxEntity> listSpeactLast,
			List<StuProvideInfo_01AjaxEntity> listSpeact, List<StuProvideInfo_06AjaxEntity> listStuNotice){

		String glade = formBean.getStudentListEntity().getHmr_glade();
		String number = "";
		if(formBean.getStudentListEntity().getCls_number() != null){
			number = formBean.getStudentListEntity().getCls_number().toString();
		}
		String name = formBean.getStudentListEntity().getSt4_name();
		// ���N�x�̊w�N
		String morelastGlade = String.valueOf(Integer.valueOf(glade) - 2);

		// ��N�x�̊w�N
		String lastGlade = String.valueOf(Integer.valueOf(glade) - 1);

		// ���l�ɕ\�����镶��
		StringBuffer comment = new StringBuffer();

		// �����ԍ��A����
		comment.append("<b>");
		comment.append(number).append("�F").append(name).append("<br>");
		comment.append("</b>");

		comment.append("<br>");


		// --- ���N�x�̏�񐮌`
		// ���N�x�́u���ʊ����v�̏��𐮌`
		editSpeactInfo(listSpeact, comment, glade);

		// --- ��N�x�̏�񐮌`
		// ��N�x�́u���ʊ����v�̏��𐮌`
		editSpeactInfo(listSpeactLast, comment, lastGlade);

		// --- ���N�x�̏�񐮌`
		// ���N�x�́u���ʊ����v�̏��𐮌`
		editSpeactInfo(listSpeactMoreLast, comment, morelastGlade);

		// --- �C�Â����
		if(listStuNotice != null && listStuNotice.size() > 0){

			String befGlade = "";
			StuProvideInfo_06AjaxEntity ent = null;
			DateFormatUtility uty = new DateFormatUtility(user);

			for(int i = 0; i < listStuNotice.size(); i++){
				// SQL�Ńf�[�^���擾�ł������C�Â����e��null�A��̏ꍇ�͕\�����Ȃ�

				ent = listStuNotice.get(i);

				if(null != ent.getStn_notice() && !"".equals(ent.getStn_notice())){

					// ���O�������̊w�N�ƈقȂ�ꍇ�̂ݔN���o��
					// ����͕K���o��
					if (!befGlade.equals(ent.getCls_glade())){
						comment.append(H4_TAG);
						comment.append("<b>");
						comment.append(ent.getCls_glade()).append("�N�F�C�Â�").append("<br>");
						comment.append("</b>");
						comment.append("</h4>");
					}

					comment.append(ent.getStn_notice());
					comment.append("<br>");

					// �L����
					comment.append("<font color=\"#800000\">(�L�����F")
						.append(uty.formatDate("YYYY�NMM��DD��", ent.getStn_makedate()))
						.append("�@�J�e�S���F")
						.append(ent.getSnc_name())
						.append(")</font><br>")
						.append("<br>");
				}

				// ���O�������̊w�N��ێ�
				befGlade = ent.getCls_glade();
			}
		}


		return comment.toString();
	}

	/**
	 * ���ʊ����̋L�^����ҏW����
	 * @param list
	 * @param comment
	 * @param tagetGrade
	 */
	private void editSpeactInfo(List<StuProvideInfo_01AjaxEntity> list, StringBuffer comment, String tagetGrade){

		if(list != null &&  list.size() > 0){
			comment.append(H4_TAG);
			comment.append("<b>");
			comment.append(tagetGrade).append("�N�F���ʊ���").append("<br>");
			comment.append("</b>");
			comment.append("</h4>");

			String preKind = "";
			for(int i = 0; i < list.size(); i++){
				if(i == 0){
					// 1���ڂ͖������ɒǉ�
					comment.append(list.get(i).getExt_name());
					if(null != list.get(i).getPos_code() && !"".equals(list.get(i).getPos_code())
							&& StringUtils.isNotEmpty(list.get(i).getPst_name()) ){
						// ��E���擾�ł�����ǉ�
						comment.append("�i").append(list.get(i).getPst_name()).append("�j");
					}
					preKind = list.get(i).getExt_kind();
				} else {
					// 2���ڈȍ~
					if(preKind.equals(list.get(i).getExt_kind())){
						// �ۊO�����敪�������ꍇ�̓J���}��؂�Œǉ�
						comment.append(",").append(list.get(i).getExt_name());
					} else {
						// �ۊO�����敪���Ⴄ�ꍇ�͉��s���Ēǉ�
						comment.append("<br>").append(list.get(i).getExt_name());
					}
					if(null != list.get(i).getPos_code() && !"".equals(list.get(i).getPos_code())
							&& StringUtils.isNotEmpty(list.get(i).getPst_name()) ){
						// ��E���擾�ł�����ǉ�
						comment.append("�i").append(list.get(i).getPst_name()).append("�j");
					}
					preKind = list.get(i).getExt_kind();
				}
			}
			comment.append("<br>");
			comment.append("<br>");
		}
	}

	private List<SimpleTagFormBean> getGuideActEstimatEntityList(List<CmlguideactestimateEntity> cmlGuideActEstimateEntityList) {
		List<SimpleTagFormBean> actList  = new ArrayList<SimpleTagFormBean>();
		for( CmlguideactestimateEntity entity : cmlGuideActEstimateEntityList){
			actList.add(new SimpleTagFormBean( entity.getGace_gacecode(), entity.getGace_display() ));
		}
		return actList;
	}

	/**
	 * <PRE>
	 * �p�����[�^�ݒ�.
	 * </PRE>
	 *
	 * @param user �����R�[�h
	 * @param nendoEnd
	 * @param nendoStart
	 * @param formBean
	 */
	public void setParameter(String user, String startDate, String endDate, Detail32170000FormBean formBean) {
		this.user = user;
		this.nendoStartMD = startDate;
		this.nendoEndMD = endDate;
		this.formBean = formBean;
	}
}
