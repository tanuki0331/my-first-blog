package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31952000ScorptattendrecordEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31952000SpScorptactviewpointvalueEntity;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Detail31952000FormBean;

/**
 * <PRE>
 *  ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ꗗ �X�V Service.
 * </PRE>
 *
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class RegistDetail31952000Service  extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(RegistDetail31952000Service.class);
	
	/** �T�[�r�X���� */
	private static final String serviceName = "���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ꗗ �X�V";

	/** ���sSQL */
	private static final String EXEC_SQL_DELETE_SP_SCORPTCOMMENT = "common/deleteSpScorptcommentByPK.sql";
	private static final String EXEC_SQL_INSERT_SP_SCORPTCOMMENT = "common/insertSpScorptcomment.sql";
	private static final String EXEC_SQL_DELETE_SP_SCORPTACTVIEWPOINTVALUE = "common/deleteSpScorptactviewpointvalueByPK.sql";
	private static final String EXEC_SQL_INSERT_SP_SCORPTACTVIEWPOINTVALUE = "common/insertSpScorptactviewpointvalue.sql";
	private static final String EXEC_SQL_DELETE_SCORPTATTENDRECORD = "common/deleteScorptattendrecordByPK.sql";
	private static final String EXEC_SQL_INSERT_SCORPTATTENDRECORD = "common/insertScorptattendrecord.sql";

	/** ����SessionBean */
	private SystemInfoBean sessionBean;

	/** �ꗗFormBean. */
	private Detail31952000FormBean detailFormBean;

	
	/**
	 * �R���X�g���N�^
	 * @param reques t
	 * @param sessionBean
	 * @param detailFormBean
	 */
	public RegistDetail31952000Service(HttpServletRequest request, SystemInfoBean sessionBean, Detail31952000FormBean detailFormBean) {
		super();
		this.sessionBean = sessionBean;
		this.detailFormBean = detailFormBean;
		
		detailFormBean.getSpScorptcommentMap().put("G1", request.getParameter("srcom_comment_g1"));
		detailFormBean.getSpScorptcommentMap().put("G2", request.getParameter("srcom_comment_g2"));
		detailFormBean.getSpScorptcommentMap().put("G3", request.getParameter("srcom_comment_g3"));
		
		for (int i = 0; i < detailFormBean.getSpScorptactviewpointvalueList().size(); i++) {
			String sravt_sravtcode = detailFormBean.getSpScorptactviewpointvalueList().get(i).getSravt_sravtcode();
			
			detailFormBean.getSpScorptactviewpointvalueList().get(i).setSravv_indivivp(request.getParameter("sravv_indivivp_" + sravt_sravtcode));
			detailFormBean.getSpScorptactviewpointvalueList().get(i).setSravv_sracecode(request.getParameter("sravv_sracecode_" + sravt_sravtcode));
		}
		
		detailFormBean.setSrad_descript(request.getParameter("srad_descript"));
		
		for (int i = 0; i < detailFormBean.getAttendList().size(); i++) {
			String rar_term = detailFormBean.getAttendList().get(i).getRar_term();
			
			detailFormBean.getAttendList().get(i).setRar_count(getIntParameter(request, "rar_count_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_stop(getIntParameter(request, "rar_stop_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_must(getIntParameter(request, "rar_must_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_absence(getIntParameter(request, "rar_absence_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_attend(getIntParameter(request, "rar_attend_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_late(getIntParameter(request, "rar_late_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_leave(getIntParameter(request, "rar_leave_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_memo(request.getParameter("rar_memo_" + rar_term));
		}
		
	}

	/**
	 * �N�G�������s����
	 */
	public void execute() throws TnaviDbException {
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		try {
			
			// ����(�ʒm�\)(���x) �X�V
			deleteInsertSpScorptcomment();
			
			// �s���̋L�^�]��(�ʒm�\)(���x) �X�V
			deleteInsertSpScorptactviewpointvalue();
			
			// �o���̋L�^�e�[�u��(�ʒm�\) �X�V
			deleteInsertScorptattendrecord();
			
			this.commit();
			
		} catch (Exception e) {
			this.rollback();
			log.error(serviceName + " DB�X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} 

	}
	
	
	/**
	 * ����(�ʒm�\)(���x) �X�V
	 * 
	 * @param evalEntity �ϓ_�]�� Entity
	 */
	private void deleteInsertSpScorptcomment() {
		
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager(EXEC_SQL_DELETE_SP_SCORPTCOMMENT);
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_INSERT_SP_SCORPTCOMMENT);
		
		try{
			this.initialBatchUpdate(deleteQM);
			this.initialBatchUpdate(insertQM);
			
			for (Entry<String, String> entry : detailFormBean.getSpScorptcommentMap().entrySet()) {
				String itemCode = entry.getKey();
				String comment = entry.getValue();
				
				//DELETE
				Object[] deleteParam = new Object[]{ sessionBean.getUserCode()
												      ,sessionBean.getSystemNendoSeireki()
												      ,detailFormBean.getStudent().getCls_stucode()
												      ,detailFormBean.getStudent().getCls_glade()
												      ,Detail31952000FormBean.SRCOM_GOPTCODE
												      ,itemCode
													};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
		
				//INSERT
				Object[] insertParam = new Object[]{ sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,Detail31952000FormBean.SRCOM_GOPTCODE
													  ,itemCode
													  ,comment
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													};
				this.executeBatchUpdate(insertQM, insertParam);
			}
		} catch (Exception e) {
			log.error(" ����(�ʒm�\)(���x) �e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(deleteQM);
			closeQueryUpdateBatchManager(insertQM);
		}
	}
	
	
	/**
	 * �s���̋L�^�]��(�ʒm�\)(���x) �X�V
	 */
	private void deleteInsertSpScorptactviewpointvalue() {
		
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager(EXEC_SQL_DELETE_SP_SCORPTACTVIEWPOINTVALUE);
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_INSERT_SP_SCORPTACTVIEWPOINTVALUE);
		try{
			
			this.initialBatchUpdate(deleteQM);
			this.initialBatchUpdate(insertQM);
			
			for (Data31952000SpScorptactviewpointvalueEntity entity : detailFormBean.getSpScorptactviewpointvalueList()) {
				
				//DELETE
				Object[] deleteParam = new Object[]{ sessionBean.getUserCode()
												      ,sessionBean.getSystemNendoSeireki()
												      ,detailFormBean.getStudent().getCls_stucode()
												      ,detailFormBean.getStudent().getCls_glade()
												      ,detailFormBean.getGoptcode()
												      ,entity.getSravt_sravtcode()
													};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
				
				//INSERT
				Object[] insertParam = new Object[]{ sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,detailFormBean.getGoptcode()
													  ,entity.getSravt_sravtcode()
													  ,entity.getSravv_sracecode()
													  ,entity.getSravv_indivivp()
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													};
				this.executeBatchUpdate(insertQM, insertParam);
			}
		} catch (Exception e) {
			log.error(" �s���̋L�^�]��(�ʒm�\)(���x)�e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(deleteQM);
			closeQueryUpdateBatchManager(insertQM);
		}
	}
	
	
	/**
	 * �o���̋L�^�e�[�u��(�ʒm�\) �X�V
	 */
	private void deleteInsertScorptattendrecord() {
					
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager(EXEC_SQL_DELETE_SCORPTATTENDRECORD);
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_INSERT_SCORPTATTENDRECORD);
		try{
			
			this.initialBatchUpdate(deleteQM);
			this.initialBatchUpdate(insertQM);
			
			for (Data31952000ScorptattendrecordEntity entity : detailFormBean.getAttendList()) {
				
				//DELETE
				Object[] deleteParam = new Object[]{ sessionBean.getUserCode()
												      ,sessionBean.getSystemNendoSeireki()
												      ,detailFormBean.getStudent().getCls_stucode()
												      ,detailFormBean.getStudent().getCls_glade()
												      ,entity.getRar_term()
													};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
				
				//INSERT
				Object[] insertParam = new Object[]{ sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,entity.getRar_term()
													  ,entity.getRar_count()
													  ,entity.getRar_stop()
													  ,null
													  ,entity.getRar_must()
													  ,entity.getRar_absence()
													  ,null
													  ,entity.getRar_attend()
													  ,entity.getRar_late()
													  ,entity.getRar_leave()
													  ,entity.getRar_memo()
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													};
				this.executeBatchUpdate(insertQM, insertParam);
			}
		} catch (Exception e) {
			log.error(" �o���̋L�^�e�[�u��(�ʒm�\)�e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(deleteQM);
			closeQueryUpdateBatchManager(insertQM);
		}
	}

	private void closeQueryUpdateBatchManager(QueryUpdateBatchManager qm) {
		if(qm != null){
			this.closeBatchUpdate(qm);
			qm = null;
		}
	}
	
	/**
	 * ���N�G�X�g�p�����[�^�̒l�𐔒l�ϊ����ĕԂ�
	 * @param request 
	 * @param value
	 * @return ���l�ϊ���̒l
	 */
	private Integer getIntParameter(HttpServletRequest request, String name){
		try{
			return Integer.parseInt(request.getParameter(name));
		}catch(NumberFormatException ne){
			return null;
		}
	}
	
	public Detail31952000FormBean getDetailFormBean() {
		return detailFormBean;
	}



}
