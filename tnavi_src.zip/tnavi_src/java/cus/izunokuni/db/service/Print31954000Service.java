package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.db.entity.SchoolStampEntity;
import jp.co.systemd.tnavi.common.db.entity.UserHistoryEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.formbean.SpClassKeyFormBean;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_AttendEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_ManifestActionEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_SchoolMemoEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_ScoreEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_ScorptcommontextEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_ScorptevalEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_StudentInfoEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31954000_TeacherEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Deta31954000SpScorptcommentEntity;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31954000AttendValueFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31954000CmlguideFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31954000FindingsFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31954000FormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Print31954000FormBean;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z���ʎx���w��) ��� Service.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31954000Service  extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(Print31954000Service.class);

	/** ���sSQL */
	private static final String EXEC_SQL_SCHOOLSTAMP			= "sys/getSchoolStamp.sql";										// �Z��
	private static final String EXEC_SQL_SCHOOLNAME			= "common/getUserhistoryByUserAndYear.sql";						// �w�Z��
	private static final String EXEC_SQL_COMMONTEXT				= "cus/izunokuni/getDataPrint31954000_scorptcommontext.sql";	// ����ڕW�itbl_scorptcommontext)
	private static final String EXEC_SQL_STUDENTINFO			= "cus/izunokuni/getDataPrint31954000_studentinfo.sql";			// ���k���
	private static final String EXEC_SQL_PRINCIPAL_NAME		= "cus/izunokuni/getDataPrint31954000_principalName.sql";		// �Z������
	private static final String EXEC_SQL_TEACHER_NAME			= "cus/izunokuni/getDataPrint31954000_teacherName.sql";			// �S�C����
	private static final String EXEC_SQL_ITEMVIEWPOINT		= "cus/izunokuni/getDataPrint31954000_itemViewpoint.sql";		// �w�K�̋L�^�@���ȁE�ϓ_���
	private static final String EXEC_SQL_SCORE 				= "cus/izunokuni/getDataPrint31954000_score.sql";				// ���я��
	private static final String EXEC_SQL_SCORPTEVAL			= "cus/izunokuni/getDataPrint31954000_scorpteval.sql";			// �]��E�L�q�]���f�[�^�擾
	private static final String EXEC_SQL_SCORPTCOMMENT		= "cus/izunokuni/getData31954000_sp_scorptcomment.sql";			// �L�q�]�����̏o�͓��e
	private static final String EXEC_SQL_MANIFESTACTION		= "cus/izunokuni/getData31954000_sp_manifestaction.sql";		// �s���̂�����
	private static final String EXEC_SQL_SCHOOLMEMO			= "cus/izunokuni/getDataPrint31954000_schoolMemo.sql";			// �o�Ȃ̋L�^���l�o��
	private static final String EXEC_SQL_ATTEND 			    = "cus/izunokuni/getDataPrint31954000_attend.sql";				// �o���̋L�^
	private static final String EXEC_SQL_TERMLIST 		        = "cus/izunokuni/getDataPrint31954000_termList.sql";			// ���ԃ��X�g�擾

	/** ����SessionBean */
	private SystemInfoBean sessionBean;

	/** ���ʎx���w���N���X���FormBean. */
	private SpClassKeyFormBean spClassKeyFormBean;

	/** ���FormBean�@*/
	private Print31954000FormBean printFormBean;

	/**
	 * <pre>
	 * Request�̓��e��FormBean���쐬����
	 * ���̏�����Action.doAction���\�b�h���ŌĂяo�����
	 * </pre>
	 *
	 * @param request
	 *            HTTP���N�G�X�g
	 * @param sessionBean
	 *            �V�X�e�����Bean(�Z�b�V�������)
	 * @throws TnaviDbException
	 *             DB��O�������ɃX���[�����
	 */
	public void execute(Print31954000FormBean printFormBean, SystemInfoBean sessionBean)
			throws TnaviDbException {

		// FormBean��ݒ�
		this.printFormBean = printFormBean;
		// ����Session��ݒ�
		this.sessionBean = sessionBean;
		// �z�[�����[�����FormBean��ݒ�
		spClassKeyFormBean = sessionBean.getSelectSpClassKey();

		// �N�G�������s����
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		try {

			// �N�x
			String nendo = printFormBean.getNendo();
			// �����R�[�h
			String user = printFormBean.getUserCode();
			// ���ʎx���w���ԍ�
			String spgCode = spClassKeyFormBean.getSpgcode();


			String endDate = DateUtility.getNendoEndDate(nendo, sessionBean.getSystemNendoStartDate().trim(),
					sessionBean.getSystemNendoEndDate().trim());


			// ------------------------------------------------------------------------------------------
			// �Z������(��ʏo�͓��t)
			// ------------------------------------------------------------------------------------------
			Object[] param = {user, printFormBean.getOutputDate()};
			QueryManager queryManager = new QueryManager(EXEC_SQL_PRINCIPAL_NAME, param, String.class);
			String principalName = String.valueOf(this.executeQuery(queryManager));


			// �C���؏��p
			param = new Object[]{user, endDate};
			queryManager = new QueryManager(EXEC_SQL_PRINCIPAL_NAME, param, String.class);
			String principalNameDeed = String.valueOf(this.executeQuery(queryManager));
			// �Z���搶����
			printFormBean.setPrincipalName(principalName);
			printFormBean.setPrincipalNameDeed(principalNameDeed);

			// ------------------------------------------------------------------------------------------
			// �w�Z��
			// ------------------------------------------------------------------------------------------
			param = new Object[]{user, nendo};
			queryManager = new QueryManager(EXEC_SQL_SCHOOLNAME, param, UserHistoryEntity.class);
			List<UserHistoryEntity> userHistoryEntityList = (List<UserHistoryEntity>) this.executeQuery(queryManager);
			// �w�Z������
			for (UserHistoryEntity usehEntity:userHistoryEntityList) {
				printFormBean.setSchoolNameO(usehEntity.getUseh_name_o());
			}

			// ------------------------------------------------------------------------------------------
			// �S�C����
			// ------------------------------------------------------------------------------------------
			param = getTeacherNameParam(user, nendo,printFormBean.getOutputDate(),spgCode);
			queryManager = new QueryManager(EXEC_SQL_TEACHER_NAME, param, Data31954000_TeacherEntity.class);
			List<Data31954000_TeacherEntity> teacherEntitieList = (List<Data31954000_TeacherEntity>)this.executeQuery(queryManager);
			// �S�C����Bean�ɃZ�b�g
			printFormBean.setTeacherNameList(getTeacherList(teacherEntitieList));

			// �o�͑Ώې��kFormBeanList
			List<Data31954000FormBean> data31954000FormBeanList = new ArrayList<Data31954000FormBean>();


			// ------------------------------------------------------------------------------------------
			// �Z����
			// ------------------------------------------------------------------------------------------
			param = new Object[]{user, "03"};
			queryManager = new QueryManager(EXEC_SQL_SCHOOLSTAMP, param, SchoolStampEntity.class);
			List<SchoolStampEntity> principalEntityList = (List<SchoolStampEntity>) this.executeQuery(queryManager);
			// �Z�̓C���[�W�̎擾
			for (SchoolStampEntity principalEntity:principalEntityList){
				printFormBean.setSchoolPrincipalStampImage(principalEntity.getStm_image());
			}

			// ���k���ƂɎ擾
			for(String stucode : printFormBean.getStucodeArray()){

				// �o�͑Ώې��kFormBean
				Data31954000FormBean data31954000FormBean = printFormBean.getStudentMap().get(stucode);

				// ------------------------------------------------------------------------------------------
				// ���k�����擾
				// ------------------------------------------------------------------------------------------
				param = new Object[]{user, printFormBean.getOutputDate(), user, nendo, data31954000FormBean.getStuClsno(),data31954000FormBean.getStuStucode()};
				queryManager = new QueryManager(EXEC_SQL_STUDENTINFO, param, Data31954000_StudentInfoEntity.class);
				List<Data31954000_StudentInfoEntity> studentInfoEntityList = (List<Data31954000_StudentInfoEntity>)this.executeQuery(queryManager);

				//**********************************************************
				//              �\�����o�͂���ꍇ                         *
				//**********************************************************
				if (printFormBean.isOutput_cover()) {
					// ------------------------------------------------------------------------------------------
					// �Z��
					// ------------------------------------------------------------------------------------------
					param = new Object[]{user, "01"};
					queryManager = new QueryManager(EXEC_SQL_SCHOOLSTAMP, param, SchoolStampEntity.class);
					List<SchoolStampEntity> schoolStampEntityList = (List<SchoolStampEntity>) this.executeQuery(queryManager);
					// �Z�̓C���[�W�̎擾
					for (SchoolStampEntity schoolStampEntity:schoolStampEntityList){
						printFormBean.setSchoolStampImage(schoolStampEntity.getStm_image());
					}

					// ------------------------------------------------------------------------------------------
					// �w�Z����ڕW�A�d�_�ڕW
					// ------------------------------------------------------------------------------------------
					param = new Object[]{ user, nendo, data31954000FormBean.getStuGrade(), sessionBean.getUseKind2()};
					queryManager = new QueryManager(EXEC_SQL_COMMONTEXT, param, Data31954000_ScorptcommontextEntity.class);
					List<Data31954000_ScorptcommontextEntity> commonTextEntityList = (List<Data31954000_ScorptcommontextEntity>)this.executeQuery(queryManager);
					data31954000FormBean.setScorptCommontextEntityList(commonTextEntityList);
				}

				// �������X�g
				param = new Object[]{user, nendo, printFormBean.getTerm()};
				queryManager = new QueryManager(EXEC_SQL_TERMLIST, param, CmlguideoutputtermEntity.class);
				List<CmlguideoutputtermEntity> termList = (List<CmlguideoutputtermEntity>)this.executeQuery(queryManager);
				List<String> termArray = new ArrayList<String>();
				for(int i=0; i<termList.size(); i++){
					termArray.add(termList.get(i).getGopt_goptcode());
				}

				printFormBean.setTermArray(termArray);

				//**********************************************************
				//              �w�K�̂����� �ϓ_�ꗗ                    *
				//**********************************************************
				if (printFormBean.isOutput_page1()) {

					// ------------------------------------------------------------------------------------------
					// ���ȕʊϓ_�f�[�^���擾
					// ------------------------------------------------------------------------------------------
					param = new Object[]{nendo, data31954000FormBean.getStuGrade(), data31954000FormBean.getStuStucode(), printFormBean.getTerm(), user};
					queryManager = new QueryManager(EXEC_SQL_ITEMVIEWPOINT, param, Data31954000_ItemViewpointEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31954000_ItemViewpointEntity> itemViewpointList = (List<Data31954000_ItemViewpointEntity>) this.executeQuery(queryManager);

					// ------------------------------------------------------------------------------------------
					// SQL�Ŏ擾�������яo�͎����ɑ΂���ϓ_�ʕ]���E���ȕ]����擾
					// ------------------------------------------------------------------------------------------
					param = new Object[]{user, nendo,printFormBean.getTerm(),user, nendo ,stucode};
					queryManager =  new QueryManager(EXEC_SQL_SCORE, param, Data31954000_ScoreEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31954000_ScoreEntity> scoreEntityList = (List<Data31954000_ScoreEntity>) this.executeQuery(queryManager);

					// ------------------------------------------------------------------------------------------
					// �]��E�L�q�]���f�[�^�擾
					// ------------------------------------------------------------------------------------------
					param = new Object[]{printFormBean.getTerm(),user, nendo ,stucode};
					queryManager =  new QueryManager(EXEC_SQL_SCORPTEVAL, param, Data31954000_ScorptevalEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31954000_ScorptevalEntity> scorptevalEntityList = (List<Data31954000_ScorptevalEntity>) this.executeQuery(queryManager);

					// �ϓ_���e�A�]���i�[�pMap
					Map<String, Data31954000CmlguideFormBean> cmlguideFormBeanMap = new HashMap<String, Data31954000CmlguideFormBean>();
					for (Data31954000_ItemViewpointEntity viewEntity:itemViewpointList) {
						// �ϓ_���i�[For��Bean
						Data31954000CmlguideFormBean data31954000CmlguideFormBean = new Data31954000CmlguideFormBean();
						// ���ȏ��
						data31954000CmlguideFormBean.setSi_item(viewEntity.getSi_item());
						// �ϓ_�R�[�h
						data31954000CmlguideFormBean.setSrivt_srivtcode(viewEntity.getSrivt_srivtcode());
						// �ʒm�\�p���Ȗ�
						data31954000CmlguideFormBean.setSi_reportname(viewEntity.getSi_reportname());
						// �ʒm�\�p���Ȗ�
						data31954000CmlguideFormBean.setSrvpv_indivivp(viewEntity.getSrvpv_indivivp());

						// �ϓ_�]��
						Map<String,String> goptcodeDisplay = new HashMap<String,String>();
						// ���яo�͎����ɑ΂���ϓ_�ʕ]���E���ȕ]��
						for (Data31954000_ScoreEntity scoreEntity:scoreEntityList) {
							if (scoreEntity.getSriu_item().equals(viewEntity.getSi_item())
									&& scoreEntity.getSrivt_srivtcode().equals(viewEntity.getSrivt_srivtcode())) {
								// �ϓ_�]��
								goptcodeDisplay.put(scoreEntity.getSrivt_goptcode(), scoreEntity.getSrvpe_reportdisplay());
							}
						}
						data31954000CmlguideFormBean.setSrvpe_reportdisplay(goptcodeDisplay);

						String descript = "";
						int count = 0;
						// ���яo�͎����ɑ΂���ϓ_�ʕ]���E���ȕ]��
						for (Data31954000_ScorptevalEntity scorptevalEntity:scorptevalEntityList) {
							if (scorptevalEntity.getSriu_item().equals(viewEntity.getSi_item())) {
								// �m��]��
								data31954000CmlguideFormBean.setSrevl_display(checkNullStr(scorptevalEntity.getSrevl_display()));
								// �L�q�]��
								if (count != 0) {
									descript += "\r\n\r\n";
								}
								descript += checkNullStr(scorptevalEntity.getSrev_descript());
								data31954000CmlguideFormBean.setSrev_descript(descript);
								count++;
							}
						}
						// Map�擾����Key�R�[�h�ݒ�
						String mapKeyCode = data31954000CmlguideFormBean.getSi_item() + "_" + data31954000CmlguideFormBean.getSrivt_srivtcode();
						cmlguideFormBeanMap.put(mapKeyCode, data31954000CmlguideFormBean);
					}
					// �ϓ_�E�]������FormBean�ɃZ�b�g
					data31954000FormBean.setCmlguideFormBeanList(cmlguideFormBeanMap);
					// ���ȕʊϓ_�f�[�^List
					data31954000FormBean.setItemViewpointList(itemViewpointList);
				}

				// ������
				if (printFormBean.isOutput_page2()) {

					// ------------------------------------------------------------------------------------------
					// �]��E�L�q�]���f�[�^�擾
					// ------------------------------------------------------------------------------------------
					param = new Object[]{user, nendo ,stucode, data31954000FormBean.getStuGrade()};
					queryManager =  new QueryManager(EXEC_SQL_SCORPTCOMMENT, param, Deta31954000SpScorptcommentEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Deta31954000SpScorptcommentEntity> scorptevalEntityList = (List<Deta31954000SpScorptcommentEntity>) this.executeQuery(queryManager);

					// �]��E�L�q�]���f�[�^��FormBean��
					for (Deta31954000SpScorptcommentEntity scorptcommentEntity:scorptevalEntityList) {
						if ("G1".equals(scorptcommentEntity.getSrcom_item())) {
							data31954000FormBean.setSrcom_comment_G1(scorptcommentEntity.getSrcom_comment());
						}
						else if ("G2".equals(scorptcommentEntity.getSrcom_item())) {
							data31954000FormBean.setSrcom_comment_G2(scorptcommentEntity.getSrcom_comment());
						}
						else if ("G3".equals(scorptcommentEntity.getSrcom_item())) {
							data31954000FormBean.setSrcom_comment_G3(scorptcommentEntity.getSrcom_comment());
						}

					}

					// ------------------------------------------------------------------------------------------
					// �s���̂����� �f�[�^�擾
					// ------------------------------------------------------------------------------------------
					String tempTerm = printFormBean.getTerm();

					if ("99".equals(printFormBean.getTerm())) {
						tempTerm = "03";
					}

					param = new Object[]{tempTerm,user, nendo ,stucode, user, nendo, tempTerm};
					queryManager =  new QueryManager(EXEC_SQL_MANIFESTACTION, param, Data31954000_ManifestActionEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31954000_ManifestActionEntity> manifestActionEntityList = (List<Data31954000_ManifestActionEntity>) this.executeQuery(queryManager);

					// ------------------------------------------------------------------------------------------
					// �o�Ȃ̋L�^���l�o��
					// ------------------------------------------------------------------------------------------
					param = new Object[]{user, nendo, stucode, data31954000FormBean.getStuGrade(), user, nendo, printFormBean.getTerm()};
					queryManager =  new QueryManager(EXEC_SQL_SCHOOLMEMO, param, Data31954000_SchoolMemoEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31954000_SchoolMemoEntity> schoolMemoEntityList = (List<Data31954000_SchoolMemoEntity>) this.executeQuery(queryManager);

					// ------------------------------------------------------------------------------------------
					// �o�Ȃ̋L�^�o��
					// ------------------------------------------------------------------------------------------
					param =  new Object[]{user, nendo, printFormBean.getTerm(), user, nendo, stucode
											,user, nendo, printFormBean.getTerm(), user, nendo, stucode};
					queryManager =  new QueryManager(EXEC_SQL_ATTEND, param, Data31954000_AttendEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31954000_AttendEntity> attendEntityList = (List<Data31954000_AttendEntity>) this.executeQuery(queryManager);

					// �����F�s���̂�����Map��FormBean�ɃZ�b�g
					data31954000FormBean.setFindingFormBeanList(setManifestActionFormBeanMap(manifestActionEntityList));
					// �����F�o�ȏ�
					data31954000FormBean.setAttendValueFormBeanList(setAttendValueFormBeanMap(attendEntityList,schoolMemoEntityList));
					// �s���̂�����List
					data31954000FormBean.setManifestActionEntityList( setManifestActionEntityList(manifestActionEntityList));
				}

				// ���k���List
				data31954000FormBeanList.add(data31954000FormBean);
			}

			// ���k���List��FormBean�Ɋi�[
			printFormBean.setData31954000FormBeanList(data31954000FormBeanList);


		} catch (Exception e) {
			log.error("�ʒm�\����(�ʒm�\) DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
	}

	/**
	 * @return the printFormBean
	 */
	public Print31954000FormBean getPrintFormBean() {
		return printFormBean;
	}


	/**
	 * �S�C�������擾����ׂ̃o�C���h�ϐ��Z�b�g
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param date	�o�͑Ώۓ��t
	 * @param spgdCode	���ʎx���w���ԍ�
	 * @return �o�C���h�ϐ�
	 */
	private Object[] getTeacherNameParam(String user, String nendo, String date, String spgdCode) {

		Object[] param = {
						  user
						, nendo
						, date
						, spgdCode
						, user
						, nendo
						, spgdCode
						, user };
		return param;
	}

	/**
	 * �S�C�������3���擾
	 * @param teacherEntitieList
	 * @return
	 */
	private List<String> getTeacherList(List<Data31954000_TeacherEntity> teacherEntitieList){

		// ���ʎx���w���S�C���i�[List
		List<String> teacherList = new ArrayList<String>();
		// �擾����Entity�����ʂR���̒S�C��Bean�ɃZ�b�g
		for(Data31954000_TeacherEntity teacherEntity:teacherEntitieList){
			boolean addFlg = false;
			// ���ʎx���w���S�C���i�[List����̏ꍇ
			if(teacherList.size() == 0){
				// List�ɒǉ�
				teacherList.add(teacherEntity.getStf_name());
			}
			else {
				// List�ɒǉ������S�C�ƁA�d�����Ă��Ȃ����̃`�F�b�N
				for(String teacher:teacherList){
					if(teacher.equals(teacherEntity.getStf_name())) {
						// �ǉ��ς݂Ȃ�΃t���O��true
						addFlg = true;
						break;
					}
				}
				// �t���O��false�Ȃ�΁AList�ɒǉ�
				if(!addFlg){
					teacherList.add(teacherEntity.getStf_name());
				}
			}
			// List�o�^����3���Ȃ�΃��[�v�I��
			if(teacherList.size() == 3){
				break;
			}
		}
		return teacherList;
	}


	/**
	 * �����̏o�ȏ󋵂̃f�[�^��Map�ɕϊ�
	 * @param attendEntityList
	 * @return
	 */
	private Map<String, Data31954000FindingsFormBean> setManifestActionFormBeanMap(List<Data31954000_ManifestActionEntity> manifestActionEntityList){

		// ����Map
		Map<String, Data31954000FindingsFormBean> findingFormBeanMap = new HashMap<String, Data31954000FindingsFormBean>();
		// �����F�s���̂�����
		for (Data31954000_ManifestActionEntity manifestActionEntity:manifestActionEntityList) {
			// �s���̂�����
			Data31954000FindingsFormBean findingsFormBean = new Data31954000FindingsFormBean();
			// �w�Дԍ�
			findingsFormBean.setCls_stucode(manifestActionEntity.getCls_stucode());
			// �o�͎���
			findingsFormBean.setGopt_goptcode(manifestActionEntity.getGopt_goptcode());
			// ���ڃR�[�h
			findingsFormBean.setSravt_sravtcode(manifestActionEntity.getSravt_sravtcode());
			// ���ږ�
			findingsFormBean.setSravt_name(manifestActionEntity.getSravt_name());
			// �ʍ���
			findingsFormBean.setSravv_indivivp(manifestActionEntity.getSravv_indivivp());
			// �ʒm�\�\���n
			findingsFormBean.setSrace_display(manifestActionEntity.getSrace_display());
			// Map�ɒǉ�
			findingFormBeanMap.put(manifestActionEntity.getGopt_goptcode()+"_"+manifestActionEntity.getSravt_sravtcode(),findingsFormBean);
		}
		return findingFormBeanMap;
	}

	/**
	 * �����̏o�ȏ󋵂̃f�[�^��Map�ɕϊ�
	 * @param attendEntityList
	 * @return
	 */
	private Map<String, Data31954000AttendValueFormBean> setAttendValueFormBeanMap(List<Data31954000_AttendEntity> attendEntityList,List<Data31954000_SchoolMemoEntity> schoolMemoEntityList){

		// �����E�o�ȕ]��Map
		Map<String, Data31954000AttendValueFormBean> attendValueFormBeanMap =  new HashMap<String, Data31954000AttendValueFormBean>();
		// �����F�s���̂�����
		for (Data31954000_AttendEntity attendEntity:attendEntityList) {
			// �s���̂�����
			Data31954000AttendValueFormBean attendEntityFormBean = new Data31954000AttendValueFormBean();
			// �o�͎�����
			attendEntityFormBean.setGopt_name(attendEntity.getGopt_name());
			// �o�͎���
			attendEntityFormBean.setGopt_goptcode(attendEntity.getGopt_goptcode());
			// �\����
			attendEntityFormBean.setGopt_order(attendEntity.getGopt_order());
			// �w�N
			attendEntityFormBean.setCls_glade(attendEntity.getCls_glade());
			// �w�Дԍ�
			attendEntityFormBean.setCls_stucode(attendEntity.getCls_stucode());
			// �N���X�ԍ�
			attendEntityFormBean.setCls_number(attendEntity.getCls_number());
			// ���Ɠ���
			attendEntityFormBean.setClasscount(attendEntity.getClasscount());
			// �o��E����������
			attendEntityFormBean.setSchoolkindcount(attendEntity.getSchoolkindcount());
			// �o�Ȃ��ׂ�����
			attendEntityFormBean.setMustcount(attendEntity.getMustcount());
			// ���ȓ���
			attendEntityFormBean.setAbsencecount(attendEntity.getAbsencecount());
			// �o�ȓ���
			attendEntityFormBean.setAttendcount(attendEntity.getAttendcount());
			// �x������
			attendEntityFormBean.setLatecount(attendEntity.getLatecount());
			// ���ޓ���
			attendEntityFormBean.setLeavecount(attendEntity.getLeavecount());

			// �����F���l�f�[�^��FormBean��
			for (Data31954000_SchoolMemoEntity schoolMemoEntity:schoolMemoEntityList) {
				if (attendEntity.getGopt_goptcode() != null) {
					if (attendEntity.getGopt_goptcode().equals(schoolMemoEntity.getRar_term())) {
						attendEntityFormBean.setRar_memo(schoolMemoEntity.getRar_memo());
					}
				}
			}

			// Map�ɒǉ�
			attendValueFormBeanMap.put(attendEntity.getGopt_goptcode(),attendEntityFormBean);
		}
		return attendValueFormBeanMap;
	}

	/**
	 * �s���̂����ꃊ�X�g
	 * @param entityList
	 * @return
	 */
	private List<Data31954000_ManifestActionEntity> setManifestActionEntityList(List<Data31954000_ManifestActionEntity> entityList){

		List<Data31954000_ManifestActionEntity> tempEntity = new ArrayList<Data31954000_ManifestActionEntity>();

		String term = printFormBean.getTerm();

		if ("99".equals(term)){
			term = "03";
		}

		for (Data31954000_ManifestActionEntity entity:entityList) {
			if (term.equals(entity.getGopt_goptcode())) {
				tempEntity.add(entity);
			}
		}
		return tempEntity;
	}

	/**
	 * Null�`�F�b�N����сA�󔒂�Ԃ�
	 * @param str
	 * @return
	 */
	private String checkNullStr(String str){

		if (str == null || str.isEmpty()) {
			str = "";
		}
		return str;
	}
}
