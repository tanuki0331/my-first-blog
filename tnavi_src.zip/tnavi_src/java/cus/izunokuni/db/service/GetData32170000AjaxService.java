package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CmlguideactviewpointvalueEntity;
import jp.co.systemd.tnavi.common.db.entity.CmlguidespeactvalueEntity;
import jp.co.systemd.tnavi.common.db.entity.CodeEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_CmlguideforeignlangactEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_CmlguidetotalacttitleEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data32170000_Cmlguidetotalactvalue;

/**
 * <PRE>
 * Ajax �w���v�^����(���ʎx�� �ɓ��̍��s�E���쒬) �e�f�[�^���pService
 * </PRE>
 *
 * <B>Create</B> 2019.01.11 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author
 * @since.
 */
public class GetData32170000AjaxService extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(GetData32170000AjaxService.class);

	/** �����R�[�h */
	protected String user;

	/** �N�x **/
	protected String year;

	/** �w�Дԍ� **/
	private String stuCode;

	/** �w�N */
	private String grade;
	/** �N���X�ԍ� */
	private String clsno;
	/** ����ID */
	private String sgcr_item;

	private Map<String, String> resultMap = new HashMap<String, String>();

	public GetData32170000AjaxService(String userCode, String year, String stuCode, String grade, String clsno,
			String sgcr_item) {
		this.user = userCode;
		this.year = year;
		this.stuCode = stuCode;
		this.grade = grade;
		this.clsno = clsno;
		this.sgcr_item = sgcr_item;

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void doQuery() throws TnaviDbException {

		if(sgcr_item.equals("FE")){
			//�O���ꊈ���̋L�^
			doQueryForFE();
		}else if(sgcr_item.equals("SE")){
			//���ʊ����̋L�^
			doQueryForSE();
		}else if(sgcr_item.equals("BE")){
			//�s���̋L�^
			doQueryForBE();
		}else{
			//�����I�Ȋw�K�̎��Ԃ̋L�^
			doQueryForSynthesis();
		}

	}

	/**
	 * �O���ꊈ���̋L�^���擾
	 */
	private void doQueryForFE() {
		// �p�����[�^����
		Object[] param = {user, year, stuCode};
		// �擾�������s
		QueryManager queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguideforeignlangact.sql", param, Data32170000_CmlguideforeignlangactEntity.class);
		// --- �������s
		List<Data32170000_CmlguideforeignlangactEntity> resultList = (List<Data32170000_CmlguideforeignlangactEntity>)this.executeQuery(queryManager);
		if(resultList != null){
			for(Data32170000_CmlguideforeignlangactEntity result : resultList){
				resultMap.put(result.getGfla_givtcode(), result.getGfla_eval());
			}
		}
	}

	/**
	 * ���ʊ����̋L�^���擾
	 */
	private void doQueryForSE() {
		// �p�����[�^����
		Object[] param = {user, year, stuCode};
		// �擾�������s
		QueryManager queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguidespeactvalue.sql", param, CmlguidespeactvalueEntity.class);
		// --- �������s
		List<CmlguidespeactvalueEntity> resultList = (List<CmlguidespeactvalueEntity>)this.executeQuery(queryManager);
		if(resultList != null){
			for(CmlguidespeactvalueEntity result : resultList){
				resultMap.put(result.getGsav_gsatcode(), result.getGsav_gsaecode());
			}
		}
	}

	/**
	 * �s���̋L�^
	 */
	private void doQueryForBE() {
		// �p�����[�^����
		Object[] param = {user, year, stuCode};
		// �擾�������s
		QueryManager queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguideactviewpointvalue.sql", param, CmlguideactviewpointvalueEntity.class);
		// --- �������s
		List<CmlguideactviewpointvalueEntity> resultList = (List<CmlguideactviewpointvalueEntity>)this.executeQuery(queryManager);
		if(resultList != null){
			for(CmlguideactviewpointvalueEntity result : resultList){
				resultMap.put(result.getGavv_gavtcode(), result.getGavv_gacecode());
			}
		}
	}

	/**
	 * �����I�Ȋw�K�̎��Ԃ̋L�^���擾
	 */
	private void doQueryForSynthesis() {

		// �p�����[�^����
		Object [] param = new Object[]{user, "606", "005"};
		// QueryManager����
		QueryManager queryManager = new QueryManager("common/getCodeByUserAndKindAndCode.sql", param, CodeEntity.class);
		// �N�G���̎��s(List�`���Ńf�[�^�i�[)
		List<CodeEntity> entityList = (List<CodeEntity>)this.executeQuery(queryManager);

		if (0 < entityList.size()){

			String cod_value2 = entityList.get(0).getCod_value2();
			if(cod_value2.equals("2")){

				param = new Object[]{user, year, stuCode};
				queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguidetotalactvalue.sql", param, Data32170000_Cmlguidetotalactvalue.class);
				List<Data32170000_Cmlguidetotalactvalue> resultList = (List<Data32170000_Cmlguidetotalactvalue>)this.executeQuery(queryManager);
				if(resultList != null){
					for(Data32170000_Cmlguidetotalactvalue result : resultList){
						resultMap.put("TC", result.getGtav_content());//�w�K����
						resultMap.put("TV", result.getGtav_viewpoint());//�ϓ_
						resultMap.put("TE", result.getGtav_value());//�]��
					}
				}

			}else{
				if(cod_value2.equals("1")){

					//getData32170000_Cmlguidetotalacttitle.sql
					param = new Object[]{user, year, grade};
					queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguidetotalacttitle.sql", param, Data32170000_CmlguidetotalacttitleEntity.class);
					queryManager.setPlusSQL("AND gtat_clsno = '" + clsno + "'");
					List<Data32170000_CmlguidetotalacttitleEntity> resultList = (List<Data32170000_CmlguidetotalacttitleEntity>)this.executeQuery(queryManager);
					if(resultList != null){
						for(Data32170000_CmlguidetotalacttitleEntity result : resultList){
							resultMap.put("TC", result.getGtat_act());//�w�K����
							resultMap.put("TV", result.getGtat_pointview());//�ϓ_
						}
					}

				}else{

					//getData32170000_Cmlguidetotalacttitle.sql
					param = new Object[]{user, year, grade};
					queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguidetotalacttitle.sql", param, Data32170000_CmlguidetotalacttitleEntity.class);
					List<Data32170000_CmlguidetotalacttitleEntity> resultList = (List<Data32170000_CmlguidetotalacttitleEntity>)this.executeQuery(queryManager);
					if(resultList != null){
						for(Data32170000_CmlguidetotalacttitleEntity result : resultList){
							resultMap.put("TC", result.getGtat_act());//�w�K����
							resultMap.put("TV", result.getGtat_pointview());//�ϓ_
						}
					}
				}

				param = new Object[]{user, year, stuCode};
				queryManager = new QueryManager("cus/izunokuni/getData32170000_Cmlguidetotalactvalue.sql", param, Data32170000_Cmlguidetotalactvalue.class);
				List<Data32170000_Cmlguidetotalactvalue> resultList = (List<Data32170000_Cmlguidetotalactvalue>)this.executeQuery(queryManager);
				if(resultList != null){
					for(Data32170000_Cmlguidetotalactvalue result : resultList){
						resultMap.put("TE", result.getGtav_value());//�]��
					}
				}
			}

		}

	}

	public Map<String, String> getResultMap() {
		return this.resultMap;
	}
}
