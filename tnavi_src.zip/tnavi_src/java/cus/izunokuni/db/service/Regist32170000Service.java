package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.db.QueryUpdateManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Detail32170000FormBean;

/**
 * <PRE>
 * �w���v�^����(���ʎx�� �ɓ��̍��s�E���쒬) �X�V Service.
 * </PRE>
 *
 * <B>Create</B> 2019.01.11 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author System D, Inc.
 * @since 1.0.
 */
public class Regist32170000Service extends AbstractExecuteQuery {

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist32170000Service.class);

	private String user = "";
	private String year = "";
	private String stucode = "";
	private String grade = "";
	private String curcode = "";
	private String foreignActItemCode = "";
	private String systemDate = "";
	private String staffId = "";

	HttpServletRequest request = null;

	/**
	 * �R���X�g���N�^
	 * @param user �����R�[�h
	 * @param year �N�x
	 * @param stucode �w�Дԍ�
	 * @param grade �w�N
	 * @param date
	 * @param staffId
	 * @param request
	 */
	public Regist32170000Service(String user, String year, String stucode, String grade, String curcode,
			String foreignActItemCode, String systemDate, String staffId, HttpServletRequest request) {

		this.user = user;
		this.year = year;
		this.stucode = stucode;
		this.grade = grade;
		this.curcode = curcode;
		this.foreignActItemCode = foreignActItemCode;
		this.systemDate = systemDate;
		this.staffId = staffId;
		this.request = request;
	}

	@Override
	public void execute() throws TnaviDbException {
		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {
		doQueryForOther(year, stucode, grade);
	}

	/**
	 * �����󋵓����擾����N�G�������s����
	 * @param year
	 * @param stucode
	 */
	private void doQueryForOther(String year, String stucode, String glade){

		QueryUpdateBatchManager updateCgVpValue = new QueryUpdateBatchManager("cus/izunokuni/updateInsert32170000_Cmlguideviewpointvalue.sql");
		this.initialBatchUpdate(updateCgVpValue);

		QueryUpdateBatchManager updateCgEval = new QueryUpdateBatchManager("cus/izunokuni/updateInsert32170000_Cmlguideevalvalue.sql");
		this.initialBatchUpdate(updateCgEval);

		try {
			// --- �m�萬�� �]���E�]�� �X�V
			updateVpAndEval(year, stucode, glade, updateCgVpValue, updateCgEval);

			// --- �o���̋L�^
			updateAttendRecord(year, stucode, glade);

			// -- ��L�ȊO�̕]�����͒l�擾�ƍX�V
			Map<String, List<String[]>> inputValMap = editInputValueMap();
			updateOtherRecord(year, stucode, glade, inputValMap);

			this.commit();

		} catch (Exception e){
			log.error("�w���v�^����(���ʎx��)(�m�I�ȊO) �X�V���ɃG���[���������܂����B:", e);
			this.rollback();
			throw new TnaviDbException(e);

		} finally {
			if(null != updateCgVpValue){
				this.closeBatchUpdate(updateCgVpValue);
				updateCgVpValue = null;
			}
			if(null != updateCgEval){
				this.closeBatchUpdate(updateCgEval);
				updateCgEval = null;
			}
		}

	}

	/**
	 * �m�萬�� �]���E�]�� �X�V
	 * @param nendo �N�x
	 * @param stucode �w�Дԍ�
	 * @param grade �w�N
	 * @param updateCgVpValue �ϓ_�ʕ]���X�V�pQueryUpdateBatchManager
	 * @param updateCgEval �]��X�V�pQueryUpdateBatchManager
	 */
	private void updateVpAndEval(String nendo, String stucode, String grade,
			QueryUpdateBatchManager updateCgVpValue, QueryUpdateBatchManager updateCgEval) {

		Set<String> kyokaList = new HashSet<String>();
		Object[] insParam;
		Object[] updParam;

		//�m�萬�� �]��
		Map<String, String[]> map_par = request.getParameterMap();
		Set<String> map_ite = map_par.keySet();
		for (String key : map_ite) {
			String par[]=map_par.get(key);

			for (int i = 0; i < par.length; i++) {
				String val = par[i];
				if ( key.startsWith("gvpecode_") ){

					String item = key.split("_")[1];//���ȃR�[�h
					String givtcode = key.split("_")[2];//�ϓ_�R�[�h

					// UPDATE param
					updParam = new Object[] {
							val, systemDate, staffId, 					// �X�V�l
							user, nendo, stucode, grade, item, givtcode // �����l
							};
					// INSERT param
					insParam = new Object[] {
							user, nendo, stucode, grade, item, givtcode, null, val, systemDate, staffId
							};

					this.executeBatchUpdate( updateCgVpValue,
							Stream.concat(Arrays.stream(updParam), Arrays.stream(insParam)).toArray() );

					kyokaList.add(item);
				}
			}
		}

		//�m�萬�� �]��E�ύX���R�E���l
		for(String item : kyokaList){

			String gevlcode = request.getParameter("gevlcode_" + item);
			String changememo = request.getParameter("changememo_" + item);
			String biko = request.getParameter("memo_" + item);

			// UPDATE param
			updParam = new Object[] {
					gevlcode, changememo, biko, systemDate, staffId, 	// �X�V�l
					user, nendo, stucode, grade, item 					// �����l
					};
			// INSERT param
			insParam = new Object[] {
					user, nendo, stucode, grade, item, null, gevlcode, changememo, biko, systemDate, staffId
					};

			this.executeBatchUpdate( updateCgEval,
					Stream.concat(Arrays.stream(updParam), Arrays.stream(insParam)).toArray() );
		}

	}

	/**
	 * ���ʊ����̋L�^�E�s���̋L�^�E���w�E���������y�юw����Q�l�ƂȂ鏔���� ���͒l�擾
	 * key�ɍ��ڎ�ʂ��Avalue�ɓ��͒l�̔z����i�[����Map��Ԃ��B
	 *
	 * <pre>
	 * Map��value�Ɋi�[�����List�v�f�̔z��͉��L�̍\��
	 *  [0]�]��������܂��͕]���l�R�[�h
	 *  [1]�ϓ_�R�[�h
	 * </pre>
	 *
	 * @return ���͒l��ێ�����Map
	 */
	private Map<String, List<String[]>> editInputValueMap() {
		//
		Map<String, List<String[]>> inputValMap = new HashMap<String, List<String[]>>();

		Map<String, String[]> map_par = request.getParameterMap();
		Set<String> map_ite = map_par.keySet();
		for (String key : map_ite) {
			String par[]=map_par.get(key);

			for (int i = 0; i < par.length; i++) {
				String val = par[i]; // ���͒l

				if ( key.startsWith("record_") ){
					String[] keys = key.split("_");
					String itemKind = keys[1]; 	// ���ڎ��
					String vpcode = "";			// �ϓ_�R�[�h

					if(keys.length > 2){
						vpcode = keys[2];
						// ���ʊ����̋L�^ or �s���̋L�^�ł���ꍇ�͕]���l�R�[�h���擾
						if((itemKind.equals(Detail32170000FormBean.SPECIAL_ACT) || itemKind.equals(Detail32170000FormBean.ACT))){
							val = request.getParameter(key);
						}
					}

					if (inputValMap.containsKey(itemKind)) {
						inputValMap.get(itemKind).add(new String[]{val, vpcode});
					}else{
						List<String[]> list = new ArrayList<String[]>();
						list.add(new String[]{val, vpcode});
						inputValMap.put(itemKind, list);
					}
				}
			}

		}

		return inputValMap;
	}

	/**
	 * �o���̋L�^(�w���v�^)�e�[�u���̍X�V����
	 * @param nendo
	 * @param stucode
	 * @param grade
	 */
	private void updateAttendRecord(String nendo, String stucode, String grade) {

		Object[] updParam;
		Object[] insParam;

		String gar_count = request.getParameter("gar_count");
		if(gar_count != null && gar_count.length() == 0){
			gar_count = null;
		}
		String gar_stop = request.getParameter("gar_stop");
		if(gar_stop != null && gar_stop.length() == 0){
			gar_stop = null;
		}
		String gar_must = request.getParameter("gar_must");
		if(gar_must != null && gar_must.length() == 0){
			gar_must = null;
		}
		String gar_absence = request.getParameter("gar_absence");
		if(gar_absence != null && gar_absence.length() == 0){
			gar_absence = null;
		}
		String gar_attend = request.getParameter("gar_attend");
		if(gar_attend != null && gar_attend.length() == 0){
			gar_attend = null;
		}

		//�o���̋L�^�e�[�u��(�w���v�^)
		updParam = new Object[] {
				// �X�V�l
				gar_count
				,gar_stop
				,gar_must
				,gar_absence
				,gar_attend
				,request.getParameter("gar_memo")
				,request.getParameter("gar_update")
				,request.getParameter("gar_upuser")
				// �����l
				,user
				,nendo
				,stucode
				,grade
		};
		insParam = new Object[] {
				user
				,nendo
				,stucode
				,grade
				,gar_count
				,gar_stop
				,gar_must
				,gar_absence
				,gar_attend
				,null
				,null
				,request.getParameter("gar_memo")
				,systemDate
				,staffId
		};

		QueryUpdateManager updateQm = new QueryUpdateManager("cus/izunokuni/updateInsert32170000_Cmlguideattendrecord.sql",
				Stream.concat( Arrays.stream(updParam), Arrays.stream(insParam)).toArray());
		this.executeUpdate(updateQm);
	}

	/**
	 * �ϓ_�ʕ]���A�]��A�o���̋L�^�ȊO�̃e�[�u���X�V����
	 * @param nendo
	 * @param stucode
	 * @param grade
	 * @param inputValMap
	 */
	private void updateOtherRecord(String nendo, String stucode, String grade, Map<String, List<String[]>> inputValMap) {

		for (Entry<String, List<String[]>> map : inputValMap.entrySet()) {
			for (String[] arr : map.getValue()) {
				System.out.println("key:"+map.getKey() + " hyoka:"+ arr[0] + " vp:" + arr[1]);
			}
		}

		// ���ʂ̋��� ����
		if (inputValMap.containsKey(Detail32170000FormBean.MORAL)) {
			updateMoral(nendo, stucode, grade, inputValMap.get(Detail32170000FormBean.MORAL));
		}

		// �O���ꊈ���̋L�^
		if (inputValMap.containsKey(Detail32170000FormBean.FOREIGNACT)) {
			updateForeignact(nendo, stucode, grade, inputValMap.get(Detail32170000FormBean.FOREIGNACT));
		}

		// �����I�Ȋw�K�̎��Ԃ̋L�^
		if (inputValMap.containsKey(Detail32170000FormBean.TOTALACT_EVAL)) {
			updateTotalact(nendo, stucode, grade, inputValMap);
		}

		// ���ʊ����̋L�^
		if (inputValMap.containsKey(Detail32170000FormBean.SPECIAL_ACT)) {
			updateSpeact(nendo, stucode, grade, inputValMap.get(Detail32170000FormBean.SPECIAL_ACT));
		}

		// �s���̋L�^
		if (inputValMap.containsKey(Detail32170000FormBean.ACT)) {
			updateAct(nendo, stucode, grade, inputValMap.get(Detail32170000FormBean.ACT));
		}

		// ���������y�юw����Q�l�ƂȂ鏔����
		if (inputValMap.containsKey(Detail32170000FormBean.COMMENT)) {
			updateComment(nendo, stucode, grade, inputValMap.get(Detail32170000FormBean.COMMENT));
		}
	}


	/**
	 * ���������y�юw����Q�l�ƂȂ鏔���� �X�V
	 * @param nendo
	 * @param stucode
	 * @param grade
	 * @param dataList �X�V�l�i�[List
	 */
	private void updateComment(String nendo, String stucode, String grade, List<String[]> dataList) {

		String val = dataList.get(0)[0];

		Object[] updParam = new Object[] {
			// �X�V�l
			 val ,systemDate ,staffId
			// �����l
			,user, nendo, stucode
		};
		Object[] insParam = new Object[] { user, nendo, grade, stucode, val,
				null, null, null, null, null, null, null, null, null, null,
				systemDate ,staffId };
		QueryUpdateManager updateQm = new QueryUpdateManager("cus/izunokuni/updateInsert32170000_Cmlguidecomment.sql",
				Stream.concat( Arrays.stream(updParam), Arrays.stream(insParam)).toArray());
		this.executeUpdate(updateQm);
	}

	/**
	 * �s���̋L�^ �X�V
	 * @param nendo
	 * @param stucode
	 * @param grade
	 * @param dataList �X�V�l�i�[List
	 */
	private void updateAct(String nendo, String stucode, String grade, List<String[]> dataList) {

		Object[] updParam = null;
		Object[] insParam = null;
		QueryUpdateManager updateQm = null;

		// �����ϓ_�̂��߁A�ϓ_���ɏ���
		for (String[] dataArr : dataList) {
			String val = dataArr[0];
			String vpCode = dataArr[1];

			updParam = new Object[] {
					// �X�V�l
					val ,systemDate ,staffId
					// �����l
					,user, nendo, stucode, vpCode
			};
			insParam = new Object[] { user, nendo, stucode, grade, vpCode, val, systemDate ,staffId, curcode };
			updateQm = new QueryUpdateManager("cus/izunokuni/updateInsert32170000_Cmlguideact.sql",
					Stream.concat( Arrays.stream(updParam), Arrays.stream(insParam)).toArray());
			this.executeUpdate(updateQm);
		}
	}

	/**
	 * ���ʊ����̋L�^ �X�V
	 * @param nendo
	 * @param stucode
	 * @param grade
	 * @param dataList �X�V�l�i�[List
	 */
	private void updateSpeact(String nendo, String stucode, String grade, List<String[]> dataList) {

		Object[] updParam = null;
		Object[] insParam = null;
		QueryUpdateManager updateQm = null;

		// �����ϓ_�̂��߁A�ϓ_���ɏ���
		for (String[] dataArr : dataList) {
			String val = dataArr[0];
			String vpCode = dataArr[1];

			updParam = new Object[] {
				// �X�V�l
				 val ,systemDate ,staffId
				// �����l
				,user, nendo, stucode, vpCode
			};
			insParam = new Object[] { user, nendo, stucode, grade, vpCode, val, systemDate ,staffId, curcode };
			updateQm = new QueryUpdateManager("cus/izunokuni/updateInsert32170000_Cmlguidespeact.sql",
					Stream.concat( Arrays.stream(updParam), Arrays.stream(insParam)).toArray());
			this.executeUpdate(updateQm);
		}
	}

	/**
	 * �����I�Ȋw�K�̎��Ԃ̋L�^ �X�V
	 * @param nendo
	 * @param stucode
	 * @param grade
	 * @param inputValMap �X�V�l�i�[Map
	 */
	private void updateTotalact(String nendo, String stucode, String grade, Map<String, List<String[]>> inputValMap) {

		final String VPCODE = "0001"; // �ϓ_�R�[�h��0001�Œ�
		String content = null;
		String viewpoint = null;
		String eval = null;

		// �w�K����
		if (inputValMap.containsKey(Detail32170000FormBean.TOTALACT_CONTENT)) {
			content = inputValMap.get(Detail32170000FormBean.TOTALACT_CONTENT).get(0)[0];
		}
		// �ϓ_
		if (inputValMap.containsKey(Detail32170000FormBean.TOTALACT_VP)) {
			viewpoint = inputValMap.get(Detail32170000FormBean.TOTALACT_VP).get(0)[0];
		}
		// �]��
		eval = inputValMap.get(Detail32170000FormBean.TOTALACT_EVAL).get(0)[0];

		Object[] updParam = new Object[] {
			// �X�V�l
				eval, content, viewpoint, systemDate ,staffId
			// �����l
			,user, nendo, stucode, VPCODE
		};
		Object[] insParam = new Object[] {
				user, nendo, stucode, grade, VPCODE, eval, systemDate ,staffId, curcode, content, viewpoint };
		QueryUpdateManager updateQm = new QueryUpdateManager("cus/izunokuni/updateInsert32170000_Cmlguidetotalact.sql",
				Stream.concat( Arrays.stream(updParam), Arrays.stream(insParam)).toArray());
		this.executeUpdate(updateQm);
	}

	/**
	 * �O���ꊈ���̋L�^ �X�V
	 * @param nendo
	 * @param stucode
	 * @param grade
	 * @param dataList �X�V�l�i�[List
	 */
	private void updateForeignact(String nendo, String stucode, String grade, List<String[]> dataList) {

		Object[] updParam = null;
		Object[] insParam = null;
		QueryUpdateManager updateQm = null;

		// �����ϓ_�̃P�[�X�����邽�߁A�ϓ_���ɏ���
		for (String[] dataArr : dataList) {
			String val = dataArr[0];
			String vpCode = dataArr[1];

			updParam = new Object[] {
				// �X�V�l
				 val ,systemDate ,staffId
				// �����l
				,user, nendo, stucode, vpCode
			};
			insParam = new Object[] {
					user, nendo, curcode, stucode, grade, foreignActItemCode, vpCode, val ,systemDate ,staffId
					};
			updateQm = new QueryUpdateManager("cus/izunokuni/updateInsert32170000_Cmlguideforeignact.sql",
					Stream.concat( Arrays.stream(updParam), Arrays.stream(insParam)).toArray());
			this.executeUpdate(updateQm);
		}
	}

	/**
	 * �����̕]�� �X�V
	 * @param nendo
	 * @param stucode
	 * @param grade
	 * @param dataList �X�V�l�i�[List
	 */
	private void updateMoral(String nendo, String stucode, String grade, List<String[]> dataList) {

		String val = dataList.get(0)[0];

		Object[] updParam = new Object[] {
			// �X�V�l
			 val ,systemDate ,staffId
			// �����l
			,user, nendo, stucode
		};
		Object[] insParam = new Object[] { user, nendo, stucode, val ,systemDate ,staffId };
		QueryUpdateManager updateQm = new QueryUpdateManager("cus/izunokuni/updateInsert32170000_Cmlguidemoral.sql",
				Stream.concat( Arrays.stream(updParam), Arrays.stream(insParam)).toArray());
		this.executeUpdate(updateQm);
	}

}
