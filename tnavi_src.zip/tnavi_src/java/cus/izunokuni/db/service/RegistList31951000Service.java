package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000StudentEntity;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.List31951000FormBean;

/**
 * <PRE>
 *  ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ꗗ �X�V Service.
 * </PRE>
 *
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class RegistList31951000Service  extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(RegistList31951000Service.class);
	
	private static final String serviceName = "���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ꗗ �X�V";

	/** ���sSQL */
	private static final String EXEC_SQL_INSERT = "common/deleteSpScorptevalmethodByPK.sql";
	private static final String EXEC_SQL_DELETE = "common/insertSpScorptevalmethod.sql";

	/** ����SessionBean */
	private SystemInfoBean sessionBean;

	/** �ꗗFormBean. */
	private List31951000FormBean listFormBean;


	/**
	 * <pre>
	 * Request�̓��e��FormBean���쐬����
	 * ���̏�����Action.doAction���\�b�h���ŌĂяo�����
	 * </pre>
	 *
	 * @param request
	 *            HTTP���N�G�X�g
	 * @param sessionBean
	 *            �V�X�e�����Bean(�Z�b�V�������)
	 * @throws TnaviDbException
	 *             DB��O�������ɃX���[�����
	 */
	public void execute(HttpServletRequest request, SystemInfoBean sessionBean, Object formBean)
			throws TnaviDbException {
		
		// ����Session��ݒ�
		this.sessionBean = sessionBean;
		
		// FormBean�̍쐬
		listFormBean = (List31951000FormBean) formBean;
		
		for (Data31951000StudentEntity student : listFormBean.getStudentList()) {
			student.setSrem_em(request.getParameter("srem_em_" + student.getCls_stucode()));
		}
		
		// �N�G�������s����
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_DELETE);
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager(EXEC_SQL_INSERT);
		
		try {
			
			this.initialBatchUpdate(insertQM);
			this.initialBatchUpdate(deleteQM);
			
			for (Data31951000StudentEntity student : listFormBean.getStudentList()) {
				// DELETE
				Object[] deleteParam = new Object[]{sessionBean.getUserCode()
											 ,sessionBean.getSystemNendoSeireki()
											 ,student.getCls_stucode()
											 ,student.getCls_glade()
											 ,listFormBean.getGoptcode()};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
				//INSERT
				if(student.getSrem_em() != null){
					Object[] insertParam = new Object[]{sessionBean.getUserCode()
														 ,sessionBean.getSystemNendoSeireki()
														 ,student.getCls_stucode()
														 ,student.getCls_glade()
														 ,listFormBean.getGoptcode()
														 ,student.getSrem_em()
														 ,DateUtility.getSystemDate()
														 ,sessionBean.getStaffId()
														};
					this.executeBatchUpdate(insertQM, insertParam);
				}
				
			}

			this.commit();
			
			listFormBean.setUpdateMessage("�]�����@�̍X�V���������܂����B");
			
		} catch (Exception e) {
			this.rollback();
			log.error(serviceName + " DB�X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			if(insertQM != null){
				this.closeBatchUpdate(insertQM);
				insertQM = null;
			}
			if(deleteQM != null){
				this.closeBatchUpdate(deleteQM);
				deleteQM = null;
			}
		}

	}
	
	/**
	 * �ꗗFormBean���擾����
	 * @return
	 */
	public List31951000FormBean getListFormBean() {
		return listFormBean;
	}

}
