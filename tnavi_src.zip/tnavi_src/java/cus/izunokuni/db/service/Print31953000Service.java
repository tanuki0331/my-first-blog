package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryManager;
import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.common.db.entity.SchoolStampEntity;
import jp.co.systemd.tnavi.common.db.entity.UserHistoryEntity;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.BeanUtilManager;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_AttendEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_ItemViewScoreEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_ManifestActionEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_ManifestActionMemoEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_SchoolMemoEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_ScorptcommontextEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31953000_TeacherEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Deta31953000SpScorptcommentEntity;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31953000AttendValueFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31953000CmlguideFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31953000FindingsFormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Data31953000FormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Print31953000FormBean;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s���w�Z���ʎx���w��) ��� Service.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31953000Service  extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(Print31953000Service.class);

	/** ���sSQL */
	private static final String EXEC_SQL_SCHOOLSTAMP			= "sys/getSchoolStamp.sql";											// �Z��
	private static final String EXEC_SQL_SCHOOLNAME			= "common/getUserhistoryByUserAndYear.sql";							// �w�Z��
	private static final String EXEC_SQL_COMMONTEXT			= "cus/izunokuni/getDataPrint31953000_scorptcommontext.sql";	// ����ڕW�itbl_scorptcommontext)
	private static final String EXEC_SQL_PRINCIPAL_NAME		= "cus/izunokuni/getDataPrint31953000_principalName.sql";			// �Z������
	private static final String EXEC_SQL_TEACHER_NAME			= "cus/izunokuni/getDataPrint31953000_teacherName.sql";				// �S�C����
	private static final String EXEC_SQL_ITEMVIESCORE			= "cus/izunokuni/getDataPrint31953000_itemViewScore.sql";			// �w�K�̋L�^�@���ȁE�ϓ_���
	private static final String EXEC_SQL_SCORPTCOMMENT		= "cus/izunokuni/getDataPrint31953000_sp_scorptcomment.sql";		// �L�q�]�����̏o�͓��e
	private static final String EXEC_SQL_MANIFESTACTION		= "cus/izunokuni/getDataPrint31953000_sp_manifestAction.sql";		// �s���̂�����
	private static final String EXEC_SQL_MANIFESTACTIONMEMO	= "cus/izunokuni/getDataPrint31953000_sp_manifestActionMemo.sql";	// �s���̂�����(�L��)
	private static final String EXEC_SQL_SCHOOLMEMO			= "cus/izunokuni/getDataPrint31953000_schoolMemo.sql";				// �o�Ȃ̋L�^���l�o��
	private static final String EXEC_SQL_ATTEND 			    = "cus/izunokuni/getDataPrint31953000_attend.sql";					// �o���̋L�^
	private static final String EXEC_SQL_TERMLIST 		        = "cus/izunokuni/getDataPrint31953000_termList.sql";				// ���ԃ��X�g�擾
	private static final String EXEC_SQL_SREMEM 		        = "cus/izunokuni/getDataPrint31953000_ScorptevalMethod.sql";		// �L���\������擾


	/** ����SessionBean */
	private SystemInfoBean sessionBean;

	/** ���FormBean�@*/
	private Print31953000FormBean printFormBean;

	private static final String TERM_01 = "01";	// 1�w��
	private static final String TERM_02 = "02";	// 2�w��
	private static final String TERM_03 = "03"; // 3�w��
	private static final String TERM_99 = "99";	// �w�N��

	/**
	 * <pre>
	 * Request�̓��e��FormBean���쐬����
	 * ���̏�����Action.doAction���\�b�h���ŌĂяo�����
	 * </pre>
	 *
	 * @param request
	 *            HTTP���N�G�X�g
	 * @param sessionBean
	 *            �V�X�e�����Bean(�Z�b�V�������)
	 * @throws TnaviDbException
	 *             DB��O�������ɃX���[�����
	 */
	public void execute(Print31953000FormBean printFormBean, SystemInfoBean sessionBean)
			throws TnaviDbException {

		// FormBean��ݒ�
		this.printFormBean = printFormBean;
		// ����Session��ݒ�
		this.sessionBean = sessionBean;

		// �N�G�������s����
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		try {

			BeanUtilsBean beanUtil = BeanUtilManager.getDBToPresentationUtil();

			// �N�x
			String nendo = printFormBean.getNendo();
			// �����R�[�h
			String user = printFormBean.getUserCode();

			// �I����
			String endDate = DateUtility.getNendoEndDate(nendo, sessionBean.getSystemNendoStartDate().trim(),
					sessionBean.getSystemNendoEndDate().trim());

			// �\���p������
			printFormBean.setTermName(getTermName(printFormBean.getTerm()));

			// ------------------------------------------------------------------------------------------
			// �Z������(��ʏo�͓��t)
			// ------------------------------------------------------------------------------------------
			Object[] param = {user, printFormBean.getOutputDate()};
			QueryManager queryManager = new QueryManager(EXEC_SQL_PRINCIPAL_NAME, param, String.class);
			String principalName = (String) this.executeQuery(queryManager);
			printFormBean.setPrincipalName(principalName);

			param = new Object[]{user, endDate};
			queryManager = new QueryManager(EXEC_SQL_PRINCIPAL_NAME, param, String.class);
			String principalNameDeed = (String) this.executeQuery(queryManager);
			printFormBean.setPrincipalNameDeed(principalNameDeed);

			// ------------------------------------------------------------------------------------------
			// �w�Z��
			// ------------------------------------------------------------------------------------------
			param = new Object[]{user, nendo};
			queryManager = new QueryManager(EXEC_SQL_SCHOOLNAME, param, UserHistoryEntity.class);
			List<UserHistoryEntity> userHistoryEntityList = (List<UserHistoryEntity>) this.executeQuery(queryManager);
			// �w�Z������
			for (UserHistoryEntity usehEntity:userHistoryEntityList) {
				printFormBean.setSchoolName(usehEntity.getUseh_name_o());
			}

			// ------------------------------------------------------------------------------------------
			// �Z����
			// ------------------------------------------------------------------------------------------
			param = new Object[]{user, "03"};
			queryManager = new QueryManager(EXEC_SQL_SCHOOLSTAMP, param, SchoolStampEntity.class);
			List<SchoolStampEntity> principalEntityList = (List<SchoolStampEntity>) this.executeQuery(queryManager);
			// �Z�̓C���[�W�̎擾
			for (SchoolStampEntity principalEntity:principalEntityList){
				printFormBean.setSchoolPrincipalStampImage(principalEntity.getStm_image());
			}

			// �o�͑Ώې��kFormBeanList
			List<Data31953000FormBean> data31953000FormBeanList = new ArrayList<Data31953000FormBean>();

			// ���k���ƂɎ擾
			for(String stucode : printFormBean.getStucodeArray()){

				// �o�͑Ώې��kFormBean
				Data31953000FormBean data31953000FormBean = printFormBean.getStudentMap().get(stucode);

				// ------------------------------------------------------------------------------------------
				// �o�͕\���t���O�擾
				// ------------------------------------------------------------------------------------------
				param = new Object[]{user, nendo, data31953000FormBean.getStuStucode(),data31953000FormBean.getStuGrade(),printFormBean.getTerm()};
				queryManager = new QueryManager(EXEC_SQL_SREMEM, param, String.class);
				String srem_em = (String)this.executeQuery(queryManager);
				data31953000FormBean.setSrem_em(srem_em);

				// ------------------------------------------------------------------------------------------
				// �S�C����
				// ------------------------------------------------------------------------------------------
				param = getTeacherNameParam(user, nendo,printFormBean.getOutputDate(),data31953000FormBean.getStuClsno());
				queryManager = new QueryManager(EXEC_SQL_TEACHER_NAME, param, Data31953000_TeacherEntity.class);
				List<Data31953000_TeacherEntity> teacherEntitieList = (List<Data31953000_TeacherEntity>)this.executeQuery(queryManager);
				// �S�C����Bean�ɃZ�b�g
				data31953000FormBean.setTeacherNameList(getTeacherList(teacherEntitieList));

				//**********************************************************
				//              �\�����o�͂���ꍇ                         *
				//**********************************************************
				if (printFormBean.isOutput_cover()) {
					// ------------------------------------------------------------------------------------------
					// �Z��
					// ------------------------------------------------------------------------------------------
					param = new Object[]{user, "02"};
					queryManager = new QueryManager(EXEC_SQL_SCHOOLSTAMP, param, SchoolStampEntity.class);
					List<SchoolStampEntity> schoolStampEntityList = (List<SchoolStampEntity>) this.executeQuery(queryManager);
					// �Z�̓C���[�W�̎擾
					for (SchoolStampEntity schoolStampEntity:schoolStampEntityList){
						printFormBean.setTitleImage(schoolStampEntity.getStm_image());
					}

					// ------------------------------------------------------------------------------------------
					// ����ڕW(tbl_scorptcommontext)
					// ------------------------------------------------------------------------------------------
					param = new Object[]{ user, nendo, data31953000FormBean.getStuGrade(), sessionBean.getUseKind2()};
					queryManager = new QueryManager(EXEC_SQL_COMMONTEXT, param, Data31953000_ScorptcommontextEntity.class);
					List<Data31953000_ScorptcommontextEntity> commonTextEntityList = (List<Data31953000_ScorptcommontextEntity>)this.executeQuery(queryManager);
					data31953000FormBean.setScorptCommontextEntityList(commonTextEntityList);
				}

				// �������X�g
				param = new Object[]{user, nendo, printFormBean.getTerm()};
				queryManager = new QueryManager(EXEC_SQL_TERMLIST, param, CmlguideoutputtermEntity.class);
				List<CmlguideoutputtermEntity> termList = (List<CmlguideoutputtermEntity>)this.executeQuery(queryManager);
				List<String> termArray = new ArrayList<String>();
				for(int i=0; i<termList.size(); i++){
					termArray.add(termList.get(i).getGopt_goptcode());
				}
				if (TERM_03.equals(printFormBean.getTerm())) {
					termArray.add(TERM_99);
				}

				printFormBean.setTermArray(termArray);

				//**********************************************************
				//              �w�K�̂����� �ϓ_�ꗗ                    *
				//**********************************************************
				if (printFormBean.isOutput_page1()) {

					// ------------------------------------------------------------------------------------------
					// ���ȕʊϓ_�f�[�^���擾
					// ------------------------------------------------------------------------------------------
					param = new Object[]{printFormBean.getTerm(),printFormBean.getTerm(),printFormBean.getTerm(),user, nendo, data31953000FormBean.getStuStucode(),};
					queryManager = new QueryManager(EXEC_SQL_ITEMVIESCORE, param, Data31953000_ItemViewScoreEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31953000_ItemViewScoreEntity> itemViewscoretList = (List<Data31953000_ItemViewScoreEntity>) this.executeQuery(queryManager);


					// ------------------------------------------------------------------------------------------

					// �ϓ_���e�A�]���i�[�pMa
					// ------------------------------------------------------------------------------------------p
					Map<String, Data31953000CmlguideFormBean> cmlguideFormBeanMap = new HashMap<String, Data31953000CmlguideFormBean>();
					for (Data31953000_ItemViewScoreEntity viewEntity:itemViewscoretList) {
						// �ϓ_���i�[For��Bean
						Data31953000CmlguideFormBean data31953000CmlguideFormBean = new Data31953000CmlguideFormBean();

						beanUtil.copyProperties(data31953000CmlguideFormBean, viewEntity);

						// Map�擾����Key�R�[�h�ݒ�
						String mapKeyCode = data31953000CmlguideFormBean.getSriu_item() + "_" + data31953000CmlguideFormBean.getSrivt_srivtcode();
						cmlguideFormBeanMap.put(mapKeyCode, data31953000CmlguideFormBean);
					}
					// �ϓ_�E�]������FormBean�ɃZ�b�g
					data31953000FormBean.setCmlguideFormBeanList(cmlguideFormBeanMap);
					// ���ȕʊϓ_�f�[�^List
					data31953000FormBean.setItemViewScoreList(itemViewscoretList);
				}

				// ������
				if (printFormBean.isOutput_page2()) {

					// ------------------------------------------------------------------------------------------
					// �]��E�L�q�]���f�[�^�擾
					// ------------------------------------------------------------------------------------------
					param = new Object[]{user, nendo ,stucode, data31953000FormBean.getStuGrade(),printFormBean.getTerm()};
					queryManager =  new QueryManager(EXEC_SQL_SCORPTCOMMENT, param, Deta31953000SpScorptcommentEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Deta31953000SpScorptcommentEntity> scorptevalEntityList = (List<Deta31953000SpScorptcommentEntity>) this.executeQuery(queryManager);

					// �]��E�L�q�]���f�[�^��FormBean��
					for (Deta31953000SpScorptcommentEntity scorptcommentEntity:scorptevalEntityList) {
						if ("G1".equals(scorptcommentEntity.getSrcom_item())) {
							data31953000FormBean.setSrcom_comment_G1(scorptcommentEntity.getSrcom_comment());
						}
						else if ("G2".equals(scorptcommentEntity.getSrcom_item())) {
							data31953000FormBean.setSrcom_comment_G2(scorptcommentEntity.getSrcom_comment());
						}
						else if ("G3".equals(scorptcommentEntity.getSrcom_item())) {
							data31953000FormBean.setSrcom_comment_G3(scorptcommentEntity.getSrcom_comment());
						}

					}

					// ------------------------------------------------------------------------------------------
					// �s���̂����� �f�[�^�擾
					// ------------------------------------------------------------------------------------------
					String tempTerm = printFormBean.getTerm();

					if ("99".equals(printFormBean.getTerm())) {
						tempTerm = "03";
					}
					param = new Object[]{tempTerm,tempTerm,user, nendo ,stucode};
					queryManager =  new QueryManager(EXEC_SQL_MANIFESTACTION, param, Data31953000_ManifestActionEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31953000_ManifestActionEntity> manifestActionEntityList = (List<Data31953000_ManifestActionEntity>) this.executeQuery(queryManager);

					param = new Object[]{user,nendo ,stucode,data31953000FormBean.getStuGrade(),tempTerm};
					queryManager =  new QueryManager(EXEC_SQL_MANIFESTACTIONMEMO, param, Data31953000_ManifestActionMemoEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31953000_ManifestActionMemoEntity> manifestActionMemoEntityList = (List<Data31953000_ManifestActionMemoEntity>) this.executeQuery(queryManager);
					// FormBean�Ɋi�[
					for (Data31953000_ManifestActionMemoEntity memoEntity:manifestActionMemoEntityList) {
						data31953000FormBean.setManifestActionMemo(memoEntity.getSrad_descript());
					}

					// ------------------------------------------------------------------------------------------
					// �o�Ȃ̋L�^���l�o��
					// ------------------------------------------------------------------------------------------
					if ("03".equals(printFormBean.getTerm())) {
						tempTerm = "99";
					}
					param = new Object[]{user, nendo, stucode, data31953000FormBean.getStuGrade(), user, nendo, tempTerm};
					queryManager =  new QueryManager(EXEC_SQL_SCHOOLMEMO, param, Data31953000_SchoolMemoEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31953000_SchoolMemoEntity> schoolMemoEntityList = (List<Data31953000_SchoolMemoEntity>) this.executeQuery(queryManager);

					// ------------------------------------------------------------------------------------------
					// �o�Ȃ̋L�^�o��
					// ------------------------------------------------------------------------------------------
					param =  new Object[]{user, nendo, printFormBean.getTerm(), user, nendo, stucode
											,user, nendo, printFormBean.getTerm(), user, nendo, stucode};
					queryManager =  new QueryManager(EXEC_SQL_ATTEND, param, Data31953000_AttendEntity.class);
					// �N�G���̎��s(List�`���Ńf�[�^�i�[)
					List<Data31953000_AttendEntity> attendEntityList = (List<Data31953000_AttendEntity>) this.executeQuery(queryManager);

					// �����F�s���̂�����Map��FormBean�ɃZ�b�g
					data31953000FormBean.setFindingFormBeanList(setManifestActionFormBeanMap(manifestActionEntityList));
					// �����F�o�ȏ�
					data31953000FormBean.setAttendValueFormBeanList(setAttendValueFormBeanMap(attendEntityList,schoolMemoEntityList));
				}

				// ���k���List
				data31953000FormBeanList.add(data31953000FormBean);
			}

			// ���k���List��FormBean�Ɋi�[
			printFormBean.setData31953000FormBeanList(data31953000FormBeanList);


		} catch (Exception e) {
			log.error("�ʒm�\����(�ʒm�\) DB�擾�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		}
	}

	/**
	 * @return the printFormBean
	 */
	public Print31953000FormBean getPrintFormBean() {
		return printFormBean;
	}


	/**
	 * �S�C�������擾����ׂ̃o�C���h�ϐ��Z�b�g
	 * @param user	�����R�[�h
	 * @param nendo	�N�x
	 * @param date	�o�͑Ώۓ��t
	 * @param spgdCode	���ʎx���w���ԍ�
	 * @return �o�C���h�ϐ�
	 */
	private Object[] getTeacherNameParam(String user, String nendo, String date, String spgdCode) {

		Object[] param = {
						  user
						, nendo
						, spgdCode
						, date
						, user
						, nendo
						, spgdCode
						, user };
		return param;
	}

	/**
	 * �S�C�������3���擾
	 * @param teacherEntitieList
	 * @return
	 */
	private List<String> getTeacherList(List<Data31953000_TeacherEntity> teacherEntitieList){

		// ���ʎx���w���S�C���i�[List
		List<String> teacherList = new ArrayList<String>();
		// �擾����Entity�����ʂR���̒S�C��Bean�ɃZ�b�g
		for(Data31953000_TeacherEntity teacherEntity:teacherEntitieList){
			boolean addFlg = false;
			// ���ʎx���w���S�C���i�[List����̏ꍇ
			if(teacherList.size() == 0){
				// List�ɒǉ�
				teacherList.add(teacherEntity.getStf_name());
			}
			else {
				// List�ɒǉ������S�C�ƁA�d�����Ă��Ȃ����̃`�F�b�N
				for(String teacher:teacherList){
					if(teacher.equals(teacherEntity.getStf_name())) {
						// �ǉ��ς݂Ȃ�΃t���O��true
						addFlg = true;
						break;
					}
				}
				// �t���O��false�Ȃ�΁AList�ɒǉ�
				if(!addFlg){
					teacherList.add(teacherEntity.getStf_name());
				}
			}
			// List�o�^����3���Ȃ�΃��[�v�I��
			if(teacherList.size() == 3){
				break;
			}
		}
		return teacherList;
	}


	/**
	 * �����̏o�ȏ󋵂̃f�[�^��Map�ɕϊ�
	 * @param attendEntityList
	 * @return
	 */
	private List<Data31953000FindingsFormBean> setManifestActionFormBeanMap(List<Data31953000_ManifestActionEntity> manifestActionEntityList){

		// ����Map
		List<Data31953000FindingsFormBean> findingFormBeanMap = new ArrayList<Data31953000FindingsFormBean>();
		// �����F�s���̂�����
		for (Data31953000_ManifestActionEntity manifestActionEntity:manifestActionEntityList) {
			// �s���̂�����
			Data31953000FindingsFormBean findingsFormBean = new Data31953000FindingsFormBean();

			/**
			 * �w�Дԍ�
			 */
			findingsFormBean.setCls_stucode(manifestActionEntity.getCls_stucode());
			/**
			 * �o�͎����R�[�h
			 */
			findingsFormBean.setSravt_goptcode(manifestActionEntity.getSravt_goptcode());
			/**
			 * ���ڃR�[�h
			 */
			findingsFormBean.setSravt_sravtcode(manifestActionEntity.getSravt_sravtcode());
			/**
			 * �ʍ���
			 */
			findingsFormBean.setSravv_indivivp(manifestActionEntity.getSravv_indivivp());
			/**
			 * �ʒm�\�\���p�]��
			 */
			findingsFormBean.setSrace_reportdisplay(manifestActionEntity.getSrace_reportdisplay());
			/**
			 * �L���\������
			 */
			findingsFormBean.setSrem_em(manifestActionEntity.getSrem_em());
			/**
			 *  List�ɒǉ�
			 */
			findingFormBeanMap.add(findingsFormBean);
		}
		return findingFormBeanMap;
	}

	/**
	 * �����̏o�ȏ󋵂̃f�[�^��Map�ɕϊ�
	 * @param attendEntityList
	 * @return
	 */
	private Map<String, Data31953000AttendValueFormBean> setAttendValueFormBeanMap(List<Data31953000_AttendEntity> attendEntityList,List<Data31953000_SchoolMemoEntity> schoolMemoEntityList){

		// �����E�o�ȕ]��Map
		Map<String, Data31953000AttendValueFormBean> attendValueFormBeanMap =  new HashMap<String, Data31953000AttendValueFormBean>();
		// �����F�s���̂�����
		for (Data31953000_AttendEntity attendEntity:attendEntityList) {
			// �s���̂�����
			Data31953000AttendValueFormBean attendEntityFormBean = new Data31953000AttendValueFormBean();
			// �o�͎�����
			attendEntityFormBean.setGopt_name(attendEntity.getGopt_name());
			// �o�͎���
			attendEntityFormBean.setGopt_goptcode(attendEntity.getGopt_goptcode());
			// �\����
			attendEntityFormBean.setGopt_order(attendEntity.getGopt_order());
			// �w�N
			attendEntityFormBean.setCls_glade(attendEntity.getCls_glade());
			// �w�Дԍ�
			attendEntityFormBean.setCls_stucode(attendEntity.getCls_stucode());
			// �N���X�ԍ�
			attendEntityFormBean.setCls_number(attendEntity.getCls_number());
			// ���Ɠ���
			attendEntityFormBean.setClasscount(attendEntity.getClasscount());
			// �o��E����������
			attendEntityFormBean.setSchoolkindcount(attendEntity.getSchoolkindcount());
			// �o�Ȃ��ׂ�����
			attendEntityFormBean.setMustcount(attendEntity.getMustcount());
			// ���ȓ���
			attendEntityFormBean.setAbsencecount(attendEntity.getAbsencecount());
			// �o�ȓ���
			attendEntityFormBean.setAttendcount(attendEntity.getAttendcount());
			// �x������
			attendEntityFormBean.setLatecount(attendEntity.getLatecount());
			// ���ޓ���
			attendEntityFormBean.setLeavecount(attendEntity.getLeavecount());

			// �����F���l�f�[�^��FormBean��
			for (Data31953000_SchoolMemoEntity schoolMemoEntity:schoolMemoEntityList) {
				if (attendEntity.getGopt_goptcode() != null) {
					if (attendEntity.getGopt_goptcode().equals(schoolMemoEntity.getRar_term())) {
						attendEntityFormBean.setRar_memo(schoolMemoEntity.getRar_memo());
					}
				}
			}

			// Map�ɒǉ�
			attendValueFormBeanMap.put(attendEntity.getGopt_goptcode(),attendEntityFormBean);
		}
		return attendValueFormBeanMap;
	}

	/**
	 * ����List�̍쐬
	 * @param entityList
	 * @return
	 */
	private List<Data31953000_ManifestActionEntity> setManifestActionEntityList(List<Data31953000_ManifestActionEntity> entityList){

			List<Data31953000_ManifestActionEntity> tempEntity = new ArrayList<Data31953000_ManifestActionEntity>();

			String term = printFormBean.getTerm();

			if ("99".equals(term)){
				term = "03";
			}

			for (Data31953000_ManifestActionEntity entity:tempEntity) {
				if (term.equals(entity.getSravt_goptcode())) {
					tempEntity.add(entity);
				}
			}
			return tempEntity;
		}

	/**
	 * NULL�����̃`�F�b�N����ы󔒂ւ̒u������
	 * @param str
	 * @return
	 */
	private String checkNullStr(String str){

		if (str == null || str.isEmpty()) {
			str = "";
		}
		return str;
	}

	/**
	 * �w�����擾
	 * @param term
	 * @return
	 */
	private String getTermName(String term) {

		String termName = "";

		if (TERM_01.equals(term)) {
			termName = "��1�w��";
		}
		else if (TERM_02.equals(term)) {
			termName = "��2�w��";
		}
		else if (TERM_03.equals(term)) {
			termName = "��3�w��";
		}
		else if (TERM_99.equals(term)) {
			termName = "��3�w��";
		}

		return termName;
	}
}
