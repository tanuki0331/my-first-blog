package jp.co.systemd.tnavi.cus.izunokuni.db.service;

import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000EvalEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000ScorptattendrecordEntity;
import jp.co.systemd.tnavi.cus.izunokuni.db.entity.Data31951000SpScorptactviewpointvalueEntity;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Detail31951000FormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Detail31951000ReportFormBean;

/**
 * <PRE>
 *  ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ꗗ �X�V Service.
 * </PRE>
 *
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class RegistDetail31951000Service  extends AbstractExecuteQuery {

	/** Log4j */
	private static final Log log = LogFactory.getLog(RegistDetail31951000Service.class);
	
	/** �T�[�r�X���� */
	private static final String serviceName = "���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ꗗ �X�V";

	/** ���sSQL */
	private static final String EXEC_SQL_UPDATE_INSERT_SP_SCORPTEVAL = "cus/izunokuni/update_insert31951000_sp_scorpteval.sql";
	private static final String EXEC_SQL_UPDATE_INSERT_SP_SCORPTVIEWPOINTVALUE = "cus/izunokuni/update_insert31951000_sp_scorptviewpointvalue.sql";
	private static final String EXEC_SQL_DELETE_SP_SCORPTCOMMENT = "common/deleteSpScorptcommentByPK.sql";
	private static final String EXEC_SQL_INSERT_SP_SCORPTCOMMENT = "common/insertSpScorptcomment.sql";
	private static final String EXEC_SQL_DELETE_SP_SCORPTACTVIEWPOINTVALUE = "common/deleteSpScorptactviewpointvalueByPK.sql";
	private static final String EXEC_SQL_INSERT_SP_SCORPTACTVIEWPOINTVALUE = "common/insertSpScorptactviewpointvalue.sql";
	private static final String EXEC_SQL_DELETE_SCORPTATTENDRECORD = "common/deleteScorptattendrecordByPK.sql";
	private static final String EXEC_SQL_INSERT_SCORPTATTENDRECORD = "common/insertScorptattendrecord.sql";

	/** ����SessionBean */
	private SystemInfoBean sessionBean;

	/** �ꗗFormBean. */
	private Detail31951000FormBean detailFormBean;

	
	/**
	 * �R���X�g���N�^
	 * @param request
	 * @param sessionBean
	 * @param detailFormBean
	 */
	public RegistDetail31951000Service(HttpServletRequest request, SystemInfoBean sessionBean, Detail31951000FormBean detailFormBean) {
		super();
		this.sessionBean = sessionBean;
		this.detailFormBean = detailFormBean;
		
		for (Entry<String, Detail31951000ReportFormBean> entry : detailFormBean.getReportMap().entrySet()) {
			Detail31951000ReportFormBean reportFormBean = entry.getValue();
			String itemCode = reportFormBean.getItemCode();
			
			for (int i = 0; i < reportFormBean.getEvalList().size(); i++) {
				Data31951000EvalEntity evalEntity = reportFormBean.getEvalList().get(i);
				reportFormBean.getEvalList().get(i).setSrvpv_indivivp( request.getParameter("srvpv_indivivp_"  + itemCode + "_" + evalEntity.getSrivt_srivtcode()));
				reportFormBean.getEvalList().get(i).setSrvpv_manualest(request.getParameter("srvpv_manualest_" + itemCode + "_" + evalEntity.getSrivt_srivtcode()));
			}
			reportFormBean.setDescript(request.getParameter("descript_" + itemCode));
		}
		
		detailFormBean.getSpScorptcommentMap().put("G1", request.getParameter("srcom_comment_g1"));
		detailFormBean.getSpScorptcommentMap().put("G2", request.getParameter("srcom_comment_g2"));
		detailFormBean.getSpScorptcommentMap().put("G3", request.getParameter("srcom_comment_g3"));
		
		for (int i = 0; i < detailFormBean.getSpScorptactviewpointvalueList().size(); i++) {
			String sravt_sravtcode = detailFormBean.getSpScorptactviewpointvalueList().get(i).getSravt_sravtcode();
			
			detailFormBean.getSpScorptactviewpointvalueList().get(i).setSravv_indivivp(request.getParameter("sravv_indivivp_" + sravt_sravtcode));
			detailFormBean.getSpScorptactviewpointvalueList().get(i).setSravv_sracecode(request.getParameter("sravv_sracecode_" + sravt_sravtcode));
		}
		
		detailFormBean.setSrad_descript(request.getParameter("srad_descript"));
		
		for (int i = 0; i < detailFormBean.getAttendList().size(); i++) {
			String rar_term = detailFormBean.getAttendList().get(i).getRar_term();
			
			detailFormBean.getAttendList().get(i).setRar_count(getIntParameter(request, "rar_count_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_stop(getIntParameter(request, "rar_stop_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_must(getIntParameter(request, "rar_must_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_absence(getIntParameter(request, "rar_absence_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_attend(getIntParameter(request, "rar_attend_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_late(getIntParameter(request, "rar_late_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_leave(getIntParameter(request, "rar_leave_" + rar_term));
			detailFormBean.getAttendList().get(i).setRar_memo(request.getParameter("rar_memo_" + rar_term));
		}
		
	}

	/**
	 * �N�G�������s����
	 */
	public void execute() throws TnaviDbException {
		super.execute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doQuery() throws TnaviDbException {

		try {
			for (Entry<String, Detail31951000ReportFormBean> entry : detailFormBean.getReportMap().entrySet()) {
				Detail31951000ReportFormBean reportFormBean = entry.getValue();
				
				// �]��e�[�u���X�V
				updateInsertSpScorpteval(reportFormBean);
				
				for (int i = 0; i < reportFormBean.getEvalList().size(); i++) {
					// ���Ȋϓ_�]���e�[�u���X�V
					updateInsertSpScorptviewpointvalue(reportFormBean.getEvalList().get(i));
				}
			}
			
			// ����(�ʒm�\)(���x) �X�V
			deleteInsertSpScorptcomment();
			
			// �s���̋L�^�]��(�ʒm�\)(���x) �X�V
			deleteInsertSpScorptactviewpointvalue();
			
			// �o���̋L�^�e�[�u��(�ʒm�\) �X�V
			deleteInsertScorptattendrecord();

			//�s���̋L�^�L�q�]��(�ʒm�\)(���x) �X�V
			deleteInsertSpScorptactdescript();
			
			this.commit();
			
		} catch (Exception e) {
			this.rollback();
			log.error(serviceName + " DB�X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} 

	}

	/**
	 * �]��e�[�u��(�ʒm�\)(���x)�Ftbl_sp_scorpteval ���X�V����
	 * @param reportFormBean ���� FormBean
	 */
	private void updateInsertSpScorpteval(Detail31951000ReportFormBean reportFormBean) {
		
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_UPDATE_INSERT_SP_SCORPTEVAL);
		try{
			
			this.initialBatchUpdate(insertQM);
		
			//���ɓ����L�[�Ƀ��R�[�h�����݂���ꍇ��UPDATE�A�Ȃ����INSERT
			if("2".equals(detailFormBean.getStudent().getSrem_em())){
				// �]�����@�u�L�q�]���L��v�̏ꍇ�̂�
				Object[] insertParam = new Object[]{ 
													   //UPDATE����
					       						       reportFormBean.getDescript()
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													  ,sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,detailFormBean.getGoptcode()
													  ,reportFormBean.getItemCode()
													  //INSERT����
													  ,sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,detailFormBean.getGoptcode()
													  ,reportFormBean.getItemCode()
													  ,null
													  ,null
													  ,reportFormBean.getDescript()
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													 
													};
				this.executeBatchUpdate(insertQM, insertParam);
			}
		} catch (Exception e) {
			log.error(" �]��e�[�u��(�ʒm�\)(���x) �e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(insertQM);
		}
	}
	
	/**
	 * ���Ȋϓ_�]���e�[�u��(�ʒm�\)(���x) �X�V
	 * 
	 * @param evalEntity �ϓ_�]�� Entity
	 */
	private void updateInsertSpScorptviewpointvalue(Data31951000EvalEntity evalEntity) {
		
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_UPDATE_INSERT_SP_SCORPTVIEWPOINTVALUE);
		try{
			
			this.initialBatchUpdate(insertQM);
		
			//���ɓ����L�[�Ƀ��R�[�h�����݂���ꍇ��UPDATE�A�Ȃ����INSERT
			Object[] insertParam = new Object[]{ 
												   //UPDATE����
											       evalEntity.getSrvpv_manualest()
												  ,evalEntity.getSrvpv_indivivp()
												  ,DateUtility.getSystemDate()
												  ,sessionBean.getStaffId()
												  ,sessionBean.getUserCode()
												  ,sessionBean.getSystemNendoSeireki()
												  ,detailFormBean.getStudent().getCls_stucode()
												  ,detailFormBean.getStudent().getCls_glade()
												  ,detailFormBean.getGoptcode()
												  ,evalEntity.getSi_item()
												  ,evalEntity.getSrivt_srivtcode()
												  
												  //INSERT����
												  ,sessionBean.getUserCode()
												  ,sessionBean.getSystemNendoSeireki()
												  ,detailFormBean.getStudent().getCls_stucode()
												  ,detailFormBean.getStudent().getCls_glade()
												  ,detailFormBean.getGoptcode()
												  ,evalEntity.getSi_item()
												  ,evalEntity.getSrivt_srivtcode()
												  ,null
												  ,evalEntity.getSrvpv_manualest()
												  ,evalEntity.getSrvpv_indivivp()
												  ,DateUtility.getSystemDate()
												  ,sessionBean.getStaffId()
												 
												};
			this.executeBatchUpdate(insertQM, insertParam);
		} catch (Exception e) {
			log.error(" ���Ȋϓ_�]���e�[�u��(�ʒm�\)(���x) �e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(insertQM);
		}
	}
	
	
	/**
	 * ����(�ʒm�\)(���x) �X�V
	 * 
	 * @param evalEntity �ϓ_�]�� Entity
	 */
	private void deleteInsertSpScorptcomment() {
		
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager(EXEC_SQL_DELETE_SP_SCORPTCOMMENT);
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_INSERT_SP_SCORPTCOMMENT);
		
		try{
			this.initialBatchUpdate(deleteQM);
			this.initialBatchUpdate(insertQM);
			
			for (Entry<String, String> entry : detailFormBean.getSpScorptcommentMap().entrySet()) {
				String itemCode = entry.getKey();
				String comment = entry.getValue();
				
				//DELETE
				Object[] deleteParam = new Object[]{ sessionBean.getUserCode()
												      ,sessionBean.getSystemNendoSeireki()
												      ,detailFormBean.getStudent().getCls_stucode()
												      ,detailFormBean.getStudent().getCls_glade()
												      ,detailFormBean.getGoptcode()
												      ,itemCode
													};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
		
				//INSERT
				Object[] insertParam = new Object[]{ sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,detailFormBean.getGoptcode()
													  ,itemCode
													  ,comment
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													};
				this.executeBatchUpdate(insertQM, insertParam);
			}
		} catch (Exception e) {
			log.error(" ����(�ʒm�\)(���x) �e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(deleteQM);
			closeQueryUpdateBatchManager(insertQM);
		}
	}
	
	
	/**
	 * �s���̋L�^�]��(�ʒm�\)(���x) �X�V
	 */
	private void deleteInsertSpScorptactviewpointvalue() {
		
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager(EXEC_SQL_DELETE_SP_SCORPTACTVIEWPOINTVALUE);
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_INSERT_SP_SCORPTACTVIEWPOINTVALUE);
		try{
			
			this.initialBatchUpdate(deleteQM);
			this.initialBatchUpdate(insertQM);
			
			for (Data31951000SpScorptactviewpointvalueEntity entity : detailFormBean.getSpScorptactviewpointvalueList()) {
				
				//DELETE
				Object[] deleteParam = new Object[]{ sessionBean.getUserCode()
												      ,sessionBean.getSystemNendoSeireki()
												      ,detailFormBean.getStudent().getCls_stucode()
												      ,detailFormBean.getStudent().getCls_glade()
												      ,detailFormBean.getGoptcode()
												      ,entity.getSravt_sravtcode()
													};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
				
				//INSERT
				Object[] insertParam = new Object[]{ sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,detailFormBean.getGoptcode()
													  ,entity.getSravt_sravtcode()
													  ,entity.getSravv_sracecode()
													  ,entity.getSravv_indivivp()
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													};
				this.executeBatchUpdate(insertQM, insertParam);
			}
		} catch (Exception e) {
			log.error(" �s���̋L�^�]��(�ʒm�\)(���x)�e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(deleteQM);
			closeQueryUpdateBatchManager(insertQM);
		}
	}
	
	
	/**
	 * �s���̋L�^�L�q�]��(�ʒm�\)(���x) �X�V
	 */
	private void deleteInsertSpScorptactdescript() {
		
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager("common/deleteSpScorptactdescriptByPK.sql");
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager("common/insertSpScorptactdescript.sql");
		try{
			
			this.initialBatchUpdate(deleteQM);
			this.initialBatchUpdate(insertQM);
			
			if("2".equals(detailFormBean.getStudent().getSrem_em())){
				
				//DELETE
				Object[] deleteParam = new Object[]{ sessionBean.getUserCode()
												      ,sessionBean.getSystemNendoSeireki()
												      ,detailFormBean.getStudent().getCls_stucode()
												      ,detailFormBean.getStudent().getCls_glade()
												      ,detailFormBean.getGoptcode()
													};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
				
				//INSERT
				Object[] insertParam = new Object[]{ sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,detailFormBean.getGoptcode()
													  ,detailFormBean.getSrad_descript()
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													};
				this.executeBatchUpdate(insertQM, insertParam);
				
			}
		} catch (Exception e) {
			log.error(" �s���̋L�^�L�q�]��(�ʒm�\)(���x)�e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(deleteQM);
			closeQueryUpdateBatchManager(insertQM);
		}
	}
	
	
	/**
	 * �o���̋L�^�e�[�u��(�ʒm�\) �X�V
	 */
	private void deleteInsertScorptattendrecord() {
					
		QueryUpdateBatchManager deleteQM = new QueryUpdateBatchManager(EXEC_SQL_DELETE_SCORPTATTENDRECORD);
		QueryUpdateBatchManager insertQM = new QueryUpdateBatchManager(EXEC_SQL_INSERT_SCORPTATTENDRECORD);
		try{
			
			this.initialBatchUpdate(deleteQM);
			this.initialBatchUpdate(insertQM);
			
			for (Data31951000ScorptattendrecordEntity entity : detailFormBean.getAttendList()) {
				
				//DELETE
				Object[] deleteParam = new Object[]{ sessionBean.getUserCode()
												      ,sessionBean.getSystemNendoSeireki()
												      ,detailFormBean.getStudent().getCls_stucode()
												      ,detailFormBean.getStudent().getCls_glade()
												      ,entity.getRar_term()
													};
				this.executeBatchUpdate(deleteQM, deleteParam);
				
				
				//INSERT
				Object[] insertParam = new Object[]{ sessionBean.getUserCode()
													  ,sessionBean.getSystemNendoSeireki()
													  ,detailFormBean.getStudent().getCls_stucode()
													  ,detailFormBean.getStudent().getCls_glade()
													  ,entity.getRar_term()
													  ,entity.getRar_count()
													  ,entity.getRar_stop()
													  ,null
													  ,entity.getRar_must()
													  ,entity.getRar_absence()
													  ,null
													  ,entity.getRar_attend()
													  ,entity.getRar_late()
													  ,entity.getRar_leave()
													  ,entity.getRar_memo()
													  ,DateUtility.getSystemDate()
													  ,sessionBean.getStaffId()
													};
				this.executeBatchUpdate(insertQM, insertParam);
			}
		} catch (Exception e) {
			log.error(" �o���̋L�^�e�[�u��(�ʒm�\)�e�[�u�� �X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			closeQueryUpdateBatchManager(deleteQM);
			closeQueryUpdateBatchManager(insertQM);
		}
	}

	/**
	 * QueryUpdateBatchManager �����
	 * @param qm
	 */
	private void closeQueryUpdateBatchManager(QueryUpdateBatchManager qm) {
		if(qm != null){
			this.closeBatchUpdate(qm);
			qm = null;
		}
	}
	
	/**
	 * ���N�G�X�g�p�����[�^�̒l�𐔒l�ϊ����ĕԂ�
	 * @param request 
	 * @param value
	 * @return ���l�ϊ���̒l
	 */
	private Integer getIntParameter(HttpServletRequest request, String name){
		try{
			return Integer.parseInt(request.getParameter(name));
		}catch(NumberFormatException ne){
			return null;
		}
	}
	
	public Detail31951000FormBean getDetailFormBean() {
		return detailFormBean;
	}



}
