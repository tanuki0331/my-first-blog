package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * �w�Z����̏����̏o��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchhi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31953000_SchoolMemoEntity {

	/**
	 * �w�Дԍ�
	 */
	private String rar_stucode;

	/**
	 * �]������
	 */
	private String rar_term;

	/**
	 * �w�Z����̏���
	 */
	private String rar_memo;

	public String getRar_stucode() {
		return rar_stucode;
	}

	public void setRar_stucode(String rar_stucode) {
		this.rar_stucode = rar_stucode;
	}

	public String getRar_term() {
		return rar_term;
	}

	public void setRar_term(String rar_term) {
		this.rar_term = rar_term;
	}

	public String getRar_memo() {
		return rar_memo;
	}

	public void setRar_memo(String rar_memo) {
		this.rar_memo = rar_memo;
	}


}
