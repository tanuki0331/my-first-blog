package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_RefEvaluationListEntity {

	@Getter @Setter
	private String gvpv_item = "";
	@Getter @Setter
	private String gvpv_givtcode = "";
	@Getter @Setter
	private String gvpe_gvpecode = "";
	@Getter @Setter
	private String gvpe_display = "";
}
