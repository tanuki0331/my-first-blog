package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_CmlguideforeignlangactEntity {

	@Getter @Setter
	private String gfla_givtcode = "";
	@Getter @Setter
	private String gfla_eval = "";
}
