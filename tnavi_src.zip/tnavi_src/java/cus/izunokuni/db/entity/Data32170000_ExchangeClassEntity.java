package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_ExchangeClassEntity {

	/** �𗬐�w�N */
	@Getter @Setter
	private String exc_glade = "";
	/** �𗬐�g */
	@Getter @Setter
	private String exc_class = "";
}
