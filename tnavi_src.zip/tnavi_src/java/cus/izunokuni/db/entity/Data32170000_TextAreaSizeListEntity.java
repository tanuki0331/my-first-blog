package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_TextAreaSizeListEntity {
    /**
     * �����R�[�h
     */
	@Getter @Setter
    private String ctas_user;
    /**
     * �����N�x
     */
	@Getter @Setter
    private String ctas_year;
    /**
     * �w�N
     */
	@Getter @Setter
    private String ctas_grade;
    /**
     * ����
     */
	@Getter @Setter
    private String ctas_item;
    /**
     * ����
     */
	@Getter @Setter
    private Integer ctas_height;
    /**
     * ��
     */
	@Getter @Setter
    private Integer ctas_width;
    /**
     * nowrap�L���ݒ�t���O
     */
	@Getter @Setter
    private String ctas_nowrap;
}
