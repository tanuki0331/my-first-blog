package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �L�q�]�� Entity.
 * </PRE>
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31952000DescriptEvalEntity {

	/** 
	 * ���ȃR�[�h 
	 */
	private String si_item;
	
	/**
	 * �ʒm�\�p���Ȗ�
	 */
	private String si_reportname;
	
	/**
	 * �L�q�]��
	 */
	private String srev_descript;

	public String getSi_item() {
		return si_item;
	}

	public void setSi_item(String si_item) {
		this.si_item = si_item;
	}

	public String getSi_reportname() {
		return si_reportname;
	}

	public void setSi_reportname(String si_reportname) {
		this.si_reportname = si_reportname;
	}

	public String getSrev_descript() {
		return srev_descript;
	}

	public void setSrev_descript(String srev_descript) {
		this.srev_descript = srev_descript;
	}

	
}