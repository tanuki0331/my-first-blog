package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_EstimateListEntity {

	@Getter @Setter
	private String gvpe_gvpecode = "";
	@Getter @Setter
	private String gvpe_display = "";
}
