package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * �����̕]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.06.13 BY fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31950000_MoralEntity {

	/**
	 * �w�Дԍ�
	 */
	private String rmrl_stucode;

    /**
     * �o�͎���
     */
    private String rmrl_term;

    /**
     * �]��
     */
    private String rmrl_value;

	public String getRmrl_stucode() {
		return rmrl_stucode;
	}

	public void setRmrl_stucode(String rmrl_stucode) {
		this.rmrl_stucode = rmrl_stucode;
	}

	public String getRmrl_term() {
		return rmrl_term;
	}

	public void setRmrl_term(String rmrl_term) {
		this.rmrl_term = rmrl_term;
	}

	public String getRmrl_value() {
		return rmrl_value;
	}

	public void setRmrl_value(String rmrl_value) {
		this.rmrl_value = rmrl_value;
	}

}
