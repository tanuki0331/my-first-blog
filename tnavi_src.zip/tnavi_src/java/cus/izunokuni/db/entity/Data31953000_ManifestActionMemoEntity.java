package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * �]���E�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchhi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31953000_ManifestActionMemoEntity {

	/**
	 * �o�͎����R�[�h
	 */
	private String srad_goptcode;

	/**
	 * �L�q�]��(�L��)
	 */
	private String srad_descript;

	public String getSrad_goptcode() {
		return srad_goptcode;
	}

	public void setSrad_goptcode(String srad_goptcode) {
		this.srad_goptcode = srad_goptcode;
	}

	public String getSrad_descript() {
		return srad_descript;
	}

	public void setSrad_descript(String srad_descript) {
		this.srad_descript = srad_descript;
	}
}
