package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_RefRatingListEntity {

	@Getter @Setter
	private String gev_item = "";
	@Getter @Setter
	private String gevl_display = "";
	@Getter @Setter
	private String gevl_gevlcode = "";
}
