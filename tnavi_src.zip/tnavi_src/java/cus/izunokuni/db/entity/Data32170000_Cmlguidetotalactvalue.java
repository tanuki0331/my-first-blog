package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_Cmlguidetotalactvalue {

	@Getter @Setter
	private String gtav_content = "";
	@Getter @Setter
	private String gtav_viewpoint = "";
	@Getter @Setter
	private String gtav_value = "";
}
