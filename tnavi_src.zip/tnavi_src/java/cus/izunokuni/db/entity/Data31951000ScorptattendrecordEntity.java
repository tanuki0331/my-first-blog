package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �o����� Entity.
 * </PRE>
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Data31951000ScorptattendrecordEntity {

	/**
	 * �o�͎���ID
	 */
	private String rar_term;
	
	/**
	 * ���Ɠ���
	 */
	private Integer rar_count;
	
	/**
	 * �o�Ȓ�~�E��������
	 */
	private Integer rar_stop;
	
	/**
	 * �o�Ȃ��Ȃ���΂Ȃ�Ȃ�(���ׂ�)����
	 */
	private Integer rar_must;
	
	/**
	 * ���ȓ���
	 */
	private Integer rar_absence;
	
	/**
	 * �o�ȓ���
	 */
	private Integer rar_attend;
	
	/**
	 * �x��
	 */
	private Integer rar_late;
	
	/**
	 * ����
	 */
	private Integer rar_leave;
	
	/**
	 * �o�����l
	 */
	private String rar_memo;
	
	/**
	 * �o�͎�������
	 */
	private String gopt_name;
	
	/**
	 * �N�x�����уt���O
	 */
	private String gopt_score_flg;

	public String getRar_term() {
		return rar_term;
	}

	public void setRar_term(String rar_term) {
		this.rar_term = rar_term;
	}

	public Integer getRar_count() {
		return rar_count;
	}

	public void setRar_count(Integer rar_count) {
		this.rar_count = rar_count;
	}

	public Integer getRar_stop() {
		return rar_stop;
	}

	public void setRar_stop(Integer rar_stop) {
		this.rar_stop = rar_stop;
	}

	public Integer getRar_must() {
		return rar_must;
	}

	public void setRar_must(Integer rar_must) {
		this.rar_must = rar_must;
	}

	public Integer getRar_absence() {
		return rar_absence;
	}

	public void setRar_absence(Integer rar_absence) {
		this.rar_absence = rar_absence;
	}

	public Integer getRar_attend() {
		return rar_attend;
	}

	public void setRar_attend(Integer rar_attend) {
		this.rar_attend = rar_attend;
	}

	public Integer getRar_late() {
		return rar_late;
	}

	public void setRar_late(Integer rar_late) {
		this.rar_late = rar_late;
	}

	public Integer getRar_leave() {
		return rar_leave;
	}

	public void setRar_leave(Integer rar_leave) {
		this.rar_leave = rar_leave;
	}

	public String getRar_memo() {
		return rar_memo;
	}

	public void setRar_memo(String rar_memo) {
		this.rar_memo = rar_memo;
	}

	public String getGopt_name() {
		return gopt_name;
	}

	public void setGopt_name(String gopt_name) {
		this.gopt_name = gopt_name;
	}

	public String getGopt_score_flg() {
		return gopt_score_flg;
	}

	public void setGopt_score_flg(String gopt_score_flg) {
		this.gopt_score_flg = gopt_score_flg;
	}
	
}