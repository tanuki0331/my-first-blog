package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_GavtDataEntity {

	@Getter @Setter
	private String gavt_user = "";
	@Getter @Setter
	private String gavt_curcode = "";
	@Getter @Setter
	private String gavt_gavtcode = "";
	@Getter @Setter
	private String gavt_gavtname = "";
	@Getter @Setter
	private String gavt_gavtname2 = "";
	@Getter @Setter
	private String gavt_order = "";
	@Getter @Setter
	private String gavt_update = "";
	@Getter @Setter
	private String gavt_upuser = "";
}
