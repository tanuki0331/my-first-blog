package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(�ɓ��̍��s_���w�Z) ��� �ʒm�\���ʃe�L�X�g���� Entity.
 * </PRE>
 *
 * <B>Create</B> 2019.01.12 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31949000_ScorptcommontextEntity {

	/**
	 *
	 */
	private String cod_code;

	/**
	 *  ���ږ���
	 */
	private String cod_name1;

	/**
	 * ���ژA��
	 */
	private String ic_num;

	/**
	 * �ݒ�l
	 */
	private String rct_value;

	public String getCod_code() {
		return cod_code;
	}

	public void setCod_code(String cod_code) {
		this.cod_code = cod_code;
	}

	public String getCod_name1() {
		return cod_name1;
	}

	public void setCod_name1(String cod_name1) {
		this.cod_name1 = cod_name1;
	}

	public String getIc_num() {
		return ic_num;
	}

	public void setIc_num(String ic_num) {
		this.ic_num = ic_num;
	}

	public String getRct_value() {
		return rct_value;
	}

	public void setRct_value(String rct_value) {
		this.rct_value = rct_value;
	}


}
