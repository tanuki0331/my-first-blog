package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_GivtDataEntity {

	@Getter @Setter
	private String givt_user = "";
	@Getter @Setter
	private String givt_curcode = "";
	@Getter @Setter
	private String givt_item = "";
	@Getter @Setter
	private String givt_givtcode = "";
	@Getter @Setter
	private String givt_givtname = "";
	@Getter @Setter
	private String givt_givtname2 = "";
	@Getter @Setter
	private String givt_order = "";
}
