package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_HyokaEntity {

	@Getter @Setter
	// �]��
	private String value = "";

	@Getter @Setter
	// �ϓ_�R�[�h
	private String vpCode = "";

}
