package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_CmlguideattendrecordEntity {

	@Getter @Setter
	private String gar_count = "";
	@Getter @Setter
	private String gar_stop = "";
	@Getter @Setter
	private String gar_must = "";
	@Getter @Setter
	private String gar_absence = "";
	@Getter @Setter
	private String gar_attend = "";
	@Getter @Setter
	private String gar_memo = "";
}
