package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * �����̕]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.06.06 BY fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31949000_MoralEntity {

    /**
	 * �w�Дԍ�
	 */
	private String rmrl_stucode;

	/** �]�� */
	private String rmrl_value;

	/**
	 * rmrl_stucode ���擾����B
	 * @return rmrl_stucode
	 */
	public final String getRmrl_stucode() {
		return rmrl_stucode;
	}

	/**
	 * rmrl_stucode ��ݒ肷��B
	 * @param rmrl_stucode �Z�b�g���� rmrl_stucode
	 */
	public final void setRmrl_stucode(String rmrl_stucode) {
		this.rmrl_stucode = rmrl_stucode;
	}

	/**
	 * rmrl_value ���擾����B
	 * @return rmrl_value
	 */
	public final String getRmrl_value() {
		return rmrl_value;
	}

	/**
	 * rmrl_value ��ݒ肷��B
	 * @param rmrl_value �Z�b�g���� rmrl_value
	 */
	public final void setRmrl_value(String rmrl_value) {
		this.rmrl_value = rmrl_value;
	}

}
