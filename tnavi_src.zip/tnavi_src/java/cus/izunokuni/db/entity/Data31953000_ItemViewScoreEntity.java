package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31953000_ItemViewScoreEntity {

	/** �w�Дԍ� */
	private String cls_stucode;

	/** �o�͎����R�[�h */
	private String srivt_goptcode;

	/** ���ȃR�[�h */
	private String sriu_item;

	/** �ʒm�\�p���Ȗ��� */
	private String si_reportname;

	/** �ϓ_�R�[�h */
	private String srivt_srivtcode;

	/** �ʒm�\�p�ϓ_���� */
	private String srivt_reportname;

	/** �����ʊϓ_ */
	private String srvpv_indivivp;

	/** �m��ϓ_�ʕ]���R�[�h */
	private String srvpv_manualest;

	/** �]�������{�t���O */
	private String srvpe_none_flg;

	/** �]���s�\�t���O */
	private String srvpe_cannot_flg;

	/** �]�������{�܂��͕]���s�\���ɏo�͂���]�� */
	private String srvpe_display;

	/** �L�q�]�� */
	private String srev_descript;

	/** �L�q�]���\������ */
	private String srem_em;

	public String getCls_stucode() {
		return cls_stucode;
	}

	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}

	public String getSrivt_goptcode() {
		return srivt_goptcode;
	}

	public void setSrivt_goptcode(String srivt_goptcode) {
		this.srivt_goptcode = srivt_goptcode;
	}

	public String getSriu_item() {
		return sriu_item;
	}

	public void setSriu_item(String sriu_item) {
		this.sriu_item = sriu_item;
	}

	public String getSi_reportname() {
		return si_reportname;
	}

	public void setSi_reportname(String si_reportname) {
		this.si_reportname = si_reportname;
	}

	public String getSrivt_srivtcode() {
		return srivt_srivtcode;
	}

	public void setSrivt_srivtcode(String srivt_srivtcode) {
		this.srivt_srivtcode = srivt_srivtcode;
	}

	public String getSrivt_reportname() {
		return srivt_reportname;
	}

	public void setSrivt_reportname(String srivt_reportname) {
		this.srivt_reportname = srivt_reportname;
	}

	public String getSrvpv_indivivp() {
		return srvpv_indivivp;
	}

	public void setSrvpv_indivivp(String srvpv_indivivp) {
		this.srvpv_indivivp = srvpv_indivivp;
	}

	public String getSrvpv_manualest() {
		return srvpv_manualest;
	}

	public void setSrvpv_manualest(String srvpv_manualest) {
		this.srvpv_manualest = srvpv_manualest;
	}

	public String getSrvpe_none_flg() {
		return srvpe_none_flg;
	}

	public void setSrvpe_none_flg(String srvpe_none_flg) {
		this.srvpe_none_flg = srvpe_none_flg;
	}

	public String getSrvpe_cannot_flg() {
		return srvpe_cannot_flg;
	}

	public void setSrvpe_cannot_flg(String srvpe_cannot_flg) {
		this.srvpe_cannot_flg = srvpe_cannot_flg;
	}

	public String getSrvpe_display() {
		return srvpe_display;
	}

	public void setSrvpe_display(String srvpe_display) {
		this.srvpe_display = srvpe_display;
	}

	public String getSrev_descript() {
		return srev_descript;
	}

	public void setSrev_descript(String srev_descript) {
		this.srev_descript = srev_descript;
	}

	public String getSrem_em() {
		return srem_em;
	}

	public void setSrem_em(String srem_em) {
		this.srem_em = srem_em;
	}

}
