package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_CmlguidetotalacttitleEntity {

	@Getter @Setter
	private String gtat_act = "";
	@Getter @Setter
	private String gtat_pointview = "";
}
