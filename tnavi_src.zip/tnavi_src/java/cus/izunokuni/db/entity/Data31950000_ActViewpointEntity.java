package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * �s���̂�����Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.05.24 BY yamazaki <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31950000_ActViewpointEntity {

	private String ravt_term;
	private String ravt_ravtname;
	private String ravt_purpose;
	private String ravv_stucode;
	private String ravt_ravtcode;
	private String race_reportdisplay;

	public String getRavt_term() {
		return ravt_term;
	}
	public void setRavt_term(String ravt_term) {
		this.ravt_term = ravt_term;
	}
	public String getRavt_ravtname() {
		return ravt_ravtname;
	}
	public void setRavt_ravtname(String ravt_ravtname) {
		this.ravt_ravtname = ravt_ravtname;
	}
	public String getRavt_purpose() {
		return ravt_purpose;
	}
	public void setRavt_purpose(String ravt_purpose) {
		this.ravt_purpose = ravt_purpose;
	}

	public String getRavv_stucode() {
		return ravv_stucode;
	}
	public void setRavv_stucode(String ravv_stucode) {
		this.ravv_stucode = ravv_stucode;
	}
	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}
	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}
	public String getRace_reportdisplay() {
		return race_reportdisplay;
	}
	public void setRace_reportdisplay(String race_reportdisplay) {
		this.race_reportdisplay = race_reportdisplay;
	}

}
