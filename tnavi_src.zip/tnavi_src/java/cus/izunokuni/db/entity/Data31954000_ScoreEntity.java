package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * �]���E�]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchhi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31954000_ScoreEntity {

	/**
	 * �w�Дԍ�
	 */
	private String cls_stucode;
	/**
	 * �o�͎����R�[�h
	 */
	private String srivt_goptcode;
	/**
	 * ���ȃR�[�h
	 */
	private String sriu_item;
	/**
	 * �ϓ_�R�[�h
	 */
	private String srivt_srivtcode;
	/**
	 * �m��ϓ_�ʕ]��(�ʒm�\�p)
	 */
	private String srvpe_reportdisplay;

	public String getCls_stucode() {
		return cls_stucode;
	}
	public void setCls_stucode(String cls_stucode) {
		this.cls_stucode = cls_stucode;
	}
	public String getSrivt_goptcode() {
		return srivt_goptcode;
	}
	public void setSrivt_goptcode(String srivt_goptcode) {
		this.srivt_goptcode = srivt_goptcode;
	}
	public String getSriu_item() {
		return sriu_item;
	}
	public void setSriu_item(String sriu_item) {
		this.sriu_item = sriu_item;
	}
	public String getSrivt_srivtcode() {
		return srivt_srivtcode;
	}
	public void setSrivt_srivtcode(String srivt_srivtcode) {
		this.srivt_srivtcode = srivt_srivtcode;
	}
	public String getSrvpe_reportdisplay() {
		return srvpe_reportdisplay;
	}
	public void setSrvpe_reportdisplay(String srvpe_reportdisplay) {
		this.srvpe_reportdisplay = srvpe_reportdisplay;
	}


}
