package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

import lombok.Getter;
import lombok.Setter;

public class Data32170000_GsatDataEntity {

	@Getter @Setter
	private String gsat_user = "";
	@Getter @Setter
	private String gsat_curcode = "";
	@Getter @Setter
	private String gsat_gsatcode = "";
	@Getter @Setter
	private String gsat_gsatname = "";
	@Getter @Setter
	private String gsat_gsatname2 = "";
	@Getter @Setter
	private String gsat_order = "";
	@Getter @Setter
	private String gsat_kind1 = "";
	@Getter @Setter
	private String gsat_kind2 = "";
}
