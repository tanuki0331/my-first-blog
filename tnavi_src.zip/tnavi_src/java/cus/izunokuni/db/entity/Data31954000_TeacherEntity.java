package jp.co.systemd.tnavi.cus.izunokuni.db.entity;

/**
 * <PRE>
 * �S�C����Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.06.06 BY takeuchi <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31954000_TeacherEntity {

	/**
	 * �w�Дԍ�
	 */
	private String old;

	/**
	 * �S�C��
	 */
	private String stf_name;

	public String getOld() {
		return old;
	}

	public void setOld(String old) {
		this.old = old;
	}

	public String getStf_name() {
		return stf_name;
	}

	public void setStf_name(String stf_name) {
		this.stf_name = stf_name;
	}
}
