package jp.co.systemd.tnavi.cus.izunokuni.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.cus.izunokuni.db.service.Detail31951000Service;
import jp.co.systemd.tnavi.cus.izunokuni.db.service.List31951000Service;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Detail31951000FormBean;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.List31951000FormBean;
import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;


/**
 * <PRE>
 *  ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) ���� Action.
 * </PRE>
 *
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Detail31951000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Detail31951000Action.class);
	
	/** ���O�ɏo�͂��邽�߂̖��O */
	private static final String actionName = "�y��ʁz���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) ����";

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return false;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request, HttpServletResponse response, 
							SystemInfoBean sessionBean) {
		
		// ------------------------------------------------------------------------------------------
		// �J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info(actionName + " START");
		
		// ------------------------------------------------------------------------------------------
		// ���N�G�X�g��formbean�ɃR�s�[����`��FormBean���쐬
		// ------------------------------------------------------------------------------------------
		List31951000FormBean listFormBean = (List31951000FormBean)copyRequestParamToFormBean(request, new List31951000FormBean());
		
		// ------------------------------------------------------------------------------------------
		// �ꗗ�T�[�r�X�N���X�̐���
		// ------------------------------------------------------------------------------------------
		List31951000Service listService = new List31951000Service();
		listService.execute(request, sessionBean, listFormBean);
		
		sessionBean.getIzunokuniSessionBean().setList31951000FormBean(listService.getListFormBean());
		
		// ------------------------------------------------------------------------------------------
		// ���N�G�X�g��formbean�ɃR�s�[����`��FormBean���쐬
		// ------------------------------------------------------------------------------------------
		Detail31951000FormBean detailFormBean = (Detail31951000FormBean)copyRequestParamToFormBean(request, new Detail31951000FormBean());
		
		// ------------------------------------------------------------------------------------------
		// �T�[�r�X�N���X�̐���
		// ------------------------------------------------------------------------------------------
		Detail31951000Service service = new Detail31951000Service(request, sessionBean, new Detail31951000FormBean(), listFormBean);
		service.execute();

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g����B
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", service.getDetailFormBean());

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info(actionName + " END");

		return null;
	}

}
