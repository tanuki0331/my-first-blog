package jp.co.systemd.tnavi.cus.izunokuni.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.izunokuni.db.service.Print31950000Service;
import jp.co.systemd.tnavi.cus.izunokuni.print.Print31950000;

/**
 * ���ђʒm�\���(�ɓ��̍��s���w�Z) ��� Action.
 *
 * <B>Create</B> 2017.05.24 BY yamazaki <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31950000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print31950000Action.class);

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("���ђʒm�\���(���쒬���w�Z) START");

		//-----���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("���ђʒm�\");

		try{

			//���[�t�H�[���t�@�C��
			String formFileName = "cus/izunokuni/form31950000.cfx";

			Print31950000Service service = new Print31950000Service();
			service.execute(request, sessionBean);

			Print31950000 print31950000 = new Print31950000();
			print31950000.setPrintFormBean(service.getPrintFormBean());
			print31950000.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print31950000.execute(formFileName);

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("���ђʒm�\���(���쒬���w�Z) END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return null;
	}

}
