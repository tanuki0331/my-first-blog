package jp.co.systemd.tnavi.cus.izunokuni.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.action.AbstractAction;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.izunokuni.db.service.Detail31951000Service;
import jp.co.systemd.tnavi.cus.izunokuni.db.service.RegistDetail31951000Service;
import jp.co.systemd.tnavi.cus.izunokuni.formbean.Detail31951000FormBean;


/**
 * <PRE>
 *  ���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ڍ� �X�V Action.
 * </PRE>
 *
 * <B>Create</B> 2017.05.26 BY AIVICK <BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class RegistDetail31951000Action extends AbstractAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(RegistDetail31951000Action.class);
	
	/** ���O�ɏo�͂��邽�߂̖��O */
	private static final String actionName = "�y��ʁz���ђʒm�\����(�ɓ��̍��s ���w�Z���ʎx���w��) �ڍ� �X�V";

	@Override
	public boolean isSkip(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return false;
	}

	@Override
	public boolean doCheck(ServletContext sc, HttpServletRequest request, SystemInfoBean sessionBean) {
		return true;
	}

	@Override
	public String doAction(ServletContext sc, HttpServletRequest request, HttpServletResponse response, 
							SystemInfoBean sessionBean) {
		
		// ------------------------------------------------------------------------------------------
		// �J�n���O�o��
		// ------------------------------------------------------------------------------------------
		log.info(actionName + " START");
		
		// ------------------------------------------------------------------------------------------
		// ���N�G�X�g��formbean�ɃR�s�[����`��FormBean���쐬
		// ------------------------------------------------------------------------------------------
		Detail31951000FormBean requestDetailFormBean = (Detail31951000FormBean)copyRequestParamToFormBean(request, new Detail31951000FormBean());
		
		// ------------------------------------------------------------------------------------------
		// �T�[�r�X�N���X�̐���
		// ------------------------------------------------------------------------------------------
		Detail31951000Service service = new Detail31951000Service(request, sessionBean, requestDetailFormBean, sessionBean.getIzunokuniSessionBean().getList31951000FormBean());
		service.execute();

		// �ڍ׍X�V
		RegistDetail31951000Service registService = new RegistDetail31951000Service(request, sessionBean, service.getDetailFormBean());
		registService.execute();
		
		// �X�V����߂ăf�[�^���Ď擾
		service = new Detail31951000Service(request, sessionBean, new Detail31951000FormBean(), sessionBean.getIzunokuniSessionBean().getList31951000FormBean());
		service.execute();
		
		// �X�V���b�Z�[�W���Z�b�g
		Detail31951000FormBean detailFormBean = service.getDetailFormBean();
		detailFormBean.setUpdateMessage("�X�V�������������܂����B");

		// ------------------------------------------------------------------------------------------
		// Request��FormBean���Z�b�g����B
		// ------------------------------------------------------------------------------------------
		request.setAttribute("FORM_BEAN", detailFormBean);

		// ------------------------------------------------------------------------------------------
		// �����I�����O�o��
		// ------------------------------------------------------------------------------------------
		log.info(actionName + " END");

		return null;
	}

}
