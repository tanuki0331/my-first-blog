package jp.co.systemd.tnavi.cus.feskinderkindai.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.att.db.entity.AttCountEntity;
import jp.co.systemd.tnavi.common.db.entity.StaffEntity;

/**
 * <PRE>
 * ���ђʒm�[���(�ߋE��w�������w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31945000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �g�E�o�Ȕԍ��̏o�̓��[�h */
	public final static String OUTPUT_HROOMINFO_NORMAL = "0";	// �ʏ�ʂ�A�ݐЊw���̑g�E�o�Ȕԍ����o�͂���
	public final static String OUTPUT_HROOMINFO_GROUP  = "1";	// �ݐЊw��������������ʎx���w���O���[�v���̂ƁA�ݐЊw���̏o�Ȕԍ����o�͂���(���x�w���������̂ݑI���\)
	public final static String OUTPUT_HROOMINFO_KOURYU = "2";	// �𗬐�̑g�E�o�Ȕԍ����o�͂���(���x�w���������̂ݑI���\)

	/** �o�͂���o�Ȕԍ��̎�� */
	public final static String OUTPUT_NUMBER_KOUBO  = "0"; 	// cls_reference_number���o��
	public final static String OUTPUT_NUMBER_NORMAL = "1"; 	// cls_number���o��

	/** �����R�[�h */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���o�͎��� */
	private String term = DEFALUT_VALUE;

	/** �I���o�͎����� */
	private String termName = DEFALUT_VALUE;

	/** �������� */
	private String schoolName = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �C�����t */
	private String deedDate = DEFALUT_VALUE;

	/** �o�̓y�[�W�\�� */
	private boolean output_cover;

	/** �o�̓y�[�W�w�K�̋L�^ */
	private boolean output_score;

	/** �o�̓y�[�W�����̋L�^�E���� */
	private boolean output_other;

	/** �o�̓y�[�W�C���� */
	private boolean output_deed;

	/** �g�E�o�Ȕԍ��̏o�̓��[�h */
	private String outputHroomInfoMode = OUTPUT_HROOMINFO_NORMAL;

	/** �o�Ȕԍ��̏o�͎�� */
	private String outputNumberKind = OUTPUT_NUMBER_NORMAL;

	/** �ʒm�[�\��C���[�W */
	private byte[] stampImage;

	/** �\���摜�C���[�W */
	private byte[] coverImage;

	/** ���k���̃f�[�^ */
	private Map<String, Print31945000StudentFormBean> studentMap;

	/** �Z�����X�g(�~���j */
	private List<StaffEntity> principalList;

	/** �S�C���X�g(�~���j */
	private List<StaffEntity> staffList;

	/** �g�̂̂悤�� �� */
	private String healthrecordDate;

	/** �C���؂ɏo�͂���Z���� */
	private String deedPrincipalName;

	private Map<String, Boolean> notHyokaMap;

	private Map<String, Boolean> notHyoteiMap;

	/** �ӂ肪�ȏo�̓t���O */
	private boolean isOutputKana;

	/** �o�Z�� */
	private Map<String, AttCountEntity> schooldaysMap;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public String getDeedDate() {
		return deedDate;
	}

	public void setDeedDate(String deedDate) {
		this.deedDate = deedDate;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_score() {
		return output_score;
	}

	public void setOutput_score(boolean output_score) {
		this.output_score = output_score;
	}

	public boolean isOutput_other() {
		return output_other;
	}

	public void setOutput_other(boolean output_other) {
		this.output_other = output_other;
	}

	public boolean isOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(boolean output_deed) {
		this.output_deed = output_deed;
	}

	public String getOutputHroomInfoMode() {
		return outputHroomInfoMode;
	}

	public void setOutputHroomInfoMode(String outputHroomInfoMode) {
		this.outputHroomInfoMode = outputHroomInfoMode;
	}

	public String getOutputNumberKind() {
		return outputNumberKind;
	}

	public void setOutputNumberKind(String outputNumberKind) {
		this.outputNumberKind = outputNumberKind;
	}

	public byte[] getStampImage() {
		return stampImage;
	}

	public void setStampImage(byte[] stampImage) {
		this.stampImage = stampImage;
	}

	public byte[] getCoverImage() {
		return coverImage;
	}

	public void setCoverImage(byte[] coverImage) {
		this.coverImage = coverImage;
	}

	public Map<String, Print31945000StudentFormBean> getStudentMap() {
		return studentMap;
	}

	public void setStudentMap(Map<String, Print31945000StudentFormBean> studentMap) {
		this.studentMap = studentMap;
	}

	public List<StaffEntity> getPrincipalList() {
		return principalList;
	}

	public void setPrincipalList(List<StaffEntity> principalList) {
		this.principalList = principalList;
	}

	public List<StaffEntity> getStaffList() {
		return staffList;
	}

	public void setStaffList(List<StaffEntity> staffList) {
		this.staffList = staffList;
	}

	public String getHealthrecordDate() {
		return healthrecordDate;
	}

	public void setHealthrecordDate(String healthrecordDate) {
		this.healthrecordDate = healthrecordDate;
	}

	public String getDeedPrincipalName() {
		return deedPrincipalName;
	}

	public void setDeedPrincipalName(String deedPrincipalName) {
		this.deedPrincipalName = deedPrincipalName;
	}

	public Map<String, Boolean> getNotHyokaMap() {
		return notHyokaMap;
	}

	public void setNotHyokaMap(Map<String, Boolean> notHyokaMap) {
		this.notHyokaMap = notHyokaMap;
	}

	public Map<String, Boolean> getNotHyoteiMap() {
		return notHyoteiMap;
	}

	public void setNotHyoteiMap(Map<String, Boolean> notHyoteiMap) {
		this.notHyoteiMap = notHyoteiMap;
	}

	/**
	 * @return isOutputKana
	 */
	public boolean isOutputKana() {
		return isOutputKana;
	}

	/**
	 * @param isOutputKana isOutputKana��ݒ肷��
	 */
	public void setOutputKana(boolean isOutputKana) {
		this.isOutputKana = isOutputKana;
	}

	public Map<String, AttCountEntity> getSchooldaysMap() {
		return schooldaysMap;
	}

	public void setSchooldaysMap(Map<String, AttCountEntity> schooldaysMap) {
		this.schooldaysMap = schooldaysMap;
	}


}
