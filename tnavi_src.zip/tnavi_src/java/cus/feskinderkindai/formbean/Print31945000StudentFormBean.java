package jp.co.systemd.tnavi.cus.feskinderkindai.formbean;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000ActviewEntity;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000AttendEntity;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000CommentEntity;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000ForeignLangActEntity;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000HealthrecordEntity;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000ScoreEntity;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000SpActEntity;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000TotalActEntity;

/**
 * <PRE>
 * ���ђʒm�\���(�ߋE��w�������w�Z) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31945000StudentFormBean {

	public final static String DEFALUT_VALUE = "";

	/** �����R�[�h **/
	private String usercode = DEFALUT_VALUE;

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String stuGrade = DEFALUT_VALUE;

	/** �g **/
	private String stuClass = DEFALUT_VALUE;

	/** �����ԍ�(�o�Ȕԍ�) **/
	private String stuNumber = DEFALUT_VALUE;

	/** �w�Дԍ� **/
	private String stuCode = DEFALUT_VALUE;

	/** �������� **/
	private String stuName = DEFALUT_VALUE;

	/** ������������ **/
	private String stuKana = DEFALUT_VALUE;

	/** ���N���� */
	private String stuBirth = DEFALUT_VALUE;

	/** �w�K�̋L�^Map */
	private Map<String, List<Print31945000ScoreEntity>> scoreMap = new LinkedHashMap<String, List<Print31945000ScoreEntity>>();

	/** �����I�Ȋw�K�̎��� */
	private Print31945000TotalActEntity totalAct;

	/** �O���ꊈ���̋L�^���X�g */
	private List<Print31945000ForeignLangActEntity> foreignLangActList = new ArrayList<Print31945000ForeignLangActEntity>();

	/** ���ʊ����̋L�^ ���X�g */
	private List<Print31945000SpActEntity> spActList = new ArrayList<Print31945000SpActEntity>();

	/** �����̂悤�� ���X�g */
	private List<Print31945000ActviewEntity> actviewList = new ArrayList<Print31945000ActviewEntity>();

	/** �������� */
	private Print31945000CommentEntity comment = new Print31945000CommentEntity();

	/** �o���̋L�^ */
	private List<Print31945000AttendEntity> attendList = new ArrayList<Print31945000AttendEntity>();

	/** ���N�f�f�̋L�^ */
	private Print31945000HealthrecordEntity healthrecord;

	/** �����x�ƒ��̏o�Z�� */
	private String schooldaysOnLongHolidays;

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}

	/** �w�N�𐔒l�ϊ������l���擾���� */
	public Integer getGrade(){
		return Integer.parseInt(stuGrade);
	}

	/** �o�͗p�̖��O���擾���� */
	public String getOutputStuName() {
		// 2�N���ȉ��͂��ȕ\�L
		String stuName = this.stuName;
		if(this.getGrade() <= 2){
			stuName = this.stuKana;
		}

		// @@TODO 2016�N�x�b��Ή� 2016�N�x�́A�D�z���w�Z�̂݁A�K�������������o�͂���
		if ( "1028".equals(this.usercode) && "2016".equals(this.nendo) ){
			stuName = this.stuName;
		}

		return stuName;
	}

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getStuGrade() {
		return stuGrade;
	}

	public void setStuGrade(String stuGrade) {
		this.stuGrade = stuGrade;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getStuNumber() {
		return stuNumber;
	}

	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getStuCode() {
		return stuCode;
	}

	public void setStuCode(String stuCode) {
		this.stuCode = stuCode;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuKana() {
		return stuKana;
	}

	public void setStuKana(String stuKana) {
		this.stuKana = stuKana;
	}

	public String getStuBirth() {
		return stuBirth;
	}

	public void setStuBirth(String stuBirth) {
		this.stuBirth = stuBirth;
	}

	public Map<String, List<Print31945000ScoreEntity>> getScoreMap() {
		return scoreMap;
	}

	public void setScoreMap(Map<String, List<Print31945000ScoreEntity>> scoreMap) {
		this.scoreMap = scoreMap;
	}

	public Print31945000TotalActEntity getTotalAct() {
		return totalAct;
	}

	public void setTotalAct(Print31945000TotalActEntity totalAct) {
		this.totalAct = totalAct;
	}

	public List<Print31945000ForeignLangActEntity> getForeignLangActList() {
		return foreignLangActList;
	}

	public void setForeignLangActList(List<Print31945000ForeignLangActEntity> foreignLangActList) {
		this.foreignLangActList = foreignLangActList;
	}

	public List<Print31945000SpActEntity> getSpActList() {
		return spActList;
	}

	public void setSpActList(List<Print31945000SpActEntity> spActList) {
		this.spActList = spActList;
	}

	public List<Print31945000ActviewEntity> getActviewList() {
		return actviewList;
	}

	public void setActviewList(List<Print31945000ActviewEntity> actviewList) {
		this.actviewList = actviewList;
	}

	public Print31945000CommentEntity getComment() {
		return comment;
	}

	public void setComment(Print31945000CommentEntity comment) {
		this.comment = comment;
	}

	public List<Print31945000AttendEntity> getAttendList() {
		return attendList;
	}

	public void setAttendList(List<Print31945000AttendEntity> attendList) {
		this.attendList = attendList;
	}

	public Print31945000HealthrecordEntity getHealthrecord() {
		return healthrecord;
	}

	public void setHealthrecord(Print31945000HealthrecordEntity healthrecord) {
		this.healthrecord = healthrecord;
	}

	public String getSchooldaysOnLongHolidays() {
		return schooldaysOnLongHolidays;
	}

	public void setSchooldaysOnLongHolidays(String schooldaysOnLongHolidays) {
		this.schooldaysOnLongHolidays = schooldaysOnLongHolidays;
	}



}
