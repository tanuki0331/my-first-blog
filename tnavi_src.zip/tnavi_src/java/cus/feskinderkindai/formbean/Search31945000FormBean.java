package jp.co.systemd.tnavi.cus.feskinderkindai.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.formbean.SimpleTagFormBean;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.entity.Print31945000StudentEntity;


/**
 * <PRE>
 * ���ђʒm�\���(�ߋE��w�������w�Z) ���� FormBean.
 * </PRE>
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Search31945000FormBean {

	public final static String DEFALUT_VALUE = "";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �N���X�� **/
	private String hmrName = DEFALUT_VALUE;

	/** �o�͎������X�g **/
	private List<SimpleTagFormBean> outputTermList;

	/** �o�͎��� */
	private String outputTerm;

	/** �o�̓y�[�W �\��*/
	private String output_cover;

	/** �o�̓y�[�W �w�K�̂悤�� */
	private String output_score;

	/** �o�̓y�[�W �����̋L�^�E���� */
	private String output_other;

	/** �o�̓y�[�W �C���� */
	private String output_deed;

	/** �o�͓��t �N **/
	private String output_year;

	/** �o�͓��t �� **/
	private String output_month;

	/** �o�͓��t �� **/
	private String output_day;

	/** �����X�g **/
	private List<SimpleTagFormBean> monthList;

	/** �����X�g **/
	private List<SimpleTagFormBean> dayList;

	/** ���k�ꗗ **/
	private List<Print31945000StudentEntity> studentList;

	/** �G���[���b�Z�[�W */
	private Map<String, String> errorMessage;

	/** ���ʎx���w���t���O */
	private boolean isSpSupportCls = false;

	/** �����x�ƒ��̏o�Z�� */
	private String schooldaysOnLongHolidays;

	/** �o�Z��Map�i���k�P�ʁj */
	private Map<String, String> schooldaysMap;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getHmrName() {
		return hmrName;
	}

	public void setHmrName(String hmrName) {
		this.hmrName = hmrName;
	}

	public List<SimpleTagFormBean> getOutputTermList() {
		return outputTermList;
	}

	public void setOutputTermList(List<SimpleTagFormBean> outputTermList) {
		this.outputTermList = outputTermList;
	}

	public String getOutputTerm() {
		return outputTerm;
	}

	public void setOutputTerm(String outputTerm) {
		this.outputTerm = outputTerm;
	}

	public String getOutput_cover() {
		return output_cover;
	}

	public void setOutput_cover(String output_cover) {
		this.output_cover = output_cover;
	}

	public String getOutput_score() {
		return output_score;
	}

	public void setOutput_score(String output_score) {
		this.output_score = output_score;
	}

	public String getOutput_other() {
		return output_other;
	}

	public void setOutput_other(String output_other) {
		this.output_other = output_other;
	}

	public String getOutput_deed() {
		return output_deed;
	}

	public void setOutput_deed(String output_deed) {
		this.output_deed = output_deed;
	}

	public String getOutput_year() {
		return output_year;
	}

	public void setOutput_year(String output_year) {
		this.output_year = output_year;
	}

	public String getOutput_month() {
		return output_month;
	}

	public void setOutput_month(String output_month) {
		this.output_month = output_month;
	}

	public String getOutput_day() {
		return output_day;
	}

	public void setOutput_day(String output_day) {
		this.output_day = output_day;
	}

	public List<SimpleTagFormBean> getMonthList() {
		return monthList;
	}

	public void setMonthList(List<SimpleTagFormBean> monthList) {
		this.monthList = monthList;
	}

	public List<SimpleTagFormBean> getDayList() {
		return dayList;
	}

	public void setDayList(List<SimpleTagFormBean> dayList) {
		this.dayList = dayList;
	}

	public List<Print31945000StudentEntity> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<Print31945000StudentEntity> studentList) {
		this.studentList = studentList;
	}

	public Map<String, String> getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(Map<String, String> errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isSpSupportCls() {
		return isSpSupportCls;
	}

	public void setSpSupportCls(boolean isSpSupportCls) {
		this.isSpSupportCls = isSpSupportCls;
	}

	public String getSchooldaysOnLongHolidays() {
		return schooldaysOnLongHolidays;
	}

	public void setSchooldaysOnLongHolidays(String schooldaysOnLongHolidays) {
		this.schooldaysOnLongHolidays = schooldaysOnLongHolidays;
	}

	public Map<String, String> getSchooldaysMap() {
		return schooldaysMap;
	}

	public void setSchooldaysMap(Map<String, String> schooldaysMap) {
		this.schooldaysMap = schooldaysMap;
	}


}