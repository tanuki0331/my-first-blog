package jp.co.systemd.tnavi.cus.feskinderkindai.db.entity;

/**
 * <PRE>
 * ���ђʒm�[���(�ߋE��w�������w�Z) ��� ���k��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31945000StudentEntity {

	public final static String DEFALUT_VALUE = "";

	/** �N�x **/
	private String nendo = DEFALUT_VALUE;

	/** �w�N **/
	private String stuGrade = DEFALUT_VALUE;

	/** �g **/
	private String stuClass = DEFALUT_VALUE;

	/** �o�Ȕԍ� **/
	private String stuNumber = DEFALUT_VALUE;

	/** �o�Ȕԍ��i�𗬁j */
	private String refNumber = DEFALUT_VALUE;

	/** �w�Дԍ� **/
	private String stuCode = DEFALUT_VALUE;

	/** ���k�E�������� **/
	private String stuName = DEFALUT_VALUE;

	/** ���k�E������������ **/
	private String stuKana = DEFALUT_VALUE;

	/** ���N���� */
	private String stuBirth = DEFALUT_VALUE;

	/** ���ʎx���w���O���[�v���� */
	private String spGroupname = DEFALUT_VALUE;

	/** ���ʎx���𗬐�w���� */
	private String excClass = DEFALUT_VALUE;

	/** ���ʎx���𗬐�o�Ȕԍ� */
	private String excNumber = DEFALUT_VALUE;

	/** �𗬊w���Q���҃t���O */
	private String isKoryu;

	public String getNendo() {
		return nendo;
	}

	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getStuGrade() {
		return stuGrade;
	}

	public void setStuGrade(String stuGrade) {
		this.stuGrade = stuGrade;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getStuNumber() {
		return stuNumber;
	}

	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getRefNumber() {
		return refNumber;
	}

	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}

	public String getStuCode() {
		return stuCode;
	}

	public void setStuCode(String stuCode) {
		this.stuCode = stuCode;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuKana() {
		return stuKana;
	}

	public void setStuKana(String stuKana) {
		this.stuKana = stuKana;
	}

	public String getStuBirth() {
		return stuBirth;
	}

	public void setStuBirth(String stuBirth) {
		this.stuBirth = stuBirth;
	}

	public String getSpGroupname() {
		return spGroupname;
	}

	public void setSpGroupname(String spGroupname) {
		this.spGroupname = spGroupname;
	}

	public String getExcClass() {
		return excClass;
	}

	public void setExcClass(String excClass) {
		this.excClass = excClass;
	}

	public String getExcNumber() {
		return excNumber;
	}

	public void setExcNumber(String excNumber) {
		this.excNumber = excNumber;
	}

	/**
	 * @return isKoryu
	 */
	public String getIsKoryu() {
		return isKoryu;
	}

	/**
	 * @param isKoryu isKoryu��ݒ肷��
	 */
	public void setIsKoryu(String isKoryu) {
		this.isKoryu = isKoryu;
	}

}
