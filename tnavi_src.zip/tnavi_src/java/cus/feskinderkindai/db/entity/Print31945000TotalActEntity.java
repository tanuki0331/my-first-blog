package jp.co.systemd.tnavi.cus.feskinderkindai.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(�ߋE��w�������w�Z) ��� �����I�Ȋw�K�̎��� Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31945000TotalActEntity {
	
	/**
	 * �w�Дԍ�
	 */
	private String rtav_stucode;
	
	/**
	 * �A��
	 */
	private String rtav_rtavcode;
	
	/**
	 * �ϓ_
	 */
	private String rtav_value;
	
	/**
	 * �w�K����
	 */
	private String rtav_contents;

	
	public String getRtav_stucode() {
		return rtav_stucode;
	}

	public void setRtav_stucode(String rtav_stucode) {
		this.rtav_stucode = rtav_stucode;
	}

	public String getRtav_rtavcode() {
		return rtav_rtavcode;
	}

	public void setRtav_rtavcode(String rtav_rtavcode) {
		this.rtav_rtavcode = rtav_rtavcode;
	}

	public String getRtav_value() {
		return rtav_value;
	}

	public void setRtav_value(String rtav_value) {
		this.rtav_value = rtav_value;
	}

	public String getRtav_contents() {
		return rtav_contents;
	}

	public void setRtav_contents(String rtav_contents) {
		this.rtav_contents = rtav_contents;
	}
	
}
