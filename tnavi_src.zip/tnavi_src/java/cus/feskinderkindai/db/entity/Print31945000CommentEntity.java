package jp.co.systemd.tnavi.cus.feskinderkindai.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(�ߋE��w�������w�Z) ��� �������� Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31945000CommentEntity {
	
	/**
	 * �w�Дԍ�
	 */
	private String rcom_stucode;
	
	/**
	 * ����
	 */
	private String rcom_comment;

	public String getRcom_stucode() {
		return rcom_stucode;
	}

	public void setRcom_stucode(String rcom_stucode) {
		this.rcom_stucode = rcom_stucode;
	}

	public String getRcom_comment() {
		return rcom_comment;
	}

	public void setRcom_comment(String rcom_comment) {
		this.rcom_comment = rcom_comment;
	}

	
}
