package jp.co.systemd.tnavi.cus.feskinderkindai.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(�ߋE��w�������w�Z) ��� �o���̋L�^ Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31945000AttendEntity {
	
	/** �w�Дԍ� */
	private String stucode;

	/** �o�͎��� */
	private String goptcode;
	
	/** �ϓ_ */
	private String purpose;

	/** �N */
	private String year;
	
	/** �� */
	private String month;
	
	/** �ݐЃt���O 0:���̏o�͎����ɍݐЂ��Ă��Ȃ�, 1:���̏o�͎����ɍݐЂ��Ă��� */
	private String onRegist;

	/** �o�ȓ��� */
	private Integer attendSum;
	
	/** ���ȓ���(�a��) */
	private Integer absenceSickSum;
	
	/** [���ȓ���(���̑�) */
	private Integer absenceOtherSum;
	
	/** �o��E�������� */
	private Integer stopSum;
	
	/** �x������ */
	private Integer lateSum;
	
	/** ���ޓ��� */
	private Integer leaveSum;

	
	public String getStucode() {
		return stucode;
	}

	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	public String getGoptcode() {
		return goptcode;
	}

	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getOnRegist() {
		return onRegist;
	}

	public void setOnRegist(String onRegist) {
		this.onRegist = onRegist;
	}

	public Integer getAttendSum() {
		return attendSum;
	}

	public void setAttendSum(Integer attendSum) {
		this.attendSum = attendSum;
	}

	public Integer getAbsenceSickSum() {
		return absenceSickSum;
	}

	public void setAbsenceSickSum(Integer absenceSickSum) {
		this.absenceSickSum = absenceSickSum;
	}

	public Integer getAbsenceOtherSum() {
		return absenceOtherSum;
	}

	public void setAbsenceOtherSum(Integer absenceOtherSum) {
		this.absenceOtherSum = absenceOtherSum;
	}

	public Integer getStopSum() {
		return stopSum;
	}

	public void setStopSum(Integer stopSum) {
		this.stopSum = stopSum;
	}

	public Integer getLateSum() {
		return lateSum;
	}

	public void setLateSum(Integer lateSum) {
		this.lateSum = lateSum;
	}

	public Integer getLeaveSum() {
		return leaveSum;
	}

	public void setLeaveSum(Integer leaveSum) {
		this.leaveSum = leaveSum;
	}

	

	
}
