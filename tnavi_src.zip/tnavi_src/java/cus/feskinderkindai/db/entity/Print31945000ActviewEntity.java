package jp.co.systemd.tnavi.cus.feskinderkindai.db.entity;

/**
 * <PRE>
 * ���ђʒm�\���(�ߋE��w�������w�Z) ��� �w�Z�����̂悤��Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31945000ActviewEntity {
	
	/** �w�Дԍ� */
	private String stucode;
	
	/** �o�͎����R�[�h */
	private String ravtterm;
	
	/** �w���v�^ ���ڃR�[�h */
	private String gavtcode;
	
	/** ���ڃR�[�h */
	private String ravtcode;

	/** �ϓ_���� */
	private String ravtname;
	
	/** �ϓ_�̎�|�E�w�K�̂߂��� */
	private String purpose;

	/** �]���l�R�[�h */
	private String racecode;
	
	/** �]���l(�ʒm�\�\���p) */
	private String reportdisplay;

	
	public String getStucode() {
		return stucode;
	}

	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	public String getRavtterm() {
		return ravtterm;
	}

	public void setRavtterm(String ravtterm) {
		this.ravtterm = ravtterm;
	}

	public String getGavtcode() {
		return gavtcode;
	}

	public void setGavtcode(String gavtcode) {
		this.gavtcode = gavtcode;
	}

	public String getRavtcode() {
		return ravtcode;
	}

	public void setRavtcode(String ravtcode) {
		this.ravtcode = ravtcode;
	}

	public String getRavtname() {
		return ravtname;
	}

	public void setRavtname(String ravtname) {
		this.ravtname = ravtname;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getRacecode() {
		return racecode;
	}

	public void setRacecode(String racecode) {
		this.racecode = racecode;
	}

	public String getReportdisplay() {
		return reportdisplay;
	}

	public void setReportdisplay(String reportdisplay) {
		this.reportdisplay = reportdisplay;
	}

	



}
