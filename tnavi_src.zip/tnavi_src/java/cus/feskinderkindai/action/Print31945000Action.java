package jp.co.systemd.tnavi.cus.feskinderkindai.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.hos.coreports.exception.CrException;
import jp.co.systemd.tnavi.common.action.AbstractPrintAction;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.print.PdfDocumentBeanCR;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.cus.ashigarakami.action.Print31910000Action;
import jp.co.systemd.tnavi.cus.feskinderkindai.db.service.Print31945000Service;
import jp.co.systemd.tnavi.cus.feskinderkindai.print.Print31945000;

/**
 * ���ђʒm�\���(�ߋE��w�������w�Z) ���  Action.
 *
 * <B>Create</B> 2017.03.17 BY SD fukuda<BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Print31945000Action extends AbstractPrintAction {

	/** log4j */
	private static final Log log = LogFactory.getLog(Print31910000Action.class);

	@Override
	protected String doPrint(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response, SystemInfoBean sessionBean) {

		log.info("���ђʒm�\���(�ߋE��w�������w�Z) ���  START");

		//-----���[�o�͗p�̃f�[�^���擾���󎚂���B
		PdfDocumentBeanCR pdfDocumentBeanCR = new PdfDocumentBeanCR("���ђʒm�\");

		try {
			Print31945000Service service = new Print31945000Service();
			service.execute(request, sessionBean);

			Print31945000 print31945000 = new Print31945000(sessionBean);
			print31945000.setPrintFormBean(service.getPrintFormBean());
			print31945000.setPdfDocumentBeanCR(pdfDocumentBeanCR);
			print31945000.execute("cus/feskinderkindai/form31945000.cfx");

			pdfDocumentBeanCR.responseOutput(response);

		} catch (CrException cex) {
			log.error("��O����",cex);
			pdfDocumentBeanCR.abortJob();
			throw new TnaviException(cex);
		} catch(TnaviException tex) {
	    	throw new TnaviException(tex);
	    } catch(Exception e) {
	    	log.error("��O����",e);
	    	throw new TnaviException(e);
	    } finally {
	    	//���\�[�X�̊J��
	    	if(pdfDocumentBeanCR != null) {
	    		pdfDocumentBeanCR.close();
	    	}
	    }

		log.info("���ђʒm�\���(�ߋE��w�������w�Z) ���  END");

		return null;
	}

	@Override
	protected Log getLogClass() {
		return null;
	}

}
