/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2012 SystemD ,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.fuzokukyoto.print;

import jp.co.systemd.tnavi.common.print.AbstractExcelManager;
import jp.co.systemd.tnavi.common.print.ExcelPrintResult;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.PrintDownloadError31919000Entity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.formbean.PrintDownloadError31919000FormBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

/**
 * �w�N���ѓo�^(���s����啍�� ���w�Z)(�G���[��M)(Excel���o��) �N���X.
 *
 * <B>Create</B> 2016.08.04 BY SD hirata<BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class PrintDownloadError31919000 extends AbstractExcelManager {

	/** log4j */
	private final Log log = LogFactory.getLog(PrintDownloadError31919000.class);

	/** Excel�o��FormBean */
	protected PrintDownloadError31919000FormBean printFormBean;

	/** �e���v���[�g�t�@�C���� */
	protected String templateFileName = null;

	/** �o�̓V�[�g�� */
	private static final String outputSheetName = "�w�N���ѓo�^�ǂݍ��݃G���[";

	/** �o�͗�ԍ� */
	private static int
		ERR_MSG_OUT_COL = 0,			// �G���[���b�Z�[�W
		CLS_GLADE_OUT_COL = 1,			// �w�N
		CLS_CLSNO_OUT_COL = 2,			// �g�o�͗�
		CLS_NUMBER_OUT_COL = 3,			// �o�Ȕԍ�
		CLS_STUCODE_OUT_COL = 4,		// �w�Дԍ�
		STU_NAME_OUT_COL = 5,			// ����
		ITEM_OUT_COL = 6,				// ���ȃR�[�h
		ITEM_NAME_OUT_COL = 7,			// ���Ȗ�
		DETAIL_VALUE_01_OUT_COL = 8,	// �]���l1�`30
		DETAIL_VALUE_02_OUT_COL = 9,
		DETAIL_VALUE_03_OUT_COL = 10,
		DETAIL_VALUE_04_OUT_COL = 11,
		DETAIL_VALUE_05_OUT_COL = 12,
		DETAIL_VALUE_06_OUT_COL = 13,
		DETAIL_VALUE_07_OUT_COL = 14,
		DETAIL_VALUE_08_OUT_COL = 15,
		DETAIL_VALUE_09_OUT_COL = 16,
		DETAIL_VALUE_10_OUT_COL = 17,
		DETAIL_VALUE_11_OUT_COL = 18,
		DETAIL_VALUE_12_OUT_COL = 19,
		DETAIL_VALUE_13_OUT_COL = 20,
		DETAIL_VALUE_14_OUT_COL = 21,
		DETAIL_VALUE_15_OUT_COL = 22,
		DETAIL_VALUE_16_OUT_COL = 23,
		DETAIL_VALUE_17_OUT_COL = 24,
		DETAIL_VALUE_18_OUT_COL = 25,
		DETAIL_VALUE_19_OUT_COL = 26,
		DETAIL_VALUE_20_OUT_COL = 27,
		DETAIL_VALUE_21_OUT_COL = 28,
		DETAIL_VALUE_22_OUT_COL = 29,
		DETAIL_VALUE_23_OUT_COL = 30,
		DETAIL_VALUE_24_OUT_COL = 31,
		DETAIL_VALUE_25_OUT_COL = 32,
		DETAIL_VALUE_26_OUT_COL = 33,
		DETAIL_VALUE_27_OUT_COL = 34,
		DETAIL_VALUE_28_OUT_COL = 35,
		DETAIL_VALUE_29_OUT_COL = 36,
		DETAIL_VALUE_30_OUT_COL = 37
	;

	/** Row�I�u�W�F�N�g */
	private Row outputRow;

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ExcelPrintResult init(ExcelPrintResult result) {
		super.getTemplateWorkbook(this.templateFileName);
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ExcelPrintResult doPrint(ExcelPrintResult result) {

		// �o�̓V�[�g�I�u�W�F�N�g���擾����
		Sheet outputSheet = wb.getSheet(outputSheetName);

		// ���׍s�o�͍s�ԍ�
		int rowIdx = 0;

		// �N���X�Ґ������o�����X�g�����[�v
		for (PrintDownloadError31919000Entity ent : printFormBean.getEntityList()) {

			if (log.isDebugEnabled()) {
				log.debug("�������̃��X�gIndex:" + rowIdx + " �o�̓V�[�g���F" + outputSheetName );
			}

			// �o�͍s�I�u�W�F�N�g���쐬
			outputRow = outputSheet.createRow(rowIdx);

			// ���ڏo��
			setCell(ent.getErrorMessage(), ERR_MSG_OUT_COL);				// �G���[���b�Z�[�W
			setCell(ent.getClsGlade(), CLS_GLADE_OUT_COL);					// �w�N
			setCell(ent.getHmrClass(), CLS_CLSNO_OUT_COL);					// �g
			setCell(ent.getClsNumber(), CLS_NUMBER_OUT_COL);				// �o�Ȕԍ�
			setCell(ent.getClsStucode(), CLS_STUCODE_OUT_COL);				// �w�Дԍ�
			setCell(ent.getStuName(), STU_NAME_OUT_COL);					// ����
			setCell(ent.getItemCode(), ITEM_OUT_COL);						// ���ȃR�[�h
			setCell(ent.getItemName(), ITEM_NAME_OUT_COL);				// ���Ȗ�
			setCell(ent.getDetailValue1(), DETAIL_VALUE_01_OUT_COL);		// �]���l1�`30
			setCell(ent.getDetailValue2(), DETAIL_VALUE_02_OUT_COL);
			setCell(ent.getDetailValue3(), DETAIL_VALUE_03_OUT_COL);
			setCell(ent.getDetailValue4(), DETAIL_VALUE_04_OUT_COL);
			setCell(ent.getDetailValue5(), DETAIL_VALUE_05_OUT_COL);
			setCell(ent.getDetailValue6(), DETAIL_VALUE_06_OUT_COL);
			setCell(ent.getDetailValue7(), DETAIL_VALUE_07_OUT_COL);
			setCell(ent.getDetailValue8(), DETAIL_VALUE_08_OUT_COL);
			setCell(ent.getDetailValue9(), DETAIL_VALUE_09_OUT_COL);
			setCell(ent.getDetailValue10(), DETAIL_VALUE_10_OUT_COL);
			setCell(ent.getDetailValue11(), DETAIL_VALUE_11_OUT_COL);
			setCell(ent.getDetailValue12(), DETAIL_VALUE_12_OUT_COL);
			setCell(ent.getDetailValue13(), DETAIL_VALUE_13_OUT_COL);
			setCell(ent.getDetailValue14(), DETAIL_VALUE_14_OUT_COL);
			setCell(ent.getDetailValue15(), DETAIL_VALUE_15_OUT_COL);
			setCell(ent.getDetailValue16(), DETAIL_VALUE_16_OUT_COL);
			setCell(ent.getDetailValue17(), DETAIL_VALUE_17_OUT_COL);
			setCell(ent.getDetailValue18(), DETAIL_VALUE_18_OUT_COL);
			setCell(ent.getDetailValue19(), DETAIL_VALUE_19_OUT_COL);
			setCell(ent.getDetailValue20(), DETAIL_VALUE_20_OUT_COL);
			setCell(ent.getDetailValue21(), DETAIL_VALUE_21_OUT_COL);
			setCell(ent.getDetailValue22(), DETAIL_VALUE_22_OUT_COL);
			setCell(ent.getDetailValue23(), DETAIL_VALUE_23_OUT_COL);
			setCell(ent.getDetailValue24(), DETAIL_VALUE_24_OUT_COL);
			setCell(ent.getDetailValue25(), DETAIL_VALUE_25_OUT_COL);
			setCell(ent.getDetailValue26(), DETAIL_VALUE_26_OUT_COL);
			setCell(ent.getDetailValue27(), DETAIL_VALUE_27_OUT_COL);
			setCell(ent.getDetailValue28(), DETAIL_VALUE_28_OUT_COL);
			setCell(ent.getDetailValue29(), DETAIL_VALUE_29_OUT_COL);
			setCell(ent.getDetailValue30(), DETAIL_VALUE_30_OUT_COL);

			rowIdx++;
		}

		return result;
	}

	/**
	 * <PRE>
	 * �Z���̐ݒ�
	 * </PRE>
	 *
	 * @param value�l
	 * @param �J������
	 */
	protected void setCell(String value, int col) {

		// �Z����ݒ肷��
		Cell outputCell1 = outputRow.createCell(col);
		outputCell1.setCellValue(changeNullSp(value));
	}

	/**
	 * <PRE>
	 * null�f�[�^���󕶎��ɕϊ�����
	 * </PRE>
	 *
	 * @param �\���f�[�^
	 */
	protected String changeNullSp(String value) {

		// �ԋp�p�ϐ�
		String str = "";

		if (value != null) {
			str = value;
		}
		return str;
	}

	/**
	 * �e���v���[�g�t�@�C�����̐ݒ�
	 *
	 * @param template
	 *            �ݒ肷��e���v���[�g�t�@�C����
	 */
	public void setParameter(String template) {
		this.templateFileName = template;
	}

	/**
	 * Excel�o��FormBean�̐ݒ�
	 *
	 * @param printFormBean
	 *            �ݒ肷��o��FormBean
	 */
	public void setPrintDownloadError31919000FormBean(PrintDownloadError31919000FormBean printFormBean) {
		this.printFormBean = printFormBean;
	}
}
