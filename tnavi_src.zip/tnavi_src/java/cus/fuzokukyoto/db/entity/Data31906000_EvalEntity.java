package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �]��Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31906000_EvalEntity {
	
	/**
	 * ���ȃR�[�h
	 */
	private String item_code;
	
	/**
	 * ���Ȗ���
	 */
	private String item_name;

	/**
	 * �]��
	 */
	private String revl_display;

	
	/**
	 * �w�Дԍ�
	 */
	private String rev_stucode;

	/**
	 * �o�͎���
	 */
	private String rev_goptcode;

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getRevl_display() {
		return revl_display;
	}

	public void setRevl_display(String revl_display) {
		this.revl_display = revl_display;
	}

	public String getRev_stucode() {
		return rev_stucode;
	}

	public void setRev_stucode(String rev_stucode) {
		this.rev_stucode = rev_stucode;
	}

	public String getRev_goptcode() {
		return rev_goptcode;
	}

	public void setRev_goptcode(String rev_goptcode) {
		this.rev_goptcode = rev_goptcode;
	}


	
}
