/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * �w�N���ѓo�^(���s����啍�� ���w�Z) �ꗗ���ׁi�L�^���jEntity.
 * </PRE>
 *
 * <B>Create</B> 2016.07.20 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31919000_03Entity implements CommonConstantsUseable {

	/**
	 * �����R�[�h
	 */
	private String user;
	/**
	 * �N�x
	 */
	private String year;
	/**
	 * �w�Дԍ�
	 */
	private String stucode;
	/**
	 * �w�N
	 */
	private String grade;
	/**
	 * ����
	 */
	private String item;
	/**
	 * ���яo�͎���ID
	 */
	private String goptcode;
	/**
	 * �ϓ_ID
	 */
	private String rivtcode;
	/**
	 * �l(�]���]��ID�����e�L�X�g)
	 */
	private String data;
	/**
	 * �f�[�^���(�t�B�[���h��)
	 */
	private String datakind;
	/**
	 * �c�[���`�b�v���b�Z�[�W
	 */
	private String tooltipMsg = "";
	/**
	 * �\���p�l
	 */
	private String dispVal;
	/**
	 * ���ʂƂȂ�ϓ_�ʕ]���̕]���l�R�[�h
	 */
	private String dataSub;
	
	/**
	 * @param user �Z�b�g���� user
	 */
	public void setUser(String user) {
		this.user = user;
	}
	/**
	 * @return user
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param year �Z�b�g���� year
	 */
	public void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return year
	 */
	public String getYear() {
		return year;
	}
	/**
	 * @param stucode �Z�b�g���� stucode
	 */
	public void setStucode(String stucode) {
		this.stucode = stucode;
	}
	/**
	 * @return stucode
	 */
	public String getStucode() {
		return stucode;
	}
	/**
	 * @param grade �Z�b�g���� grade
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}
	/**
	 * @return grade
	 */
	public String getGrade() {
		return grade;
	}
	/**
	 * @param item �Z�b�g���� item
	 */
	public void setItem(String item) {
		this.item = item;
	}
	/**
	 * @return item
	 */
	public String getItem() {
		return item;
	}
	/**
	 * @param goptcode �Z�b�g���� goptcode
	 */
	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}
	/**
	 * @return goptcode
	 */
	public String getGoptcode() {
		return goptcode;
	}
	/**
	 * @param data �Z�b�g���� data
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @return data
	 */
	public String getData() {
		return data;
	}
	/**
	 * @param datakind �Z�b�g���� datakind
	 */
	public void setDatakind(String datakind) {
		this.datakind = datakind;
	}
	/**
	 * @return datakind
	 */
	public String getDatakind() {
		return datakind;
	}
	/**
	 * @param rivtcode �Z�b�g���� rivtcode
	 */
	public void setRivtcode(String rivtcode) {
		this.rivtcode = rivtcode;
	}
	/**
	 * @return rivtcode
	 */
	public String getRivtcode() {
		return rivtcode;
	}
	/**
	 * @return tooltipMsg
	 */
	public String getTooltipMsg() {
		return tooltipMsg;
	}
	/**
	 * @param tooltipMsg the tooltipMsg to set
	 */
	public void setTooltipMsg(String tooltipMsg) {
		this.tooltipMsg = tooltipMsg;
	}
	/**
	 * @return dispVal
	 */
	public String getDispVal() {
		return dispVal;
	}
	/**
	 * @param dispVal the dispVal to set
	 */
	public void setDispVal(String dispVal) {
		this.dispVal = dispVal;
	}
	/**
	 * @return dataSub
	 */
	public String getDataSub() {
		return dataSub;
	}
	/**
	 * @param dataSub the dataSub to set
	 */
	public void setDataSub(String dataSub) {
		this.dataSub = dataSub;
	}

}
