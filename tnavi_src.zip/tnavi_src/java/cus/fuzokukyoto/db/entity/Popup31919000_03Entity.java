package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

public class Popup31919000_03Entity {

	/** �o�͎����R�[�h **/
	private String goptcode;
	
	/** �ʒm�\�ϓ_�R�[�h **/
	private String rivtcode;
	
	/** �v�^�ϓ_�R�[�h **/
	private String givtcode;

	/** �ʒm�\�ϓ_���� **/
	private String rivtname;
	
	/** �ʒm�\�]�� �\���p�̒l **/
	private String disp_value;

	/** �ʒm�\�]���̏�� (0:����o�^ 1:�ϓ_���g�p���Ȃ� 2:�]���s�\�E�]�������{(����ȕ]��) 3:���o�^) **/
	private String est_status;
	
	/**
	 * @return goptcode
	 */
	public String getGoptcode() {
		return goptcode;
	}

	/**
	 * @param goptcode the goptcode to set
	 */
	public void setGoptcode(String goptcode) {
		this.goptcode = goptcode;
	}

	/**
	 * @return rivtcode
	 */
	public String getRivtcode() {
		return rivtcode;
	}

	/**
	 * @param rivtcode the rivtcode to set
	 */
	public void setRivtcode(String rivtcode) {
		this.rivtcode = rivtcode;
	}

	/**
	 * @return givtcode
	 */
	public String getGivtcode() {
		return givtcode;
	}

	/**
	 * @param givtcode the givtcode to set
	 */
	public void setGivtcode(String givtcode) {
		this.givtcode = givtcode;
	}

	/**
	 * @return rivtname
	 */
	public String getRivtname() {
		return rivtname;
	}

	/**
	 * @param rivtname the rivtname to set
	 */
	public void setRivtname(String rivtname) {
		this.rivtname = rivtname;
	}

	/**
	 * @return disp_value
	 */
	public String getDisp_value() {
		return disp_value;
	}

	/**
	 * @param disp_value the disp_value to set
	 */
	public void setDisp_value(String disp_value) {
		this.disp_value = disp_value;
	}

	/**
	 * @return est_status
	 */
	public String getEst_status() {
		return est_status;
	}

	/**
	 * @param est_status the est_status to set
	 */
	public void setEst_status(String est_status) {
		this.est_status = est_status;
	}
	
}
