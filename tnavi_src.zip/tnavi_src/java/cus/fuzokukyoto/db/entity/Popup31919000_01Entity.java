package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

public class Popup31919000_01Entity {

	/** �ϓ_�R�[�h **/
	private String givtcode;

	/** �ϓ_���� **/
	private String givtname;
	
	/** �֘A����ʒm�\�ϓ_�� **/
	private int vpcnt;

	/**
	 * @return givtcode
	 */
	public String getGivtcode() {
		return givtcode;
	}

	/**
	 * @param givtcode the givtcode to set
	 */
	public void setGivtcode(String givtcode) {
		this.givtcode = givtcode;
	}

	/**
	 * @return givtname
	 */
	public String getGivtname() {
		return givtname;
	}

	/**
	 * @param givtname the givtname to set
	 */
	public void setGivtname(String givtname) {
		this.givtname = givtname;
	}

	/**
	 * @return vpcnt
	 */
	public int getVpcnt() {
		return vpcnt;
	}

	/**
	 * @param vpcnt the vpcnt to set
	 */
	public void setVpcnt(int vpcnt) {
		this.vpcnt = vpcnt;
	}
	
}
