/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD Inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �o���W�v�E�ؖ����t�ݒ�(������)(���s����啍������) Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.04.06 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31943000Entity {
    /**
     * �����R�[�h
     */
    private String crs_user;
    /**
     * �N�x
     */
    private String crs_year;
    /**
     * ���R�[�h���
     */
    private String crs_kind;
    /**
     * �ݗ��敪
     */
    private String crs_estab_kind;
    /**
     * �I���敪
     */
    private String crs_select_kind;
    /**
     * �o���W�v���ؓ�
     */
    private String crs_attdate;
    /**
     * �ؖ����t
     */
    private String crs_certdate;
    /**
     * ���я�
     */
    private Integer crs_order;
    /**
     * ���w���p�o�͎����R�[�h
     */
    private String crs_totalgoptcode;
    /**
     * �X�V��
     */
    private String crs_update;
    /**
     * �X�V��
     */
    private String crs_upuser;
	/**
	 * @return crs_user
	 */
	public String getCrs_user() {
		return crs_user;
	}
	/**
	 * @param crs_user �Z�b�g���� crs_user
	 */
	public void setCrs_user(String crs_user) {
		this.crs_user = crs_user;
	}
	/**
	 * @return crs_year
	 */
	public String getCrs_year() {
		return crs_year;
	}
	/**
	 * @param crs_year �Z�b�g���� crs_year
	 */
	public void setCrs_year(String crs_year) {
		this.crs_year = crs_year;
	}
	/**
	 * @return crs_kind
	 */
	public String getCrs_kind() {
		return crs_kind;
	}
	/**
	 * @param crs_kind �Z�b�g���� crs_kind
	 */
	public void setCrs_kind(String crs_kind) {
		this.crs_kind = crs_kind;
	}
	/**
	 * @return crs_estab_kind
	 */
	public String getCrs_estab_kind() {
		return crs_estab_kind;
	}
	/**
	 * @param crs_estab_kind �Z�b�g���� crs_estab_kind
	 */
	public void setCrs_estab_kind(String crs_estab_kind) {
		this.crs_estab_kind = crs_estab_kind;
	}
	/**
	 * @return crs_select_kind
	 */
	public String getCrs_select_kind() {
		return crs_select_kind;
	}
	/**
	 * @param crs_select_kind �Z�b�g���� crs_select_kind
	 */
	public void setCrs_select_kind(String crs_select_kind) {
		this.crs_select_kind = crs_select_kind;
	}
	/**
	 * @return crs_attdate
	 */
	public String getCrs_attdate() {
		return crs_attdate;
	}
	/**
	 * @param crs_attdate �Z�b�g���� crs_attdate
	 */
	public void setCrs_attdate(String crs_attdate) {
		this.crs_attdate = crs_attdate;
	}
	/**
	 * @return crs_certdate
	 */
	public String getCrs_certdate() {
		return crs_certdate;
	}
	/**
	 * @param crs_certdate �Z�b�g���� crs_certdate
	 */
	public void setCrs_certdate(String crs_certdate) {
		this.crs_certdate = crs_certdate;
	}
	/**
	 * @return crs_order
	 */
	public Integer getCrs_order() {
		return crs_order;
	}
	/**
	 * @param crs_order �Z�b�g���� crs_order
	 */
	public void setCrs_order(Integer crs_order) {
		this.crs_order = crs_order;
	}
	/**
	 * @return crs_totalgoptcode
	 */
	public String getCrs_totalgoptcode() {
		return crs_totalgoptcode;
	}
	/**
	 * @param crs_totalgoptcode �Z�b�g���� crs_totalgoptcode
	 */
	public void setCrs_totalgoptcode(String crs_totalgoptcode) {
		this.crs_totalgoptcode = crs_totalgoptcode;
	}
	/**
	 * @return crs_update
	 */
	public String getCrs_update() {
		return crs_update;
	}
	/**
	 * @param crs_update �Z�b�g���� crs_update
	 */
	public void setCrs_update(String crs_update) {
		this.crs_update = crs_update;
	}
	/**
	 * @return crs_upuser
	 */
	public String getCrs_upuser() {
		return crs_upuser;
	}
	/**
	 * @param crs_upuser �Z�b�g���� crs_upuser
	 */
	public void setCrs_upuser(String crs_upuser) {
		this.crs_upuser = crs_upuser;
	}

}
