package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �u�����̗l�q�v�i�E�y�[�W�j Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31906000_ActReportEntity {
	
	/**
	 * �w�Дԍ�
	 */
	private String ravv_stucode;
		
	/**
	 * �]��
	 */
	private String race_reportdisplay;

	/**
	 * �o�͎����R�[�h
	 */
	private String ravv_term;

	
	
	public String getRavv_stucode() {
		return ravv_stucode;
	}

	public void setRavv_stucode(String ravv_stucode) {
		this.ravv_stucode = ravv_stucode;
	}

	public String getRace_reportdisplay() {
		return race_reportdisplay;
	}

	public void setRace_reportdisplay(String race_reportdisplay) {
		this.race_reportdisplay = race_reportdisplay;
	}

	public String getRavv_term() {
		return ravv_term;
	}

	public void setRavv_term(String ravv_term) {
		this.ravv_term = ravv_term;
	}

	
}
