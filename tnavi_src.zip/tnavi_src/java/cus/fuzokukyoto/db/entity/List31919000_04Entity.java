/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2001 APSIS CORPORATION,All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

import jp.co.systemd.tnavi.common.db.entity.VpestCombineEntity;

/**
 * <PRE>
 * �w�N���ѓo�^(���s����啍�� ���w�Z) �ϓ_�ʕ]���g�����p�^�[���}�X�^��� Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.07.26 BY SD hirata<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31919000_04Entity extends VpestCombineEntity{

	/**
	 * �\���p�̒l
	 */
	private String rvpe_display;

	/**
	 * @return rvpe_display
	 */
	public String getRvpe_display() {
		return rvpe_display;
	}

	/**
	 * @param rvpe_display the rvpe_display to set
	 */
	public void setRvpe_display(String rvpe_display) {
		this.rvpe_display = rvpe_display;
	}


}
