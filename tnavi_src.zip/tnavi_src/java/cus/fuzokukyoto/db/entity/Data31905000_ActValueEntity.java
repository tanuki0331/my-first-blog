package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �u�����I�Ȋw�K�̎��ԁv�w�K�̋L�^�̃f�[�^�擾SQL(�]��) Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31905000_ActValueEntity {
	
	/**
	 * �w�Дԍ�
	 */
	private String rtav_stucode;
		
	/**
	 * �]��
	 */
	private String rtav_value;


	
	public String getRtav_stucode() {
		return rtav_stucode;
	}

	public void setRtav_stucode(String rtav_stucode) {
		this.rtav_stucode = rtav_stucode;
	}

	public String getRtav_value() {
		return rtav_value;
	}

	public void setRtav_value(String rtav_value) {
		this.rtav_value = rtav_value;
	}

	
}
