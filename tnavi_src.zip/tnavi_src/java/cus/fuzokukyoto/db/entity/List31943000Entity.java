/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD Inc., All Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

import jp.co.systemd.tnavi.common.db.constants.CommonConstantsUseable;

/**
 * <PRE>
 * �o���W�v�E�ؖ����t�ݒ�(������)(���s����啍������) Entity.
 * </PRE>
 *
 * <B>Create</B> 2017.04.06 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class List31943000Entity implements CommonConstantsUseable {

	/**
	 * �ݗ��敪
	 */
	private String crs_estab_kind;
	/**
	 * �I���敪
	 */
	private String crs_select_kind;
	/**
	 * �o���W�v���ؓ�
	 */
	private String ATTMMDD;
	/**
	 * �ؖ����t
	 */
	private String CERTMMDD;
	/**
	 * @return crs_estab_kind
	 */
	public String getCrs_estab_kind() {
		return crs_estab_kind;
	}
	/**
	 * @param crs_estab_kind �Z�b�g���� crs_estab_kind
	 */
	public void setCrs_estab_kind(String crs_estab_kind) {
		this.crs_estab_kind = crs_estab_kind;
	}
	/**
	 * @return crs_select_kind
	 */
	public String getCrs_select_kind() {
		return crs_select_kind;
	}
	/**
	 * @param crs_select_kind �Z�b�g���� crs_select_kind
	 */
	public void setCrs_select_kind(String crs_select_kind) {
		this.crs_select_kind = crs_select_kind;
	}
	/**
	 * @return aTTMMDD
	 */
	public String getATTMMDD() {
		return ATTMMDD;
	}
	/**
	 * @param aTTMMDD �Z�b�g���� aTTMMDD
	 */
	public void setATTMMDD(String aTTMMDD) {
		ATTMMDD = aTTMMDD;
	}
	/**
	 * @return cERTMMDD
	 */
	public String getCERTMMDD() {
		return CERTMMDD;
	}
	/**
	 * @param cERTMMDD �Z�b�g���� cERTMMDD
	 */
	public void setCERTMMDD(String cERTMMDD) {
		CERTMMDD = cERTMMDD;
	}

}
