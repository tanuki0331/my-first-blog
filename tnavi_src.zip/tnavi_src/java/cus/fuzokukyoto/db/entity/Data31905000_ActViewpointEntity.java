package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �u�����I�Ȋw�K�̎��ԁv�w�K�̋L�^�̃f�[�^�擾(�w�K�����A�ϓ_)Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31905000_ActViewpointEntity {
	
	/**
	 * �w�K����
	 */
	private String rtat_act;
		
	/**
	 * �ϓ_
	 */
	private String rtat_pointview;

	
	public String getRtat_act() {
		return rtat_act;
	}

	public void setRtat_act(String rtat_act) {
		this.rtat_act = rtat_act;
	}

	public String getRtat_pointview() {
		return rtat_pointview;
	}

	public void setRtat_pointview(String rtat_pointview) {
		this.rtat_pointview = rtat_pointview;
	}
	
}
