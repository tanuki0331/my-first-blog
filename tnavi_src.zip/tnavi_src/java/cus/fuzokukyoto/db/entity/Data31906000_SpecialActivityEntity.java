package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * ���ʊ���Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31906000_SpecialActivityEntity {
	
	/**
	 * ���ʊ������ڃR�[�h
	 */
	private String rsav_rsatcode;
	
	/**
	 * �]��
	 */
	private String rsav_record;
	
	/**
	 * �w�Дԍ�
	 */
	private String rsav_stucode;

	/**
	 * �o�͎���
	 */
	private String rsav_term;

	
	
	public String getRsav_rsatcode() {
		return rsav_rsatcode;
	}

	public void setRsav_rsatcode(String rsav_rsatcode) {
		this.rsav_rsatcode = rsav_rsatcode;
	}

	public String getRsav_record() {
		return rsav_record;
	}

	public void setRsav_record(String rsav_record) {
		this.rsav_record = rsav_record;
	}

	public String getRsav_stucode() {
		return rsav_stucode;
	}

	public void setRsav_stucode(String rsav_stucode) {
		this.rsav_stucode = rsav_stucode;
	}

	public String getRsav_term() {
		return rsav_term;
	}

	public void setRsav_term(String rsav_term) {
		this.rsav_term = rsav_term;
	}

	
}
