package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �u�����̗l�q�v���ځi�E�y�[�W�j Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY SD fukuda<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31905000_ActReportItemEntity {

	/**
	 * �A��
	 */
	private String ravt_ravtcode;

	/**
	* ���ږ�
	*/
	private String ravt_ravtname;

	/**
	 * �ϓ_�̎�|�E�w�K�̂߂���
	 */
	private String ravt_purpose;

	public String getRavt_ravtcode() {
		return ravt_ravtcode;
	}

	public void setRavt_ravtcode(String ravt_ravtcode) {
		this.ravt_ravtcode = ravt_ravtcode;
	}

	public String getRavt_ravtname() {
		return ravt_ravtname;
	}

	public void setRavt_ravtname(String ravt_ravtname) {
		this.ravt_ravtname = ravt_ravtname;
	}

	public String getRavt_purpose() {
		return ravt_purpose;
	}

	public void setRavt_purpose(String ravt_purpose) {
		this.ravt_purpose = ravt_purpose;
	}

}
