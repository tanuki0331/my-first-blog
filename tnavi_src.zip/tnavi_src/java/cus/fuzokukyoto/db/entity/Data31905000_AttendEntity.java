package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �o���̋L�^Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31905000_AttendEntity {

	/** 
	 * ���Ɠ��� 
	 */
	private Integer enf_count;
	/** 
	 * �o�Ȓ�~�E���� 
	 */
	private Integer att_stop;
	
	/**
	 * �o�Ȃ��ׂ����� 
	 */
	private Integer att_must;
	/**
	 * ���ȓ��� 
	 */
	private Integer att_absence;
	
	
	
	
	public Integer getEnf_count() {
		return enf_count;
	}
	public void setEnf_count(Integer enf_count) {
		this.enf_count = enf_count;
	}
	public Integer getAtt_stop() {
		return att_stop;
	}
	public void setAtt_stop(Integer att_stop) {
		this.att_stop = att_stop;
	}
	public Integer getAtt_must() {
		return att_must;
	}
	public void setAtt_must(Integer att_must) {
		this.att_must = att_must;
	}
	public Integer getAtt_absence() {
		return att_absence;
	}
	public void setAtt_absence(Integer att_absence) {
		this.att_absence = att_absence;
	}
	public Integer getAtt_attend() {
		return att_attend;
	}
	public void setAtt_attend(Integer att_attend) {
		this.att_attend = att_attend;
	}
	public String getAtt_stucode() {
		return att_stucode;
	}
	public void setAtt_stucode(String att_stucode) {
		this.att_stucode = att_stucode;
	}
	public String getGopt_goptcode() {
		return gopt_goptcode;
	}
	public void setGopt_goptcode(String gopt_goptcode) {
		this.gopt_goptcode = gopt_goptcode;
	}
	public String getGopt_attend_start() {
		return gopt_attend_start;
	}
	public void setGopt_attend_start(String gopt_attend_start) {
		this.gopt_attend_start = gopt_attend_start;
	}
	public String getGopt_attend_end() {
		return gopt_attend_end;
	}
	public void setGopt_attend_end(String gopt_attend_end) {
		this.gopt_attend_end = gopt_attend_end;
	}
	/**
	 * �o�ȓ��� 
	 */
	private Integer att_attend;
	
	/**
	 * ���k 
	 */
	private String att_stucode;
	/**
	 * �w��
	 */
	private String gopt_goptcode;
	/**
	 * �o�ȊJ�n�� 
	 */
	private String gopt_attend_start;
	/**
	 * �o�ȏI���� 
	 */
	private String gopt_attend_end	;						
	
	
	
	


}
