package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * ���ȕʊϓ_�A�]���@Entity.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31906000_ItemViewpointEntity {
	
	/**
	 * ���ȃR�[�h
	 */
	private String item_code;
	
	/**
	 * �\����
	 */
	private String item_order;
	
	/**
	 * ���Ȗ���
	 */
	private String item_name;

	/**
	 * ���ȕʊϓ_�A��
	 */
	private String rivt_rivtcode;

	/**
	 * ����
	 */
	private String rivt_rivtname;
	
	/**
	 * �]��
	 */
//	private String rvpe_reportdisplay;

	
	/**
	 * �w�Дԍ�
	 */
	private String rvpv_stucode;

	/**
	 * �o�͎���
	 */
	private String rivt_term;

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public String getItem_order() {
		return item_order;
	}

	public void setItem_order(String item_order) {
		this.item_order = item_order;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getRivt_rivtcode() {
		return rivt_rivtcode;
	}

	public void setRivt_rivtcode(String rivt_rivtcode) {
		this.rivt_rivtcode = rivt_rivtcode;
	}

	public String getRivt_rivtname() {
		return rivt_rivtname;
	}

	public void setRivt_rivtname(String rivt_rivtname) {
		this.rivt_rivtname = rivt_rivtname;
	}

//	public String getRvpe_reportdisplay() {
//		return rvpe_reportdisplay;
//	}

//	public void setRvpe_reportdisplay(String rvpe_reportdisplay) {
//		this.rvpe_reportdisplay = rvpe_reportdisplay;
//	}

	public String getRvpv_stucode() {
		return rvpv_stucode;
	}

	public void setRvpv_stucode(String rvpv_stucode) {
		this.rvpv_stucode = rvpv_stucode;
	}

	public String getRivt_term() {
		return rivt_term;
	}

	public void setRivt_term(String rivt_term) {
		this.rivt_term = rivt_term;
	}

	
}
