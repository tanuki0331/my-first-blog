package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

/**
 * <PRE>
 * �u�����v�i�E�y�[�W�j Entity.
 * </PRE>
 *
 * <B>Create</B> 2018.08.17 BY fukuda<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Data31906000_MoralEntity {
	
	/**
	 * �w�Дԍ�
	 */
	private String rmrl_stucode;
		
	/**
	 * �]��
	 */
	private String rmrl_value;


	public String getRmrl_stucode() {
		return rmrl_stucode;
	}

	public void setRmrl_stucode(String rmrl_stucode) {
		this.rmrl_stucode = rmrl_stucode;
	}

	public String getRmrl_value() {
		return rmrl_value;
	}

	public void setRmrl_value(String rmrl_value) {
		this.rmrl_value = rmrl_value;
	}
	
}
