package jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity;

public class Popup31919000_02Entity {

	/** �ʒm�\�ϓ_�R�[�h **/
	private String rivtcode;
	
	/** �v�^�ϓ_�R�[�h **/
	private String givtcode;

	/** �ʒm�\�ϓ_���� **/
	private String rivtname;

	/**
	 * @return rivtcode
	 */
	public String getRivtcode() {
		return rivtcode;
	}

	/**
	 * @param rivtcode the rivtcode to set
	 */
	public void setRivtcode(String rivtcode) {
		this.rivtcode = rivtcode;
	}

	/**
	 * @return givtcode
	 */
	public String getGivtcode() {
		return givtcode;
	}

	/**
	 * @param givtcode the givtcode to set
	 */
	public void setGivtcode(String givtcode) {
		this.givtcode = givtcode;
	}

	/**
	 * @return rivtname
	 */
	public String getRivtname() {
		return rivtname;
	}

	/**
	 * @param rivtname the rivtname to set
	 */
	public void setRivtname(String rivtname) {
		this.rivtname = rivtname;
	}
	
}
