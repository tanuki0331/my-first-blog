/**------------------------------------------------------------**
 * Te@cherNavi
 *  Copyright(C) 2016 SystemD Inc., ll Rights Reserved.
 **------------------------------------------------------------**/
package jp.co.systemd.tnavi.cus.fuzokukyoto.db.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.systemd.tnavi.common.db.AbstractExecuteQuery;
import jp.co.systemd.tnavi.common.db.QueryUpdateBatchManager;
import jp.co.systemd.tnavi.common.db.QueryUpdateManager;
import jp.co.systemd.tnavi.common.exception.TnaviDbException;
import jp.co.systemd.tnavi.common.exception.TnaviException;
import jp.co.systemd.tnavi.common.session.SystemInfoBean;
import jp.co.systemd.tnavi.common.utility.DateUtility;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31943000Entity;

/**
 * <PRE>
 * �o���W�v�E�ؖ����t�ݒ�(������)(���s����啍������) �X�V Service.
 * </PRE>
 *
 * <B>Create</B> 2017.04.06 BY AIVICK<BR>
 * <B>remark</B><BR>
 *
 * @author SystemD inc.
 * @since 1.0.
 */
public class Regist31943000Service extends AbstractExecuteQuery{

	/** log4j */
	private static final Log log = LogFactory.getLog(Regist31943000Service.class);

    /** �����R�[�h */
    private String userCode;
    /** �N�x */
    private String year;
    /** ���[�U�[ID */
    private String staffId;

    /** �������ݒ�_���s�{�f�[�^ */
	private List<Data31943000Entity> entityList;

	/**
	 * @return entityList
	 */
	public List<Data31943000Entity> getEntityList() {
		return entityList;
	}

	/**
	 * @param entityList �Z�b�g���� entityList
	 */
	public void setEntityList(List<Data31943000Entity> entityList) {
		this.entityList = entityList;
	}

	/** ���sSQL */
	private static final String EXEC_SQL_INS = "cus/fuzokukyoto/insert31943000.sql";		// �������ݒ�_���s�{ �o�^SQL
	private static final String EXEC_SQL_DEL = "cus/fuzokukyoto/delete31943000.sql";		// �������ݒ�_���s�{ �폜SQL

	public void execute(HttpServletRequest request, SystemInfoBean sessionBean) throws TnaviDbException {
		this.userCode = sessionBean.getUserCode();
		this.year = request.getParameter("year");
		this.staffId = sessionBean.getStaffId();

		String[] suffixList = {"1_1", "1_2", "1_3", "1_4", "2_0"};

		entityList = new ArrayList<Data31943000Entity>();
		int i = 0;
		for(String suffix: suffixList) {
			Data31943000Entity entity = new Data31943000Entity();

			String estabKind = suffix.substring(0, 1);
			String selectKind = suffix.substring(2, 3);
			String attdate = request.getParameter("attyy_" + suffix) + request.getParameter("attmm_" + suffix) + request.getParameter("attdd_" + suffix);
			String certdate = "";
			if (!"2_0".equals(suffix)) {
				certdate = request.getParameter("certyy_" + suffix) + request.getParameter("certmm_" + suffix) + request.getParameter("certdd_" + suffix);
			}

			entity.setCrs_estab_kind(estabKind);
			entity.setCrs_select_kind(selectKind);
			entity.setCrs_attdate(attdate);
			entity.setCrs_certdate(certdate);
			entity.setCrs_order(i + 1);

			entityList.add(entity);
			i++;
		}

		super.execute();
	}

	@Override
	protected void doQuery() throws TnaviDbException {
		// INSERT�pBatchManager
		QueryUpdateBatchManager queryManagerIns = null;

		try{
			// ----DELETE����
			// �p�����[�^�̐���
			Object[] delParam = {
					this.userCode,
					this.year,
			};
			QueryUpdateManager queryManagerDel = new QueryUpdateManager(EXEC_SQL_DEL, delParam);

			// ���s
			this.executeUpdate(queryManagerDel);

			// ----INSERT����
			queryManagerIns = new QueryUpdateBatchManager(EXEC_SQL_INS);
			this.initialBatchUpdate(queryManagerIns);

			for(Data31943000Entity entity : entityList){
				// �p�����[�^�̐���
				Object[] insParam = {
						this.userCode,
						this.year,
						"1",							// ���R�[�h��� 1:�I��(�Œ�)
						entity.getCrs_estab_kind(),
						entity.getCrs_select_kind(),
						entity.getCrs_attdate(),
						entity.getCrs_certdate(),
						entity.getCrs_order(),
						null,							// ���w���p�o�͎����R�[�h
						DateUtility.getSystemDate(),	// �X�V��
						this.staffId,					// �X�V��
				};

				// ���s
				this.executeBatchUpdate(queryManagerIns, insParam);
			}

			// �R�~�b�g
			this.commit();
		} catch (Exception e) {
			// ���[���o�b�N
			super.rollback();
			log.error("�o���W�v�E�ؖ����t�ݒ�(������)(���s����啍������) DB�X�V�����Ɏ��s���܂����B", e);
			throw new TnaviException(e);
		} finally {
			if(queryManagerIns != null){
				this.closeBatchUpdate(queryManagerIns);
				queryManagerIns = null;
			}
		}
	}

}
