package jp.co.systemd.tnavi.cus.fuzokukyoto.formbean;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_ActValueEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_ActViewpointEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_AttendEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_EvalEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_ItemViewpointEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_MoralEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_ScoreEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Data31906000_SpecialActivityEntity;
/**
 * <PRE>
 * ���ђʒm�\���(���s�����w�t�����s�����w�Z�@���w�Z�p) ��� FormBean.
 * </PRE>
 *
 * <B>Create</B> 2016.06.03 BY AIVICK <BR>
 * <B>remark</B><BR>
 *
 * @author SystemD Inc.
 * @since 1.0.
 */
public class Print31906000FormBean {

	public final static String DEFALUT_VALUE = "";

	/**
	 * �����R�[�h
	 */
	private String userCode = DEFALUT_VALUE;

	/** �N�x */
	private String nendo = DEFALUT_VALUE;

	/** �I���w���� */
	private String termName = DEFALUT_VALUE;

	/** �I���w�� */
	private String term = DEFALUT_VALUE;

	/** �I���N���X */
	private String clsno = DEFALUT_VALUE;

	/** �o�͓��t */
	private String outputDate = DEFALUT_VALUE;

	/** �Z�̓C���[�W */
	byte[] schoolStampImage;

	/** �w�Z��C���[�W */
	byte[] stampImage;

	/** �Z������ */
	private String principalName = DEFALUT_VALUE;

	/** �S�C���� */
	private String teacherName = DEFALUT_VALUE;

	/** �O�C�S�C���� */
	private String formerTeacherName = DEFALUT_VALUE;

	/** �������� */
	private String schoolNameO = DEFALUT_VALUE;

	/** �������� */
	private String schoolNameS = DEFALUT_VALUE;

	/** �u�����I�Ȋw�K�̎��ԁv�w�K�̋L�^�̃f�[�^�擾(�w�K�����A�ϓ_)�̃��X�g  */
	private List<Data31906000_ActViewpointEntity> actViewpointEntityList;

	/** �u�����I�Ȋw�K�̎��ԁv�w�K�̋L�^�̃f�[�^�擾(�w�K�����A�ϓ_)�̃��X�g  */
	private List<Data31906000_ActValueEntity> actValueEntityList;

	/** �o���̋L�^�̃��X�g */
	private Map<String, Data31906000_AttendEntity > attendEntityListMap;

	/** ���ʊ����̃��X�g */
	private Map<String, Data31906000_SpecialActivityEntity > specialActivityEntityListMap;

	/** �����̃��X�g */
	private Map<String, Data31906000_MoralEntity > moralEntityListMap;

	/** ���ȕʊϓ_�̃��X�g */
	private  LinkedHashMap<String, LinkedList<Data31906000_ItemViewpointEntity>> itemViewpointEntityListMap;

	/** �]���̃��X�g */
	private Map<String, Map<String, Data31906000_ScoreEntity>> scoreEntityMapMap;

	/** �]��̃��X�g */
	private Map<String, Map<String, Data31906000_EvalEntity>> evalEntityMapMap;

	/** ���k���̃f�[�^ */
	private List<Data31906000FormBean> dataFormBeanList;

	/** ����y�[�W�\�� */
	private boolean output_cover;

	/** ����y�[�W����1 */
	private boolean output_page1;

	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getNendo() {
		return nendo;
	}
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	public String getTermName() {
		return termName;
	}
	public void setTermName(String termName) {
		this.termName = termName;
	}

	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}

	public String getClsno() {
		return clsno;
	}
	public void setClsno(String clsno) {
		this.clsno = clsno;
	}

	public String getOutputDate() {
		return outputDate;
	}
	public void setOutputDate(String outputDate) {
		this.outputDate = outputDate;
	}

	public byte[] getSchoolStampImage() {
		return schoolStampImage;
	}
	public void setSchoolStampImage(byte[] schoolStampImage) {
		this.schoolStampImage = schoolStampImage;
	}

	public byte[] getStampImage() {
		return stampImage;
	}
	public void setStampImage(byte[] stampImage) {
		this.stampImage = stampImage;
	}

	public String getPrincipalName() {
		return principalName;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public final String getFormerTeacherName() {
		return formerTeacherName;
	}
	public final void setFormerTeacherName(String formerTeacherName) {
		this.formerTeacherName = formerTeacherName;
	}

	public String getSchoolNameO() {
		return schoolNameO;
	}
	public void setSchoolNameO(String schoolNameO) {
		this.schoolNameO = schoolNameO;
	}

	public String getSchoolNameS() {
		return schoolNameS;
	}
	public void setSchoolNameS(String schoolNameS) {
		this.schoolNameS = schoolNameS;
	}

	public List<Data31906000_ActViewpointEntity> getActViewpointEntityList() {
		return actViewpointEntityList;
	}
	public void setActViewpointEntityList(
			List<Data31906000_ActViewpointEntity> actViewpointEntityList) {
		this.actViewpointEntityList = actViewpointEntityList;
	}

	public List<Data31906000_ActValueEntity> getActValueEntityList() {
		return actValueEntityList;
	}
	public void setActValueEntityList(
			List<Data31906000_ActValueEntity> actValueEntityList) {
		this.actValueEntityList = actValueEntityList;
	}

	public Map<String, Data31906000_AttendEntity> getAttendEntityListMap() {
		return attendEntityListMap;
	}
	public void setAttendEntityListMap(
			Map<String, Data31906000_AttendEntity> attendEntityListMap) {
		this.attendEntityListMap = attendEntityListMap;
	}

	public Map<String, Data31906000_SpecialActivityEntity> getSpecialActivityEntityListMap() {
		return specialActivityEntityListMap;
	}
	public void setSpecialActivityEntityListMap(
			Map<String, Data31906000_SpecialActivityEntity> specialActivityEntityListMap) {
		this.specialActivityEntityListMap = specialActivityEntityListMap;
	}

	public Map<String, Data31906000_MoralEntity > getMoralEntityListMap() {
		return moralEntityListMap;
	}
	public void setMoralEntityListMap(Map<String, Data31906000_MoralEntity > moralEntityListMap) {
		this.moralEntityListMap = moralEntityListMap;
	}
	public LinkedHashMap<String, LinkedList<Data31906000_ItemViewpointEntity>> getItemViewpointEntityListMap() {
		return itemViewpointEntityListMap;
	}
	public void setItemViewpointEntityListMap(
			LinkedHashMap<String, LinkedList<Data31906000_ItemViewpointEntity>> itemViewpointEntityListMap) {
		this.itemViewpointEntityListMap = itemViewpointEntityListMap;
	}

	public Map<String, Map<String, Data31906000_ScoreEntity>> getScoreEntityMapMap() {
		return scoreEntityMapMap;
	}
	public void setScoreEntityMapMap(
			Map<String, Map<String, Data31906000_ScoreEntity>> scoreEntityMapMap) {
		this.scoreEntityMapMap = scoreEntityMapMap;
	}

	public Map<String, Map<String, Data31906000_EvalEntity>> getEvalEntityMapMap() {
		return evalEntityMapMap;
	}
	public void setEvalEntityMapMap(
			Map<String, Map<String, Data31906000_EvalEntity>> evalEntityMapMap) {
		this.evalEntityMapMap = evalEntityMapMap;
	}

	public List<Data31906000FormBean> getDataFormBeanList() {
		return dataFormBeanList;
	}
	public void setDataFormBeanList(List<Data31906000FormBean> dataFormBeanList) {
		this.dataFormBeanList = dataFormBeanList;
	}

	public boolean isOutput_cover() {
		return output_cover;
	}
	public void setOutput_cover(boolean output_cover) {
		this.output_cover = output_cover;
	}

	public boolean isOutput_page1() {
		return output_page1;
	}
	public void setOutput_page1(boolean output_page1) {
		this.output_page1 = output_page1;
	}

}
