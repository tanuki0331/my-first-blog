package jp.co.systemd.tnavi.cus.fuzokukyoto.formbean;

import java.util.List;
import java.util.Map;

import jp.co.systemd.tnavi.common.db.entity.CmlguideoutputtermEntity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Popup31919000_01Entity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Popup31919000_02Entity;
import jp.co.systemd.tnavi.cus.fuzokukyoto.db.entity.Popup31919000_03Entity;

public class Popup31919000FormBean {

	public final static String DEFALUT_VALUE = "";
	
	/** �N�x **/
	private String nendo = DEFALUT_VALUE;
	
	/** �\���p�N�x **/
	private String nendoStr = DEFALUT_VALUE;
	
	/** �w�N **/
	private String glade = DEFALUT_VALUE;

	/** �\���p�w�N **/
	private String gladeStr = DEFALUT_VALUE;
	
	/** �g **/
	private String hmrClass = DEFALUT_VALUE;

	/** �g�i�\���p�j**/
	private String hmrClassStr = DEFALUT_VALUE;

	/** �N���X�ԍ� **/
	private String clsno = DEFALUT_VALUE;
	
	/** �w�Дԍ� **/
	private String stucode = DEFALUT_VALUE;
	
	/** ���� **/
	private String stuname = DEFALUT_VALUE;

	/** �w���v�̃R�[�h **/
	private String curcode = DEFALUT_VALUE;
	
	/** ���� **/
	private String item = DEFALUT_VALUE;

	/** ���ȁi�\���p�j**/
	private String itemStr = DEFALUT_VALUE;

	/** �]�藘�p�L���t���O **/
	private boolean isEvalUse = false;
	
	/** �v�^�ϓ_�w�b�_���Entity **/
	private List<Popup31919000_01Entity> cmlguideTitleList = null;

	/** �ʒm�\�ϓ_�w�b�_���Entity **/
	private List<Popup31919000_02Entity> scorptTitleList = null;

	/** �o�͎������Entity **/
	private List<CmlguideoutputtermEntity> termList = null;
	
	/** �e�o�͎����̕]�����EntityList���i�[����Map[key:�o�͎����R�[�h value:�]������EntityList] **/
	private Map<String, List<Popup31919000_03Entity>> termEstListMap = null;

	/** �w���v�^�p�̎����Z�o�]�����EntityList���i�[����Map[key:�v�^�ϓ_�R�[�h value:�\���p�]��] **/
	private Map<String, String> eoyEstMap = null;

	/** �w���v�^�]�� **/
	private String eoyEval = DEFALUT_VALUE;

	/**
	 * @return nendo
	 */
	public String getNendo() {
		return nendo;
	}

	/**
	 * @param nendo the nendo to set
	 */
	public void setNendo(String nendo) {
		this.nendo = nendo;
	}

	/**
	 * @return nendoStr
	 */
	public String getNendoStr() {
		return nendoStr;
	}

	/**
	 * @param nendoStr the nendoStr to set
	 */
	public void setNendoStr(String nendoStr) {
		this.nendoStr = nendoStr;
	}

	/**
	 * @return glade
	 */
	public String getGlade() {
		return glade;
	}

	/**
	 * @param glade the glade to set
	 */
	public void setGlade(String glade) {
		this.glade = glade;
	}

	/**
	 * @return gladeStr
	 */
	public String getGladeStr() {
		return gladeStr;
	}

	/**
	 * @param gladeStr the gladeStr to set
	 */
	public void setGladeStr(String gladeStr) {
		this.gladeStr = gladeStr;
	}

	/**
	 * @return hmrClass
	 */
	public String getHmrClass() {
		return hmrClass;
	}

	/**
	 * @param hmrClass the hmrClass to set
	 */
	public void setHmrClass(String hmrClass) {
		this.hmrClass = hmrClass;
	}

	/**
	 * @return hmrClassStr
	 */
	public String getHmrClassStr() {
		return hmrClassStr;
	}

	/**
	 * @param hmrClassStr the hmrClassStr to set
	 */
	public void setHmrClassStr(String hmrClassStr) {
		this.hmrClassStr = hmrClassStr;
	}

	/**
	 * @return clsno
	 */
	public String getClsno() {
		return clsno;
	}

	/**
	 * @param clsno the clsno to set
	 */
	public void setClsno(String clsno) {
		this.clsno = clsno;
	}

	/**
	 * @return stucode
	 */
	public String getStucode() {
		return stucode;
	}

	/**
	 * @param stucode the stucode to set
	 */
	public void setStucode(String stucode) {
		this.stucode = stucode;
	}

	/**
	 * @return stuname
	 */
	public String getStuname() {
		return stuname;
	}

	/**
	 * @param stuname the stuname to set
	 */
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	/**
	 * @return curcode
	 */
	public String getCurcode() {
		return curcode;
	}

	/**
	 * @param curcode the curcode to set
	 */
	public void setCurcode(String curcode) {
		this.curcode = curcode;
	}

	/**
	 * @return item
	 */
	public String getItem() {
		return item;
	}

	/**
	 * @param item the item to set
	 */
	public void setItem(String item) {
		this.item = item;
	}

	/**
	 * @return itemStr
	 */
	public String getItemStr() {
		return itemStr;
	}

	/**
	 * @param itemStr the itemStr to set
	 */
	public void setItemStr(String itemStr) {
		this.itemStr = itemStr;
	}

	/**
	 * @return isEvalUse
	 */
	public boolean isEvalUse() {
		return isEvalUse;
	}

	/**
	 * @param isEvalUse the isEvalUse to set
	 */
	public void setEvalUse(boolean isEvalUse) {
		this.isEvalUse = isEvalUse;
	}

	/**
	 * @return cmlguideTitleList
	 */
	public List<Popup31919000_01Entity> getCmlguideTitleList() {
		return cmlguideTitleList;
	}

	/**
	 * @param cmlguideTitleList the cmlguideTitleList to set
	 */
	public void setCmlguideTitleList(List<Popup31919000_01Entity> cmlguideTitleList) {
		this.cmlguideTitleList = cmlguideTitleList;
	}

	/**
	 * @return scorptTitleList
	 */
	public List<Popup31919000_02Entity> getScorptTitleList() {
		return scorptTitleList;
	}

	/**
	 * @param scorptTitleList the scorptTitleList to set
	 */
	public void setScorptTitleList(List<Popup31919000_02Entity> scorptTitleList) {
		this.scorptTitleList = scorptTitleList;
	}

	/**
	 * @return termList
	 */
	public List<CmlguideoutputtermEntity> getTermList() {
		return termList;
	}

	/**
	 * @param termList the termList to set
	 */
	public void setTermList(List<CmlguideoutputtermEntity> termList) {
		this.termList = termList;
	}

	/**
	 * @return termEstListMap
	 */
	public Map<String, List<Popup31919000_03Entity>> getTermEstListMap() {
		return termEstListMap;
	}

	/**
	 * @param termEstListMap the termEstListMap to set
	 */
	public void setTermEstListMap(
			Map<String, List<Popup31919000_03Entity>> termEstListMap) {
		this.termEstListMap = termEstListMap;
	}

	/**
	 * @return eoyEstMap
	 */
	public Map<String, String> getEoyEstMap() {
		return eoyEstMap;
	}

	/**
	 * @param eoyEstMap the eoyEstMap to set
	 */
	public void setEoyEstMap(Map<String, String> eoyEstMap) {
		this.eoyEstMap = eoyEstMap;
	}

	/**
	 * @return eoyEval
	 */
	public String getEoyEval() {
		return eoyEval;
	}

	/**
	 * @param eoyEval the eoyEval to set
	 */
	public void setEoyEval(String eoyEval) {
		this.eoyEval = eoyEval;
	}
	
}
