select
  /*%expand*/*
from
  T_ORDER_B
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  ORDERNO = /* orderno */1
  and
  ORDER_LINE = /* orderLine */1
