select
  /*%expand*/*
from
  CS_T_MESSAGE
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  MSGID = /* msgid */'a'
