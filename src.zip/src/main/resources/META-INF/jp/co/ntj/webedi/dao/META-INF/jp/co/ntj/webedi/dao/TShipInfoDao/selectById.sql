select
  /*%expand*/*
from
  T_SHIP_INFO
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  INV_NO = /* invNo */'a'
  and
  ORDERNO = /* orderno */1
  and
  ORDER_LINE = /* orderLine */1
