insert into TEST (
  KAISYA_CD,
  GENGO_KBN,
  TEST_ID,
  TEST_CODE,
  IS_DELETED,
  CREATED_AT,
  CREATED_USER,
  UPDATED_AT,
  UPDATED_USER
) values (
  /* dto.kaisyaCd */'1000',
  /* dto.gengoKbn */'EN',
  /* dto.testId */'A11',
  /* dto.testCode */11,
  /* dto.isDeleted */1,
  /* dto.createdAt */'2019/01/18 9:59:53.655',
  /* dto.createdUser */'TEST',
  /* dto.updatedAt */'2019/01/18 9:59:53.655',
  /* dto.updatedUser */'TEST'
);