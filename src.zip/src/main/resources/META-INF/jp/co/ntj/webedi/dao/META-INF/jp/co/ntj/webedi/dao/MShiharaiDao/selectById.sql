select
  /*%expand*/*
from
  M_SHIHARAI
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  SHI_JYOKENCD = /* shiJyokencd */1
