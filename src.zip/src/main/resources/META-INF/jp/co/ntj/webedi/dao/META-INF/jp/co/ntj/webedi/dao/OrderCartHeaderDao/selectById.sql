select
  /*%expand*/*
from
  ORDER_CART_HEADER
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  CUSTOMER_USER_ID = /* customerUserId */1
