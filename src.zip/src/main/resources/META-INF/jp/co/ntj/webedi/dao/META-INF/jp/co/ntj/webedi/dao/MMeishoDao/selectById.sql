select
  /*%expand*/*
from
  M_MEISHO
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  MEIKANCD = /* meikancd */'a'
  and
  MEISHOCD = /* meishocd */'a'
