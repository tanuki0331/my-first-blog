select
  /*%expand*/*
from
  M_SHOBUN
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  LAG_BUNCD = /* lagBuncd */'a'
  and
  MID_BUNCD = /* midBuncd */'a'
  and
  SML_BUNCD1 = /* smlBuncd1 */'a'
