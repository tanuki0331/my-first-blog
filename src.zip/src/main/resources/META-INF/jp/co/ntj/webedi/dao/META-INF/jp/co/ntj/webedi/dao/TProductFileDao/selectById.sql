select
  /*%expand*/*
from
  T_PRODUCT_FILE
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  FILE_CODE = /* fileCode */1
