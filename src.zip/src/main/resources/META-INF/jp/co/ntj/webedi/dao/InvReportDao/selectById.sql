select
  /*%expand*/*
from
  INV_REPORT
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  CUSTOMER_CODE = /* customerCode */1
  and
  DESTINATION_CODE = /* destinationCode */1
  and
  INV_NUMBER = /* invNumber */'a'
