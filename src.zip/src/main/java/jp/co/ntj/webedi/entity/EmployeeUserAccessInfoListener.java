package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class EmployeeUserAccessInfoListener implements EntityListener<EmployeeUserAccessInfo> {

    @Override
    public void preInsert(EmployeeUserAccessInfo entity, PreInsertContext<EmployeeUserAccessInfo> context) {
    }

    @Override
    public void preUpdate(EmployeeUserAccessInfo entity, PreUpdateContext<EmployeeUserAccessInfo> context) {
    }

    @Override
    public void preDelete(EmployeeUserAccessInfo entity, PreDeleteContext<EmployeeUserAccessInfo> context) {
    }

    @Override
    public void postInsert(EmployeeUserAccessInfo entity, PostInsertContext<EmployeeUserAccessInfo> context) {
    }

    @Override
    public void postUpdate(EmployeeUserAccessInfo entity, PostUpdateContext<EmployeeUserAccessInfo> context) {
    }

    @Override
    public void postDelete(EmployeeUserAccessInfo entity, PostDeleteContext<EmployeeUserAccessInfo> context) {
    }
}