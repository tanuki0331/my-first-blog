package jp.co.ntj.webedi.entity;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * REMARKS情報
 */
@Entity(listener = MRemarksListener.class)
@Table(name = "M_REMARKS")
public class MRemarks {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 仕向先コード */
    @Id
    @Column(name = "SHIMUKECD")
    Long shimukecd;

    /** REMARKS1 */
    @Column(name = "REMARKS1")
    String remarks1;

    /** REMARKS2 */
    @Column(name = "REMARKS2")
    String remarks2;

    /** REMARKS3 */
    @Column(name = "REMARKS3")
    String remarks3;

    /** REMARKS4 */
    @Column(name = "REMARKS4")
    String remarks4;

    /** REMARKS5 */
    @Column(name = "REMARKS5")
    String remarks5;

    /** REMARKS6 */
    @Column(name = "REMARKS6")
    String remarks6;

    /** REMARKS7 */
    @Column(name = "REMARKS7")
    String remarks7;

    /** REMARKS8 */
    @Column(name = "REMARKS8")
    String remarks8;

    /** REMARKS9 */
    @Column(name = "REMARKS9")
    String remarks9;

    /** REMARKS10 */
    @Column(name = "REMARKS10")
    String remarks10;

    /** 登録日付時刻 */
    @Column(name = "ENTRY_DATE")
    LocalDate entryDate;

    /** 更新日付時刻 */
    @Column(name = "UPDATE_DATE")
    LocalDate updateDate;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the shimukecd.
     * 
     * @return the shimukecd
     */
    public Long getShimukecd() {
        return shimukecd;
    }

    /** 
     * Sets the shimukecd.
     * 
     * @param shimukecd the shimukecd
     */
    public void setShimukecd(Long shimukecd) {
        this.shimukecd = shimukecd;
    }

    /** 
     * Returns the remarks1.
     * 
     * @return the remarks1
     */
    public String getRemarks1() {
        return remarks1;
    }

    /** 
     * Sets the remarks1.
     * 
     * @param remarks1 the remarks1
     */
    public void setRemarks1(String remarks1) {
        this.remarks1 = remarks1;
    }

    /** 
     * Returns the remarks2.
     * 
     * @return the remarks2
     */
    public String getRemarks2() {
        return remarks2;
    }

    /** 
     * Sets the remarks2.
     * 
     * @param remarks2 the remarks2
     */
    public void setRemarks2(String remarks2) {
        this.remarks2 = remarks2;
    }

    /** 
     * Returns the remarks3.
     * 
     * @return the remarks3
     */
    public String getRemarks3() {
        return remarks3;
    }

    /** 
     * Sets the remarks3.
     * 
     * @param remarks3 the remarks3
     */
    public void setRemarks3(String remarks3) {
        this.remarks3 = remarks3;
    }

    /** 
     * Returns the remarks4.
     * 
     * @return the remarks4
     */
    public String getRemarks4() {
        return remarks4;
    }

    /** 
     * Sets the remarks4.
     * 
     * @param remarks4 the remarks4
     */
    public void setRemarks4(String remarks4) {
        this.remarks4 = remarks4;
    }

    /** 
     * Returns the remarks5.
     * 
     * @return the remarks5
     */
    public String getRemarks5() {
        return remarks5;
    }

    /** 
     * Sets the remarks5.
     * 
     * @param remarks5 the remarks5
     */
    public void setRemarks5(String remarks5) {
        this.remarks5 = remarks5;
    }

    /** 
     * Returns the remarks6.
     * 
     * @return the remarks6
     */
    public String getRemarks6() {
        return remarks6;
    }

    /** 
     * Sets the remarks6.
     * 
     * @param remarks6 the remarks6
     */
    public void setRemarks6(String remarks6) {
        this.remarks6 = remarks6;
    }

    /** 
     * Returns the remarks7.
     * 
     * @return the remarks7
     */
    public String getRemarks7() {
        return remarks7;
    }

    /** 
     * Sets the remarks7.
     * 
     * @param remarks7 the remarks7
     */
    public void setRemarks7(String remarks7) {
        this.remarks7 = remarks7;
    }

    /** 
     * Returns the remarks8.
     * 
     * @return the remarks8
     */
    public String getRemarks8() {
        return remarks8;
    }

    /** 
     * Sets the remarks8.
     * 
     * @param remarks8 the remarks8
     */
    public void setRemarks8(String remarks8) {
        this.remarks8 = remarks8;
    }

    /** 
     * Returns the remarks9.
     * 
     * @return the remarks9
     */
    public String getRemarks9() {
        return remarks9;
    }

    /** 
     * Sets the remarks9.
     * 
     * @param remarks9 the remarks9
     */
    public void setRemarks9(String remarks9) {
        this.remarks9 = remarks9;
    }

    /** 
     * Returns the remarks10.
     * 
     * @return the remarks10
     */
    public String getRemarks10() {
        return remarks10;
    }

    /** 
     * Sets the remarks10.
     * 
     * @param remarks10 the remarks10
     */
    public void setRemarks10(String remarks10) {
        this.remarks10 = remarks10;
    }

    /** 
     * Returns the entryDate.
     * 
     * @return the entryDate
     */
    public LocalDate getEntryDate() {
        return entryDate;
    }

    /** 
     * Sets the entryDate.
     * 
     * @param entryDate the entryDate
     */
    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    /** 
     * Returns the updateDate.
     * 
     * @return the updateDate
     */
    public LocalDate getUpdateDate() {
        return updateDate;
    }

    /** 
     * Sets the updateDate.
     * 
     * @param updateDate the updateDate
     */
    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }
}