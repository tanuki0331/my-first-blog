package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class CustomerUserListener implements EntityListener<CustomerUser> {

    @Override
    public void preInsert(CustomerUser entity, PreInsertContext<CustomerUser> context) {
    }

    @Override
    public void preUpdate(CustomerUser entity, PreUpdateContext<CustomerUser> context) {
    }

    @Override
    public void preDelete(CustomerUser entity, PreDeleteContext<CustomerUser> context) {
    }

    @Override
    public void postInsert(CustomerUser entity, PostInsertContext<CustomerUser> context) {
    }

    @Override
    public void postUpdate(CustomerUser entity, PostUpdateContext<CustomerUser> context) {
    }

    @Override
    public void postDelete(CustomerUser entity, PostDeleteContext<CustomerUser> context) {
    }
}