package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.ShipToUser;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface ShipToUserDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param customerUserId
     * @return the ShipToUser entity
     */
    @Select
    ShipToUser selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, Long customerUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(ShipToUser entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(ShipToUser entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(ShipToUser entity);
}