package jp.co.ntj.webedi.entity;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 最終仕向先マスタ
 */
@Entity(listener = MLshimuListener.class)
@Table(name = "M_LSHIMU")
public class MLshimu {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 最終仕向先コード */
    @Id
    @Column(name = "LSHIMUKECD")
    Long lshimukecd;

    /** 仕向先コード */
    @Column(name = "SHIMUKECD")
    Long shimukecd;

    /** 社名識別コード */
    @Column(name = "SHA_SIKIBETCD")
    String shaSikibetcd;

    /** 社名略称 */
    @Column(name = "SHA_RYAK")
    String shaRyak;

    /** 社名カナ */
    @Column(name = "SHA_KANA")
    String shaKana;

    /** 電話番号 */
    @Column(name = "TELNO")
    String telno;

    /** ＦＡＸ番号 */
    @Column(name = "FAXNO")
    String faxno;

    /** 郵便番号 */
    @Column(name = "YUBIN_NO")
    String yubinNo;

    /** 社名１ */
    @Column(name = "SHA_NM1")
    String shaNm1;

    /** 社名２ */
    @Column(name = "SHA_NM2")
    String shaNm2;

    /** 住所１ */
    @Column(name = "ADR1")
    String adr1;

    /** 住所２ */
    @Column(name = "ADR2")
    String adr2;

    /** 住所３ */
    @Column(name = "ADR3")
    String adr3;

    /** 部署名 */
    @Column(name = "BUSHO_NM")
    String bushoNm;

    /** 代表者名 */
    @Column(name = "DAIHYO_NM")
    String daihyoNm;

    /** 国籍コード */
    @Column(name = "KUNICD")
    Short kunicd;

    /** 都道府県コード */
    @Column(name = "KENCD")
    Short kencd;

    /** 仕向地港コード */
    @Column(name = "SHIM_PORTCD")
    Short shimPortcd;

    /** 仕向地空港コード */
    @Column(name = "SHIM_AIRPORTCD")
    Short shimAirportcd;

    /** 輸送期間 */
    @Column(name = "YUSO_KIKAN")
    Short yusoKikan;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Long hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the lshimukecd.
     * 
     * @return the lshimukecd
     */
    public Long getLshimukecd() {
        return lshimukecd;
    }

    /** 
     * Sets the lshimukecd.
     * 
     * @param lshimukecd the lshimukecd
     */
    public void setLshimukecd(Long lshimukecd) {
        this.lshimukecd = lshimukecd;
    }

    /** 
     * Returns the shimukecd.
     * 
     * @return the shimukecd
     */
    public Long getShimukecd() {
        return shimukecd;
    }

    /** 
     * Sets the shimukecd.
     * 
     * @param shimukecd the shimukecd
     */
    public void setShimukecd(Long shimukecd) {
        this.shimukecd = shimukecd;
    }

    /** 
     * Returns the shaSikibetcd.
     * 
     * @return the shaSikibetcd
     */
    public String getShaSikibetcd() {
        return shaSikibetcd;
    }

    /** 
     * Sets the shaSikibetcd.
     * 
     * @param shaSikibetcd the shaSikibetcd
     */
    public void setShaSikibetcd(String shaSikibetcd) {
        this.shaSikibetcd = shaSikibetcd;
    }

    /** 
     * Returns the shaRyak.
     * 
     * @return the shaRyak
     */
    public String getShaRyak() {
        return shaRyak;
    }

    /** 
     * Sets the shaRyak.
     * 
     * @param shaRyak the shaRyak
     */
    public void setShaRyak(String shaRyak) {
        this.shaRyak = shaRyak;
    }

    /** 
     * Returns the shaKana.
     * 
     * @return the shaKana
     */
    public String getShaKana() {
        return shaKana;
    }

    /** 
     * Sets the shaKana.
     * 
     * @param shaKana the shaKana
     */
    public void setShaKana(String shaKana) {
        this.shaKana = shaKana;
    }

    /** 
     * Returns the telno.
     * 
     * @return the telno
     */
    public String getTelno() {
        return telno;
    }

    /** 
     * Sets the telno.
     * 
     * @param telno the telno
     */
    public void setTelno(String telno) {
        this.telno = telno;
    }

    /** 
     * Returns the faxno.
     * 
     * @return the faxno
     */
    public String getFaxno() {
        return faxno;
    }

    /** 
     * Sets the faxno.
     * 
     * @param faxno the faxno
     */
    public void setFaxno(String faxno) {
        this.faxno = faxno;
    }

    /** 
     * Returns the yubinNo.
     * 
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /** 
     * Sets the yubinNo.
     * 
     * @param yubinNo the yubinNo
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /** 
     * Returns the shaNm1.
     * 
     * @return the shaNm1
     */
    public String getShaNm1() {
        return shaNm1;
    }

    /** 
     * Sets the shaNm1.
     * 
     * @param shaNm1 the shaNm1
     */
    public void setShaNm1(String shaNm1) {
        this.shaNm1 = shaNm1;
    }

    /** 
     * Returns the shaNm2.
     * 
     * @return the shaNm2
     */
    public String getShaNm2() {
        return shaNm2;
    }

    /** 
     * Sets the shaNm2.
     * 
     * @param shaNm2 the shaNm2
     */
    public void setShaNm2(String shaNm2) {
        this.shaNm2 = shaNm2;
    }

    /** 
     * Returns the adr1.
     * 
     * @return the adr1
     */
    public String getAdr1() {
        return adr1;
    }

    /** 
     * Sets the adr1.
     * 
     * @param adr1 the adr1
     */
    public void setAdr1(String adr1) {
        this.adr1 = adr1;
    }

    /** 
     * Returns the adr2.
     * 
     * @return the adr2
     */
    public String getAdr2() {
        return adr2;
    }

    /** 
     * Sets the adr2.
     * 
     * @param adr2 the adr2
     */
    public void setAdr2(String adr2) {
        this.adr2 = adr2;
    }

    /** 
     * Returns the adr3.
     * 
     * @return the adr3
     */
    public String getAdr3() {
        return adr3;
    }

    /** 
     * Sets the adr3.
     * 
     * @param adr3 the adr3
     */
    public void setAdr3(String adr3) {
        this.adr3 = adr3;
    }

    /** 
     * Returns the bushoNm.
     * 
     * @return the bushoNm
     */
    public String getBushoNm() {
        return bushoNm;
    }

    /** 
     * Sets the bushoNm.
     * 
     * @param bushoNm the bushoNm
     */
    public void setBushoNm(String bushoNm) {
        this.bushoNm = bushoNm;
    }

    /** 
     * Returns the daihyoNm.
     * 
     * @return the daihyoNm
     */
    public String getDaihyoNm() {
        return daihyoNm;
    }

    /** 
     * Sets the daihyoNm.
     * 
     * @param daihyoNm the daihyoNm
     */
    public void setDaihyoNm(String daihyoNm) {
        this.daihyoNm = daihyoNm;
    }

    /** 
     * Returns the kunicd.
     * 
     * @return the kunicd
     */
    public Short getKunicd() {
        return kunicd;
    }

    /** 
     * Sets the kunicd.
     * 
     * @param kunicd the kunicd
     */
    public void setKunicd(Short kunicd) {
        this.kunicd = kunicd;
    }

    /** 
     * Returns the kencd.
     * 
     * @return the kencd
     */
    public Short getKencd() {
        return kencd;
    }

    /** 
     * Sets the kencd.
     * 
     * @param kencd the kencd
     */
    public void setKencd(Short kencd) {
        this.kencd = kencd;
    }

    /** 
     * Returns the shimPortcd.
     * 
     * @return the shimPortcd
     */
    public Short getShimPortcd() {
        return shimPortcd;
    }

    /** 
     * Sets the shimPortcd.
     * 
     * @param shimPortcd the shimPortcd
     */
    public void setShimPortcd(Short shimPortcd) {
        this.shimPortcd = shimPortcd;
    }

    /** 
     * Returns the shimAirportcd.
     * 
     * @return the shimAirportcd
     */
    public Short getShimAirportcd() {
        return shimAirportcd;
    }

    /** 
     * Sets the shimAirportcd.
     * 
     * @param shimAirportcd the shimAirportcd
     */
    public void setShimAirportcd(Short shimAirportcd) {
        this.shimAirportcd = shimAirportcd;
    }

    /** 
     * Returns the yusoKikan.
     * 
     * @return the yusoKikan
     */
    public Short getYusoKikan() {
        return yusoKikan;
    }

    /** 
     * Sets the yusoKikan.
     * 
     * @param yusoKikan the yusoKikan
     */
    public void setYusoKikan(Short yusoKikan) {
        this.yusoKikan = yusoKikan;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Long getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Long hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}