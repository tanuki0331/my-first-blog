package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class PinvReportListener implements EntityListener<PinvReport> {

    @Override
    public void preInsert(PinvReport entity, PreInsertContext<PinvReport> context) {
    }

    @Override
    public void preUpdate(PinvReport entity, PreUpdateContext<PinvReport> context) {
    }

    @Override
    public void preDelete(PinvReport entity, PreDeleteContext<PinvReport> context) {
    }

    @Override
    public void postInsert(PinvReport entity, PostInsertContext<PinvReport> context) {
    }

    @Override
    public void postUpdate(PinvReport entity, PostUpdateContext<PinvReport> context) {
    }

    @Override
    public void postDelete(PinvReport entity, PostDeleteContext<PinvReport> context) {
    }
}