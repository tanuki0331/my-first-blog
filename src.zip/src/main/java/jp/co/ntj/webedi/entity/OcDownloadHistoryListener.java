package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class OcDownloadHistoryListener implements EntityListener<OcDownloadHistory> {

    @Override
    public void preInsert(OcDownloadHistory entity, PreInsertContext<OcDownloadHistory> context) {
    }

    @Override
    public void preUpdate(OcDownloadHistory entity, PreUpdateContext<OcDownloadHistory> context) {
    }

    @Override
    public void preDelete(OcDownloadHistory entity, PreDeleteContext<OcDownloadHistory> context) {
    }

    @Override
    public void postInsert(OcDownloadHistory entity, PostInsertContext<OcDownloadHistory> context) {
    }

    @Override
    public void postUpdate(OcDownloadHistory entity, PostUpdateContext<OcDownloadHistory> context) {
    }

    @Override
    public void postDelete(OcDownloadHistory entity, PostDeleteContext<OcDownloadHistory> context) {
    }
}