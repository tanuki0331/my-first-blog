package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.PinvDownloadHistory;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface PinvDownloadHistoryDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param pinvNumber
     * @return the PinvDownloadHistory entity
     */
    @Select
    PinvDownloadHistory selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String pinvNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(PinvDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(PinvDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(PinvDownloadHistory entity);
}