package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.CustomerUserDlvyMail;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface CustomerUserDlvyMailDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @param sequenceNumber
     * @return the CustomerUserDlvyMail entity
     */
    @Select
    CustomerUserDlvyMail selectById(String kaisyaCd, String gengoKbn, Long customerUserId, Short sequenceNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(CustomerUserDlvyMail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(CustomerUserDlvyMail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(CustomerUserDlvyMail entity);
}