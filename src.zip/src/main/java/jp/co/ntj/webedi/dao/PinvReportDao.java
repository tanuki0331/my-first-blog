package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.PinvReport;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface PinvReportDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param pinvNumber
     * @return the PinvReport entity
     */
    @Select
    PinvReport selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String pinvNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(PinvReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(PinvReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(PinvReport entity);
}