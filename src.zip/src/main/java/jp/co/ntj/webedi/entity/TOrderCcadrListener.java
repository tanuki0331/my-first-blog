package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class TOrderCcadrListener implements EntityListener<TOrderCcadr> {

    @Override
    public void preInsert(TOrderCcadr entity, PreInsertContext<TOrderCcadr> context) {
    }

    @Override
    public void preUpdate(TOrderCcadr entity, PreUpdateContext<TOrderCcadr> context) {
    }

    @Override
    public void preDelete(TOrderCcadr entity, PreDeleteContext<TOrderCcadr> context) {
    }

    @Override
    public void postInsert(TOrderCcadr entity, PostInsertContext<TOrderCcadr> context) {
    }

    @Override
    public void postUpdate(TOrderCcadr entity, PostUpdateContext<TOrderCcadr> context) {
    }

    @Override
    public void postDelete(TOrderCcadr entity, PostDeleteContext<TOrderCcadr> context) {
    }
}