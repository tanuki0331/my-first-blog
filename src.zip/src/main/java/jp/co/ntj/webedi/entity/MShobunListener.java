package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MShobunListener implements EntityListener<MShobun> {

    @Override
    public void preInsert(MShobun entity, PreInsertContext<MShobun> context) {
    }

    @Override
    public void preUpdate(MShobun entity, PreUpdateContext<MShobun> context) {
    }

    @Override
    public void preDelete(MShobun entity, PreDeleteContext<MShobun> context) {
    }

    @Override
    public void postInsert(MShobun entity, PostInsertContext<MShobun> context) {
    }

    @Override
    public void postUpdate(MShobun entity, PostUpdateContext<MShobun> context) {
    }

    @Override
    public void postDelete(MShobun entity, PostDeleteContext<MShobun> context) {
    }
}