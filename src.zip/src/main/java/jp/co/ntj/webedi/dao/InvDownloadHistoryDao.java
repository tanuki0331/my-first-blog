package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.InvDownloadHistory;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface InvDownloadHistoryDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param invNumber
     * @return the InvDownloadHistory entity
     */
    @Select
    InvDownloadHistory selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String invNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(InvDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(InvDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(InvDownloadHistory entity);
}