package jp.co.ntj.webedi.entity;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 注文データマッピング
 */
@Entity(listener = OrderDataMappingListener.class)
@Table(name = "ORDER_DATA_MAPPING")
public class OrderDataMapping {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 得意先コード */
    @Id
    @Column(name = "CUSTOMER_CODE")
    Long customerCode;

    /** 商品コード種別 */
    @Column(name = "PRODUCT_CODE_CATEGORY")
    Short productCodeCategory;

    /** ファイル形式 */
    @Column(name = "FILE_CATEGORY")
    Short fileCategory;

    /** 日付フォーマット */
    @Column(name = "DATE_FORMAT")
    String dateFormat;

    /** 商品コード：開始桁/列番号 */
    @Column(name = "PRODUCT_CODE_POSITION")
    Short productCodePosition;

    /** 商品コード：データ長 */
    @Column(name = "PRODUCT_CODE_LENGTH")
    Short productCodeLength;

    /** 入目：開始桁/列番号 */
    @Column(name = "EXPENDITURE_POSITION")
    Short expenditurePosition;

    /** 入目：データ長 */
    @Column(name = "EXPENDITURE_LENGTH")
    Short expenditureLength;

    /** 個数：開始桁/列番号 */
    @Column(name = "QUANTITY_POSITION")
    Short quantityPosition;

    /** 個数：データ長 */
    @Column(name = "QUANTITY_LENGTH")
    Short quantityLength;

    /** 希望納期：開始桁/列番号 */
    @Column(name = "DESIRED_DLVY_DATE_POSITION")
    Short desiredDlvyDatePosition;

    /** 希望納期：データ長 */
    @Column(name = "DESIRED_DLVY_DATE_LENGTH")
    Short desiredDlvyDateLength;

    /** P/O No.：開始桁/列番号 */
    @Column(name = "PURCHASE_ORDER_POSITION")
    Short purchaseOrderPosition;

    /** P/O No.：データ長 */
    @Column(name = "PURCHASE_ORDER_LENGTH")
    Short purchaseOrderLength;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the customerCode.
     * 
     * @return the customerCode
     */
    public Long getCustomerCode() {
        return customerCode;
    }

    /** 
     * Sets the customerCode.
     * 
     * @param customerCode the customerCode
     */
    public void setCustomerCode(Long customerCode) {
        this.customerCode = customerCode;
    }

    /** 
     * Returns the productCodeCategory.
     * 
     * @return the productCodeCategory
     */
    public Short getProductCodeCategory() {
        return productCodeCategory;
    }

    /** 
     * Sets the productCodeCategory.
     * 
     * @param productCodeCategory the productCodeCategory
     */
    public void setProductCodeCategory(Short productCodeCategory) {
        this.productCodeCategory = productCodeCategory;
    }

    /** 
     * Returns the fileCategory.
     * 
     * @return the fileCategory
     */
    public Short getFileCategory() {
        return fileCategory;
    }

    /** 
     * Sets the fileCategory.
     * 
     * @param fileCategory the fileCategory
     */
    public void setFileCategory(Short fileCategory) {
        this.fileCategory = fileCategory;
    }

    /** 
     * Returns the dateFormat.
     * 
     * @return the dateFormat
     */
    public String getDateFormat() {
        return dateFormat;
    }

    /** 
     * Sets the dateFormat.
     * 
     * @param dateFormat the dateFormat
     */
    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    /** 
     * Returns the productCodePosition.
     * 
     * @return the productCodePosition
     */
    public Short getProductCodePosition() {
        return productCodePosition;
    }

    /** 
     * Sets the productCodePosition.
     * 
     * @param productCodePosition the productCodePosition
     */
    public void setProductCodePosition(Short productCodePosition) {
        this.productCodePosition = productCodePosition;
    }

    /** 
     * Returns the productCodeLength.
     * 
     * @return the productCodeLength
     */
    public Short getProductCodeLength() {
        return productCodeLength;
    }

    /** 
     * Sets the productCodeLength.
     * 
     * @param productCodeLength the productCodeLength
     */
    public void setProductCodeLength(Short productCodeLength) {
        this.productCodeLength = productCodeLength;
    }

    /** 
     * Returns the expenditurePosition.
     * 
     * @return the expenditurePosition
     */
    public Short getExpenditurePosition() {
        return expenditurePosition;
    }

    /** 
     * Sets the expenditurePosition.
     * 
     * @param expenditurePosition the expenditurePosition
     */
    public void setExpenditurePosition(Short expenditurePosition) {
        this.expenditurePosition = expenditurePosition;
    }

    /** 
     * Returns the expenditureLength.
     * 
     * @return the expenditureLength
     */
    public Short getExpenditureLength() {
        return expenditureLength;
    }

    /** 
     * Sets the expenditureLength.
     * 
     * @param expenditureLength the expenditureLength
     */
    public void setExpenditureLength(Short expenditureLength) {
        this.expenditureLength = expenditureLength;
    }

    /** 
     * Returns the quantityPosition.
     * 
     * @return the quantityPosition
     */
    public Short getQuantityPosition() {
        return quantityPosition;
    }

    /** 
     * Sets the quantityPosition.
     * 
     * @param quantityPosition the quantityPosition
     */
    public void setQuantityPosition(Short quantityPosition) {
        this.quantityPosition = quantityPosition;
    }

    /** 
     * Returns the quantityLength.
     * 
     * @return the quantityLength
     */
    public Short getQuantityLength() {
        return quantityLength;
    }

    /** 
     * Sets the quantityLength.
     * 
     * @param quantityLength the quantityLength
     */
    public void setQuantityLength(Short quantityLength) {
        this.quantityLength = quantityLength;
    }

    /** 
     * Returns the desiredDlvyDatePosition.
     * 
     * @return the desiredDlvyDatePosition
     */
    public Short getDesiredDlvyDatePosition() {
        return desiredDlvyDatePosition;
    }

    /** 
     * Sets the desiredDlvyDatePosition.
     * 
     * @param desiredDlvyDatePosition the desiredDlvyDatePosition
     */
    public void setDesiredDlvyDatePosition(Short desiredDlvyDatePosition) {
        this.desiredDlvyDatePosition = desiredDlvyDatePosition;
    }

    /** 
     * Returns the desiredDlvyDateLength.
     * 
     * @return the desiredDlvyDateLength
     */
    public Short getDesiredDlvyDateLength() {
        return desiredDlvyDateLength;
    }

    /** 
     * Sets the desiredDlvyDateLength.
     * 
     * @param desiredDlvyDateLength the desiredDlvyDateLength
     */
    public void setDesiredDlvyDateLength(Short desiredDlvyDateLength) {
        this.desiredDlvyDateLength = desiredDlvyDateLength;
    }

    /** 
     * Returns the purchaseOrderPosition.
     * 
     * @return the purchaseOrderPosition
     */
    public Short getPurchaseOrderPosition() {
        return purchaseOrderPosition;
    }

    /** 
     * Sets the purchaseOrderPosition.
     * 
     * @param purchaseOrderPosition the purchaseOrderPosition
     */
    public void setPurchaseOrderPosition(Short purchaseOrderPosition) {
        this.purchaseOrderPosition = purchaseOrderPosition;
    }

    /** 
     * Returns the purchaseOrderLength.
     * 
     * @return the purchaseOrderLength
     */
    public Short getPurchaseOrderLength() {
        return purchaseOrderLength;
    }

    /** 
     * Sets the purchaseOrderLength.
     * 
     * @param purchaseOrderLength the purchaseOrderLength
     */
    public void setPurchaseOrderLength(Short purchaseOrderLength) {
        this.purchaseOrderLength = purchaseOrderLength;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}