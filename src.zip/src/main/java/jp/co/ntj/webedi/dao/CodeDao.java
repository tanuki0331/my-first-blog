package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.Code;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface CodeDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param codeCategory
     * @param code
     * @return the Code entity
     */
    @Select
    Code selectById(String kaisyaCd, String gengoKbn, String codeCategory, String code);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(Code entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(Code entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(Code entity);
}