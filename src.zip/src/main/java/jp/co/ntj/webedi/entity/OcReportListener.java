package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class OcReportListener implements EntityListener<OcReport> {

    @Override
    public void preInsert(OcReport entity, PreInsertContext<OcReport> context) {
    }

    @Override
    public void preUpdate(OcReport entity, PreUpdateContext<OcReport> context) {
    }

    @Override
    public void preDelete(OcReport entity, PreDeleteContext<OcReport> context) {
    }

    @Override
    public void postInsert(OcReport entity, PostInsertContext<OcReport> context) {
    }

    @Override
    public void postUpdate(OcReport entity, PostUpdateContext<OcReport> context) {
    }

    @Override
    public void postDelete(OcReport entity, PostDeleteContext<OcReport> context) {
    }
}