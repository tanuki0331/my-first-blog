package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MMeishoListener implements EntityListener<MMeisho> {

    @Override
    public void preInsert(MMeisho entity, PreInsertContext<MMeisho> context) {
    }

    @Override
    public void preUpdate(MMeisho entity, PreUpdateContext<MMeisho> context) {
    }

    @Override
    public void preDelete(MMeisho entity, PreDeleteContext<MMeisho> context) {
    }

    @Override
    public void postInsert(MMeisho entity, PostInsertContext<MMeisho> context) {
    }

    @Override
    public void postUpdate(MMeisho entity, PostUpdateContext<MMeisho> context) {
    }

    @Override
    public void postDelete(MMeisho entity, PostDeleteContext<MMeisho> context) {
    }
}