package jp.co.ntj.webedi.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 建値マスタ
 */
@Entity(listener = MTateneListener.class)
@Table(name = "M_TATENE")
public class MTatene {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 建値コード */
    @Id
    @Column(name = "TATENECD")
    String tatenecd;

    /** 建値略名 */
    @Column(name = "TATENE_RYAK")
    String tateneRyak;

    /** 建値名 */
    @Column(name = "TATENE_NM")
    String tateneNm;

    /** 見積レート */
    @Column(name = "MIT_RATE")
    BigDecimal mitRate;

    /** 船積用円換算基準値 */
    @Column(name = "SHIP_EN_KIJYUN")
    BigDecimal shipEnKijyun;

    /** 船積用円換算レート */
    @Column(name = "SHIP_EN_RATE")
    BigDecimal shipEnRate;

    /** 船積用ＵＳ換算基準値 */
    @Column(name = "SHIP_US_KIJYUN")
    BigDecimal shipUsKijyun;

    /** 船積用ＵＳ換算レート */
    @Column(name = "SHIP_US_RATE")
    BigDecimal shipUsRate;

    /** 丸め桁数 */
    @Column(name = "MARUME_KETA")
    Integer marumeKeta;

    /** 丸め方法 */
    @Column(name = "HASU_KBN")
    Short hasuKbn;

    /** 単位名１ */
    @Column(name = "TANI_NM1")
    String taniNm1;

    /** 単位名２ */
    @Column(name = "TANI_NM2")
    String taniNm2;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Integer hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the tatenecd.
     * 
     * @return the tatenecd
     */
    public String getTatenecd() {
        return tatenecd;
    }

    /** 
     * Sets the tatenecd.
     * 
     * @param tatenecd the tatenecd
     */
    public void setTatenecd(String tatenecd) {
        this.tatenecd = tatenecd;
    }

    /** 
     * Returns the tateneRyak.
     * 
     * @return the tateneRyak
     */
    public String getTateneRyak() {
        return tateneRyak;
    }

    /** 
     * Sets the tateneRyak.
     * 
     * @param tateneRyak the tateneRyak
     */
    public void setTateneRyak(String tateneRyak) {
        this.tateneRyak = tateneRyak;
    }

    /** 
     * Returns the tateneNm.
     * 
     * @return the tateneNm
     */
    public String getTateneNm() {
        return tateneNm;
    }

    /** 
     * Sets the tateneNm.
     * 
     * @param tateneNm the tateneNm
     */
    public void setTateneNm(String tateneNm) {
        this.tateneNm = tateneNm;
    }

    /** 
     * Returns the mitRate.
     * 
     * @return the mitRate
     */
    public BigDecimal getMitRate() {
        return mitRate;
    }

    /** 
     * Sets the mitRate.
     * 
     * @param mitRate the mitRate
     */
    public void setMitRate(BigDecimal mitRate) {
        this.mitRate = mitRate;
    }

    /** 
     * Returns the shipEnKijyun.
     * 
     * @return the shipEnKijyun
     */
    public BigDecimal getShipEnKijyun() {
        return shipEnKijyun;
    }

    /** 
     * Sets the shipEnKijyun.
     * 
     * @param shipEnKijyun the shipEnKijyun
     */
    public void setShipEnKijyun(BigDecimal shipEnKijyun) {
        this.shipEnKijyun = shipEnKijyun;
    }

    /** 
     * Returns the shipEnRate.
     * 
     * @return the shipEnRate
     */
    public BigDecimal getShipEnRate() {
        return shipEnRate;
    }

    /** 
     * Sets the shipEnRate.
     * 
     * @param shipEnRate the shipEnRate
     */
    public void setShipEnRate(BigDecimal shipEnRate) {
        this.shipEnRate = shipEnRate;
    }

    /** 
     * Returns the shipUsKijyun.
     * 
     * @return the shipUsKijyun
     */
    public BigDecimal getShipUsKijyun() {
        return shipUsKijyun;
    }

    /** 
     * Sets the shipUsKijyun.
     * 
     * @param shipUsKijyun the shipUsKijyun
     */
    public void setShipUsKijyun(BigDecimal shipUsKijyun) {
        this.shipUsKijyun = shipUsKijyun;
    }

    /** 
     * Returns the shipUsRate.
     * 
     * @return the shipUsRate
     */
    public BigDecimal getShipUsRate() {
        return shipUsRate;
    }

    /** 
     * Sets the shipUsRate.
     * 
     * @param shipUsRate the shipUsRate
     */
    public void setShipUsRate(BigDecimal shipUsRate) {
        this.shipUsRate = shipUsRate;
    }

    /** 
     * Returns the marumeKeta.
     * 
     * @return the marumeKeta
     */
    public Integer getMarumeKeta() {
        return marumeKeta;
    }

    /** 
     * Sets the marumeKeta.
     * 
     * @param marumeKeta the marumeKeta
     */
    public void setMarumeKeta(Integer marumeKeta) {
        this.marumeKeta = marumeKeta;
    }

    /** 
     * Returns the hasuKbn.
     * 
     * @return the hasuKbn
     */
    public Short getHasuKbn() {
        return hasuKbn;
    }

    /** 
     * Sets the hasuKbn.
     * 
     * @param hasuKbn the hasuKbn
     */
    public void setHasuKbn(Short hasuKbn) {
        this.hasuKbn = hasuKbn;
    }

    /** 
     * Returns the taniNm1.
     * 
     * @return the taniNm1
     */
    public String getTaniNm1() {
        return taniNm1;
    }

    /** 
     * Sets the taniNm1.
     * 
     * @param taniNm1 the taniNm1
     */
    public void setTaniNm1(String taniNm1) {
        this.taniNm1 = taniNm1;
    }

    /** 
     * Returns the taniNm2.
     * 
     * @return the taniNm2
     */
    public String getTaniNm2() {
        return taniNm2;
    }

    /** 
     * Sets the taniNm2.
     * 
     * @param taniNm2 the taniNm2
     */
    public void setTaniNm2(String taniNm2) {
        this.taniNm2 = taniNm2;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Integer getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Integer hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}