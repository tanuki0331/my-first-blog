package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.SearchCondition;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface SearchConditionDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @return the SearchCondition entity
     */
    @Select
    SearchCondition selectById(String kaisyaCd, String gengoKbn, Long customerUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(SearchCondition entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(SearchCondition entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(SearchCondition entity);
}