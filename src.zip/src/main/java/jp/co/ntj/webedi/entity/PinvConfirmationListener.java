package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class PinvConfirmationListener implements EntityListener<PinvConfirmation> {

    @Override
    public void preInsert(PinvConfirmation entity, PreInsertContext<PinvConfirmation> context) {
    }

    @Override
    public void preUpdate(PinvConfirmation entity, PreUpdateContext<PinvConfirmation> context) {
    }

    @Override
    public void preDelete(PinvConfirmation entity, PreDeleteContext<PinvConfirmation> context) {
    }

    @Override
    public void postInsert(PinvConfirmation entity, PostInsertContext<PinvConfirmation> context) {
    }

    @Override
    public void postUpdate(PinvConfirmation entity, PostUpdateContext<PinvConfirmation> context) {
    }

    @Override
    public void postDelete(PinvConfirmation entity, PostDeleteContext<PinvConfirmation> context) {
    }
}