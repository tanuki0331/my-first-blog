package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class InvDownloadHistoryListener implements EntityListener<InvDownloadHistory> {

    @Override
    public void preInsert(InvDownloadHistory entity, PreInsertContext<InvDownloadHistory> context) {
    }

    @Override
    public void preUpdate(InvDownloadHistory entity, PreUpdateContext<InvDownloadHistory> context) {
    }

    @Override
    public void preDelete(InvDownloadHistory entity, PreDeleteContext<InvDownloadHistory> context) {
    }

    @Override
    public void postInsert(InvDownloadHistory entity, PostInsertContext<InvDownloadHistory> context) {
    }

    @Override
    public void postUpdate(InvDownloadHistory entity, PostUpdateContext<InvDownloadHistory> context) {
    }

    @Override
    public void postDelete(InvDownloadHistory entity, PostDeleteContext<InvDownloadHistory> context) {
    }
}