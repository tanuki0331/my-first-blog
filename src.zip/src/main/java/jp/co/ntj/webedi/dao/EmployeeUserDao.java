package jp.co.ntj.webedi.dao;

import java.math.BigDecimal;
import java.util.List;

import jp.co.ntj.webedi.entity.EmployeeUser;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 */
@ConfigAutowireable
@Dao
public interface EmployeeUserDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param id
     * @return the EmployeeUser entity
     */
    @Select
    EmployeeUser selectById(String kaisyaCd, String gengoKbn, BigDecimal id);

    /**
     * OC帳票の出荷先コードを元に最終仕向先の出荷先のユーザーを取得する。
     *
     * @param destinationCode
     * @return the EmployeeUser entity list
     */
    @Select
    List<EmployeeUser> selectLShimuByDestCd(Long destinationCode);

    /**
     * OC帳票の出荷先コードを元に仕向先の出荷先のユーザーを取得する。
     *
     * @param destinationCode
     * @return the EmployeeUser entity list
     */
    @Select
    List<EmployeeUser> selectShimuByDestCd(Long destinationCode);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(EmployeeUser entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(EmployeeUser entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(EmployeeUser entity);
}