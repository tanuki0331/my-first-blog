package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MLshimuListener implements EntityListener<MLshimu> {

    @Override
    public void preInsert(MLshimu entity, PreInsertContext<MLshimu> context) {
    }

    @Override
    public void preUpdate(MLshimu entity, PreUpdateContext<MLshimu> context) {
    }

    @Override
    public void preDelete(MLshimu entity, PreDeleteContext<MLshimu> context) {
    }

    @Override
    public void postInsert(MLshimu entity, PostInsertContext<MLshimu> context) {
    }

    @Override
    public void postUpdate(MLshimu entity, PostUpdateContext<MLshimu> context) {
    }

    @Override
    public void postDelete(MLshimu entity, PostDeleteContext<MLshimu> context) {
    }
}