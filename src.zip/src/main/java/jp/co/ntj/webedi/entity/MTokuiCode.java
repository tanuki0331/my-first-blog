package jp.co.ntj.webedi.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 顧客側品目コードマスタ
 */
@Entity(listener = MTokuiCodeListener.class)
@Table(name = "M_TOKUI_CODE")
public class MTokuiCode {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 得意先コード */
    @Id
    @Column(name = "TOKUCD")
    Long tokucd;

    /** 仕向先コード */
    @Id
    @Column(name = "SHIMUKECD")
    Long shimukecd;

    /** 顧客側品目コード */
    @Id
    @Column(name = "TOKU_HINMOKU_CD")
    String tokuHinmokuCd;

    /** 入目重量 */
    @Id
    @Column(name = "IRIME_JURYO")
    BigDecimal irimeJuryo;

    /** 商品コード */
    @Column(name = "SHOHINCD")
    String shohincd;

    /** 建値コード */
    @Column(name = "TATENECD")
    String tatenecd;

    /** 英語商品名 */
    @Column(name = "SHOHIN_NM")
    String shohinNm;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the tokucd.
     * 
     * @return the tokucd
     */
    public Long getTokucd() {
        return tokucd;
    }

    /** 
     * Sets the tokucd.
     * 
     * @param tokucd the tokucd
     */
    public void setTokucd(Long tokucd) {
        this.tokucd = tokucd;
    }

    /** 
     * Returns the shimukecd.
     * 
     * @return the shimukecd
     */
    public Long getShimukecd() {
        return shimukecd;
    }

    /** 
     * Sets the shimukecd.
     * 
     * @param shimukecd the shimukecd
     */
    public void setShimukecd(Long shimukecd) {
        this.shimukecd = shimukecd;
    }

    /** 
     * Returns the tokuHinmokuCd.
     * 
     * @return the tokuHinmokuCd
     */
    public String getTokuHinmokuCd() {
        return tokuHinmokuCd;
    }

    /** 
     * Sets the tokuHinmokuCd.
     * 
     * @param tokuHinmokuCd the tokuHinmokuCd
     */
    public void setTokuHinmokuCd(String tokuHinmokuCd) {
        this.tokuHinmokuCd = tokuHinmokuCd;
    }

    /** 
     * Returns the irimeJuryo.
     * 
     * @return the irimeJuryo
     */
    public BigDecimal getIrimeJuryo() {
        return irimeJuryo;
    }

    /** 
     * Sets the irimeJuryo.
     * 
     * @param irimeJuryo the irimeJuryo
     */
    public void setIrimeJuryo(BigDecimal irimeJuryo) {
        this.irimeJuryo = irimeJuryo;
    }

    /** 
     * Returns the shohincd.
     * 
     * @return the shohincd
     */
    public String getShohincd() {
        return shohincd;
    }

    /** 
     * Sets the shohincd.
     * 
     * @param shohincd the shohincd
     */
    public void setShohincd(String shohincd) {
        this.shohincd = shohincd;
    }

    /** 
     * Returns the tatenecd.
     * 
     * @return the tatenecd
     */
    public String getTatenecd() {
        return tatenecd;
    }

    /** 
     * Sets the tatenecd.
     * 
     * @param tatenecd the tatenecd
     */
    public void setTatenecd(String tatenecd) {
        this.tatenecd = tatenecd;
    }

    /** 
     * Returns the shohinNm.
     * 
     * @return the shohinNm
     */
    public String getShohinNm() {
        return shohinNm;
    }

    /** 
     * Sets the shohinNm.
     * 
     * @param shohinNm the shohinNm
     */
    public void setShohinNm(String shohinNm) {
        this.shohinNm = shohinNm;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}