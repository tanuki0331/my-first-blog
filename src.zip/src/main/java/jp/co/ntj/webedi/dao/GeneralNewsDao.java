package jp.co.ntj.webedi.dao;

import java.math.BigDecimal;
import jp.co.ntj.webedi.entity.GeneralNews;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface GeneralNewsDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param id
     * @return the GeneralNews entity
     */
    @Select
    GeneralNews selectById(String kaisyaCd, String gengoKbn, BigDecimal id);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(GeneralNews entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(GeneralNews entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(GeneralNews entity);
}