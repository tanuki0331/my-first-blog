package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class CustomerUserAuthorityListener implements EntityListener<CustomerUserAuthority> {

    @Override
    public void preInsert(CustomerUserAuthority entity, PreInsertContext<CustomerUserAuthority> context) {
    }

    @Override
    public void preUpdate(CustomerUserAuthority entity, PreUpdateContext<CustomerUserAuthority> context) {
    }

    @Override
    public void preDelete(CustomerUserAuthority entity, PreDeleteContext<CustomerUserAuthority> context) {
    }

    @Override
    public void postInsert(CustomerUserAuthority entity, PostInsertContext<CustomerUserAuthority> context) {
    }

    @Override
    public void postUpdate(CustomerUserAuthority entity, PostUpdateContext<CustomerUserAuthority> context) {
    }

    @Override
    public void postDelete(CustomerUserAuthority entity, PostDeleteContext<CustomerUserAuthority> context) {
    }
}