package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class EmployeeUserAuthorityListener implements EntityListener<EmployeeUserAuthority> {

    @Override
    public void preInsert(EmployeeUserAuthority entity, PreInsertContext<EmployeeUserAuthority> context) {
    }

    @Override
    public void preUpdate(EmployeeUserAuthority entity, PreUpdateContext<EmployeeUserAuthority> context) {
    }

    @Override
    public void preDelete(EmployeeUserAuthority entity, PreDeleteContext<EmployeeUserAuthority> context) {
    }

    @Override
    public void postInsert(EmployeeUserAuthority entity, PostInsertContext<EmployeeUserAuthority> context) {
    }

    @Override
    public void postUpdate(EmployeeUserAuthority entity, PostUpdateContext<EmployeeUserAuthority> context) {
    }

    @Override
    public void postDelete(EmployeeUserAuthority entity, PostDeleteContext<EmployeeUserAuthority> context) {
    }
}