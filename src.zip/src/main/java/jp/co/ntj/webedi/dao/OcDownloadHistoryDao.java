package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.OcDownloadHistory;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface OcDownloadHistoryDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param ocNumber
     * @return the OcDownloadHistory entity
     */
    @Select
    OcDownloadHistory selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String ocNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(OcDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(OcDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(OcDownloadHistory entity);
}