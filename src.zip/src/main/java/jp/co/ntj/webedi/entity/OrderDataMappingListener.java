package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class OrderDataMappingListener implements EntityListener<OrderDataMapping> {

    @Override
    public void preInsert(OrderDataMapping entity, PreInsertContext<OrderDataMapping> context) {
    }

    @Override
    public void preUpdate(OrderDataMapping entity, PreUpdateContext<OrderDataMapping> context) {
    }

    @Override
    public void preDelete(OrderDataMapping entity, PreDeleteContext<OrderDataMapping> context) {
    }

    @Override
    public void postInsert(OrderDataMapping entity, PostInsertContext<OrderDataMapping> context) {
    }

    @Override
    public void postUpdate(OrderDataMapping entity, PostUpdateContext<OrderDataMapping> context) {
    }

    @Override
    public void postDelete(OrderDataMapping entity, PostDeleteContext<OrderDataMapping> context) {
    }
}