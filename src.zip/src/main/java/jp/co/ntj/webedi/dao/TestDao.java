package jp.co.ntj.webedi.dao;

import java.math.BigDecimal;
import jp.co.ntj.webedi.entity.Test;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface TestDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param id
     * @return the Test entity
     */
    @Select
    Test selectById(String kaisyaCd, String gengoKbn, BigDecimal id);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(Test entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(Test entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(Test entity);
}