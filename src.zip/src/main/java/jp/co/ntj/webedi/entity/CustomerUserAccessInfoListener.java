package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class CustomerUserAccessInfoListener implements EntityListener<CustomerUserAccessInfo> {

    @Override
    public void preInsert(CustomerUserAccessInfo entity, PreInsertContext<CustomerUserAccessInfo> context) {
    }

    @Override
    public void preUpdate(CustomerUserAccessInfo entity, PreUpdateContext<CustomerUserAccessInfo> context) {
    }

    @Override
    public void preDelete(CustomerUserAccessInfo entity, PreDeleteContext<CustomerUserAccessInfo> context) {
    }

    @Override
    public void postInsert(CustomerUserAccessInfo entity, PostInsertContext<CustomerUserAccessInfo> context) {
    }

    @Override
    public void postUpdate(CustomerUserAccessInfo entity, PostUpdateContext<CustomerUserAccessInfo> context) {
    }

    @Override
    public void postDelete(CustomerUserAccessInfo entity, PostDeleteContext<CustomerUserAccessInfo> context) {
    }
}