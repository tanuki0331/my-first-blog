package jp.co.ntj.webedi.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * プライスリスト情報
 */
@Entity(listener = MPlistListener.class)
@Table(name = "M_PLIST")
public class MPlist {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 得意先コード */
    @Id
    @Column(name = "TOKUCD")
    Long tokucd;

    /** 仕向先コード */
    @Id
    @Column(name = "SHIMUKECD")
    Long shimukecd;

    /** 商品コード */
    @Id
    @Column(name = "SHOHINCD")
    String shohincd;

    /** 商品略名コード */
    @Column(name = "SHOHIN_RYAK_CD")
    String shohinRyakCd;

    /** 英語商品名 */
    @Column(name = "SHOHIN_NM")
    String shohinNm;

    /** 建値コード */
    @Column(name = "TATENECD")
    String tatenecd;

    /** 売単価 */
    @Column(name = "SELL_TANKA")
    BigDecimal sellTanka;

    /** 入目売単価－ＫＧ売単価 */
    @Column(name = "IRIME_SELL_TANKA")
    BigDecimal irimeSellTanka;

    /** 単価使用開始日 */
    @Column(name = "TANKA_SIYO_STRDATE")
    String tankaSiyoStrdate;

    /** 単価改定番号 */
    @Column(name = "TAN_KAITEI_NO")
    Integer tanKaiteiNo;

    /** 仕向先社名１ */
    @Column(name = "SHIMUKE_NM1")
    String shimukeNm1;

    /** 仕向先社名２ */
    @Column(name = "SHIMUKE_NM2")
    String shimukeNm2;

    /** 商品分類－大分類コード */
    @Column(name = "LAG_BUNCD")
    String lagBuncd;

    /** 商品分類－中分類コード */
    @Column(name = "MID_BUNCD")
    String midBuncd;

    /** 商品分類－小分類コード１ */
    @Column(name = "SML_BUNCD1")
    String smlBuncd1;

    /** 仕向先標準価格条件コード */
    @Column(name = "SHIMUKE_HYJN_KEI_JYOKENCD")
    Short shimukeHyjnKeiJyokencd;

    /** 契約条件名 */
    @Column(name = "KEI_JYOKEN_NM")
    String keiJyokenNm;

    /** 建値名 */
    @Column(name = "TATENE_NM")
    String tateneNm;

    /** 入目重量 */
    @Column(name = "IRIME_JURYO")
    BigDecimal irimeJuryo;

    /** 入目単位コード */
    @Column(name = "IRIME_TANICD")
    Short irimeTanicd;

    /** 入目単位名 */
    @Column(name = "IRIME_TANI_NM")
    String irimeTaniNm;

    /** 梱包単位コード */
    @Column(name = "KONPO_TANI_CD")
    String konpoTaniCd;

    /** 梱包単位名 */
    @Column(name = "KONPO_TANI_NM")
    String konpoTaniNm;

    /** ユニット単価 */
    @Column(name = "UNIT_TANKA")
    BigDecimal unitTanka;

    /** ユニット単位コード */
    @Column(name = "UNIT_TANICD")
    Short unitTanicd;

    /** ユニット単位名 */
    @Column(name = "UNIT_TANI_NM")
    String unitTaniNm;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Long hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 仕入期間 */
    @Column(name = "SIIRE_KIKAN")
    Short siireKikan;

    /** 輸送方法コード */
    @Id
    @Column(name = "YUSO_HOHOCD")
    Short yusoHohocd;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the tokucd.
     * 
     * @return the tokucd
     */
    public Long getTokucd() {
        return tokucd;
    }

    /** 
     * Sets the tokucd.
     * 
     * @param tokucd the tokucd
     */
    public void setTokucd(Long tokucd) {
        this.tokucd = tokucd;
    }

    /** 
     * Returns the shimukecd.
     * 
     * @return the shimukecd
     */
    public Long getShimukecd() {
        return shimukecd;
    }

    /** 
     * Sets the shimukecd.
     * 
     * @param shimukecd the shimukecd
     */
    public void setShimukecd(Long shimukecd) {
        this.shimukecd = shimukecd;
    }

    /** 
     * Returns the shohincd.
     * 
     * @return the shohincd
     */
    public String getShohincd() {
        return shohincd;
    }

    /** 
     * Sets the shohincd.
     * 
     * @param shohincd the shohincd
     */
    public void setShohincd(String shohincd) {
        this.shohincd = shohincd;
    }

    /** 
     * Returns the shohinRyakCd.
     * 
     * @return the shohinRyakCd
     */
    public String getShohinRyakCd() {
        return shohinRyakCd;
    }

    /** 
     * Sets the shohinRyakCd.
     * 
     * @param shohinRyakCd the shohinRyakCd
     */
    public void setShohinRyakCd(String shohinRyakCd) {
        this.shohinRyakCd = shohinRyakCd;
    }

    /** 
     * Returns the shohinNm.
     * 
     * @return the shohinNm
     */
    public String getShohinNm() {
        return shohinNm;
    }

    /** 
     * Sets the shohinNm.
     * 
     * @param shohinNm the shohinNm
     */
    public void setShohinNm(String shohinNm) {
        this.shohinNm = shohinNm;
    }

    /** 
     * Returns the tatenecd.
     * 
     * @return the tatenecd
     */
    public String getTatenecd() {
        return tatenecd;
    }

    /** 
     * Sets the tatenecd.
     * 
     * @param tatenecd the tatenecd
     */
    public void setTatenecd(String tatenecd) {
        this.tatenecd = tatenecd;
    }

    /** 
     * Returns the sellTanka.
     * 
     * @return the sellTanka
     */
    public BigDecimal getSellTanka() {
        return sellTanka;
    }

    /** 
     * Sets the sellTanka.
     * 
     * @param sellTanka the sellTanka
     */
    public void setSellTanka(BigDecimal sellTanka) {
        this.sellTanka = sellTanka;
    }

    /** 
     * Returns the irimeSellTanka.
     * 
     * @return the irimeSellTanka
     */
    public BigDecimal getIrimeSellTanka() {
        return irimeSellTanka;
    }

    /** 
     * Sets the irimeSellTanka.
     * 
     * @param irimeSellTanka the irimeSellTanka
     */
    public void setIrimeSellTanka(BigDecimal irimeSellTanka) {
        this.irimeSellTanka = irimeSellTanka;
    }

    /** 
     * Returns the tankaSiyoStrdate.
     * 
     * @return the tankaSiyoStrdate
     */
    public String getTankaSiyoStrdate() {
        return tankaSiyoStrdate;
    }

    /** 
     * Sets the tankaSiyoStrdate.
     * 
     * @param tankaSiyoStrdate the tankaSiyoStrdate
     */
    public void setTankaSiyoStrdate(String tankaSiyoStrdate) {
        this.tankaSiyoStrdate = tankaSiyoStrdate;
    }

    /** 
     * Returns the tanKaiteiNo.
     * 
     * @return the tanKaiteiNo
     */
    public Integer getTanKaiteiNo() {
        return tanKaiteiNo;
    }

    /** 
     * Sets the tanKaiteiNo.
     * 
     * @param tanKaiteiNo the tanKaiteiNo
     */
    public void setTanKaiteiNo(Integer tanKaiteiNo) {
        this.tanKaiteiNo = tanKaiteiNo;
    }

    /** 
     * Returns the shimukeNm1.
     * 
     * @return the shimukeNm1
     */
    public String getShimukeNm1() {
        return shimukeNm1;
    }

    /** 
     * Sets the shimukeNm1.
     * 
     * @param shimukeNm1 the shimukeNm1
     */
    public void setShimukeNm1(String shimukeNm1) {
        this.shimukeNm1 = shimukeNm1;
    }

    /** 
     * Returns the shimukeNm2.
     * 
     * @return the shimukeNm2
     */
    public String getShimukeNm2() {
        return shimukeNm2;
    }

    /** 
     * Sets the shimukeNm2.
     * 
     * @param shimukeNm2 the shimukeNm2
     */
    public void setShimukeNm2(String shimukeNm2) {
        this.shimukeNm2 = shimukeNm2;
    }

    /** 
     * Returns the lagBuncd.
     * 
     * @return the lagBuncd
     */
    public String getLagBuncd() {
        return lagBuncd;
    }

    /** 
     * Sets the lagBuncd.
     * 
     * @param lagBuncd the lagBuncd
     */
    public void setLagBuncd(String lagBuncd) {
        this.lagBuncd = lagBuncd;
    }

    /** 
     * Returns the midBuncd.
     * 
     * @return the midBuncd
     */
    public String getMidBuncd() {
        return midBuncd;
    }

    /** 
     * Sets the midBuncd.
     * 
     * @param midBuncd the midBuncd
     */
    public void setMidBuncd(String midBuncd) {
        this.midBuncd = midBuncd;
    }

    /** 
     * Returns the smlBuncd1.
     * 
     * @return the smlBuncd1
     */
    public String getSmlBuncd1() {
        return smlBuncd1;
    }

    /** 
     * Sets the smlBuncd1.
     * 
     * @param smlBuncd1 the smlBuncd1
     */
    public void setSmlBuncd1(String smlBuncd1) {
        this.smlBuncd1 = smlBuncd1;
    }

    /** 
     * Returns the shimukeHyjnKeiJyokencd.
     * 
     * @return the shimukeHyjnKeiJyokencd
     */
    public Short getShimukeHyjnKeiJyokencd() {
        return shimukeHyjnKeiJyokencd;
    }

    /** 
     * Sets the shimukeHyjnKeiJyokencd.
     * 
     * @param shimukeHyjnKeiJyokencd the shimukeHyjnKeiJyokencd
     */
    public void setShimukeHyjnKeiJyokencd(Short shimukeHyjnKeiJyokencd) {
        this.shimukeHyjnKeiJyokencd = shimukeHyjnKeiJyokencd;
    }

    /** 
     * Returns the keiJyokenNm.
     * 
     * @return the keiJyokenNm
     */
    public String getKeiJyokenNm() {
        return keiJyokenNm;
    }

    /** 
     * Sets the keiJyokenNm.
     * 
     * @param keiJyokenNm the keiJyokenNm
     */
    public void setKeiJyokenNm(String keiJyokenNm) {
        this.keiJyokenNm = keiJyokenNm;
    }

    /** 
     * Returns the tateneNm.
     * 
     * @return the tateneNm
     */
    public String getTateneNm() {
        return tateneNm;
    }

    /** 
     * Sets the tateneNm.
     * 
     * @param tateneNm the tateneNm
     */
    public void setTateneNm(String tateneNm) {
        this.tateneNm = tateneNm;
    }

    /** 
     * Returns the irimeJuryo.
     * 
     * @return the irimeJuryo
     */
    public BigDecimal getIrimeJuryo() {
        return irimeJuryo;
    }

    /** 
     * Sets the irimeJuryo.
     * 
     * @param irimeJuryo the irimeJuryo
     */
    public void setIrimeJuryo(BigDecimal irimeJuryo) {
        this.irimeJuryo = irimeJuryo;
    }

    /** 
     * Returns the irimeTanicd.
     * 
     * @return the irimeTanicd
     */
    public Short getIrimeTanicd() {
        return irimeTanicd;
    }

    /** 
     * Sets the irimeTanicd.
     * 
     * @param irimeTanicd the irimeTanicd
     */
    public void setIrimeTanicd(Short irimeTanicd) {
        this.irimeTanicd = irimeTanicd;
    }

    /** 
     * Returns the irimeTaniNm.
     * 
     * @return the irimeTaniNm
     */
    public String getIrimeTaniNm() {
        return irimeTaniNm;
    }

    /** 
     * Sets the irimeTaniNm.
     * 
     * @param irimeTaniNm the irimeTaniNm
     */
    public void setIrimeTaniNm(String irimeTaniNm) {
        this.irimeTaniNm = irimeTaniNm;
    }

    /** 
     * Returns the konpoTaniCd.
     * 
     * @return the konpoTaniCd
     */
    public String getKonpoTaniCd() {
        return konpoTaniCd;
    }

    /** 
     * Sets the konpoTaniCd.
     * 
     * @param konpoTaniCd the konpoTaniCd
     */
    public void setKonpoTaniCd(String konpoTaniCd) {
        this.konpoTaniCd = konpoTaniCd;
    }

    /** 
     * Returns the konpoTaniNm.
     * 
     * @return the konpoTaniNm
     */
    public String getKonpoTaniNm() {
        return konpoTaniNm;
    }

    /** 
     * Sets the konpoTaniNm.
     * 
     * @param konpoTaniNm the konpoTaniNm
     */
    public void setKonpoTaniNm(String konpoTaniNm) {
        this.konpoTaniNm = konpoTaniNm;
    }

    /** 
     * Returns the unitTanka.
     * 
     * @return the unitTanka
     */
    public BigDecimal getUnitTanka() {
        return unitTanka;
    }

    /** 
     * Sets the unitTanka.
     * 
     * @param unitTanka the unitTanka
     */
    public void setUnitTanka(BigDecimal unitTanka) {
        this.unitTanka = unitTanka;
    }

    /** 
     * Returns the unitTanicd.
     * 
     * @return the unitTanicd
     */
    public Short getUnitTanicd() {
        return unitTanicd;
    }

    /** 
     * Sets the unitTanicd.
     * 
     * @param unitTanicd the unitTanicd
     */
    public void setUnitTanicd(Short unitTanicd) {
        this.unitTanicd = unitTanicd;
    }

    /** 
     * Returns the unitTaniNm.
     * 
     * @return the unitTaniNm
     */
    public String getUnitTaniNm() {
        return unitTaniNm;
    }

    /** 
     * Sets the unitTaniNm.
     * 
     * @param unitTaniNm the unitTaniNm
     */
    public void setUnitTaniNm(String unitTaniNm) {
        this.unitTaniNm = unitTaniNm;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Long getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Long hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }

    /** 
     * Returns the siireKikan.
     * 
     * @return the siireKikan
     */
    public Short getSiireKikan() {
        return siireKikan;
    }

    /** 
     * Sets the siireKikan.
     * 
     * @param siireKikan the siireKikan
     */
    public void setSiireKikan(Short siireKikan) {
        this.siireKikan = siireKikan;
    }

    /** 
     * Returns the yusoHohocd.
     * 
     * @return the yusoHohocd
     */
    public Short getYusoHohocd() {
        return yusoHohocd;
    }

    /** 
     * Sets the yusoHohocd.
     * 
     * @param yusoHohocd the yusoHohocd
     */
    public void setYusoHohocd(Short yusoHohocd) {
        this.yusoHohocd = yusoHohocd;
    }
}