package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.ProcessExecuteTime;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;
import org.springframework.context.annotation.Bean;

/**
 */
@ConfigAutowireable
@Dao
public interface ProcessExecuteTimeDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param processCategory
     * @return the ProcessExecuteTime entity
     */
    @Select
    ProcessExecuteTime selectById(String kaisyaCd, String gengoKbn, String processCategory);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(ProcessExecuteTime entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(ProcessExecuteTime entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(ProcessExecuteTime entity);
}