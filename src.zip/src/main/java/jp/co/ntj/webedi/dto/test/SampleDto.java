package jp.co.ntj.webedi.dto.test;

import java.sql.Timestamp;
import org.seasar.doma.Entity;

@Entity
public class SampleDto {
  public String kaisyaCd;
  public String gengoKbn;
  public Long id;
  public String testId;
  public Long testCode;
  public int isDeleted;
  public Timestamp createdAt;
  public String createdUser;
  public Timestamp updatedAt;
  public String updatedUser;
}
