package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MShimuListener implements EntityListener<MShimu> {

    @Override
    public void preInsert(MShimu entity, PreInsertContext<MShimu> context) {
    }

    @Override
    public void preUpdate(MShimu entity, PreUpdateContext<MShimu> context) {
    }

    @Override
    public void preDelete(MShimu entity, PreDeleteContext<MShimu> context) {
    }

    @Override
    public void postInsert(MShimu entity, PostInsertContext<MShimu> context) {
    }

    @Override
    public void postUpdate(MShimu entity, PostUpdateContext<MShimu> context) {
    }

    @Override
    public void postDelete(MShimu entity, PostDeleteContext<MShimu> context) {
    }
}