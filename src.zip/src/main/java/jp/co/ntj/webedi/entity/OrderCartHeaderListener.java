package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class OrderCartHeaderListener implements EntityListener<OrderCartHeader> {

    @Override
    public void preInsert(OrderCartHeader entity, PreInsertContext<OrderCartHeader> context) {
    }

    @Override
    public void preUpdate(OrderCartHeader entity, PreUpdateContext<OrderCartHeader> context) {
    }

    @Override
    public void preDelete(OrderCartHeader entity, PreDeleteContext<OrderCartHeader> context) {
    }

    @Override
    public void postInsert(OrderCartHeader entity, PostInsertContext<OrderCartHeader> context) {
    }

    @Override
    public void postUpdate(OrderCartHeader entity, PostUpdateContext<OrderCartHeader> context) {
    }

    @Override
    public void postDelete(OrderCartHeader entity, PostDeleteContext<OrderCartHeader> context) {
    }
}