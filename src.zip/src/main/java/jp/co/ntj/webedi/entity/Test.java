package jp.co.ntj.webedi.entity;

import java.math.BigDecimal;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * テスト
 */
@Entity(listener = TestListener.class)
@Table(name = "TEST")
public class Test {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** ID */
    @Id
    @Column(name = "ID")
    BigDecimal id;

    /** テストID */
    @Column(name = "TEST_ID")
    String testId;

    /** テストコード */
    @Column(name = "TEST_CODE")
    Long testCode;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the id.
     * 
     * @return the id
     */
    public BigDecimal getId() {
        return id;
    }

    /** 
     * Sets the id.
     * 
     * @param id the id
     */
    public void setId(BigDecimal id) {
        this.id = id;
    }

    /** 
     * Returns the testId.
     * 
     * @return the testId
     */
    public String getTestId() {
        return testId;
    }

    /** 
     * Sets the testId.
     * 
     * @param testId the testId
     */
    public void setTestId(String testId) {
        this.testId = testId;
    }

    /** 
     * Returns the testCode.
     * 
     * @return the testCode
     */
    public Long getTestCode() {
        return testCode;
    }

    /** 
     * Sets the testCode.
     * 
     * @param testCode the testCode
     */
    public void setTestCode(Long testCode) {
        this.testCode = testCode;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}