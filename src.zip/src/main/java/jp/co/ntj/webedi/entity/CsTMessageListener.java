package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class CsTMessageListener implements EntityListener<CsTMessage> {

    @Override
    public void preInsert(CsTMessage entity, PreInsertContext<CsTMessage> context) {
    }

    @Override
    public void preUpdate(CsTMessage entity, PreUpdateContext<CsTMessage> context) {
    }

    @Override
    public void preDelete(CsTMessage entity, PreDeleteContext<CsTMessage> context) {
    }

    @Override
    public void postInsert(CsTMessage entity, PostInsertContext<CsTMessage> context) {
    }

    @Override
    public void postUpdate(CsTMessage entity, PostUpdateContext<CsTMessage> context) {
    }

    @Override
    public void postDelete(CsTMessage entity, PostDeleteContext<CsTMessage> context) {
    }
}