package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MMeikanListener implements EntityListener<MMeikan> {

    @Override
    public void preInsert(MMeikan entity, PreInsertContext<MMeikan> context) {
    }

    @Override
    public void preUpdate(MMeikan entity, PreUpdateContext<MMeikan> context) {
    }

    @Override
    public void preDelete(MMeikan entity, PreDeleteContext<MMeikan> context) {
    }

    @Override
    public void postInsert(MMeikan entity, PostInsertContext<MMeikan> context) {
    }

    @Override
    public void postUpdate(MMeikan entity, PostUpdateContext<MMeikan> context) {
    }

    @Override
    public void postDelete(MMeikan entity, PostDeleteContext<MMeikan> context) {
    }
}