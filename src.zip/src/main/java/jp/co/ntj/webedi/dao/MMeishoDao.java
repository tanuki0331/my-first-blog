package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.MMeisho;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MMeishoDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param meikancd
     * @param meishocd
     * @return the MMeisho entity
     */
    @Select
    MMeisho selectById(String kaisyaCd, String gengoKbn, String meikancd, String meishocd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MMeisho entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MMeisho entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MMeisho entity);
}