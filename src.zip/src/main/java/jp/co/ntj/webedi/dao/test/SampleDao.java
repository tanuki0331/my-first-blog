package jp.co.ntj.webedi.dao.test;

import java.util.List;
import jp.co.ntj.webedi.dto.test.SampleDto;
import org.seasar.doma.Dao;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * テストDao.
 *
 * @author 日立システムズ
 */
@ConfigAutowireable
@Dao
public interface SampleDao {

  @Select
  List<SampleDto> selectAll();

  @Insert(sqlFile = true)
  int insert(SampleDto dto);

}