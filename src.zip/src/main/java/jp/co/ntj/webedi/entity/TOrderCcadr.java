package jp.co.ntj.webedi.entity;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 発注情報CCメール宛先
 */
@Entity(listener = TOrderCcadrListener.class)
@Table(name = "T_ORDER_CCADR")
public class TOrderCcadr {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** Web注文番号 */
    @Id
    @Column(name = "ORDERNO")
    Long orderno;

    /** 宛先ログイン名 */
    @Id
    @Column(name = "LOGIN_NAME")
    String loginName;

    /** 宛先氏名 */
    @Column(name = "ENAME")
    String ename;

    /** メールアドレス */
    @Column(name = "MAILADDRESS")
    String mailaddress;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the orderno.
     * 
     * @return the orderno
     */
    public Long getOrderno() {
        return orderno;
    }

    /** 
     * Sets the orderno.
     * 
     * @param orderno the orderno
     */
    public void setOrderno(Long orderno) {
        this.orderno = orderno;
    }

    /** 
     * Returns the loginName.
     * 
     * @return the loginName
     */
    public String getLoginName() {
        return loginName;
    }

    /** 
     * Sets the loginName.
     * 
     * @param loginName the loginName
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    /** 
     * Returns the ename.
     * 
     * @return the ename
     */
    public String getEname() {
        return ename;
    }

    /** 
     * Sets the ename.
     * 
     * @param ename the ename
     */
    public void setEname(String ename) {
        this.ename = ename;
    }

    /** 
     * Returns the mailaddress.
     * 
     * @return the mailaddress
     */
    public String getMailaddress() {
        return mailaddress;
    }

    /** 
     * Sets the mailaddress.
     * 
     * @param mailaddress the mailaddress
     */
    public void setMailaddress(String mailaddress) {
        this.mailaddress = mailaddress;
    }
}