package jp.co.ntj.webedi.entity;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 支払条件マスタ
 */
@Entity(listener = MShiharaiListener.class)
@Table(name = "M_SHIHARAI")
public class MShiharai {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 支払条件コード */
    @Id
    @Column(name = "SHI_JYOKENCD")
    Short shiJyokencd;

    /** 支払条件略名 */
    @Column(name = "SHI_JYOKEN_RYAK")
    String shiJyokenRyak;

    /** 支払条件名 */
    @Column(name = "SHI_JYOKEN_NM")
    String shiJyokenNm;

    /** 期日 */
    @Column(name = "KIJITU")
    Short kijitu;

    /** 支払種別 */
    @Column(name = "SHI_SHUBETU")
    Short shiShubetu;

    /** 起算日区分 */
    @Column(name = "KISAN_KBN")
    Short kisanKbn;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Long hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the shiJyokencd.
     * 
     * @return the shiJyokencd
     */
    public Short getShiJyokencd() {
        return shiJyokencd;
    }

    /** 
     * Sets the shiJyokencd.
     * 
     * @param shiJyokencd the shiJyokencd
     */
    public void setShiJyokencd(Short shiJyokencd) {
        this.shiJyokencd = shiJyokencd;
    }

    /** 
     * Returns the shiJyokenRyak.
     * 
     * @return the shiJyokenRyak
     */
    public String getShiJyokenRyak() {
        return shiJyokenRyak;
    }

    /** 
     * Sets the shiJyokenRyak.
     * 
     * @param shiJyokenRyak the shiJyokenRyak
     */
    public void setShiJyokenRyak(String shiJyokenRyak) {
        this.shiJyokenRyak = shiJyokenRyak;
    }

    /** 
     * Returns the shiJyokenNm.
     * 
     * @return the shiJyokenNm
     */
    public String getShiJyokenNm() {
        return shiJyokenNm;
    }

    /** 
     * Sets the shiJyokenNm.
     * 
     * @param shiJyokenNm the shiJyokenNm
     */
    public void setShiJyokenNm(String shiJyokenNm) {
        this.shiJyokenNm = shiJyokenNm;
    }

    /** 
     * Returns the kijitu.
     * 
     * @return the kijitu
     */
    public Short getKijitu() {
        return kijitu;
    }

    /** 
     * Sets the kijitu.
     * 
     * @param kijitu the kijitu
     */
    public void setKijitu(Short kijitu) {
        this.kijitu = kijitu;
    }

    /** 
     * Returns the shiShubetu.
     * 
     * @return the shiShubetu
     */
    public Short getShiShubetu() {
        return shiShubetu;
    }

    /** 
     * Sets the shiShubetu.
     * 
     * @param shiShubetu the shiShubetu
     */
    public void setShiShubetu(Short shiShubetu) {
        this.shiShubetu = shiShubetu;
    }

    /** 
     * Returns the kisanKbn.
     * 
     * @return the kisanKbn
     */
    public Short getKisanKbn() {
        return kisanKbn;
    }

    /** 
     * Sets the kisanKbn.
     * 
     * @param kisanKbn the kisanKbn
     */
    public void setKisanKbn(Short kisanKbn) {
        this.kisanKbn = kisanKbn;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Long getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Long hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}