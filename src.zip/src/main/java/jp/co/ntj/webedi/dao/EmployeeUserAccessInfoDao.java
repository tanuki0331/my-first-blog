package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.EmployeeUserAccessInfo;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface EmployeeUserAccessInfoDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param employeeUserId
     * @return the EmployeeUserAccessInfo entity
     */
    @Select
    EmployeeUserAccessInfo selectById(String kaisyaCd, String gengoKbn, Long employeeUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(EmployeeUserAccessInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(EmployeeUserAccessInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(EmployeeUserAccessInfo entity);
}