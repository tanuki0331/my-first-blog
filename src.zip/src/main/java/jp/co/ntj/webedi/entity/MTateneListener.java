package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MTateneListener implements EntityListener<MTatene> {

    @Override
    public void preInsert(MTatene entity, PreInsertContext<MTatene> context) {
    }

    @Override
    public void preUpdate(MTatene entity, PreUpdateContext<MTatene> context) {
    }

    @Override
    public void preDelete(MTatene entity, PreDeleteContext<MTatene> context) {
    }

    @Override
    public void postInsert(MTatene entity, PostInsertContext<MTatene> context) {
    }

    @Override
    public void postUpdate(MTatene entity, PostUpdateContext<MTatene> context) {
    }

    @Override
    public void postDelete(MTatene entity, PostDeleteContext<MTatene> context) {
    }
}