package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.MShobun;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MShobunDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param lagBuncd
     * @param midBuncd
     * @param smlBuncd1
     * @return the MShobun entity
     */
    @Select
    MShobun selectById(String kaisyaCd, String gengoKbn, String lagBuncd, String midBuncd, String smlBuncd1);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MShobun entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MShobun entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MShobun entity);
}