package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.OcReport;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 */
@ConfigAutowireable
@Dao
public interface OcReportDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param ocNumber
     * @return the OcReport entity
     */
    @Select
    OcReport selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String ocNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(OcReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(OcReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(OcReport entity);
}