package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.MShiharai;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MShiharaiDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param shiJyokencd
     * @return the MShiharai entity
     */
    @Select
    MShiharai selectById(String kaisyaCd, String gengoKbn, Short shiJyokencd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MShiharai entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MShiharai entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MShiharai entity);
}