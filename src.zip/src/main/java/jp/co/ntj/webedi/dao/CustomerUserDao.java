package jp.co.ntj.webedi.dao;

import java.math.BigDecimal;
import jp.co.ntj.webedi.entity.CustomerUser;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface CustomerUserDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param id
     * @return the CustomerUser entity
     */
    @Select
    CustomerUser selectById(String kaisyaCd, String gengoKbn, BigDecimal id);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(CustomerUser entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(CustomerUser entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(CustomerUser entity);
}