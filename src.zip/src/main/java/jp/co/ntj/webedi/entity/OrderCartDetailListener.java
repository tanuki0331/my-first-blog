package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class OrderCartDetailListener implements EntityListener<OrderCartDetail> {

    @Override
    public void preInsert(OrderCartDetail entity, PreInsertContext<OrderCartDetail> context) {
    }

    @Override
    public void preUpdate(OrderCartDetail entity, PreUpdateContext<OrderCartDetail> context) {
    }

    @Override
    public void preDelete(OrderCartDetail entity, PreDeleteContext<OrderCartDetail> context) {
    }

    @Override
    public void postInsert(OrderCartDetail entity, PostInsertContext<OrderCartDetail> context) {
    }

    @Override
    public void postUpdate(OrderCartDetail entity, PostUpdateContext<OrderCartDetail> context) {
    }

    @Override
    public void postDelete(OrderCartDetail entity, PostDeleteContext<OrderCartDetail> context) {
    }
}