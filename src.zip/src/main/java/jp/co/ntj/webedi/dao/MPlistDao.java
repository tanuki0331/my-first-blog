package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.MPlist;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MPlistDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param tokucd
     * @param shimukecd
     * @param shohincd
     * @param yusoHohocd
     * @return the MPlist entity
     */
    @Select
    MPlist selectById(String kaisyaCd, String gengoKbn, Long tokucd, Long shimukecd, String shohincd, Short yusoHohocd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MPlist entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MPlist entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MPlist entity);
}