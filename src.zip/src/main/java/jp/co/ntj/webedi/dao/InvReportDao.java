package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.InvReport;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface InvReportDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param invNumber
     * @return the InvReport entity
     */
    @Select
    InvReport selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String invNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(InvReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(InvReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(InvReport entity);
}