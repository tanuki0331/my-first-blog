package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class PinvDownloadHistoryListener implements EntityListener<PinvDownloadHistory> {

    @Override
    public void preInsert(PinvDownloadHistory entity, PreInsertContext<PinvDownloadHistory> context) {
    }

    @Override
    public void preUpdate(PinvDownloadHistory entity, PreUpdateContext<PinvDownloadHistory> context) {
    }

    @Override
    public void preDelete(PinvDownloadHistory entity, PreDeleteContext<PinvDownloadHistory> context) {
    }

    @Override
    public void postInsert(PinvDownloadHistory entity, PostInsertContext<PinvDownloadHistory> context) {
    }

    @Override
    public void postUpdate(PinvDownloadHistory entity, PostUpdateContext<PinvDownloadHistory> context) {
    }

    @Override
    public void postDelete(PinvDownloadHistory entity, PostDeleteContext<PinvDownloadHistory> context) {
    }
}