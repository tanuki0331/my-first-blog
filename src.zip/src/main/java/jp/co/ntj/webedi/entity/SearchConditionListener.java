package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class SearchConditionListener implements EntityListener<SearchCondition> {

    @Override
    public void preInsert(SearchCondition entity, PreInsertContext<SearchCondition> context) {
    }

    @Override
    public void preUpdate(SearchCondition entity, PreUpdateContext<SearchCondition> context) {
    }

    @Override
    public void preDelete(SearchCondition entity, PreDeleteContext<SearchCondition> context) {
    }

    @Override
    public void postInsert(SearchCondition entity, PostInsertContext<SearchCondition> context) {
    }

    @Override
    public void postUpdate(SearchCondition entity, PostUpdateContext<SearchCondition> context) {
    }

    @Override
    public void postDelete(SearchCondition entity, PostDeleteContext<SearchCondition> context) {
    }
}