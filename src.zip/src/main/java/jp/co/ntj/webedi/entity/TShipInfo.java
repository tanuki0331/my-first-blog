package jp.co.ntj.webedi.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 船積関連情報
 */
@Entity(listener = TShipInfoListener.class)
@Table(name = "T_SHIP_INFO")
public class TShipInfo {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** インボイス番号 */
    @Id
    @Column(name = "INV_NO")
    String invNo;

    /** Web注文番号 */
    @Id
    @Column(name = "ORDERNO")
    Long orderno;

    /** Web注文行番号 */
    @Id
    @Column(name = "ORDER_LINE")
    Short orderLine;

    /** 得意先コード */
    @Column(name = "TOKUCD")
    Long tokucd;

    /** PONO */
    @Column(name = "PONO")
    String pono;

    /** 船積数量 */
    @Column(name = "SURYO")
    BigDecimal suryo;

    /** 入港日 */
    @Column(name = "NYUKOU_DATE")
    String nyukouDate;

    /** 出港予定日 */
    @Column(name = "SHUKOU_DATE_Y")
    String shukouDateY;

    /** 実出港日 */
    @Column(name = "SHUKOU_DATE_J")
    String shukouDateJ;

    /** 着港日 */
    @Column(name = "CHAKU_DATE")
    String chakuDate;

    /** CARGOREADY */
    @Column(name = "CARGO_READY")
    LocalDate cargoReady;

    /** 登録日付時刻 */
    @Column(name = "ENTRY_DATE")
    LocalDate entryDate;

    /** 更新日付時刻 */
    @Column(name = "UPDATE_DATE")
    LocalDate updateDate;

    /** 削除日付時刻 */
    @Column(name = "DELETE_DATE")
    LocalDate deleteDate;

    /** 削除フラグ */
    @Column(name = "DELETE_FLG")
    Short deleteFlg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the invNo.
     * 
     * @return the invNo
     */
    public String getInvNo() {
        return invNo;
    }

    /** 
     * Sets the invNo.
     * 
     * @param invNo the invNo
     */
    public void setInvNo(String invNo) {
        this.invNo = invNo;
    }

    /** 
     * Returns the orderno.
     * 
     * @return the orderno
     */
    public Long getOrderno() {
        return orderno;
    }

    /** 
     * Sets the orderno.
     * 
     * @param orderno the orderno
     */
    public void setOrderno(Long orderno) {
        this.orderno = orderno;
    }

    /** 
     * Returns the orderLine.
     * 
     * @return the orderLine
     */
    public Short getOrderLine() {
        return orderLine;
    }

    /** 
     * Sets the orderLine.
     * 
     * @param orderLine the orderLine
     */
    public void setOrderLine(Short orderLine) {
        this.orderLine = orderLine;
    }

    /** 
     * Returns the tokucd.
     * 
     * @return the tokucd
     */
    public Long getTokucd() {
        return tokucd;
    }

    /** 
     * Sets the tokucd.
     * 
     * @param tokucd the tokucd
     */
    public void setTokucd(Long tokucd) {
        this.tokucd = tokucd;
    }

    /** 
     * Returns the pono.
     * 
     * @return the pono
     */
    public String getPono() {
        return pono;
    }

    /** 
     * Sets the pono.
     * 
     * @param pono the pono
     */
    public void setPono(String pono) {
        this.pono = pono;
    }

    /** 
     * Returns the suryo.
     * 
     * @return the suryo
     */
    public BigDecimal getSuryo() {
        return suryo;
    }

    /** 
     * Sets the suryo.
     * 
     * @param suryo the suryo
     */
    public void setSuryo(BigDecimal suryo) {
        this.suryo = suryo;
    }

    /** 
     * Returns the nyukouDate.
     * 
     * @return the nyukouDate
     */
    public String getNyukouDate() {
        return nyukouDate;
    }

    /** 
     * Sets the nyukouDate.
     * 
     * @param nyukouDate the nyukouDate
     */
    public void setNyukouDate(String nyukouDate) {
        this.nyukouDate = nyukouDate;
    }

    /** 
     * Returns the shukouDateY.
     * 
     * @return the shukouDateY
     */
    public String getShukouDateY() {
        return shukouDateY;
    }

    /** 
     * Sets the shukouDateY.
     * 
     * @param shukouDateY the shukouDateY
     */
    public void setShukouDateY(String shukouDateY) {
        this.shukouDateY = shukouDateY;
    }

    /** 
     * Returns the shukouDateJ.
     * 
     * @return the shukouDateJ
     */
    public String getShukouDateJ() {
        return shukouDateJ;
    }

    /** 
     * Sets the shukouDateJ.
     * 
     * @param shukouDateJ the shukouDateJ
     */
    public void setShukouDateJ(String shukouDateJ) {
        this.shukouDateJ = shukouDateJ;
    }

    /** 
     * Returns the chakuDate.
     * 
     * @return the chakuDate
     */
    public String getChakuDate() {
        return chakuDate;
    }

    /** 
     * Sets the chakuDate.
     * 
     * @param chakuDate the chakuDate
     */
    public void setChakuDate(String chakuDate) {
        this.chakuDate = chakuDate;
    }

    /** 
     * Returns the cargoReady.
     * 
     * @return the cargoReady
     */
    public LocalDate getCargoReady() {
        return cargoReady;
    }

    /** 
     * Sets the cargoReady.
     * 
     * @param cargoReady the cargoReady
     */
    public void setCargoReady(LocalDate cargoReady) {
        this.cargoReady = cargoReady;
    }

    /** 
     * Returns the entryDate.
     * 
     * @return the entryDate
     */
    public LocalDate getEntryDate() {
        return entryDate;
    }

    /** 
     * Sets the entryDate.
     * 
     * @param entryDate the entryDate
     */
    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    /** 
     * Returns the updateDate.
     * 
     * @return the updateDate
     */
    public LocalDate getUpdateDate() {
        return updateDate;
    }

    /** 
     * Sets the updateDate.
     * 
     * @param updateDate the updateDate
     */
    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    /** 
     * Returns the deleteDate.
     * 
     * @return the deleteDate
     */
    public LocalDate getDeleteDate() {
        return deleteDate;
    }

    /** 
     * Sets the deleteDate.
     * 
     * @param deleteDate the deleteDate
     */
    public void setDeleteDate(LocalDate deleteDate) {
        this.deleteDate = deleteDate;
    }

    /** 
     * Returns the deleteFlg.
     * 
     * @return the deleteFlg
     */
    public Short getDeleteFlg() {
        return deleteFlg;
    }

    /** 
     * Sets the deleteFlg.
     * 
     * @param deleteFlg the deleteFlg
     */
    public void setDeleteFlg(Short deleteFlg) {
        this.deleteFlg = deleteFlg;
    }
}