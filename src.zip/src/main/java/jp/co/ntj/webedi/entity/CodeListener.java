package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class CodeListener implements EntityListener<Code> {

    @Override
    public void preInsert(Code entity, PreInsertContext<Code> context) {
    }

    @Override
    public void preUpdate(Code entity, PreUpdateContext<Code> context) {
    }

    @Override
    public void preDelete(Code entity, PreDeleteContext<Code> context) {
    }

    @Override
    public void postInsert(Code entity, PostInsertContext<Code> context) {
    }

    @Override
    public void postUpdate(Code entity, PostUpdateContext<Code> context) {
    }

    @Override
    public void postDelete(Code entity, PostDeleteContext<Code> context) {
    }
}