package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.CustomerUserAuthority;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface CustomerUserAuthorityDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @return the CustomerUserAuthority entity
     */
    @Select
    CustomerUserAuthority selectById(String kaisyaCd, String gengoKbn, Long customerUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(CustomerUserAuthority entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(CustomerUserAuthority entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(CustomerUserAuthority entity);
}