package jp.co.ntj.webedi.entity;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 社員ユーザーアクセス情報
 */
@Entity(listener = EmployeeUserAccessInfoListener.class)
@Table(name = "EMPLOYEE_USER_ACCESS_INFO")
public class EmployeeUserAccessInfo {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 社員ユーザーID */
    @Id
    @Column(name = "EMPLOYEE_USER_ID")
    Long employeeUserId;

    /** セッションID */
    @Column(name = "SESSION_ID")
    String sessionId;

    /** 最終操作日時 */
    @Column(name = "LAST_OPERATION_AT")
    String lastOperationAt;

    /** ログイン日時 */
    @Column(name = "LOGIN_AT")
    String loginAt;

    /** 前回ログイン日時 */
    @Column(name = "PREV_LOGIN_AT")
    String prevLoginAt;

    /** ホスト名 */
    @Column(name = "HOST_NAME")
    String hostName;

    /** アクセスIP */
    @Column(name = "ACCESS_IP")
    String accessIp;

    /** ユーザーエージェント */
    @Column(name = "USER_AGENT")
    String userAgent;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the employeeUserId.
     * 
     * @return the employeeUserId
     */
    public Long getEmployeeUserId() {
        return employeeUserId;
    }

    /** 
     * Sets the employeeUserId.
     * 
     * @param employeeUserId the employeeUserId
     */
    public void setEmployeeUserId(Long employeeUserId) {
        this.employeeUserId = employeeUserId;
    }

    /** 
     * Returns the sessionId.
     * 
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /** 
     * Sets the sessionId.
     * 
     * @param sessionId the sessionId
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    /** 
     * Returns the lastOperationAt.
     * 
     * @return the lastOperationAt
     */
    public String getLastOperationAt() {
        return lastOperationAt;
    }

    /** 
     * Sets the lastOperationAt.
     * 
     * @param lastOperationAt the lastOperationAt
     */
    public void setLastOperationAt(String lastOperationAt) {
        this.lastOperationAt = lastOperationAt;
    }

    /** 
     * Returns the loginAt.
     * 
     * @return the loginAt
     */
    public String getLoginAt() {
        return loginAt;
    }

    /** 
     * Sets the loginAt.
     * 
     * @param loginAt the loginAt
     */
    public void setLoginAt(String loginAt) {
        this.loginAt = loginAt;
    }

    /** 
     * Returns the prevLoginAt.
     * 
     * @return the prevLoginAt
     */
    public String getPrevLoginAt() {
        return prevLoginAt;
    }

    /** 
     * Sets the prevLoginAt.
     * 
     * @param prevLoginAt the prevLoginAt
     */
    public void setPrevLoginAt(String prevLoginAt) {
        this.prevLoginAt = prevLoginAt;
    }

    /** 
     * Returns the hostName.
     * 
     * @return the hostName
     */
    public String getHostName() {
        return hostName;
    }

    /** 
     * Sets the hostName.
     * 
     * @param hostName the hostName
     */
    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    /** 
     * Returns the accessIp.
     * 
     * @return the accessIp
     */
    public String getAccessIp() {
        return accessIp;
    }

    /** 
     * Sets the accessIp.
     * 
     * @param accessIp the accessIp
     */
    public void setAccessIp(String accessIp) {
        this.accessIp = accessIp;
    }

    /** 
     * Returns the userAgent.
     * 
     * @return the userAgent
     */
    public String getUserAgent() {
        return userAgent;
    }

    /** 
     * Sets the userAgent.
     * 
     * @param userAgent the userAgent
     */
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}