package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.EmployeeUserAuthority;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface EmployeeUserAuthorityDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param employeeUserId
     * @return the EmployeeUserAuthority entity
     */
    @Select
    EmployeeUserAuthority selectById(String kaisyaCd, String gengoKbn, Long employeeUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(EmployeeUserAuthority entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(EmployeeUserAuthority entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(EmployeeUserAuthority entity);
}