package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class ShipToUserListener implements EntityListener<ShipToUser> {

    @Override
    public void preInsert(ShipToUser entity, PreInsertContext<ShipToUser> context) {
    }

    @Override
    public void preUpdate(ShipToUser entity, PreUpdateContext<ShipToUser> context) {
    }

    @Override
    public void preDelete(ShipToUser entity, PreDeleteContext<ShipToUser> context) {
    }

    @Override
    public void postInsert(ShipToUser entity, PostInsertContext<ShipToUser> context) {
    }

    @Override
    public void postUpdate(ShipToUser entity, PostUpdateContext<ShipToUser> context) {
    }

    @Override
    public void postDelete(ShipToUser entity, PostDeleteContext<ShipToUser> context) {
    }
}