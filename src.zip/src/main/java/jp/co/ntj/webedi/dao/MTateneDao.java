package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.MTatene;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MTateneDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param tatenecd
     * @return the MTatene entity
     */
    @Select
    MTatene selectById(String kaisyaCd, String gengoKbn, String tatenecd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MTatene entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MTatene entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MTatene entity);
}