package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.TOrderFile;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface TOrderFileDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param fileCode
     * @return the TOrderFile entity
     */
    @Select
    TOrderFile selectById(String kaisyaCd, String gengoKbn, Long fileCode);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(TOrderFile entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(TOrderFile entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(TOrderFile entity);
}