package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.OrderCartHeader;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface OrderCartHeaderDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @return the OrderCartHeader entity
     */
    @Select
    OrderCartHeader selectById(String kaisyaCd, String gengoKbn, Long customerUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(OrderCartHeader entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(OrderCartHeader entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(OrderCartHeader entity);
}