package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class TOrderHListener implements EntityListener<TOrderH> {

    @Override
    public void preInsert(TOrderH entity, PreInsertContext<TOrderH> context) {
    }

    @Override
    public void preUpdate(TOrderH entity, PreUpdateContext<TOrderH> context) {
    }

    @Override
    public void preDelete(TOrderH entity, PreDeleteContext<TOrderH> context) {
    }

    @Override
    public void postInsert(TOrderH entity, PostInsertContext<TOrderH> context) {
    }

    @Override
    public void postUpdate(TOrderH entity, PostUpdateContext<TOrderH> context) {
    }

    @Override
    public void postDelete(TOrderH entity, PostDeleteContext<TOrderH> context) {
    }
}