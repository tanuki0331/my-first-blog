package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.CustomerUserAccessInfo;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface CustomerUserAccessInfoDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @return the CustomerUserAccessInfo entity
     */
    @Select
    CustomerUserAccessInfo selectById(String kaisyaCd, String gengoKbn, Long customerUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(CustomerUserAccessInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(CustomerUserAccessInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(CustomerUserAccessInfo entity);
}