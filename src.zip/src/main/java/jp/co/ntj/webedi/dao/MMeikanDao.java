package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.MMeikan;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MMeikanDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param meikancd
     * @return the MMeikan entity
     */
    @Select
    MMeikan selectById(String kaisyaCd, String gengoKbn, String meikancd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MMeikan entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MMeikan entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MMeikan entity);
}