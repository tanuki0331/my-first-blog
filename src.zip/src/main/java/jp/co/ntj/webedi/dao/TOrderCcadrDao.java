package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.TOrderCcadr;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface TOrderCcadrDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param orderno
     * @param loginName
     * @return the TOrderCcadr entity
     */
    @Select
    TOrderCcadr selectById(String kaisyaCd, String gengoKbn, Long orderno, String loginName);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(TOrderCcadr entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(TOrderCcadr entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(TOrderCcadr entity);
}