package jp.co.ntj.webedi.entity;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 得意先ユーザー配信メール
 */
@Entity(listener = CustomerUserDlvyMailListener.class)
@Table(name = "CUSTOMER_USER_DLVY_MAIL")
public class CustomerUserDlvyMail {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 得意先ユーザーID */
    @Id
    @Column(name = "CUSTOMER_USER_ID")
    Long customerUserId;

    /** 連番 */
    @Id
    @Column(name = "SEQUENCE_NUMBER")
    Short sequenceNumber;

    /** メールアドレス */
    @Column(name = "MAIL_ADDRESS")
    String mailAddress;

    /** 注文登録メール有効フラグ */
    @Column(name = "USE_ORDER_MAIL")
    Short useOrderMail;

    /** OC発行メール有効フラグ */
    @Column(name = "IS_VALIDATED_OC_ISSUE_MAIL")
    Short isValidatedOcIssueMail;

    /** INV発行メール有効フラグ */
    @Column(name = "IS_VALIDATED_INV_ISSUE_MAIL")
    Short isValidatedInvIssueMail;

    /** P/I発行メール有効フラグ */
    @Column(name = "IS_VALIDATED_PINV_ISSUE_MAIL")
    Short isValidatedPinvIssueMail;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the customerUserId.
     * 
     * @return the customerUserId
     */
    public Long getCustomerUserId() {
        return customerUserId;
    }

    /** 
     * Sets the customerUserId.
     * 
     * @param customerUserId the customerUserId
     */
    public void setCustomerUserId(Long customerUserId) {
        this.customerUserId = customerUserId;
    }

    /** 
     * Returns the sequenceNumber.
     * 
     * @return the sequenceNumber
     */
    public Short getSequenceNumber() {
        return sequenceNumber;
    }

    /** 
     * Sets the sequenceNumber.
     * 
     * @param sequenceNumber the sequenceNumber
     */
    public void setSequenceNumber(Short sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    /** 
     * Returns the mailAddress.
     * 
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /** 
     * Sets the mailAddress.
     * 
     * @param mailAddress the mailAddress
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /** 
     * Returns the useOrderMail.
     * 
     * @return the useOrderMail
     */
    public Short getUseOrderMail() {
        return useOrderMail;
    }

    /** 
     * Sets the useOrderMail.
     * 
     * @param useOrderMail the useOrderMail
     */
    public void setUseOrderMail(Short useOrderMail) {
        this.useOrderMail = useOrderMail;
    }

    /** 
     * Returns the isValidatedOcIssueMail.
     * 
     * @return the isValidatedOcIssueMail
     */
    public Short getIsValidatedOcIssueMail() {
        return isValidatedOcIssueMail;
    }

    /** 
     * Sets the isValidatedOcIssueMail.
     * 
     * @param isValidatedOcIssueMail the isValidatedOcIssueMail
     */
    public void setIsValidatedOcIssueMail(Short isValidatedOcIssueMail) {
        this.isValidatedOcIssueMail = isValidatedOcIssueMail;
    }

    /** 
     * Returns the isValidatedInvIssueMail.
     * 
     * @return the isValidatedInvIssueMail
     */
    public Short getIsValidatedInvIssueMail() {
        return isValidatedInvIssueMail;
    }

    /** 
     * Sets the isValidatedInvIssueMail.
     * 
     * @param isValidatedInvIssueMail the isValidatedInvIssueMail
     */
    public void setIsValidatedInvIssueMail(Short isValidatedInvIssueMail) {
        this.isValidatedInvIssueMail = isValidatedInvIssueMail;
    }

    /** 
     * Returns the isValidatedPinvIssueMail.
     * 
     * @return the isValidatedPinvIssueMail
     */
    public Short getIsValidatedPinvIssueMail() {
        return isValidatedPinvIssueMail;
    }

    /** 
     * Sets the isValidatedPinvIssueMail.
     * 
     * @param isValidatedPinvIssueMail the isValidatedPinvIssueMail
     */
    public void setIsValidatedPinvIssueMail(Short isValidatedPinvIssueMail) {
        this.isValidatedPinvIssueMail = isValidatedPinvIssueMail;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}