package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.TProductFile;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface TProductFileDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param fileCode
     * @return the TProductFile entity
     */
    @Select
    TProductFile selectById(String kaisyaCd, String gengoKbn, Long fileCode);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(TProductFile entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(TProductFile entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(TProductFile entity);
}