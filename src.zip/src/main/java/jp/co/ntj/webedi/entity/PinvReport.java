package jp.co.ntj.webedi.entity;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * ProformaInvoice帳票
 */
@Entity(listener = PinvReportListener.class)
@Table(name = "PINV_REPORT")
public class PinvReport {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 得意先コード */
    @Id
    @Column(name = "CUSTOMER_CODE")
    Long customerCode;

    /** 出荷先コード */
    @Id
    @Column(name = "DESTINATION_CODE")
    Long destinationCode;

    /** P/I番号 */
    @Id
    @Column(name = "PINV_NUMBER")
    String pinvNumber;

    /** 発行日 */
    @Column(name = "ISSUE_AT")
    LocalDate issueAt;

    /** ファイルパス */
    @Column(name = "FILE_PATH")
    String filePath;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the customerCode.
     * 
     * @return the customerCode
     */
    public Long getCustomerCode() {
        return customerCode;
    }

    /** 
     * Sets the customerCode.
     * 
     * @param customerCode the customerCode
     */
    public void setCustomerCode(Long customerCode) {
        this.customerCode = customerCode;
    }

    /** 
     * Returns the destinationCode.
     * 
     * @return the destinationCode
     */
    public Long getDestinationCode() {
        return destinationCode;
    }

    /** 
     * Sets the destinationCode.
     * 
     * @param destinationCode the destinationCode
     */
    public void setDestinationCode(Long destinationCode) {
        this.destinationCode = destinationCode;
    }

    /** 
     * Returns the pinvNumber.
     * 
     * @return the pinvNumber
     */
    public String getPinvNumber() {
        return pinvNumber;
    }

    /** 
     * Sets the pinvNumber.
     * 
     * @param pinvNumber the pinvNumber
     */
    public void setPinvNumber(String pinvNumber) {
        this.pinvNumber = pinvNumber;
    }

    /** 
     * Returns the issueAt.
     * 
     * @return the issueAt
     */
    public LocalDate getIssueAt() {
        return issueAt;
    }

    /** 
     * Sets the issueAt.
     * 
     * @param issueAt the issueAt
     */
    public void setIssueAt(LocalDate issueAt) {
        this.issueAt = issueAt;
    }

    /** 
     * Returns the filePath.
     * 
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /** 
     * Sets the filePath.
     * 
     * @param filePath the filePath
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}