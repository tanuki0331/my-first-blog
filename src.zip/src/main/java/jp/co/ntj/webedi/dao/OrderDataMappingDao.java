package jp.co.ntj.webedi.dao;

import jp.co.ntj.webedi.entity.OrderDataMapping;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface OrderDataMappingDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @return the OrderDataMapping entity
     */
    @Select
    OrderDataMapping selectById(String kaisyaCd, String gengoKbn, Long customerCode);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(OrderDataMapping entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(OrderDataMapping entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(OrderDataMapping entity);
}