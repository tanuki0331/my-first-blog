package jp.co.ntj.webedi.entity;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MRemarksListener implements EntityListener<MRemarks> {

    @Override
    public void preInsert(MRemarks entity, PreInsertContext<MRemarks> context) {
    }

    @Override
    public void preUpdate(MRemarks entity, PreUpdateContext<MRemarks> context) {
    }

    @Override
    public void preDelete(MRemarks entity, PreDeleteContext<MRemarks> context) {
    }

    @Override
    public void postInsert(MRemarks entity, PostInsertContext<MRemarks> context) {
    }

    @Override
    public void postUpdate(MRemarks entity, PostUpdateContext<MRemarks> context) {
    }

    @Override
    public void postDelete(MRemarks entity, PostDeleteContext<MRemarks> context) {
    }
}