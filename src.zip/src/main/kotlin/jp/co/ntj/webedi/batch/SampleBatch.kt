package jp.co.ntj.webedi.batch

import jp.co.ntj.webedi.service.SampleService
import org.slf4j.Logger
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Service

/**
 * サンプルバッチ.
 *
 * @author 日立システムズ
 */
@Service
@ConditionalOnProperty(name = ["batch"], havingValue = "sample")
class SampleBatch(
    private val sampleService: SampleService,
    private val batchLogger: Logger) : BaseCommandLineBatch() {

  override fun init(vararg args: String?) {
    super.init(*args)
    batchLogger.debug("start SampleBatch [$args]")
  }

  override fun execute(): Int {
    sampleService.getTests().forEach { dto -> batchLogger.debug(dto.testId) }
    return 0 // 終了コード
  }
}