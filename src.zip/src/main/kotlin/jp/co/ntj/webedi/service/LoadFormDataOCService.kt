package jp.co.ntj.webedi.service

import jp.co.ntj.webedi.dao.*
import jp.co.ntj.webedi.entity.EmployeeUser
import jp.co.ntj.webedi.entity.OcConfirmation
import jp.co.ntj.webedi.entity.ProcessExecuteTime
import org.slf4j.Logger
import org.springframework.stereotype.Service

import jp.co.ntj.webedi.entity.OcReport
import org.apache.commons.lang3.StringUtils
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@Service
class LoadFormDataOCService(
    val processExecuteTimeDao: ProcessExecuteTimeDao,
    val ocReportDao: OcReportDao,
    val ocConfirmationDao: OcConfirmationDao,
    val employeeUserDao: EmployeeUserDao,
    val logger: Logger
) {
  val processCategory = "PROC0001"

  /**
   * 処理実行時刻を取得する
   */
  fun getProcessExecuteTime():String {
    var time : ProcessExecuteTime?  = processExecuteTimeDao.selectById("0000","JP", processCategory)
    if (time != null) {
      return time.executeAt.substring(0, 19)
    } else {
      return ""
    }
  }

  /**
   * 処理実行時刻を更新する
   */
  fun saveProcessExecuteTime() {
    var datetime = LocalDateTime.now()
    var zoneDatetime = ZonedDateTime.of(datetime,  ZoneId.systemDefault())
    var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssXXX")
    var datetimestr = formatter.format(zoneDatetime)

    var processExecuteTime = ProcessExecuteTime()
    processExecuteTime.kaisyaCd = "0000"//TODO 暫定
    processExecuteTime.gengoKbn = "JP"
    processExecuteTime.processCategory = processCategory
    processExecuteTime.executeAt = datetimestr
    processExecuteTime.isDeleted = 0
    processExecuteTime.createdUser = "SYSTEM"
    processExecuteTime.createdAt = datetimestr
    processExecuteTime.updatedUser = "SYSTEM"
    processExecuteTime.updatedAt = datetimestr

    var time = getProcessExecuteTime()
    if (StringUtils.isEmpty(time)) {
      processExecuteTimeDao.insert(processExecuteTime)
    } else {
      processExecuteTimeDao.update(processExecuteTime)
    }
  }

  /**
   * OC帳票データを取得
    */
  fun getOCReport(kaisyaCd: String,
                  gengoKbn: String,
                  customerCode: Long,
                  destinationCode: Long,
                  ocNumber: String): OcReport? {
    return  ocReportDao.selectById(kaisyaCd, gengoKbn, customerCode, destinationCode, ocNumber)
  }

  /**
   * OC帳票データを登録
   */
  fun insertOCRepoet(ocReport:OcReport):Int {
    return ocReportDao.insert(ocReport)
  }

  /**
   * OC帳票データを更新
   */
  fun updateOCRepoet(ocReport:OcReport):Int {
    return ocReportDao.update(ocReport)
  }

  /**
   * OC帳票確認テーブルを削除する
   */
  fun deleteOCConfirmation(kaisyaCd: String,
                           gengoKbn: String,
                           customerCode: Long,
                           destinationCode: Long,
                           ocNumber: String) {
    val ocConfirmation = OcConfirmation()
    ocConfirmation.kaisyaCd = kaisyaCd
    ocConfirmation.gengoKbn = gengoKbn
    ocConfirmation.customerCode = customerCode
    ocConfirmation.destinationCode = destinationCode
    ocConfirmation.ocNumber = ocNumber
    ocConfirmationDao.delete(ocConfirmation)

  }

  /**
   * OC帳票確認依頼メール用
   * OC帳票の出荷先コードから社員情報を取得する
   * 名前とメールアドレスのMapを返す
   */
  fun getUserMap(destinationCode: Long): Map<String, String> {
    var userMap = LinkedHashMap<String, String>()
    var list = employeeUserDao.selectLShimuByDestCd(destinationCode)
    if (list != null) {
      list.iterator().forEach {
        userMap.put(it.name, it.mailAddress)
      }
    }

    var list2 = employeeUserDao.selectShimuByDestCd(destinationCode)
    if (list2 != null) {
      list2.iterator().forEach {
        userMap.put(it.name, it.mailAddress)
      }
    }

    return userMap
  }
}
