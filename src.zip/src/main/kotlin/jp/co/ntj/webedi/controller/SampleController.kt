package jp.co.ntj.webedi.controller

import jp.co.ntj.webedi.domain.model.ResponseData
import jp.co.ntj.webedi.domain.model.test.SampleModel
import jp.co.ntj.webedi.dto.test.SampleDto
import jp.co.ntj.webedi.service.SampleService
import org.slf4j.Logger
import org.springframework.validation.BindingResult
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("sample")
class SampleController(val sampleService: SampleService, val logger: Logger) {

  @RequestMapping("test")
  fun testGet(): ResponseData {
    return try {
      val tests: List<SampleDto> = sampleService.getTests()
      logger.debug(tests.toString())
      ResponseData(data = tests)
    } catch (e: Throwable) {
      logger.error(e.message, e)
      ResponseData("error")
    }
  }

  @PostMapping("testadd")
  fun testAdd(@RequestBody @Validated sampleModel: SampleModel,
      bindingResult: BindingResult): ResponseData {
    return if (bindingResult.hasErrors()) {
      ResponseData("error", data = bindingResult.allErrors.toString())
    } else {
      var (testId: String, testCode: Long) = sampleModel
      try {
        sampleService.addTest(testId, testCode)
        ResponseData()
      } catch (e: Throwable) {
        ResponseData("error", data = e)
      }
    }
  }

  @PostMapping("testadderror")
  fun testAddError(@RequestBody @Validated sampleModel: SampleModel,
      bindingResult: BindingResult): ResponseData {
    return if (bindingResult.hasErrors()) {
      ResponseData("error", data = bindingResult.allErrors.toString())
    } else {
      var (testId: String, testCode: Long) = sampleModel
      try {
        sampleService.addTest(testId, testCode, true)
        ResponseData()
      } catch (e: Throwable) {
        ResponseData("error", data = e)
      }
    }
  }
}