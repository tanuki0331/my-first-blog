package jp.co.ntj.webedi.batch.properties

import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Configuration
import org.springframework.stereotype.Component

@Component
@Configuration
@ConfigurationProperties(prefix = "batchsetting")
class BatchProperties {
//  @Value("\${batch.ocloadtemporarydir:}")
  lateinit var ocloadtemporarydir: String //OC帳票データロード：一時ディレクトリ
//  @Value("\${batch.ocloadmasterdir:}")
  lateinit var ocloadmasterdir: String //OC帳票データロード：一時ディレクトリ
}