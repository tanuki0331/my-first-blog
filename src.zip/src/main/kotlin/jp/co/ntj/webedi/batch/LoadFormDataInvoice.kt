package jp.co.ntj.webedi.batch

class LoadFormData_Invoice {
}