IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'SP_顧客予定')
    DROP PROCEDURE [dbo].[SP_顧客予定]
GO

CREATE PROCEDURE [dbo].[SP_顧客予定]
AS
BEGIN
    -- ############################################################################################################
    -- 処理対象月のカレンダーを作成する
    -- ############################################################################################################
    DECLARE @カレンダー対象日 DATE;

    -- カレンダーデータ格納用
    CREATE TABLE #calendar
    (
        年月 NVARCHAR(6) NULL,
        日付 DATE NULL,
        曜日 decimal(1, 0) NULL,
        祝日 decimal(1, 0) NULL,
    )

    DECLARE curCalendarTarget CURSOR FOR
        SELECT DISTINCT
            DATEADD(dd, 1, EOMONTH(売上月, -1))
        FROM
            D_顧客実績
        WHERE
            営業日数 IS NULL

    OPEN curCalendarTarget
    FETCH NEXT FROM curCalendarTarget INTO @カレンダー対象日
        WHILE (@@FETCH_STATUS = 0)
        BEGIN
            INSERT INTO #calendar
            EXEC [dbo].[SP_カレンダー取得] @カレンダー対象日

            -- 次のデータをfetch
            FETCH NEXT FROM curCalendarTarget INTO @カレンダー対象日
        END
    CLOSE curCalendarTarget
    DEALLOCATE curCalendarTarget

    -- ############################################################################################################
    -- 顧客実績に営業日数を登録する
    -- ############################################################################################################
    -- DECLARE curUpdateTarget CURSOR FOR
        SELECT
            D_顧客実績.得意先CD,
            D_顧客実績.送り先CD,
            D_顧客実績.売上月,
            M_送り先.土曜設定,
            M_送り先.日曜設定,
            M_送り先.祝日設定,
            M_送り先.個別設定
        FROM
            D_顧客実績
        INNER JOIN M_送り先
            ON  D_顧客実績.得意先CD = M_送り先.得意先CD
            AND D_顧客実績.送り先CD = M_送り先.送り先CD
        WHERE
            D_顧客実績.営業日数 IS NULL













END
GO
