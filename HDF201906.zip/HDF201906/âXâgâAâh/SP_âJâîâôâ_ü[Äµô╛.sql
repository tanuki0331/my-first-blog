IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'SP_カレンダー取得')
    DROP PROCEDURE [dbo].[SP_カレンダー取得]
GO

-- 対象日付が含まれる月のカレンダーを取得する
CREATE PROCEDURE [dbo].[SP_カレンダー取得]
(
    @日付 AS DATE
)
AS
BEGIN

    -- 引数のカレンダーを取得する
    WITH DateTable(MyDate) AS (
    SELECT
        DATEADD(dd, 1, EOMONTH(@日付, -1))
    UNION ALL
    SELECT
        DATEADD(d, 1, MyDate)
    FROM
        DateTable
    WHERE
        MyDate < EOMONTH(@日付)
    )
    SELECT
        FORMAT(MyDate, 'yyyyMM') AS 年月,
        MyDate AS 日付,
        DATEPART(WEEKDAY, MyDate) AS 曜日,
        (SELECT COUNT(*) FROM M_祝日 WHERE 祝日 = MyDate) AS 祝日
    FROM
        DateTable
END
GO

