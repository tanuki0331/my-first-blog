update
  CUSTOMER_USER_DLVY_MAIL cudm
set
  cudm.IS_DELETED = 1
  ,cudm.UPDATED_AT = SYSDATE
  ,cudm.UPDATED_USER = /* updateUser */'a'
where
  cudm.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      cudm.KAISYA_CD = cu.KAISYA_CD
    and
      cudm.GENGO_KBN = cu.GENGO_KBN
    and
      cudm.CUSTOMER_USER_ID = cu.ID
    and
      cu.IS_DELETED != 1
  )
