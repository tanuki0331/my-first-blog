update
  PINV_REPORT pir
set
  pir.IS_DELETED = 1
  ,pir.UPDATED_AT = SYSDATE
  ,pir.UPDATED_USER = /* updateUser */'a'
where
  pir.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      pir.KAISYA_CD = mt.KAISYA_CD
    and
      pir.GENGO_KBN = mt.GENGO_KBN
    and
      pir.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 1
  )
