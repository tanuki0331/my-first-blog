update
  INV_REPORT ir
set
  ir.IS_DELETED = 1
  ,ir.UPDATED_AT = SYSDATE
  ,ir.UPDATED_USER = /* updateUser */'a'
where
  ir.IS_DELETED != 1
and
  not exists (
    -- 仕向け先マスタ
    select
      1
    from
      M_SHIMU ms
    where
      ir.KAISYA_CD = ms.KAISYA_CD
    and
      ir.GENGO_KBN = ms.GENGO_KBN
    and
      ir.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 1
  )
and
  not exists (
    -- 最終仕向け先マスタ
    select
      1
    from
      M_LSHIMU mls
    where
      ir.KAISYA_CD = mls.KAISYA_CD
    and
      ir.GENGO_KBN = mls.GENGO_KBN
    and
      ir.DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 1
  )
