delete from
  PINV_DOWNLOAD_HISTORY
WHERE
  CREATED_AT < /* createdAt */'2018-01-01 00:00:00'
