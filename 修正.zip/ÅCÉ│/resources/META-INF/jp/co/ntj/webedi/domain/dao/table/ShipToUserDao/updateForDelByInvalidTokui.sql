update
  SHIP_TO_USER stu
set
  stu.IS_DELETED = 1
  ,stu.UPDATED_AT = SYSDATE
  ,stu.UPDATED_USER = /* updateUser */'a'
where
  stu.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      stu.KAISYA_CD = mt.KAISYA_CD
    and
      stu.GENGO_KBN = mt.GENGO_KBN
    and
      stu.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 1
  )
