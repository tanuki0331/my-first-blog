update
  OC_DOWNLOAD_HISTORY odh
set
  odh.IS_DELETED = 1
  ,odh.UPDATED_AT = SYSDATE
  ,odh.UPDATED_USER = /* updateUser */'a'
where
  odh.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      odh.KAISYA_CD = mt.KAISYA_CD
    and
      odh.GENGO_KBN = mt.GENGO_KBN
    and
      odh.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 1
  )
