delete from
  OC_REPORT
WHERE
  CREATED_AT < /* createdAt */'2018-01-01 00:00:00'
