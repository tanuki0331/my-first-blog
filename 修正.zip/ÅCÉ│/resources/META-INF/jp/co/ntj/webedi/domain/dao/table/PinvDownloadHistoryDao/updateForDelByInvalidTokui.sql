update
  PINV_DOWNLOAD_HISTORY pdh
set
  pdh.IS_DELETED = 1
  ,pdh.UPDATED_AT = SYSDATE
  ,pdh.UPDATED_USER = /* updateUser */'a'
where
  pdh.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      pdh.KAISYA_CD = mt.KAISYA_CD
    and
      pdh.GENGO_KBN = mt.GENGO_KBN
    and
      pdh.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 1
  )
