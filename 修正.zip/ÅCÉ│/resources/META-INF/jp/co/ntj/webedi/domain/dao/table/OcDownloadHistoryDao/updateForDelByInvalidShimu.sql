update
  OC_DOWNLOAD_HISTORY odh
set
  odh.IS_DELETED = 1
  ,odh.UPDATED_AT = SYSDATE
  ,odh.UPDATED_USER = /* updateUser */'a'
where
  odh.IS_DELETED != 1
and
  not exists (
    -- 仕向け先マスタ
    select
      1
    from
      M_SHIMU ms
    where
      odh.KAISYA_CD = ms.KAISYA_CD
    and
      odh.GENGO_KBN = ms.GENGO_KBN
    and
      odh.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 1
  )
and
  not exists (
    -- 最終仕向け先マスタ
    select
      1
    from
      M_LSHIMU mls
    where
      odh.KAISYA_CD = mls.KAISYA_CD
    and
      odh.GENGO_KBN = mls.GENGO_KBN
    and
      odh.DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 1
  )
