update
  SHIP_TO_USER stu
set
  stu.IS_DELETED = 1
  ,stu.UPDATED_AT = SYSDATE
  ,stu.UPDATED_USER = /* updateUser */'a'
where
  stu.IS_DELETED != 1
and
  not exists (
    -- 仕向け先マスタ
    select
      1
    from
      M_SHIMU ms
    where
      stu.KAISYA_CD = ms.KAISYA_CD
    and
      stu.GENGO_KBN = ms.GENGO_KBN
    and
      stu.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 1
  )
and
  not exists (
    -- 最終仕向け先マスタ
    select
      1
    from
      M_LSHIMU mls
    where
      stu.KAISYA_CD = mls.KAISYA_CD
    and
      stu.GENGO_KBN = mls.GENGO_KBN
    and
      stu.DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 1
  )
