update
  CUSTOMER_USER cu
set
  cu.IS_DELETED = 1
  ,cu.UPDATED_AT = SYSDATE
  ,cu.UPDATED_USER = /* updateUser */'a'
where
  cu.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      cu.KAISYA_CD = mt.KAISYA_CD
    and
      cu.GENGO_KBN = mt.GENGO_KBN
    and
      cu.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 1
  )
