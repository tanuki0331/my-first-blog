select
  /*%expand*/*
from
  PINV_REPORT
where
  IS_DELETED != 1
order by
  KAISYA_CD
  ,GENGO_KBN
  ,CUSTOMER_CODE
  ,DESTINATION_CODE
  ,PINV_NUMBER
