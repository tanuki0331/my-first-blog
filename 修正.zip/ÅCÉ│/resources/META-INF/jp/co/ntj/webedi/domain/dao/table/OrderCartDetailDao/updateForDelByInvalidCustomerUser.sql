update
  ORDER_CART_DETAIL ocd
set
  ocd.IS_DELETED = 1
  ,ocd.UPDATED_AT = SYSDATE
  ,ocd.UPDATED_USER = /* updateUser */'a'
where
  ocd.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      ocd.KAISYA_CD = cu.KAISYA_CD
    and
      ocd.GENGO_KBN = cu.GENGO_KBN
    and
      ocd.CUSTOMER_USER_ID = cu.ID
    and
      cu.IS_DELETED != 1
  )
