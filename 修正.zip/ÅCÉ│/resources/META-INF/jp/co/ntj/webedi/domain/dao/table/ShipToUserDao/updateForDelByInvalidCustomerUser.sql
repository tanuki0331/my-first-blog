update
  SHIP_TO_USER stu
set
  stu.IS_DELETED = 1
  ,stu.UPDATED_AT = SYSDATE
  ,stu.UPDATED_USER = /* updateUser */'a'
where
  stu.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      stu.KAISYA_CD = cu.KAISYA_CD
    and
      stu.GENGO_KBN = cu.GENGO_KBN
    and
      stu.CUSTOMER_USER_ID = cu.ID
    and
      cu.IS_DELETED != 1
  )
