update
  INV_DOWNLOAD_HISTORY idh
set
  idh.IS_DELETED = 1
  ,idh.UPDATED_AT = SYSDATE
  ,idh.UPDATED_USER = /* updateUser */'a'
where
  idh.IS_DELETED != 1
and
  not exists (
    -- 仕向け先マスタ
    select
      1
    from
      M_SHIMU ms
    where
      idh.KAISYA_CD = ms.KAISYA_CD
    and
      idh.GENGO_KBN = ms.GENGO_KBN
    and
      idh.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 1
  )
and
  not exists (
    -- 最終仕向け先マスタ
    select
      1
    from
      M_LSHIMU mls
    where
      idh.KAISYA_CD = mls.KAISYA_CD
    and
      idh.GENGO_KBN = mls.GENGO_KBN
    and
      idh.DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 1
  )
