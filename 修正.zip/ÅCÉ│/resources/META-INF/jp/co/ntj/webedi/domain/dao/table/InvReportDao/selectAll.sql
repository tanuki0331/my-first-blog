select
  /*%expand*/*
from
  INV_REPORT
where
  IS_DELETED != 1
order by
  KAISYA_CD
  ,GENGO_KBN
  ,CUSTOMER_CODE
  ,DESTINATION_CODE
  ,INV_NUMBER
  ,REPORT_CATEGORY
