update
  OC_REPORT ocr
set
  ocr.IS_DELETED = 1
  ,ocr.UPDATED_AT = SYSDATE
  ,ocr.UPDATED_USER = /* updateUser */'a'
where
  ocr.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      ocr.KAISYA_CD = mt.KAISYA_CD
    and
      ocr.GENGO_KBN = mt.GENGO_KBN
    and
      ocr.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 1
  )
