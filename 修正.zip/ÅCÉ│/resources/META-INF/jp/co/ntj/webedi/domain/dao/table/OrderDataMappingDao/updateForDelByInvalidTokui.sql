update
  ORDER_DATA_MAPPING odm
set
  odm.IS_DELETED = 1
  ,odm.UPDATED_AT = SYSDATE
  ,odm.UPDATED_USER = /* updateUser */'a'
where
  odm.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      odm.KAISYA_CD = mt.KAISYA_CD
    and
      odm.GENGO_KBN = mt.GENGO_KBN
    and
      odm.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 1
  )
