update
  SEARCH_CONDITION sc
set
  sc.IS_DELETED = 1
  ,sc.UPDATED_AT = SYSDATE
  ,sc.UPDATED_USER = /* updateUser */'a'
where
  sc.IS_DELETED != 1
and
  not exists (
    -- 仕向け先マスタ
    select
      1
    from
      M_SHIMU ms
    where
      sc.KAISYA_CD = ms.KAISYA_CD
    and
      sc.GENGO_KBN = ms.GENGO_KBN
    and
      sc.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 1
  )
and
  not exists (
    -- 最終仕向け先マスタ
    select
      1
    from
      M_LSHIMU mls
    where
      sc.KAISYA_CD = mls.KAISYA_CD
    and
      sc.GENGO_KBN = mls.GENGO_KBN
    and
      sc.LAST_DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 1
  )
