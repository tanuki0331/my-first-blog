package jp.co.ntj.webedi.batch

import jp.co.ntj.webedi.batch.properties.BatchProperties
import jp.co.ntj.webedi.domain.entity.table.InvReport
import jp.co.ntj.webedi.domain.entity.table.OcReport
import jp.co.ntj.webedi.domain.entity.table.PinvReport
import jp.co.ntj.webedi.domain.service.DeleteInvalidDataService
import org.slf4j.Logger
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Service
import java.nio.file.Files
import java.nio.file.Paths
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

/**
 * 不要ファイル削除バッチ.
 *
 * @author 日立システムズ
 */
@Service
@ConditionalOnProperty(name = ["batch"], havingValue = "DeleteInvalidFile")
class DeleteInvalidFile(
        val deleteInvalidFileService: DeleteInvalidFileService,
        val batchProperties: BatchProperties,
        val batchLogger: Logger) : BaseCommandLineBatch() {

    override fun execute(): Int {
//    val result = deleteFile("C:/file_test") { path: Path ->
//        return@deleteFile path.toFile().absolutePath != "C:\\file_test\\bbb.txt"
//    }
        return 0
    }

    /**
     * 条件を満たす指定ディレクトリ直下のファイルを削除する
     *
     * @param dirPath 削除ファイルが保存されているディレクトリパス
     * @param canDelete 削除条件を満たすかチェックする関数
     * @return 削除結果を表すフラグ
     */
    fun deleteFile(dirPath: String?, canDelete: (Path) -> Boolean): Boolean {

        val dir = dirPath ?: ""
        var deleteCount = 0

        if (dir.isBlank()) {
            // ディレクトリが設定されていない
            return false
        } else if (!Files.isDirectory(Paths.get(dir))) {
            // ディレクトリが存在しない
            return false
        }

        var result = true
        Files.list(Paths.get(dir))
                .filter {
                    // ファイル削除チェック
                    return@filter Files.isRegularFile(it) && canDelete(it)
                }
                .forEach {
                    try {
                        println("★★★★${it.fileName}を削除します")
                        Files.delete(it)
                        deleteCount++
                    } catch (ex: Exception) {
                        // 削除失敗
                        println("${it.fileName}ファイルの削除に失敗しました${ex.message}")
                        result = false
                    }
                }
        println("★完了(${deleteCount}件削除しました)")
        return result
    }

    /**
     * 指定された期間日数から期限となる日付(時間は切り捨て)を取得する
     *
     * @param period 期限日数
     * @return 期限となる日付、ただし日数が空もしくは不正な数値の場合はnullが返却される
     */
    fun calcExpiredDate(period: String): String? {

        if (period.isBlank()) {
            return null
        }

        return try {
            // 現在の日付から期間日数分マイナス
            val baseDate = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS).minusDays(period.toLong())
            baseDate.format(dtf)
        } catch (e: NumberFormatException) {
            null
        }
    }

    /**
     * 指定パスの更新日時を取得する
     *
     * @param path 対象パス
     * @return 更新日時
     */
    fun lastModified(path: Path): String? {

        // ファイルの更新日時を取得
        return if (path.toFile().exists()) {
            sdf.format(path.toFile().lastModified())
        } else {
            null
        }
    }

    /**
     * メッセージをパラメータを使用して展開する
     *
     * @param message メッセージ
     * @param params パラメータ
     * @return 展開後のメッセージ
     */
    fun expandMsg(message: String, vararg params: String): String {
        var result: String = message
        params.forEachIndexed { index, s ->
            result = result.replace("{$index}", s)
        }
        return result
    }
}

