package jp.co.ntj.webedi.mail.test

import jp.co.ntj.webedi.mail.*
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component
import org.springframework.web.context.annotation.RequestScope

/**
 * テストメール.
 *
 * @author 日立システムズ
 */
@Component
@RequestScope
class TestMail(
    private val defaultMailProperties: DefaultMailProperties,
    private val testMailTemplate: TestMailTemplate
) : TemplateMailSender(defaultMailProperties, testMailTemplate) {

  /**
   * 送信.
   * @param toAddress 送信先アドレス
   * @param pageName ページ名
   */
  fun send(toAddress: String, pageName: String) {
    super.send(MailTemplateModel().apply {
      to = listOf(AddressModel(address = toAddress))
    }, pageName)
  }
}

/**
 * テストメールテンプレート.
 *
 * @author 日立システムズ
 */
@Component
@RequestScope
@ConfigurationProperties("mail-template.test")
class TestMailTemplate : MailTemplateModel()