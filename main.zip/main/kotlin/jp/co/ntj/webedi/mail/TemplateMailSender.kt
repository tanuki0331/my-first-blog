package jp.co.ntj.webedi.mail

import com.github.jknack.handlebars.Handlebars
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.core.io.FileSystemResource
import org.springframework.jndi.JndiTemplate
import org.springframework.mail.javamail.JavaMailSenderImpl
import org.springframework.mail.javamail.MimeMessageHelper
import org.springframework.stereotype.Component
import org.springframework.web.context.annotation.RequestScope
import java.nio.file.Paths
import javax.mail.Session
import javax.mail.internet.InternetAddress

/**
 * メール送信.
 *
 * @author 日立システムズ
 */
open class TemplateMailSender(
    /** メールプロパティ. */
    private val mailProperties: MailPropertiesModel,
    /** メールテンプレート. */
    private val mailTemplate: MailTemplateModel
) {

  /** JavaMailSender実装クラス. */
  private val javaMailSenderImpl: JavaMailSenderImpl = JavaMailSenderImpl().apply {
    mailProperties.also {
      defaultEncoding = it.defaultEncoding ?: ""
      protocol = it.protocol ?: ""
      host = it.host ?: ""
      port = it.port ?: 0
      password = it.password ?: ""
      username = it.username ?: ""
      it.jndiName?.let { jndiName ->
        session = JndiTemplate().lookup(jndiName) as Session
      }
      it.properties?.let { prop ->
        javaMailProperties = prop.toProperties()
      }
    }
  }

  /** Handlebars. */
  private val handlebars: Handlebars = Handlebars()

  /**
   * 送信.
   * @param mailParam 送信先など
   * @param mailData 埋め込みデータ
   */
  fun send(mailParam: MailTemplateModel? = null, mailData: Any) {
    javaMailSenderImpl.send { mimeMessage ->
      MimeMessageHelper(mimeMessage, true).apply {
        (mailParam?.let { mergeMailTemplate(it, mailTemplate) } ?: mailTemplate).also { temp ->
          println(mailProperties)
          println(mailProperties.defaultEncoding)
          println(mailTemplate)
          println(mailTemplate.from)
          temp.from?.forEach { setFrom(InternetAddress(it.address, it.name)) }
          temp.to?.forEach { addTo(InternetAddress(it.address, it.name)) }
          temp.cc?.forEach { addCc(InternetAddress(it.address, it.name)) }
          temp.bcc?.forEach { addBcc(InternetAddress(it.address, it.name)) }
          temp.replyTo?.let { setReplyTo(InternetAddress(it.address, it.name)) }
          temp.attachment?.forEach { filePath ->
            val path = Paths.get(filePath).normalize()
            addAttachment(path.fileName.toString(), FileSystemResource(path))
          }
          temp.subject?.let {
            setSubject(handlebars.compileInline(temp.subject).apply(mailData))
          }
          temp.text?.let {
            setText(handlebars.compileInline(temp.text).apply(mailData))
          }
        }
      }
    }
  }

  /**
   * テンプレートのマージ.
   * @param src 元
   * @param merged マージされる
   */
  private fun mergeMailTemplate(src: MailTemplateModel, merged: MailTemplateModel) = src.apply {
    from = from?.let { srcData ->
      merged.from?.let { mergedData ->
        listOf(*srcData.toTypedArray(), *mergedData.toTypedArray())
      } ?: from
    } ?: merged.from
    to = to?.let { srcData ->
      merged.to?.let { mergedData ->
        listOf(*srcData.toTypedArray(), *mergedData.toTypedArray())
      } ?: to
    } ?: merged.to
    cc = cc?.let { srcData ->
      merged.cc?.let { mergedData ->
        listOf(*srcData.toTypedArray(), *mergedData.toTypedArray())
      } ?: cc
    } ?: merged.cc
    bcc = bcc?.let { srcData ->
      merged.bcc?.let { mergedData ->
        listOf(*srcData.toTypedArray(), *mergedData.toTypedArray())
      } ?: bcc
    } ?: merged.bcc
    attachment = attachment?.let { srcData ->
      merged.attachment?.let { mergedData ->
        listOf(*srcData.toTypedArray(), *mergedData.toTypedArray())
      } ?: attachment
    } ?: merged.attachment
    subject = subject ?: merged.subject
    text = text ?: merged.text
  }

}

/**
 * Defaultメール設定.
 *
 * @author 日立システムズ
 */
@Component
@RequestScope
@ConfigurationProperties("mail-config.send.default")
class DefaultMailProperties : MailPropertiesModel()

/**
 * メールプロパティインタフェース.
 *
 * @author 日立システムズ
 */
open class MailPropertiesModel {

  /** Defaultエンコード. */
  open var defaultEncoding: String? = null
  /** プロトコル. */
  open var protocol: String? = null
  /** ホスト名. */
  open var host: String? = null
  /** ポート番号. */
  open var port: Int? = null
  /** JNDI名. */
  open var jndiName: String? = null
  /** パスワード. */
  open  var password: String? = null
  /** ユーザー名. */
  open var username: String? = null
  /** プロパティマップ. */
  open var properties: Map<String, String>? = null

  override fun toString(): String {
    return "defaultEncoding=$defaultEncoding" +
        ", protocol=$protocol" +
        ", host=$host" +
        ", port=$port" +
        ", jndiName=$jndiName" +
        ", password=$password" +
        ", username=$username" +
        ", properties=$properties"
  }
}

/**
 * メールテンプレートモデル.
 *
 * @author 日立システムズ
 */
open class MailTemplateModel {

  /** From. */
  open var from: List<AddressModel>? = null
  /** To. */
  open var to: List<AddressModel>? = null
  /** Cc. */
  open var cc: List<AddressModel>? = null
  /** Bcc. */
  open var bcc: List<AddressModel>? = null
  /** Reply-To. */
  open var replyTo: AddressModel? = null
  /** 添付. */
  open var attachment: List<String>? = null
  /** 件名. */
  open var subject: String? = null
  /** 本文. */
  open var text: String? = null

  override fun toString(): String {
    return "from=$from" +
        ", to=$to" +
        ", cc=$cc" +
        ", bcc=$bcc" +
        ", replyTo=$replyTo" +
        ", attachment=$attachment" +
        ", subject=$subject" +
        ", text=$text"
  }
}

/**
 * アドレスモデル.
 *
 * @author 日立システムズ
 */
data class AddressModel(
    var name: String? = null,
    var address: String = ""
)

