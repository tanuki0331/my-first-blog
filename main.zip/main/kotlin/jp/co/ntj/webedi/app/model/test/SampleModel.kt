package jp.co.ntj.webedi.app.model.test

import org.jetbrains.annotations.NotNull

data class SampleModel(
    @field: NotNull()
    val testId: String,
    @field: NotNull
    val testCode: Long
)