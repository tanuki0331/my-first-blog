package jp.co.ntj.webedi.app.model.account

import java.time.ZonedDateTime

/**
 * 社員認証モデル.
 *
 * @author 日立システムズ
 */
data class EmployeeAuthResponseModel(
    /** 社員ID. */
    val employeeId: String,
    /** 名前. */
    val name: String,
    /** 前回ログイン時刻. */
    val prevLoginAt: ZonedDateTime? = null
)