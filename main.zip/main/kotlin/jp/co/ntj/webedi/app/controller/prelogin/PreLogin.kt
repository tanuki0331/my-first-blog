package jp.co.ntj.webedi.app.controller.prelogin

import jp.co.ntj.webedi.app.model.ResponseModel
import org.springframework.security.web.csrf.DefaultCsrfToken
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import javax.servlet.http.HttpServletRequest

/**
 * プレログインコントローラー.
 */
@RestController
@RequestMapping("pre-login")
class PreLogin {

  /**
   * トークン取得.
   */
  @GetMapping
  fun getToken(request: HttpServletRequest): ResponseModel {
    val token = request.getAttribute("_csrf") as DefaultCsrfToken
    return ResponseModel.success(data = token.token)
  }
}