package jp.co.ntj.webedi.app.controller.advice

import jp.co.ntj.webedi.app.model.MessageModel
import jp.co.ntj.webedi.app.model.ResponseModel
import jp.co.ntj.webedi.properties.MessagePropertiesName
import org.slf4j.Logger
import org.springframework.beans.ConversionNotSupportedException
import org.springframework.beans.TypeMismatchException
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.http.converter.HttpMessageNotReadableException
import org.springframework.http.converter.HttpMessageNotWritableException
import org.springframework.validation.BindException
import org.springframework.validation.FieldError
import org.springframework.web.HttpMediaTypeNotAcceptableException
import org.springframework.web.HttpMediaTypeNotSupportedException
import org.springframework.web.HttpRequestMethodNotSupportedException
import org.springframework.web.bind.MethodArgumentNotValidException
import org.springframework.web.bind.MissingPathVariableException
import org.springframework.web.bind.MissingServletRequestParameterException
import org.springframework.web.bind.ServletRequestBindingException
import org.springframework.web.bind.annotation.RestControllerAdvice
import org.springframework.web.context.request.WebRequest
import org.springframework.web.context.request.async.AsyncRequestTimeoutException
import org.springframework.web.multipart.support.MissingServletRequestPartException
import org.springframework.web.servlet.NoHandlerFoundException
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler


/**
 * RestController用例外ハンドラ.
 *
 * @author 日立システムズ
 */
@RestControllerAdvice
class RestControllerExceptionHandler(val webLogger: Logger) :
    ResponseEntityExceptionHandler() {

  /**
   * 共通処理.
   */
  override fun handleExceptionInternal(ex: Exception, body: Any?, headers: HttpHeaders,
      status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleExceptionInternal", ex)
    return super.handleExceptionInternal(ex, body, headers, status, request)
  }

  /**
   * Validation例外ハンドラ.
   */
  override fun handleMethodArgumentNotValid(ex: MethodArgumentNotValidException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleMethodArgumentNotValid", ex)
    return handleExceptionInternal(ex,
        ResponseModel.error(buildMessageModels(ex.bindingResult.fieldErrors)), headers,
        HttpStatus.OK, request)
    // return super.handleMethodArgumentNotValid(ex, headers, status, request)
  }

  /**
   * バインド例外ハンドラ.
   */
  override fun handleBindException(ex: BindException, headers: HttpHeaders, status: HttpStatus,
      request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleBindException", ex)
    return handleExceptionInternal(ex, ResponseModel.error(buildMessageModels(ex.bindingResult.fieldErrors)), headers, HttpStatus.OK, request)
    // return super.handleBindException(ex, headers, status, request)
  }

  /**
   * Httpメッセージ読み込み例外ハンドラ.
   * Jsonのマッピングエラーなど
   */
  override fun handleHttpMessageNotReadable(ex: HttpMessageNotReadableException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleHttpMessageNotReadable", ex)
    return handleExceptionInternal(ex, ResponseModel.error(MessagePropertiesName.MA0001), headers,
        HttpStatus.BAD_REQUEST, request)
    // return super.handleHttpMessageNotReadable(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleAsyncRequestTimeoutException(ex: AsyncRequestTimeoutException,
      headers: HttpHeaders, status: HttpStatus, webRequest: WebRequest): ResponseEntity<Any>? {
    webLogger.error("handleAsyncRequestTimeoutException", ex)
    return super.handleAsyncRequestTimeoutException(ex, headers, status, webRequest)
  }

  /**
   * .
   */
  override fun handleConversionNotSupported(ex: ConversionNotSupportedException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleConversionNotSupported", ex)
    return super.handleConversionNotSupported(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleHttpMediaTypeNotAcceptable(ex: HttpMediaTypeNotAcceptableException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleHttpMediaTypeNotAcceptable", ex)
    return super.handleHttpMediaTypeNotAcceptable(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleHttpMediaTypeNotSupported(ex: HttpMediaTypeNotSupportedException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleHttpMediaTypeNotSupported", ex)
    return super.handleHttpMediaTypeNotSupported(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleHttpMessageNotWritable(ex: HttpMessageNotWritableException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleHttpMessageNotWritable", ex)
    return super.handleHttpMessageNotWritable(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleHttpRequestMethodNotSupported(ex: HttpRequestMethodNotSupportedException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleHttpRequestMethodNotSupported", ex)
    return super.handleHttpRequestMethodNotSupported(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleMissingPathVariable(ex: MissingPathVariableException, headers: HttpHeaders,
      status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleMissingPathVariable", ex)
    return super.handleMissingPathVariable(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleMissingServletRequestParameter(ex: MissingServletRequestParameterException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleMissingServletRequestParameter", ex)
    return super.handleMissingServletRequestParameter(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleMissingServletRequestPart(ex: MissingServletRequestPartException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleMissingServletRequestPart", ex)
    return super.handleMissingServletRequestPart(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleNoHandlerFoundException(ex: NoHandlerFoundException, headers: HttpHeaders,
      status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleNoHandlerFoundException", ex)
    return super.handleNoHandlerFoundException(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleServletRequestBindingException(ex: ServletRequestBindingException,
      headers: HttpHeaders, status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleServletRequestBindingException", ex)
    return super.handleServletRequestBindingException(ex, headers, status, request)
  }

  /**
   * .
   */
  override fun handleTypeMismatch(ex: TypeMismatchException, headers: HttpHeaders,
      status: HttpStatus, request: WebRequest): ResponseEntity<Any> {
    webLogger.error("handleTypeMismatch", ex)
    return super.handleTypeMismatch(ex, headers, status, request)
  }

  /**
   * メッセージ構築.
   * @param fieldErrors フィールドエラー配列
   * @return メッセージモデル
   */
  private fun buildMessageModels(fieldErrors: List<FieldError>) = fieldErrors.map { fieldError ->
    buildMessageModel(fieldError)
  }

  /**
   * メッセージ構築.
   * @param fieldError フィールドエラー
   * @return メッセージモデル
   */
  private fun buildMessageModel(fieldError: FieldError) = fieldError.run {
    val tmpMsg = defaultMessage ?: ""
    if (tmpMsg.isBlank()) {
      MessageModel(MessagePropertiesName.MA0001)
    } else {
      if (tmpMsg.matches("^M[AWECI]\\d{4}".toRegex())) {
        // メッセージID
        val tmpArgs = arguments?.drop(1)?.reversed()?.map { it.toString() } ?: emptyList()
        MessageModel.create(tmpMsg, field, *tmpArgs.toTypedArray())
      } else {
        // その他メッセージ
        MessageModel(messageId = "", message = tmpMsg)
      }
    }
  }
}