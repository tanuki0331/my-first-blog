package jp.co.ntj.webedi.app.controller.destination

import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

/**
 * 仕向先コントローラー.
 *
 * @author 日立システムズ
 */
@RestController
@RequestMapping("destination")
class DestinationController {



}