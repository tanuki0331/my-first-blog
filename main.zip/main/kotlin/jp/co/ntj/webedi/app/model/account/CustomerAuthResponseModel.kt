package jp.co.ntj.webedi.app.model.account

import java.time.ZonedDateTime

/**
 * 得意先認証モデル.
 *
 * @author 日立システムズ
 */
data class CustomerAuthResponseModel(
    /** ユーザーID. */
    val userId: String,
    /** 名前. */
    val name: String,
    /** 前回ログイン時刻. */
    val prevLoginAt: ZonedDateTime? = null,
    /** パスワード変更フラグ. */
    val isInitPassword: Boolean,
    /** 国内納入日表示有効フラグ. */
    val isValidatedDomesticDlvy: Boolean,
    /** 商品一覧表示有効フラグ. */
    val isValidatedProductList: Boolean,
    /** 商品情報URL. */
    val productInfoUrl: String,
    /** カート件数. */
    val cartItemCount: Int,
    /** 代理ログインか. */
    val isProxyLogin: Boolean
)