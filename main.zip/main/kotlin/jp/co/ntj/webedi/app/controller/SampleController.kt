package jp.co.ntj.webedi.app.controller

import jp.co.ntj.webedi.app.model.MessageModel
import jp.co.ntj.webedi.app.model.ResponseModel
import jp.co.ntj.webedi.app.model.ResponseResult
import jp.co.ntj.webedi.app.model.test.SampleModel
import jp.co.ntj.webedi.domain.dto.test.SampleDto
import jp.co.ntj.webedi.domain.service.SampleService
import jp.co.ntj.webedi.domain.service.account.CustomerAccountService
import jp.co.ntj.webedi.domain.service.message.MessageService
import jp.co.ntj.webedi.mail.test.TestMail
import jp.co.ntj.webedi.mail.test.TestMailTemplate
import jp.co.ntj.webedi.security.authentication.model.WebUserDetails
import org.slf4j.Logger
import org.springframework.security.core.annotation.AuthenticationPrincipal
import org.springframework.validation.BindingResult
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*
import java.sql.Timestamp
import java.time.LocalDateTime
import java.time.ZonedDateTime
import java.util.*

@RestController
@RequestMapping("sample")
class SampleController(
    val sampleService: SampleService,
    val logger: Logger,
    val messageService: MessageService,
    val customerAccountService: CustomerAccountService,
    val testMail: TestMail
) {

  @RequestMapping("test")
  fun testGet(): ResponseModel {
    return try {
      val tests: List<SampleDto> = sampleService.getTests()
      logger.debug(tests.toString())
      ResponseModel(data = tests)
    } catch (e: Throwable) {
      logger.error(e.message, e)
      ResponseModel(ResponseResult.Error)
    }
  }

  @PostMapping("testadd")
  fun testAdd(@RequestBody @Validated sampleModel: SampleModel,
      bindingResult: BindingResult): ResponseModel {
    return if (bindingResult.hasErrors()) {
      ResponseModel(ResponseResult.Error, data = bindingResult.allErrors.toString())
    } else {
      var (testId: String, testCode: Long) = sampleModel
      try {
        sampleService.addTest(testId, testCode)
        ResponseModel()
      } catch (e: Throwable) {
        ResponseModel(ResponseResult.Error, data = e)
      }
    }
  }

  @PostMapping("testadderror")
  fun testAddError(@RequestBody @Validated sampleModel: SampleModel,
      bindingResult: BindingResult): ResponseModel {
    return if (bindingResult.hasErrors()) {
      ResponseModel(ResponseResult.Error, data = bindingResult.allErrors.toString())
    } else {
      var (testId: String, testCode: Long) = sampleModel
      try {
        sampleService.addTest(testId, testCode, true)
        ResponseModel()
      } catch (e: Throwable) {
        ResponseModel(ResponseResult.Error, data = e)
      }
    }
  }

  @GetMapping
  fun get() = ResponseModel(messages = listOf(MessageModel("ME0001")))

  @GetMapping("getProp")
  fun getProp(): ResponseModel {
    return ResponseModel(data = messageService.buildMessage("ME0001"))
  }

  @GetMapping("date")
  fun date() = ResponseModel.success(listOf(Date(),
      Timestamp.from(ZonedDateTime.now().toInstant()),
      ZonedDateTime.now(),
      LocalDateTime.now()))

  @GetMapping("customer")
  fun customer() = ResponseModel.success(
      customerAccountService.searchUser("0000100917000") ?: false)

  @GetMapping("mail")
  fun sendMail(): ResponseModel {
    testMail.send("kouta.takahashi@hcs-hd.co.jp","ほげ")
    logger.debug("mail end")
    return ResponseModel.success()
  }

  @GetMapping("account")
  fun getAccount(@AuthenticationPrincipal account: WebUserDetails) = ResponseModel.success(account)
}