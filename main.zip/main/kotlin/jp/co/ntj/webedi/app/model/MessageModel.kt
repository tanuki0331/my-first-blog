package jp.co.ntj.webedi.app.model

import jp.co.ntj.webedi.properties.MessagePropertiesName
import org.springframework.validation.FieldError

/**
 * メッセージモデル.
 *
 * @author 日立システムズ
 */
data class MessageModel(
    /** メッセージID. */
    val messageId: String,
    /** 辞書キー. */
    val dictionaryKeys: List<String>? = null,
    /** メッセージ. */
    val message: String? = null
) {

  /**  ファクトリ. */
  companion object Factory {

    /**
     * インスタンス作成.
     * @param messageId メッセージID
     * @param dictionaryKeys 辞書キー
     */
    fun create(messageId: String, vararg dictionaryKeys: String) = if (dictionaryKeys.isNotEmpty()) {
      MessageModel(messageId, listOf(*dictionaryKeys))
    } else {
      MessageModel(messageId)
    }
  }
}

