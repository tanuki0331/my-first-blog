package jp.co.ntj.webedi.app.model

/**
 * レスポンスモデル.
 *
 * @author 日立システムズ
 */
data class ResponseModel(
    /** 結果. */
    val result: ResponseResult = ResponseResult.Success,
    /** メッセージモデル. */
    val messages: List<MessageModel>? = null,
    /** 返送データ. */
    val data: Any? = null

) {

  /** ファクトリ. */
  companion object Factory {

    /**
     * 成功.
     * @return レスポンスモデル（成功）
     */
    fun success() = ResponseModel(ResponseResult.Success)

    /**
     * 成功.
     * @param data 返送データ
     * @return レスポンスモデル（成功）
     */
    fun success(data: Any) = ResponseModel(ResponseResult.Success, data = data)

    /**
     * 成功.
     * @param messageId メッセージID
     * @param dictionaryKeys 辞書キー
     * @return レスポンスモデル（成功）
     */
    fun success(messageId: String, vararg dictionaryKeys: String) = ResponseModel(
        ResponseResult.Success, listOf(MessageModel.create(messageId, *dictionaryKeys)))

    /**
     * 成功.
     * @param messages メッセージ
     * @return レスポンスモデル（成功）
     */
    fun success(vararg messages: MessageModel) = ResponseModel(ResponseResult.Success,
        listOf(*messages))

    /**
     * 成功.
     * @param messageId メッセージID
     * @param dictionaryKeys 辞書キー
     * @param data 返送データ
     * @return レスポンスモデル（成功）
     */
    fun success(messageId: String, vararg dictionaryKeys: String, data: Any) = ResponseModel(
        ResponseResult.Success, listOf(MessageModel.create(messageId, *dictionaryKeys)), data)

    /**
     * 成功.
     * @param messages メッセージ
     * @param data 返送データ
     * @return レスポンスモデル（成功）
     */
    fun success(vararg messages: MessageModel, data: Any) = ResponseModel(
        ResponseResult.Success, listOf(*messages), data)

    /**
     * エラー.
     * @return レスポンスモデル（エラー）
     */
    fun error() = ResponseModel(ResponseResult.Error)

    /**
     * エラー.
     * @param data 返送データ
     * @return レスポンスモデル（エラー）
     */
    fun error(data: Any) = ResponseModel(ResponseResult.Error, data = data)

    /**
     * エラー.
     * @param messageId メッセージID
     * @param dictionaryKeys 辞書キー
     * @return レスポンスモデル（エラー）
     */
    fun error(messageId: String, vararg dictionaryKeys: String) = ResponseModel(
        ResponseResult.Error, listOf(MessageModel.create(messageId, *dictionaryKeys)))

    /**
     * エラー.
     * @param messages メッセージ
     * @return レスポンスモデル（エラー）
     */
    fun error(vararg messages: MessageModel) = ResponseModel(ResponseResult.Error,
        listOf(*messages))

    /**
     * エラー.
     * @param messageId メッセージID
     * @param dictionaryKeys 辞書キー
     * @param data 返送データ
     * @return レスポンスモデル（エラー）
     */
    fun error(messageId: String, vararg dictionaryKeys: String, data: Any) = ResponseModel(
        ResponseResult.Error, listOf(MessageModel.create(messageId, *dictionaryKeys)), data)

    /**
     * エラー.
     * @param messages メッセージ
     * @param data 返送データ
     * @return レスポンスモデル（エラー）
     */
    fun error(vararg messages: MessageModel, data: Any) = ResponseModel(
        ResponseResult.Error, listOf(*messages), data)
  }
}

/**
 * レスポンス結果.
 *
 * @author 日立システムズ
 */
enum class ResponseResult {

  /** 成功. */
  Success,
  /** エラー. */
  Error
}
