package jp.co.ntj.webedi.app.controller

import jp.co.ntj.webedi.app.model.ResponseModel
import jp.co.ntj.webedi.security.authentication.model.WebAccount
import jp.co.ntj.webedi.security.authentication.model.WebUserDetails
import org.springframework.security.core.annotation.AuthenticationPrincipal
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

/**
 * .
 *
 * @author 日立システムズ
 */
@RestController
@RequestMapping("test")
class TestController(
    val webAccount: WebAccount
) {

  @GetMapping("account")
  fun getAccount(@AuthenticationPrincipal account: WebUserDetails) = ResponseModel.success(account)


  @GetMapping("user")
  fun getUser() = ResponseModel.success(webAccount.customerAccount!!)
}