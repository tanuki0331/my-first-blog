package jp.co.ntj.webedi.domain.service.account

import jp.co.ntj.webedi.domain.dao.account.EmployeeAccountDao
import jp.co.ntj.webedi.domain.service.account.model.EmployeeAccountModel
import org.springframework.stereotype.Service
import java.math.BigDecimal
import java.time.ZonedDateTime

/**
 * 社員ユーザーサービス.
 *
 * @author 日立システムズ
 */
@Service
class EmployeeAccountService(
    private val employeeAccountDao: EmployeeAccountDao
) : AccountService() {

  /**
   * ユーザー検索.
   * @param employeeId 社員ID
   */
  fun searchUser(employeeId: String) = employeeAccountDao.selectEmployeeUserByEmployeeId(
      employeeId)?.run {
    EmployeeAccountModel(
        kaisyaCd = kaisyaCd,
        gengoKbn = gengoKbn,
        id = id,
        employeeId = this.employeeId,
        name = name,
        password = password,
        mailAddress = mailAddress,
        isValidatedUser = isValidatedUser.isValid,
        sessionId = sessionId,
        lastOperationAt = lastOperationAt?.let { ZonedDateTime.from(it.toInstant()) },
        loginAt = loginAt?.let { ZonedDateTime.from(it.toInstant()) },
        prevLoginAt = prevLoginAt?.let { ZonedDateTime.from(it.toInstant()) },
        hostName = hostName,
        accessIp = accessIp,
        userAgent = userAgent,
        authorities = employeeAccountDao.selectEmployeeAuthority(kaisyaCd, gengoKbn,
            id).map { it.authority }
    )
  }

  /**
   * ユーザー検索.
   * @param kaisyaCd 会社コード
   * @param gengoKbn 言語区分
   * @param id id
   */
  fun searchUser(kaisyaCd: String, gengoKbn: String,
      id: BigDecimal) = employeeAccountDao.selectEmployeeUserById(kaisyaCd, gengoKbn, id)?.run {
    EmployeeAccountModel(
        kaisyaCd = kaisyaCd,
        gengoKbn = gengoKbn,
        id = id,
        employeeId = this.employeeId,
        name = name,
        password = password,
        mailAddress = mailAddress,
        isValidatedUser = isValidatedUser.isValid,
        sessionId = sessionId,
        lastOperationAt = lastOperationAt?.let { ZonedDateTime.from(it.toInstant()) },
        loginAt = loginAt?.let { ZonedDateTime.from(it.toInstant()) },
        prevLoginAt = prevLoginAt?.let { ZonedDateTime.from(it.toInstant()) },
        hostName = hostName,
        accessIp = accessIp,
        userAgent = userAgent,
        authorities = employeeAccountDao.selectEmployeeAuthority(kaisyaCd, gengoKbn,
            id).map { it.authority }
    )
  }
}