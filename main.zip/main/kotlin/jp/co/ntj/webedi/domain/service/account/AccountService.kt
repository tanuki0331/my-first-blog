package jp.co.ntj.webedi.domain.service.account

import jp.co.ntj.webedi.domain.service.account.model.AccountModelInterface
import java.time.Duration
import java.time.ZonedDateTime

/**
 * Accountサービス.
 *
 * @author 日立システムズ
 */
abstract class AccountService {

  /**
   * ログイン中か.
   * @param account Account
   * @param nowSessionId セッションID
   */
  fun isLogin(account: AccountModelInterface, nowSessionId: String): Boolean = account.run {
    sessionId?.let { storeSessionId ->
      storeSessionId != nowSessionId && lastOperationAt?.let { storeLastOperationAt ->
        Duration.between(storeLastOperationAt, ZonedDateTime.now()).abs() < Duration.parse("PT30M")
      } ?: false
    } ?: false

    // セッションIDが空　=>　ログインされていない
    // セッションID有り
    // 　現在のセッションIDと同じ
    // 　
    // 　現在のセッションIDと違う

  }

  /**
   * 有効なユーザーか.
   * @param account Account
   */
  fun isValidUser(account: AccountModelInterface): Boolean = account.isValidatedUser
}