package jp.co.ntj.webedi.domain.service.account.model

import java.math.BigDecimal
import java.time.ZonedDateTime

/**
 * 得意先アカウントモデル.
 *
 * @author 日立システムズ
 */
data class CustomerAccountModel(
    /** 会社コード. */
    override val kaisyaCd: String,
    /** 言語区分. */
    override val gengoKbn: String,
    /** ID. */
    override val id: BigDecimal,
    /** ユーザーID. */
    val userId: String,
    /** 得意先コード. */
    val customerCode: Long,
    /** 氏名. */
    override val name: String,
    /** パスワード. */
    override val password: String,
    /** パスワード変更フラグ. */
    val isInitPassword: Boolean,
    /** メールアドレス. */
    override val mailAddress: String,
    /** 注文登録メール有効フラグ. */
    val useOrderMail: Boolean,
    /** OC発行メール有効フラグ. */
    val isValidatedOcIssueMail: Boolean,
    /** INV発行メール有効フラグ. */
    val isValidatedInvIssueMail: Boolean,
    /** P/I発行メール有効フラグ. */
    val isValidatedPinvIssueMail: Boolean,
    /** 国内納入日表示有効フラグ. */
    val isValidatedDomesticDlvy: Boolean,
    /** 商品一覧表示有効フラグ. */
    val isValidatedProductList: Boolean,
    /** ユーザー有効フラグ. */
    override val isValidatedUser: Boolean,
    /** セッションID. */
    override val sessionId: String? = null,
    /** 最終操作日時. */
    override val lastOperationAt: ZonedDateTime? = null,
    /** ログイン日時. */
    override val loginAt: ZonedDateTime? = null,
    /** 前回ログイン日時. */
    override val prevLoginAt: ZonedDateTime? = null,
    /** ホスト名. */
    override val hostName: String? = null,
    /** アクセスIP. */
    override val accessIp: String? = null,
    /** ユーザーエージェント. */
    override val userAgent: String? = null,
    /** 代理ログインか. */
    val isProxyLogin: Boolean,
    /** 商品情報URL. */
    val productInfoUrl: String,
    /** カート件数. */
    val cartItemCount: Int,
    /** 権限. */
    override val authorities: List<String>,
    /** 追加メール. */
    val deliveryMails: List<CustomerAccountMailModel>? = null
) : AccountModelInterface

/**
 * 得意先アカウントメールモデル.
 *
 * @author 日立システムズ
 */
data class CustomerAccountMailModel(
    /** 連番. */
    val sequenceNumber: Short,
    /** メールアドレス. */
    val mailAddress: String,
    /** 注文登録メール有効フラグ. */
    val useOrderMail: Boolean,
    /** OC発行メール有効フラグ. */
    val isValidatedOcIssueMail: Boolean,
    /** INV発行メール有効フラグ. */
    val isValidatedInvIssueMail: Boolean,
    /** P/I発行メール有効フラグ. */
    val isValidatedPinvIssueMail: Boolean
)