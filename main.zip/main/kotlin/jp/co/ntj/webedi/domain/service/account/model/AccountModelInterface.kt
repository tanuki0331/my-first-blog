package jp.co.ntj.webedi.domain.service.account.model

import java.math.BigDecimal
import java.time.ZonedDateTime

/**
 * Accountモデルインタフェース.
 *
 * @author 日立システムズ
 */
interface AccountModelInterface {
  /** 会社コード. */
  val kaisyaCd: String
  /** 言語区分. */
  val gengoKbn: String
  /** ID. */
  val id: BigDecimal
  /** 氏名. */
  val name: String
  /** パスワード. */
  val password: String
  /** メールアドレス. */
  val mailAddress: String
  /** ユーザー有効フラグ. */
  val isValidatedUser: Boolean
  /** セッションID. */
  val sessionId: String?
  /** 最終操作日時. */
  val lastOperationAt: ZonedDateTime?
  /** ログイン日時. */
  val loginAt: ZonedDateTime?
  /** 前回ログイン日時. */
  val prevLoginAt: ZonedDateTime?
  /** ホスト名. */
  val hostName: String?
  /** アクセスIP. */
  val accessIp: String?
  /** ユーザーエージェント. */
  val userAgent: String?
  /** 権限. */
  val authorities: List<String>
}