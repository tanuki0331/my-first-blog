package jp.co.ntj.webedi.domain.model

/**
 * レスポンスデータ.
 *
 * @author 日立システムズ
 */
data class ResponseData(
    /** 結果. */
    val result: String = "success",
    /** メッセージID. */
    val messageId: String = "",
    /** 返送データ. */
    val data: Any = ""
)