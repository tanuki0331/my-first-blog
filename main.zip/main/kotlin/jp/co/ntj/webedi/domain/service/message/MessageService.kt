package jp.co.ntj.webedi.domain.service.message

import org.springframework.core.env.Environment
import org.springframework.stereotype.Service

/**
 * メッセージサービス.
 *
 * @author 日立システムズ
 */
@Service
class MessageService(private val environment: Environment) {

  /**
   * メッセージ構築.
   * @param messageId メッセージID
   * @param labelKye ラベルキー
   * @return メッセージ、未定義の場合はメッセージID
   */
  fun buildMessage(messageId: String, vararg labelKye: String): String {
    return getMessage(messageId)?.let {
      var tmp = it
      getLabels(*labelKye).forEachIndexed { index, value -> tmp = tmp.replace("\\{$index\\}".toRegex(), value) }
      tmp
    } ?: messageId
  }

  /**
   * メッセージ取得.
   * @param messageId メッセージID
   * @return メッセージ未定義の場合はメッセージIDを返す
   */
  private fun getMessage(messageId: String) = environment.getProperty("message.$messageId")

  /**
   * ラベル取得.
   * @param labelKyes ラベルキー
   * @return ラベル、未定義のラベルはラベルキー
   */
  private fun getLabels(vararg labelKye: String): List<String> {
    return if (labelKye.isNotEmpty()) {
      labelKye.map {
        environment.getProperty("label.$it") ?: it
      }
    } else {
      emptyList()
    }
  }
}