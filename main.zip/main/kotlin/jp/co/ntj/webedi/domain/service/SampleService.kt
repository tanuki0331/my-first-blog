package jp.co.ntj.webedi.domain.service

import jp.co.ntj.webedi.domain.dao.test.SampleDao
import jp.co.ntj.webedi.domain.dto.test.SampleDto
import org.slf4j.Logger
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.sql.Timestamp
import java.util.Date

@Service
class SampleService(val sampleDao: SampleDao, val logger: Logger) {

  fun getTests() = sampleDao.selectAll()

  @Transactional
  fun addTest(testId: String, testCode: Long, isError: Boolean = false): Int {
    val sampleDto = SampleDto()
    sampleDto.kaisyaCd = "1000"
    sampleDto.gengoKbn = "EN"
    sampleDto.testId = testId
    sampleDto.testCode = testCode
    sampleDto.isDeleted = 0
    sampleDto.createdAt = Timestamp(Date().time)
    sampleDto.createdUser = "TEST"
    sampleDto.updatedAt = Timestamp(Date().time)
    sampleDto.updatedUser = "TEST"
    val result = sampleDao.insert(sampleDto)
    return if (isError) {
      logger.error("isError!")
      throw RuntimeException()
    } else result
  }
}