package jp.co.ntj.webedi.service

import jp.co.ntj.webedi.domain.dao.*
import jp.co.ntj.webedi.domain.dao.table.EmployeeUserDao
import jp.co.ntj.webedi.domain.dao.table.InvReportDao
import jp.co.ntj.webedi.domain.dao.table.ProcessExecuteTimeDao
import jp.co.ntj.webedi.domain.entity.table.InvReport
import jp.co.ntj.webedi.domain.entity.table.OcConfirmation
import jp.co.ntj.webedi.domain.entity.table.ProcessExecuteTime
import org.slf4j.Logger
import org.springframework.stereotype.Service

import jp.co.ntj.webedi.domain.entity.table.OcReport
import org.apache.commons.lang3.StringUtils
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@Service
class LoadFormDataInvService(
    val processExecuteTimeDao: ProcessExecuteTimeDao,
    val invReportDao: InvReportDao,
    val employeeUserDao: EmployeeUserDao,
    val logger: Logger
) {
  val processCategory = "PROC0002" // 処理区分

  /**
   * 処理実行時刻を取得する
   */
  fun getProcessExecuteTime():String {
    var time : ProcessExecuteTime?  = processExecuteTimeDao.selectById("0000","JP", processCategory)
    if (time != null) {
      return time.executeAt.substring(0, 19)
    } else {
      return ""
    }
  }

  /**
   * 処理実行時刻を更新する
   */
  fun saveProcessExecuteTime() {
    var datetime = LocalDateTime.now()
    var zoneDatetime = ZonedDateTime.of(datetime,  ZoneId.systemDefault())
    var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssXXX")
    var datetimestr = formatter.format(zoneDatetime)

    var processExecuteTime = ProcessExecuteTime()
    processExecuteTime.kaisyaCd = "0000"//TODO 暫定
    processExecuteTime.gengoKbn = "JP"
    processExecuteTime.processCategory = processCategory
    processExecuteTime.executeAt = datetimestr
    processExecuteTime.isDeleted = 0
    processExecuteTime.createdUser = "SYSTEM"
    processExecuteTime.createdAt = datetimestr
    processExecuteTime.updatedUser = "SYSTEM"
    processExecuteTime.updatedAt = datetimestr

    var time = getProcessExecuteTime()
    if (StringUtils.isEmpty(time)) {
      processExecuteTimeDao.insert(processExecuteTime)
    } else {
      processExecuteTimeDao.update(processExecuteTime)
    }
  }

  /**
   * Invoice帳票データを取得
    */
  fun getInvReport(kaisyaCd: String,
                   gengoKbn: String,
                   customerCode: Long,
                   destinationCode: Long,
                   invNumber: String,
                   reportCategory: String): InvReport? {
    return  invReportDao.selectById(kaisyaCd, gengoKbn, customerCode, destinationCode, invNumber, reportCategory)
  }

  /**
   * Invoice帳票データを登録
   */
  fun insertInvRepoet(invReport:InvReport):Int {
    return invReportDao.insert(invReport)
  }

  /**
   * Invoice帳票データを更新
   */
  fun updateInvRepoet(invReport:InvReport):Int {
    return invReportDao.update(invReport)
  }

  /**
   * Invoice発行メール用
   * Invoice帳票の出荷先コードから社員情報を取得する
   * 名前とメールアドレスのMapを返す
   */
  fun getUserMap(destinationCode: Long): Map<String, String> {
    var userMap = LinkedHashMap<String, String>()
    var list = employeeUserDao.selectLShimuByDestCd(destinationCode)
    if (list != null) {
      list.iterator().forEach {
        userMap.put(it.name, it.mailAddress)
      }
    }

    var list2 = employeeUserDao.selectShimuByDestCd(destinationCode)
    if (list2 != null) {
      list2.iterator().forEach {
        userMap.put(it.name, it.mailAddress)
      }
    }

    return userMap
  }
}
