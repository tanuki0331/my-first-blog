package jp.co.ntj.webedi.domain.service.account.model

import java.math.BigDecimal
import java.time.ZonedDateTime

/**
 * 社員アカウントモデル.
 *
 * @author 日立システムズ
 */
data class EmployeeAccountModel(
    /** 会社コード. */
    override val kaisyaCd: String,
    /** 言語区分. */
    override val gengoKbn: String,
    /** ID. */
    override val id: BigDecimal,
    /** 社員ID. */
    val employeeId: String,
    /** 氏名. */
    override val name: String,
    /** パスワード. */
    override val password: String,
    /** メールアドレス. */
    override val mailAddress: String,
    /** ユーザー有効フラグ. */
    override val isValidatedUser: Boolean,
    /** セッションID. */
    override val sessionId: String? = null,
    /** 最終操作日時. */
    override val lastOperationAt: ZonedDateTime? = null,
    /** ログイン日時. */
    override val loginAt: ZonedDateTime? = null,
    /** 前回ログイン日時. */
    override val prevLoginAt: ZonedDateTime? = null,
    /** ホスト名. */
    override val hostName: String? = null,
    /** アクセスIP. */
    override val accessIp: String? = null,
    /** ユーザーエージェント. */
    override val userAgent: String? = null,
    /** 権限. */
    override val authorities: List<String>
) : AccountModelInterface
