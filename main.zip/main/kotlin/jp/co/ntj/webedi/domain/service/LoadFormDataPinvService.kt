package jp.co.ntj.webedi.service

import jp.co.ntj.webedi.domain.dao.table.*
import jp.co.ntj.webedi.domain.entity.table.PinvConfirmation
import jp.co.ntj.webedi.domain.entity.table.PinvReport
import jp.co.ntj.webedi.domain.entity.table.ProcessExecuteTime
import org.slf4j.Logger
import org.springframework.stereotype.Service

import org.apache.commons.lang3.StringUtils
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@Service
class LoadFormDataPinvService(
    val processExecuteTimeDao: ProcessExecuteTimeDao,
    val pinvReportDao: PinvReportDao,
    val pinvConfirmationDao: PinvConfirmationDao,
    val employeeUserDao: EmployeeUserDao,
    val logger: Logger
) {
  val processCategory = "PROC0003" // 処理区分

  /**
   * 処理実行時刻を取得する
   */
  fun getProcessExecuteTime():String {
    var time : ProcessExecuteTime?  = processExecuteTimeDao.selectById("0000","JP", processCategory)
    if (time != null) {
      return time.executeAt.substring(0, 19)
    } else {
      return ""
    }
  }

  /**
   * 処理実行時刻を更新する
   */
  fun saveProcessExecuteTime() {
    var datetime = LocalDateTime.now()
    var zoneDatetime = ZonedDateTime.of(datetime,  ZoneId.systemDefault())
    var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssXXX")
    var datetimestr = formatter.format(zoneDatetime)

    var processExecuteTime = ProcessExecuteTime()
    processExecuteTime.kaisyaCd = "0000"//TODO 暫定
    processExecuteTime.gengoKbn = "JP"
    processExecuteTime.processCategory = processCategory
    processExecuteTime.executeAt = datetimestr
    processExecuteTime.isDeleted = 0
    processExecuteTime.createdUser = "SYSTEM"
    processExecuteTime.createdAt = datetimestr
    processExecuteTime.updatedUser = "SYSTEM"
    processExecuteTime.updatedAt = datetimestr

    var time = getProcessExecuteTime()
    if (StringUtils.isEmpty(time)) {
      processExecuteTimeDao.insert(processExecuteTime)
    } else {
      processExecuteTimeDao.update(processExecuteTime)
    }
  }

  /**
   * ProformaInvoice帳票データを取得
   */
  fun getPinvReport(kaisyaCd: String,
                    gengoKbn: String,
                    customerCode: Long,
                    destinationCode: Long,
                    invNumber: String): PinvReport? {
    return  pinvReportDao.selectById(kaisyaCd, gengoKbn, customerCode, destinationCode, invNumber)
  }

  /**
   * ProformaInvoice帳票データを登録
   */
  fun insertPinvRepoet(pinvReport:PinvReport):Int {
    return pinvReportDao.insert(pinvReport)
  }

  /**
   * ProformaInvoice帳票データを更新
   */
  fun updatePinvRepoet(pinvReport:PinvReport):Int {
    return pinvReportDao.update(pinvReport)
  }

  /**
   * OC帳票確認テーブルを削除する
   */
  fun deletePinvConfirmation(kaisyaCd: String,
                             gengoKbn: String,
                             customerCode: Long,
                             destinationCode: Long,
                             pinvNumber: String) {
    val pinvConfirmation = PinvConfirmation()
    pinvConfirmation.kaisyaCd = kaisyaCd
    pinvConfirmation.gengoKbn = gengoKbn
    pinvConfirmation.customerCode = customerCode
    pinvConfirmation.destinationCode = destinationCode
    pinvConfirmation.pinvNumber = pinvNumber
    pinvConfirmationDao.delete(pinvConfirmation)
  }

  /**
   * ProformaInvoice発行メール用
   * ProformaInvoice帳票の出荷先コードから社員情報を取得する
   * 名前とメールアドレスのMapを返す
   */
  fun getUserMap(destinationCode: Long): Map<String, String> {
    var userMap = LinkedHashMap<String, String>()
    var list = employeeUserDao.selectLShimuByDestCd(destinationCode)
    if (list != null) {
      list.iterator().forEach {
        userMap.put(it.name, it.mailAddress)
      }
    }

    var list2 = employeeUserDao.selectShimuByDestCd(destinationCode)
    if (list2 != null) {
      list2.iterator().forEach {
        userMap.put(it.name, it.mailAddress)
      }
    }

    return userMap
  }
}
