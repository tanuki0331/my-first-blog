package jp.co.ntj.webedi.domain.service.account

import jp.co.ntj.webedi.domain.dao.account.CustomerAccountDao
import jp.co.ntj.webedi.domain.service.account.model.CustomerAccountMailModel
import jp.co.ntj.webedi.domain.service.account.model.CustomerAccountModel
import jp.co.ntj.webedi.properties.AppProperties
import org.springframework.stereotype.Service
import java.math.BigDecimal
import java.time.ZonedDateTime

/**
 * 得意先アカウントサービス.
 *
 * @author 日立システムズ
 */
@Service
class CustomerAccountService(
    /** 得意先アカウントDao. */
    private val customerAccountDao: CustomerAccountDao,
    /** アプリケーション設定. */
    private val appProperties: AppProperties
) : AccountService() {

  /**
   * ユーザー検索.
   * @param userId ユーザーID
   */
  fun searchUser(userId: String) = customerAccountDao.selectCustomerUserByUserId(userId)?.run {
    val mails = customerAccountDao.selectCustomerMail(kaisyaCd, gengoKbn, id)
    val auths = customerAccountDao.selectCustomerAuthority(kaisyaCd, gengoKbn, id)
    CustomerAccountModel(
        kaisyaCd = kaisyaCd,
        gengoKbn = gengoKbn,
        id = id,
        userId = this.userId,
        customerCode = customerCode,
        name = name,
        password = password,
        isInitPassword = isInitPassword.isValid,
        mailAddress = mailAddress,
        useOrderMail = useOrderMail.isValid,
        isValidatedOcIssueMail = isValidatedOcIssueMail.isValid,
        isValidatedInvIssueMail = isValidatedInvIssueMail.isValid,
        isValidatedPinvIssueMail = isValidatedPinvIssueMail.isValid,
        isValidatedDomesticDlvy = isValidatedDomesticDlvy.isValid,
        isValidatedProductList = isValidatedProductList.isValid,
        isValidatedUser = isValidatedUser.isValid,
        sessionId = sessionId,
        lastOperationAt = lastOperationAt?.let { ZonedDateTime.from(it.toInstant()) },
        loginAt = loginAt?.let { ZonedDateTime.from(it.toInstant()) },
        prevLoginAt = prevLoginAt?.let { ZonedDateTime.from(it.toInstant()) },
        hostName = hostName,
        accessIp = accessIp,
        userAgent = userAgent,
        isProxyLogin = false,
        productInfoUrl = appProperties.productInfoUrl + customerCode,
        cartItemCount = cartItemCount,
        authorities = auths.map { it.authority },
        deliveryMails = mails.map {
          CustomerAccountMailModel(
              sequenceNumber = it.sequenceNumber,
              mailAddress = it.mailAddress,
              useOrderMail = it.useOrderMail.isValid,
              isValidatedOcIssueMail = it.isValidatedOcIssueMail.isValid,
              isValidatedInvIssueMail = it.isValidatedInvIssueMail.isValid,
              isValidatedPinvIssueMail = it.isValidatedPinvIssueMail.isValid
          )
        }
    )
  }

  /**
   * ユーザー検索.
   * @param kaisyaCd 会社コード
   * @param gengoKbn 言語区分
   * @param id id
   */
  fun searchUser(kaisyaCd: String, gengoKbn: String,
      id: BigDecimal) = customerAccountDao.selectCustomerUserById(kaisyaCd, gengoKbn, id)?.run {
    val mails = customerAccountDao.selectCustomerMail(kaisyaCd, gengoKbn, id)
    val auths = customerAccountDao.selectCustomerAuthority(kaisyaCd, gengoKbn, id)
    CustomerAccountModel(
        kaisyaCd = kaisyaCd,
        gengoKbn = gengoKbn,
        id = id,
        userId = this.userId,
        customerCode = customerCode,
        name = name,
        password = password,
        isInitPassword = isInitPassword.isValid,
        mailAddress = mailAddress,
        useOrderMail = useOrderMail.isValid,
        isValidatedOcIssueMail = isValidatedOcIssueMail.isValid,
        isValidatedInvIssueMail = isValidatedInvIssueMail.isValid,
        isValidatedPinvIssueMail = isValidatedPinvIssueMail.isValid,
        isValidatedDomesticDlvy = isValidatedDomesticDlvy.isValid,
        isValidatedProductList = isValidatedProductList.isValid,
        isValidatedUser = isValidatedUser.isValid,
        sessionId = sessionId,
        lastOperationAt = lastOperationAt?.let { ZonedDateTime.from(it.toInstant()) },
        loginAt = loginAt?.let { ZonedDateTime.from(it.toInstant()) },
        prevLoginAt = prevLoginAt?.let { ZonedDateTime.from(it.toInstant()) },
        hostName = hostName,
        accessIp = accessIp,
        userAgent = userAgent,
        isProxyLogin = false,
        productInfoUrl = appProperties.productInfoUrl + customerCode,
        cartItemCount = cartItemCount,
        authorities = auths.map { it.authority },
        deliveryMails = mails.map {
          CustomerAccountMailModel(
              sequenceNumber = it.sequenceNumber,
              mailAddress = it.mailAddress,
              useOrderMail = it.useOrderMail.isValid,
              isValidatedOcIssueMail = it.isValidatedOcIssueMail.isValid,
              isValidatedInvIssueMail = it.isValidatedInvIssueMail.isValid,
              isValidatedPinvIssueMail = it.isValidatedPinvIssueMail.isValid
          )
        }
    )
  }
}
