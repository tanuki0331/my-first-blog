package jp.co.ntj.webedi.domain.service

import jp.co.ntj.webedi.domain.dao.table.*
import jp.co.ntj.webedi.domain.entity.table.InvReport
import jp.co.ntj.webedi.domain.entity.table.OcReport
import jp.co.ntj.webedi.domain.entity.table.PinvReport
import org.slf4j.Logger
import org.springframework.stereotype.Service
import java.time.LocalDateTime

@Service
class DeleteInvalidDataService(
    val codeDao: CodeDao,
    val customerUserAccessInfoDao: CustomerUserAccessInfoDao,
    val customerUserAuthorityDao: CustomerUserAuthorityDao,
    val customerUserDao: CustomerUserDao,
    val customerUserDlvyMailDao: CustomerUserDlvyMailDao,
    val employeeUserAccessInfoDao: EmployeeUserAccessInfoDao,
    val employeeUserAuthorityDao: EmployeeUserAuthorityDao,
    val employeeUserDao: EmployeeUserDao,
    val generalNewsDao: GeneralNewsDao,
    val invDownloadHistoryDao: InvDownloadHistoryDao,
    val invReportDao: InvReportDao,
    val ocConfirmationDao: OcConfirmationDao,
    val ocDownloadHistoryDao: OcDownloadHistoryDao,
    val ocReportDao: OcReportDao,
    val orderCartDetailDao: OrderCartDetailDao,
    val orderCartHeaderDao: OrderCartHeaderDao,
    val orderDataMappingDao: OrderDataMappingDao,
    val pinvConfirmationDao: PinvConfirmationDao,
    val pinvDownloadHistoryDao: PinvDownloadHistoryDao,
    val pinvReportDao: PinvReportDao,
    val processExecuteTimeDao: ProcessExecuteTimeDao,
    val searchConditionDao: SearchConditionDao,
    val shipToUserDao: ShipToUserDao,
    val logger: Logger
) {

  /**
   * 存在しないもしくは論理削除された得意先に紐付く得意先ユーザを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelCustomerUserByInvalidTokui(updateUser: String): Int {
    return customerUserDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付く注文データマッピングを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOrderDataMappingByInvalidTokui(updateUser: String): Int {
    return orderDataMappingDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くOC帳票マスタを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOcReportByInvalidTokui(updateUser: String): Int {
    return ocReportDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くOC帳票ダウンロード履歴を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOcDownloadHistoryByInvalidTokui(updateUser: String): Int {
    return ocDownloadHistoryDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くOC帳票確認を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOcConfirmationByInvalidTokui(updateUser: String): Int {
    return ocConfirmationDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くP/I帳票を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelPinvReportByInvalidTokui(updateUser: String): Int {
    return pinvReportDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くP/I帳票ダウンロード履歴を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelPinvDownloadHistoryByInvalidTokui(updateUser: String): Int {
    return pinvDownloadHistoryDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くP/I帳票確認を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelPinvConfirmationByInvalidTokui(updateUser: String): Int {
    return pinvConfirmationDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くINV帳票を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelInvReportByInvalidTokui(updateUser: String): Int {
    return invReportDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くINV帳票ダウンロード履歴を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelInvDownloadHistoryByInvalidTokui(updateUser: String): Int {
    return invDownloadHistoryDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付く出荷先ユーザーを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelShipToUserByInvalidTokui(updateUser: String): Int {
    return shipToUserDao.updateForDelByInvalidTokui(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付く得意先ユーザー追加メールを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelCustomerUserDlvyMailByInvalidCstmUser(updateUser: String): Int {
    return customerUserDlvyMailDao.updateForDelByInvalidCustomerUser(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付く得意先ユーザーアクセス情報を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelCustomerUserAccessInfoByInvalidCstmUser(updateUser: String): Int {
    return customerUserAccessInfoDao.updateForDelByInvalidCustomerUser(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付く得意先ユーザー権限を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelCustomerUserAuthorityByInvalidCstmUser(updateUser: String): Int {
    return customerUserAuthorityDao.updateForDelByInvalidCustomerUser(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付く検索条件を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelSearchConditionByInvalidCstmUser(updateUser: String): Int {
    return searchConditionDao.updateForDelByInvalidCustomerUser(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付く注文カートヘッダを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOrderCartHeaderByInvalidCstmUser(updateUser: String): Int {
    return orderCartHeaderDao.updateForDelByInvalidCustomerUser(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付く注文カート明細を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOrderCartDetailByInvalidCstmUser(updateUser: String): Int {
    return orderCartDetailDao.updateForDelByInvalidCustomerUser(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付く出荷先ユーザーを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelShipToUserByInvalidCstmUser(updateUser: String): Int {
    return shipToUserDao.updateForDelByInvalidCustomerUser(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付く検索条件を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelSearchConditionByInvalidShimu(updateUser: String): Int {
    return searchConditionDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付く注文カートヘッダを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOrderCartHeaderByInvalidShimu(updateUser: String): Int {
    return orderCartHeaderDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 注文カートヘッダに存在しない、注文カート明細を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOrderCartDetailByHeader(updateUser: String): Int {
    return orderCartDetailDao.updateForDelByHeader(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くOC帳票マスタを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOcReportByInvalidShimu(updateUser: String): Int {
    return ocReportDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くOC帳票ダウンロード履歴を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOcDownloadHistoryByInvalidShimu(updateUser: String): Int {
    return ocDownloadHistoryDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くOC帳票確認を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOcConfirmationByInvalidShimu(updateUser: String): Int {
    return ocConfirmationDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くP/I帳票を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelPinvReportByInvalidShimu(updateUser: String): Int {
    return pinvReportDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くP/I帳票ダウンロード履歴を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelPinvDownloadHistoryByInvalidShimu(updateUser: String): Int {
    return pinvDownloadHistoryDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くP/I帳票確認を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelPinvConfirmationByInvalidShimu(updateUser: String): Int {
    return pinvConfirmationDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くINV帳票を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelInvReportByInvalidShimu(updateUser: String): Int {
    return invReportDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付くINV帳票ダウンロード履歴を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelInvDownloadHistoryByInvalidShimu(updateUser: String): Int {
    return invDownloadHistoryDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除された仕向先マスタ／最終仕向先マスタに紐付く出荷先ユーザーを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelShipToUserByInvalidShimu(updateUser: String): Int {
    return shipToUserDao.updateForDelByInvalidShimu(updateUser)
  }

  /**
   * 存在しないもしくは論理削除されたプライスリスト情報に紐付く注文カート明細を論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOrderCartDetailByInvalidPlist(updateUser: String): Int {
    return orderCartDetailDao.updateForDelByInvalidPlist(updateUser)
  }

  /**
   * 注文カート明細に存在しない、注文カートヘッダを論理削除する
   *
   * @param updateUser 更新ユーザー
   * @return 論理削除件数
   */
  fun logicalDelOrderCartHeaderByDetail(updateUser: String): Int {
    return orderCartHeaderDao.updateForDelByDetail(updateUser)
  }

  /**
   * 全OC帳票を取得する
   *
   * @return 全OC帳票のリスト
   */
  fun getOcReports(): List<OcReport> {
    return ocReportDao.selectAll()
  }

  /**
   * OC帳票を削除する
   *
   * @param ocReports 削除対象のOC帳票リスト
   * @return 合計削除件数
   */
  fun deleteOcReport(ocReports: List<OcReport>): Int {
    return ocReportDao.delete(ocReports).sum()
  }

  /**
   * OC帳票に関連するOC帳票ダウンロード履歴を削除する
   *
   * @param ocReports 削除基準となるOC帳票リスト
   * @return 合計削除件数
   */
  fun deleteOcDownloadHistory(ocReports: List<OcReport>): Int {
    return ocDownloadHistoryDao.deleteByOcReports(ocReports).sum()
  }

  /**
   * OC帳票に関連するOC帳票確認を削除する
   *
   * @param ocReports 削除基準となるOC帳票リスト
   * @return 合計削除件数
   */
  fun deleteOcConfirmation(ocReports: List<OcReport>): Int {
    return ocConfirmationDao.deleteByOcReports(ocReports).sum()
  }

  /**
   * 全P/I帳票を取得する
   *
   * @return 全P/I帳票のリスト
   */
  fun getPinvReports(): List<PinvReport> {
    return pinvReportDao.selectAll()
  }

  /**
   * P/I帳票を削除する
   *
   * @param pinvReports 削除対象のP/I帳票リスト
   * @return 合計削除件数
   */
  fun deletePinvReport(pinvReports: List<PinvReport>): Int {
    return pinvReportDao.delete(pinvReports).sum()
  }

  /**
   * P/I帳票に関連するP/I帳票ダウンロード履歴を削除する
   *
   * @param pinvReports 削除基準となるP/I帳票リスト
   * @return 合計削除件数
   */
  fun deletePinvDownloadHistory(pinvReports: List<PinvReport>): Int {
    return pinvDownloadHistoryDao.deleteByPinvReports(pinvReports).sum()
  }

  /**
   * P/I帳票に関連するP/I帳票確認を削除する
   *
   * @param pinvReports 削除基準となるP/I帳票リスト
   * @return 合計削除件数
   */
  fun deletePinvConfirmation(pinvReports: List<PinvReport>): Int {
    return pinvConfirmationDao.deleteByPinvReports(pinvReports).sum()
  }

  /**
   * 全INV帳票を取得する
   *
   * @return 全INV帳票のリスト
   */
  fun getInvReports(): List<InvReport> {
    return invReportDao.selectAll()
  }

  /**
   * INV帳票を削除する
   *
   * @param invReports 削除対象のINV帳票リスト
   * @return 合計削除件数
   */
  fun deleteInvReport(invReports: List<InvReport>): Int {
    return invReportDao.delete(invReports).sum()
  }

  /**
   * INV帳票に関連するINV帳票ダウンロード履歴を削除する
   *
   * @param invReports 削除基準となるINV帳票リスト
   * @return 合計削除件数
   */
  fun deleteInvDownloadHistory(invReports: List<InvReport>): Int {
    return invDownloadHistoryDao.deleteByInvReports(invReports).sum()
  }

  /**
   * 保管期間が終了した注文カートヘッダを削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredOrderCart(baseDate: LocalDateTime): Int {
    return orderCartHeaderDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了した注文カート明細を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredOrderCartDetail(baseDate: LocalDateTime): Int {
    return orderCartDetailDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したOC帳票マスタを削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredOcReport(baseDate: LocalDateTime): Int {
    return ocReportDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したOC帳票ダウンロード履歴を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredOcDownloadHistory(baseDate: LocalDateTime): Int {
    return ocDownloadHistoryDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したOC帳票確認を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredOcConfirmation(baseDate: LocalDateTime): Int {
    return ocConfirmationDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したP/I帳票を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredPinvReport(baseDate: LocalDateTime): Int {
    return pinvReportDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したP/I帳票ダウンロード履歴を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredPinvDownloadHistory(baseDate: LocalDateTime): Int {
    return pinvDownloadHistoryDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したP/I帳票確認を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredPinvConfirmation(baseDate: LocalDateTime): Int {
    return pinvConfirmationDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したINV帳票を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredInvReport(baseDate: LocalDateTime): Int {
    return invReportDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 保管期間が終了したINV帳票ダウンロード履歴を削除する
   *
   * @param baseDate 期限切れとなる基準日
   * @return 削除件数
   */
  fun deleteExpiredInvDownloadHistory(baseDate: LocalDateTime): Int {
    return invDownloadHistoryDao.deleteBeforeByCreatedAt(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのコードを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedCode(baseDate: LocalDateTime): Int {
    return codeDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの得意先ユーザーを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedCustomerUser(baseDate: LocalDateTime): Int {
    return customerUserDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの得意先ユーザーアクセス情報を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedCustomerUserAccessInfo(baseDate: LocalDateTime): Int {
    return customerUserAccessInfoDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの得意先ユーザー権限を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedCustomerUserAuthority(baseDate: LocalDateTime): Int {
    return customerUserAuthorityDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの得意先ユーザー配信メールを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedCustomerUserDlvyMail(baseDate: LocalDateTime): Int {
    return customerUserDlvyMailDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの社員ユーザーを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedEmployeeUser(baseDate: LocalDateTime): Int {
    return employeeUserDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの社員ユーザーアクセス情報を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedEmployeeUserAccessInfo(baseDate: LocalDateTime): Int {
    return employeeUserAccessInfoDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの社員ユーザー権限を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedEmployeeUserAuthority(baseDate: LocalDateTime): Int {
    return employeeUserAuthorityDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの共通お知らせを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedGeneralNews(baseDate: LocalDateTime): Int {
    return generalNewsDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのINV帳票ダウンロード履歴を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedInvDownloadHistory(baseDate: LocalDateTime): Int {
    return invDownloadHistoryDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのINV帳票を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedInvReport(baseDate: LocalDateTime): Int {
    return invReportDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのOC帳票確認を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedOcConfirmation(baseDate: LocalDateTime): Int {
    return ocConfirmationDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのOC帳票ダウンロード履歴を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedOcDownloadHistory(baseDate: LocalDateTime): Int {
    return ocDownloadHistoryDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのOC帳票を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedOcReport(baseDate: LocalDateTime): Int {
    return ocReportDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの注文カート明細を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedOrderCartDetail(baseDate: LocalDateTime): Int {
    return orderCartDetailDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの注文カートヘッダを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedOrderCartHeader(baseDate: LocalDateTime): Int {
    return orderCartHeaderDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの注文データマッピングを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedOrderDataMapping(baseDate: LocalDateTime): Int {
    return orderDataMappingDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのP/I帳票確認を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedPinvConfirmation(baseDate: LocalDateTime): Int {
    return pinvConfirmationDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのP/I帳票ダウンロード履歴を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedPinvDownloadHistory(baseDate: LocalDateTime): Int {
    return pinvDownloadHistoryDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみのP/I帳票を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedPinvReport(baseDate: LocalDateTime): Int {
    return pinvReportDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの処理実行時刻を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedProcessExecuteTime(baseDate: LocalDateTime): Int {
    return processExecuteTimeDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの検索条件を削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedSearchCondition(baseDate: LocalDateTime): Int {
    return searchConditionDao.deleteDeletedData(baseDate)
  }

  /**
   * 指定日時以前に作成された論理削除ずみの出荷先ユーザーを削除する
   *
   * @param baseDate 削除する基準日
   * @return 削除件数
   */
  fun deleteDeletedShipToUser(baseDate: LocalDateTime): Int {
    return shipToUserDao.deleteDeletedData(baseDate)
  }
}
