package jp.co.ntj.webedi.security.authentication.exception

import jp.co.ntj.webedi.properties.MessagePropertiesName
import org.springframework.security.core.AuthenticationException

/**
 * 多重ログイン例外.
 *
 * @author 日立システムズ
 */
class MultipleLoginException : AuthenticationException(MessagePropertiesName.MC0009) {
}