package jp.co.ntj.webedi.security.authentication.exception

import jp.co.ntj.webedi.properties.MessagePropertiesName
import org.springframework.security.core.AuthenticationException

/**
 * ユーザー存在しない例外.
 *
 * @author 日立システムズ
 */
class UserNotFoundException : AuthenticationException(MessagePropertiesName.ME0036)