package jp.co.ntj.webedi.security.logout.handler

import org.springframework.security.core.Authentication
import org.springframework.security.web.authentication.logout.LogoutHandler
import org.springframework.stereotype.Component
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * ログアウト処理前のハンドラ.
 */
@Component
class WebLogoutHandler : LogoutHandler {

  override fun logout(request: HttpServletRequest?, response: HttpServletResponse?,
      authentication: Authentication?) {
    // 何か処理
  }
}