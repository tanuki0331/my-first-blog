package jp.co.ntj.webedi.security.authentication.exception

import jp.co.ntj.webedi.properties.MessagePropertiesName
import org.springframework.security.core.AuthenticationException

/**
 * ユーザー無効例外.
 *
 * @author 日立システムズ
 */
class UserInvalidException: AuthenticationException(MessagePropertiesName.ME9001)