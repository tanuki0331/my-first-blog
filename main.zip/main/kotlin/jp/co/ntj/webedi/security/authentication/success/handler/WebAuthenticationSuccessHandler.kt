package jp.co.ntj.webedi.security.authentication.success.handler

import jp.co.ntj.webedi.app.model.ResponseModel
import jp.co.ntj.webedi.app.model.ResponseResult
import jp.co.ntj.webedi.app.model.account.CustomerAuthResponseModel
import jp.co.ntj.webedi.app.model.account.EmployeeAuthResponseModel
import jp.co.ntj.webedi.domain.service.account.model.CustomerAccountModel
import jp.co.ntj.webedi.domain.service.account.model.EmployeeAccountModel
import jp.co.ntj.webedi.security.authentication.model.LoginType
import jp.co.ntj.webedi.security.authentication.model.WebAccount
import jp.co.ntj.webedi.security.authentication.model.WebUserDetails
import org.slf4j.Logger
import org.springframework.http.HttpStatus
import org.springframework.security.core.Authentication
import org.springframework.security.web.authentication.AuthenticationSuccessHandler
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import org.springframework.security.web.WebAttributes
import org.springframework.stereotype.Component
import org.springframework.http.MediaType
import org.springframework.http.server.ServletServerHttpResponse
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.core.userdetails.UsernameNotFoundException


/**
 * 認証成功時のハンドラ.
 */
@Component
class WebAuthenticationSuccessHandler(
    /** ロガー. */
    private val webLogger: Logger,
    /** HttpMessageのJsonコンバーター. */
    private val httpMessageConverter: MappingJackson2HttpMessageConverter,
    /** 認証ユーザー情報. */
    private val webAccount: WebAccount
) : AuthenticationSuccessHandler {

  override fun onAuthenticationSuccess(request: HttpServletRequest?, response: HttpServletResponse?,
      authentication: Authentication?) {

    // レスポンスコミット済み
    if (response?.isCommitted!!) {
      webLogger.info("Response has already been committed.")
      return
    }

    // レスポンスデータ作成
    val responseModel = when (webAccount.loginType) {
      LoginType.Customer -> {
        ResponseModel.success(toCustomerResponse(webAccount.customerAccount!!))
      }
      LoginType.Employee -> {
        ResponseModel.success(toEmployeeResponse(webAccount.employeeAccount!!))
      }
      else -> {
        throw UsernameNotFoundException("")
      }
    }

    // Httpステータス：200を返す
    val outputMessage = ServletServerHttpResponse(response)
    httpMessageConverter.write(responseModel, MediaType.APPLICATION_JSON_UTF8, outputMessage) // Responseに書き込む
    response.status = HttpStatus.OK.value() // 200 OK.

    // 一時データ削除
    clearAuthenticationAttributes(request!!)
  }

  /**
   * Removes temporary authentication-related data which may have been stored in the
   * session during the authentication process.
   */
  private fun clearAuthenticationAttributes(request: HttpServletRequest) {
    val session = request.getSession(false) ?: return
    session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION)
  }

  /**
   * 得意先レスポンス変換.
   */
  private fun toCustomerResponse(customerAccount: CustomerAccountModel) = customerAccount.let {
    CustomerAuthResponseModel(
        userId = it.userId,
        name = it.name,
        prevLoginAt = it.prevLoginAt,
        isInitPassword = it.isInitPassword,
        isValidatedDomesticDlvy = it.isValidatedDomesticDlvy,
        isValidatedProductList = it.isValidatedProductList,
        productInfoUrl = it.productInfoUrl,
        cartItemCount = it.cartItemCount,
        isProxyLogin = it.isProxyLogin
    )
  }

  /**
   * 社員レスポンス変換.
   */
  private fun toEmployeeResponse(employeeAccount: EmployeeAccountModel) = employeeAccount!!.let {
    EmployeeAuthResponseModel(
        employeeId = it.employeeId,
        name = it.name,
        prevLoginAt = it.prevLoginAt
    )
  }


}