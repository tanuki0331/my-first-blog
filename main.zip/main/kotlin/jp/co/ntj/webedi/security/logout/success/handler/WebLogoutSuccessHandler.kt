package jp.co.ntj.webedi.security.logout.success.handler

import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler
import org.springframework.stereotype.Component

/**
 * ログアウト成功時のハンドラ.
 */
@Component
class WebLogoutSuccessHandler : HttpStatusReturningLogoutSuccessHandler()
