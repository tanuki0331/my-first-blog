package jp.co.ntj.webedi.security.authentication.entrypoint

import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.security.core.AuthenticationException
import org.springframework.security.web.AuthenticationEntryPoint
import org.springframework.stereotype.Component
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * 未認証アクセス時のエントリーポイント.
 *
 * @author 日立システムズ
 */
@Component
class WebAuthenticationEntryPoint() : AuthenticationEntryPoint {

  @Autowired
  lateinit var logger: Logger;

  override fun commence(request: HttpServletRequest?, response: HttpServletResponse?,
      authException: AuthenticationException?) {
    // レスポンスがコミット済み
    if (response?.isCommitted!!) {
      logger.info("Response has already been committed.")
      return
    }
    // Httpステータスコード：401を返す
    return response?.sendError(HttpStatus.UNAUTHORIZED.value(),
        HttpStatus.UNAUTHORIZED.reasonPhrase)
  }
}