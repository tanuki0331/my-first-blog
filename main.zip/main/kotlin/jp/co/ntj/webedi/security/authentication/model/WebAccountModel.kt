package jp.co.ntj.webedi.security.authentication.model

import jp.co.ntj.webedi.domain.dto.account.customer.SelectCustomerUserDto
import jp.co.ntj.webedi.domain.service.account.model.CustomerAccountModel
import jp.co.ntj.webedi.domain.service.account.model.EmployeeAccountModel
import org.springframework.security.core.authority.AuthorityUtils
import org.springframework.security.core.userdetails.User
import org.springframework.stereotype.Component
import org.springframework.web.context.annotation.SessionScope
import java.math.BigDecimal

/**
 * 認証ユーザー情報.
 * @author 日立システムズ
 */
@Component
@SessionScope
class WebAccount {

  /** 得意先アカウントモデル. */
  var customerAccount: CustomerAccountModel? = null

  /** 社員アカウントモデル. */
  var employeeAccount: EmployeeAccountModel? = null

  /**
   * ログインタイプ取得.
   */
  val loginType: LoginType
    get() = when {
      customerAccount != null && employeeAccount != null -> {
        LoginType.Proxy
      }
      customerAccount != null && employeeAccount == null -> {
        LoginType.Customer
      }
      customerAccount == null && employeeAccount != null -> {
        LoginType.Employee
      }
      else -> {
        LoginType.None
      }
    }
}

/**
 * ログインタイプ.
 * @author 日立システムズ
 */
enum class LoginType {

  /** 得意先. */
  Customer,
  /** 社員. */
  Employee,
  /** 代理. */
  Proxy,
  /** 未ログイン. */
  None
}
