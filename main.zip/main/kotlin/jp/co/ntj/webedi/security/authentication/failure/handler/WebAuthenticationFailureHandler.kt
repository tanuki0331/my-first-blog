package jp.co.ntj.webedi.security.authentication.failure.handler

import jp.co.ntj.webedi.app.model.ResponseModel
import jp.co.ntj.webedi.properties.MessagePropertiesName
import jp.co.ntj.webedi.security.authentication.exception.MultipleLoginException
import jp.co.ntj.webedi.security.authentication.exception.UserInvalidException
import jp.co.ntj.webedi.security.authentication.exception.UserNotFoundException
import org.slf4j.Logger
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
import org.springframework.http.server.ServletServerHttpResponse
import org.springframework.security.core.AuthenticationException
import org.springframework.security.web.WebAttributes
import org.springframework.security.web.authentication.AuthenticationFailureHandler
import org.springframework.stereotype.Component
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * 認証失敗時のハンドラ.
 */
@Component
class WebAuthenticationFailureHandler(
    /** HttpMessageのJsonコンバーター. */
    private val httpMessageConverter: MappingJackson2HttpMessageConverter,
    /** ロガー. */
    private val webLogger: Logger
) : AuthenticationFailureHandler {

  override fun onAuthenticationFailure(request: HttpServletRequest?, response: HttpServletResponse?,
      exception: AuthenticationException?) {

    // レスポンスコミット済み
    if (response?.isCommitted!!) {
      webLogger.info("Response has already been committed.")
      return
    }

    val exceptionMessage = exception?.message ?: MessagePropertiesName.MA0001

    when (exception) {
      is MultipleLoginException -> {
        // 多重ログイン
        httpMessageConverter.write(ResponseModel.success(messageId = exceptionMessage),
            MediaType.APPLICATION_JSON_UTF8,
            ServletServerHttpResponse(response)) // Responseに書き込む
        response.status = HttpStatus.OK.value() // 200 OK.
      }
      is UserInvalidException -> {
        // ユーザー無効
        httpMessageConverter.write(ResponseModel.error(messageId = exceptionMessage),
            MediaType.APPLICATION_JSON_UTF8,
            ServletServerHttpResponse(response)) // Responseに書き込む
        response.status = HttpStatus.OK.value() // 200 OK.
      }
      is UserNotFoundException -> {
        // ユーザーが存在しないorパスワードミス
        httpMessageConverter.write(ResponseModel.error(messageId = exceptionMessage),
            MediaType.APPLICATION_JSON_UTF8,
            ServletServerHttpResponse(response)) // Responseに書き込む
        response.status = HttpStatus.OK.value() // 200 OK.
      }
      else -> {
        // それ以外のエラー
        httpMessageConverter.write(ResponseModel.error(), MediaType.APPLICATION_JSON_UTF8,
            ServletServerHttpResponse(response)) // Responseに書き込む
        response.status = HttpStatus.UNAUTHORIZED.value() // 401 Unauthorized.
      }
    }

    // 一時データ削除
    clearAuthenticationAttributes(request!!)

  }

  private fun clearAuthenticationAttributes(request: HttpServletRequest) {
    val session = request.getSession(false) ?: return
    session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION)
  }
}