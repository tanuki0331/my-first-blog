package jp.co.ntj.webedi.security.authentication.provider

import jp.co.ntj.webedi.domain.service.account.CustomerAccountService
import jp.co.ntj.webedi.domain.service.account.EmployeeAccountService
import jp.co.ntj.webedi.domain.service.account.model.CustomerAccountModel
import jp.co.ntj.webedi.domain.service.account.model.EmployeeAccountModel
import jp.co.ntj.webedi.security.authentication.exception.MultipleLoginException
import jp.co.ntj.webedi.security.authentication.exception.UserInvalidException
import jp.co.ntj.webedi.security.authentication.exception.UserNotFoundException
import jp.co.ntj.webedi.security.authentication.model.LoginType
import jp.co.ntj.webedi.security.authentication.model.WebAccount
import jp.co.ntj.webedi.security.authentication.model.WebUserDetails
import org.slf4j.Logger
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider
import org.springframework.security.core.authority.AuthorityUtils
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.stereotype.Component
import javax.servlet.http.HttpServletRequest

/**
 * Web認証プロバイダ.
 *
 * @author 日立システムズ
 */
@Component
class WebAuthenticationProvider(
    /** 得意先アカウントサービス. */
    private val customerAccountService: CustomerAccountService,
    /** 社員アカウントサービス. */
    private val employeeAccountService: EmployeeAccountService,
    /** ロガー. */
    private val webLogger: Logger,
    /** httprequest */
    private val request: HttpServletRequest?,
    /** 認証ユーザー情報. */
    private val webAccount: WebAccount
) : AbstractUserDetailsAuthenticationProvider() {

  override fun retrieveUser(username: String?,
      authentication: UsernamePasswordAuthenticationToken?): UserDetails {

    // 空はエラー
    val userId = username ?: throw UserNotFoundException()
    val password = authentication?.let { it.credentials.toString() }
        ?: throw UserNotFoundException()
    val logonFlg = request?.getParameter("logonFlg")?.let { it.toBoolean() } ?: false
    // 必要ならパスワードをエンコード

    // 得意先から検索、存在しなければ社員から検索
    val account = customerAccountService.searchUser(userId) ?: employeeAccountService.searchUser(
        userId)
    return when (account) {
      is CustomerAccountModel -> {
        // パスワードチェック
        if ( (account.password == password).not()) throw UserNotFoundException()
        // 多重ログインチェック
        if (customerAccountService.isLogin(account, request?.session!!.id)) throw MultipleLoginException()
        // ユーザー無効チェック
        if (customerAccountService.isValidUser(account).not()) throw UserInvalidException()

        webAccount.customerAccount = account

        WebUserDetails(
            account.kaisyaCd,
            account.gengoKbn,
            account.id,
            AuthorityUtils.createAuthorityList(*account.authorities.toTypedArray()),
            LoginType.Customer)
      }
      is EmployeeAccountModel -> {
        // パスワードチェック
        if ( (account.password == password).not()) throw UserNotFoundException()
        // 多重ログインチェック
        if (employeeAccountService.isLogin(account, request?.session!!.id)) throw MultipleLoginException()
        // ユーザー無効チェック
        if (employeeAccountService.isValidUser(account).not()) throw UserInvalidException()

        webAccount.employeeAccount = account

        WebUserDetails(
            account.kaisyaCd,
            account.gengoKbn,
            account.id,
            AuthorityUtils.createAuthorityList(*account.authorities.toTypedArray()),
            LoginType.Employee)
      }
      else -> {
        throw UserNotFoundException()
      }
    }
  }

  override fun additionalAuthenticationChecks(userDetails: UserDetails?,
      authentication: UsernamePasswordAuthenticationToken?) {
    // No
  }
}
