package jp.co.ntj.webedi.security.password.encoder

import org.springframework.security.crypto.password.PasswordEncoder

/**
 * パスワードのエンコーダー.
 */
class WebPasswordEncoder : PasswordEncoder {

  override fun encode(rawPassword: CharSequence?): String {
    return rawPassword.toString()
  }

  override fun matches(rawPassword: CharSequence?, encodedPassword: String?): Boolean {
    return rawPassword.toString() == encodedPassword
  }
}