package jp.co.ntj.webedi.security.authentication.model

import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.userdetails.User
import java.math.BigDecimal

/**
 * Webユーザー(SpringSecurity用).
 *
 * @author 日立システムズ
 */
class WebUserDetails(
    /** 会社コード. */
    val kaisyaCd: String,
    /** 言語区分. */
    val gengoKbn: String,
    /** ID. */
    val id: BigDecimal,
    /** 権限. */
    val authorities: List<GrantedAuthority>,
    /** ログインタイプ. */
    val loginType: LoginType
) : User(id.toPlainString(), "", authorities) {

  override fun getAuthorities(): MutableCollection<GrantedAuthority> {
    return super.getAuthorities()
  }
}