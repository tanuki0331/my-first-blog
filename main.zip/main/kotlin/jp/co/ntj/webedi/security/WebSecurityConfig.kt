package jp.co.ntj.webedi.security

import jp.co.ntj.webedi.security.accessdenied.handler.WebAccessDeniedHandler
import jp.co.ntj.webedi.security.authentication.entrypoint.WebAuthenticationEntryPoint
import jp.co.ntj.webedi.security.authentication.failure.handler.WebAuthenticationFailureHandler
import jp.co.ntj.webedi.security.authentication.provider.WebAuthenticationProvider
import jp.co.ntj.webedi.security.authentication.success.handler.WebAuthenticationSuccessHandler
import jp.co.ntj.webedi.security.logout.handler.WebLogoutHandler
import jp.co.ntj.webedi.security.logout.success.handler.WebLogoutSuccessHandler
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter
import org.springframework.security.web.csrf.CookieCsrfTokenRepository

/**
 * Spring Security 設定クラス.
 */
//@EnableWebSecurity
class WebSecurityConfig : WebSecurityConfigurerAdapter {
  /** Web認証プロバイダ. */
  /** ログアウト処理時のハンドラ. */
  /** ログアウト成功時のハンドラ. */
  /** 認証失敗時のハンドラ. */
  /** 認証成功時のハンドラ. */
  /** 未認可アクセス時のハンドラ. */

  /** 未認証アクセス時のエントリーポイント. */
  private val webAuthenticationEntryPoint: WebAuthenticationEntryPoint
  private val webAccessDeniedHandler: WebAccessDeniedHandler
  private val webAuthenticationSuccessHandler: WebAuthenticationSuccessHandler
  private val webAuthenticationFailureHandler: WebAuthenticationFailureHandler
  private val webLogoutSuccessHandler: WebLogoutSuccessHandler
  private val webLogoutHandler: WebLogoutHandler
  private val webAuthenticationProvider: WebAuthenticationProvider

  constructor(webAuthenticationEntryPoint: WebAuthenticationEntryPoint, webAccessDeniedHandler: WebAccessDeniedHandler, webAuthenticationSuccessHandler: WebAuthenticationSuccessHandler, webAuthenticationFailureHandler: WebAuthenticationFailureHandler, webLogoutSuccessHandler: WebLogoutSuccessHandler, webLogoutHandler: WebLogoutHandler, webAuthenticationProvider: WebAuthenticationProvider) : super() {
    this.webAuthenticationEntryPoint = webAuthenticationEntryPoint
    this.webAccessDeniedHandler = webAccessDeniedHandler
    this.webAuthenticationSuccessHandler = webAuthenticationSuccessHandler
    this.webAuthenticationFailureHandler = webAuthenticationFailureHandler
    this.webLogoutSuccessHandler = webLogoutSuccessHandler
    this.webLogoutHandler = webLogoutHandler
    this.webAuthenticationProvider = webAuthenticationProvider
  }

  /**
   * Http設定.
   * @param http HttpSecurity
   */
  override fun configure(http: HttpSecurity?) {
    http!!
        // 認可
        .authorizeRequests()
        // csrf取得用APIとサンプルは常に許可
        .mvcMatchers("/pre-login", "/news/**", "/sample/**", "/i18n/*.yml", "/config/*.yml")
        .permitAll()
        // 得意先のみアクセス可能
        .mvcMatchers("/customer/**")
        .hasRole("USER")
        // 社員のみアクセス可能
        .mvcMatchers("/employee/**")
        .hasRole("ADMIN")
        // 上記以外は認証のみ必要
        .anyRequest()
        .authenticated()
        .and()
        // 例外のハンドリング
        .exceptionHandling()
        // 未認証ユーザーのアクセス
        .authenticationEntryPoint(webAuthenticationEntryPoint)
        // 未認可リソースへのアクセス
        .accessDeniedHandler(webAccessDeniedHandler)
        .and()
        // ログイン
        .formLogin()
        // ログインAPIは認証不要
        .loginProcessingUrl("/login").permitAll()
        // ユーザー名のパラメータ名
        .usernameParameter("userId")
        // パスワードのパラメータ名
        .passwordParameter("password")
        // ログイン成功時のハンドラ
        .successHandler(webAuthenticationSuccessHandler)
        // ログイン失敗時のハンドラ
        .failureHandler(webAuthenticationFailureHandler)
        .and()
        // ログアウト
        .logout()
        // ログアウトURL
        .logoutUrl("/logout")
        // セッション削除
        .invalidateHttpSession(true)
        // Cookie削除
        .deleteCookies("JSESSIONID", "SESSION", "remember-me")
        // ログアウト処理前のハンドラ
        .addLogoutHandler(webLogoutHandler)
        // ログアウト成功時のハンドラ
        .logoutSuccessHandler(webLogoutSuccessHandler)
        .and()
        // csrfトークン
        .csrf()
        //.disable()
        //.ignoringAntMatchers("/login")
        .csrfTokenRepository(CookieCsrfTokenRepository())
  }

  /**
   * 認証処理設定.
   */
  @Autowired
  fun configureGlobal(auth: AuthenticationManagerBuilder) {
    auth.eraseCredentials(true)
        .authenticationProvider(webAuthenticationProvider)
  }

}