package jp.co.ntj.webedi.properties

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Configuration

/**
 * アプリケーション設定.
 *
 * @author 日立システムズ
 */
@Configuration
@ConfigurationProperties("app")
data class AppProperties(
    var productInfoUrl: String = "http://localhost/"
)