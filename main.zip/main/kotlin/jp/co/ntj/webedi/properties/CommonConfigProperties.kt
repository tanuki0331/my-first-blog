package jp.co.ntj.webedi.properties

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Configuration

/**
 * 共通設定プロパティ.
 *
 * @author 日立システムズ
 */
@Configuration
@ConfigurationProperties(prefix = "common-config")
data class CommonConfigProperties(

    /** 明細件数. */
    var numberOfItems: Int = 50,

    /** オートコンプリート件数. */
    var numberOfAutocomplete: Int = 10

)
