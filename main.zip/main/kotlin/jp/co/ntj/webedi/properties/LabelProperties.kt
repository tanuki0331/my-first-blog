package jp.co.ntj.webedi.properties

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Configuration

/**
 * ラベルプロパティ.
 *
 * @author 日立システムズ
 */
@Configuration
@ConfigurationProperties("label")
data class LabelProperties(
    /** ダミー. */
    var none: String = "None"
)

/**
 * ラベルプロパティ名.
 *
 * @author 日立システムズ
 */
object LabelPropertiesName {
  /** 出荷先. */
  const val destination = "destination"
}
