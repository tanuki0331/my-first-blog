package jp.co.ntj.webedi.properties

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Configuration

/**
 * メッセージプロパティ.
 *
 * @author 日立システムズ
 */
@Configuration
@ConfigurationProperties("message")
data class MessageProperties(
    /** {0}を入力してください。. */
    var ME0001: String = MessagePropertiesName.ME0001,
    /** {0}を指定してください。. */
    var ME0002: String = MessagePropertiesName.ME0002,
    /** 無効な{0}です。. */
    var ME0003: String = MessagePropertiesName.ME0003,
    /** {0}を選択してください。. */
    var ME0004: String = MessagePropertiesName.ME0004,
    /** {0}は半角英数字で入力してください。. */
    var ME0005: String = MessagePropertiesName.ME0005,
    /** {0}は半角数字で入力してください。. */
    var ME0006: String = MessagePropertiesName.ME0006,
    /** {0}は半角英字で入力してください。. */
    var ME0007: String = MessagePropertiesName.ME0007,
    /** {0}は半角文字で入力してください。. */
    var ME0008: String = MessagePropertiesName.ME0008,
    /** {0}は半角文字、半角カナで入力してください。 . */
    var ME0009: String = MessagePropertiesName.ME0009,
    /** {0}は全角文字で入力してください。. */
    var ME0010: String = MessagePropertiesName.ME0010,
    /** {0}は数値で入力してください。. */
    var ME0011: String = MessagePropertiesName.ME0011,
    /** {0}に負数はご指定いただけません。. */
    var ME0012: String = MessagePropertiesName.ME0012,
    /** {0}に小数はご指定いただけません。. */
    var ME0013: String = MessagePropertiesName.ME0013,
    /** {0}は{1}桁で入力してください。. */
    var ME0014: String = MessagePropertiesName.ME0014,
    /** {0}は{1}桁以内で入力してください。. */
    var ME0015: String = MessagePropertiesName.ME0015,
    /** {0}は{1}文字で入力してください。. */
    var ME0016: String = MessagePropertiesName.ME0016,
    /** {0}は{1}文字以内で入力してください。. */
    var ME0017: String = MessagePropertiesName.ME0017,
    /** {0}には正しい{1}を入力してください。. */
    var ME0018: String = MessagePropertiesName.ME0018,
    /** {0}は{1}バイトで入力してください。. */
    var ME0019: String = MessagePropertiesName.ME0019,
    /** 正しい{0}を入力してください。. */
    var ME0020: String = MessagePropertiesName.ME0020,
    /** {0}が正しくありません。. */
    var ME0021: String = MessagePropertiesName.ME0021,
    /** 有効な{0}を入力してください。. */
    var ME0022: String = MessagePropertiesName.ME0022,
    /** {0}には有効な{1}を入力してください。. */
    var ME0023: String = MessagePropertiesName.ME0023,
    /** {0}には本日から{1}年以内の日付を入力してください。. */
    var ME0024: String = MessagePropertiesName.ME0024,
    /** {0}には本日から{1}ヶ月以内の日付を入力してください。. */
    var ME0025: String = MessagePropertiesName.ME0025,
    /** {0}には本日から{1}日以内の日付を入力してください。. */
    var ME0026: String = MessagePropertiesName.ME0026,
    /** 不正な引数です。引数[{0}]. */
    var ME0027: String = MessagePropertiesName.ME0027,
    /** {0}がありません。. */
    var ME0028: String = MessagePropertiesName.ME0028,
    /** {0}が見つかりませんでした。. */
    var ME0029: String = MessagePropertiesName.ME0029,
    /** {0}が見つかりません[{1}]. */
    var ME0030: String = MessagePropertiesName.ME0030,
    /** {0}の作成に失敗しました。[{1}]. */
    var ME0031: String = MessagePropertiesName.ME0031,
    /** {0}の削除に失敗しました。[{1}]. */
    var ME0032: String = MessagePropertiesName.ME0032,
    /** {0}の登録に失敗しました。[{1}]. */
    var ME0033: String = MessagePropertiesName.ME0033,
    /** {0}の変更に失敗しました。[{1}]. */
    var ME0034: String = MessagePropertiesName.ME0034,
    /** 規定の形式ではありません。[{0}]. */
    var ME0035: String = MessagePropertiesName.ME0035,
    /** ユーザーID、もしくはパスワードが一致しません。. */
    var ME0036: String = MessagePropertiesName.ME0036,
    /** パスワードは「8文字以上、30文字以下、半角英数大文字小文字」で入力してください。. */
    var ME0037: String = MessagePropertiesName.ME0037,
    /** 新パスワードと一致するように入力してください。. */
    var ME0038: String = MessagePropertiesName.ME0038,
    /** 電話番号は半角数字、\"-（ハイフン）\"区切りでご指定ください。. */
    var ME0039: String = MessagePropertiesName.ME0039,
    /** 携帯電話の電話番号はご指定いただけません。. */
    var ME0040: String = MessagePropertiesName.ME0040,
    /** メールの送信に失敗しました。. */
    var ME0041: String = MessagePropertiesName.ME0041,
    /** メールアドレスの確認のため、テストメールを送信してください。送信完了後、受信ができているか確認をしてください。. */
    var ME0042: String = MessagePropertiesName.ME0042,
    /** {0}を変更された場合はテスト送信をしてください。. */
    var ME0043: String = MessagePropertiesName.ME0043,
    /** ご注文いただいた情報が一部古くなっております。大変申し訳ございませんが、最初からご注文をお願い致します。. */
    var ME0044: String = MessagePropertiesName.ME0044,
    /** ご注文のステータスが更新されています。お手数ではありますが、注文履歴よりステータスをご確認ください。. */
    var ME0045: String = MessagePropertiesName.ME0045,
    /** ご注文される商品の個数を入力してください。. */
    var ME0046: String = MessagePropertiesName.ME0046,
    /** ご変更される商品の個数を入力、もしくはキャンセルをチェックしてください。. */
    var ME0047: String = MessagePropertiesName.ME0047,
    /** {0}に失敗しました。. */
    var ME0048: String = MessagePropertiesName.ME0048,
    /** {0}には{1}から{2}年以内の日付を入力してください。. */
    var ME0049: String = MessagePropertiesName.ME0049,
    /** {0}には{1}から{2}ヶ月以内の日付を入力してください。. */
    var ME0050: String = MessagePropertiesName.ME0050,
    /** {0}には{1}から{2}日以内の日付を入力してください。. */
    var ME0051: String = MessagePropertiesName.ME0051,
    /** ご注文のステータスが更新されています。お手数ではありますが、再度ご検索頂きステータスをご確認ください。. */
    var ME0052: String = MessagePropertiesName.ME0052,
    /** 現在ご注文頂けない商品が含まれています。. */
    var ME0053: String = MessagePropertiesName.ME0053,
    /** {0}には本日から{1}年前までの日付を入力してください。. */
    var ME0054: String = MessagePropertiesName.ME0054,
    /** {0}には本日から{1}ヶ月前までの日付を入力してください。. */
    var ME0055: String = MessagePropertiesName.ME0055,
    /** {0}には本日から{1}日前までの日付を入力してください。. */
    var ME0056: String = MessagePropertiesName.ME0056,
    /** {0}に失敗しました。時間を置いて再実施して頂くか、担当営業へご連絡ください。. */
    var ME0057: String = MessagePropertiesName.ME0057,
    /** 起動引数の数が不正です。このプログラムの起動引数の数[{0}]　指定された起動引数の数[{1}]. */
    var ME0058: String = MessagePropertiesName.ME0058,
    /** エラーが発生しました。全件ロールバックを実施します。. */
    var ME0059: String = MessagePropertiesName.ME0059,
    /** メールデータの読み込みに失敗しました。開始行[{0}]. */
    var ME0060: String = MessagePropertiesName.ME0060,
    /** メール構築に失敗しました。開始行[{0}]. */
    var ME0061: String = MessagePropertiesName.ME0061,
    /** メール送信に失敗しました。開始行[{0}]. */
    var ME0062: String = MessagePropertiesName.ME0062,
    /** {0}は正の整数で入力してください。. */
    var ME0063: String = MessagePropertiesName.ME0063,
    /** メールの送信に失敗しました。[{0}]. */
    var ME0064: String = MessagePropertiesName.ME0064,
    /** {0}は全角{1}文字以内、半角{2}文字以内で入力してください。. */
    var ME0065: String = MessagePropertiesName.ME0065,
    /** {0}に失敗しました。時間を置いて再実施してください。. */
    var ME0066: String = MessagePropertiesName.ME0066,
    /** 該当する{0}が見つかりません。. */
    var ME0067: String = MessagePropertiesName.ME0067,
    /** ご指定の条件では、登録がありません。. */
    var ME0068: String = MessagePropertiesName.ME0068,
    /** {0}が登録されておりません。. */
    var ME0069: String = MessagePropertiesName.ME0069,
    /** {0}は整数{1}桁以内、小数{2}桁以内で入力してください。. */
    var ME0070: String = MessagePropertiesName.ME0070,
    /** 「出荷先（最終出荷先）、通貨、輸送方法」を指定してください。. */
    var ME9000: String = MessagePropertiesName.ME9000,
    /** 一定期間使用されていなかったためユーザーIDを一時停止しております。お手数ですが、担当営業までお問い合わせください。. */
    var ME9001: String = MessagePropertiesName.ME9001,
    /** カートへ登録される商品の個数を入力してください。. */
    var ME9002: String = MessagePropertiesName.ME9002,
    /** 「出荷先、最終出荷先、通貨、輸送方法」の組み合わせが１組のみになるよう選択してください。. */
    var ME9003: String = MessagePropertiesName.ME9003,
    /** アップロードするファイルを指定してください。. */
    var ME9004: String = MessagePropertiesName.ME9004,
    /** アップロードするファイルが見つかりません。ファイルが存在するか確認してください。. */
    var ME9005: String = MessagePropertiesName.ME9005,
    /** アップロードするファイルの中にデータがありません。ファイルを確認してください。. */
    var ME9006: String = MessagePropertiesName.ME9006,
    /** CSVファイルを指定してください。. */
    var ME9007: String = MessagePropertiesName.ME9007,
    /** 規定の形式のファイルではありません。ファイルを確認してください。. */
    var ME9008: String = MessagePropertiesName.ME9008,
    /** 文字コードが？と異なります。ファイルを確認してください。. */
    var ME9009: String = MessagePropertiesName.ME9009,
    /** 現在お取扱いしていない商品です。. */
    var ME9010: String = MessagePropertiesName.ME9010,
    /** 入目が誤っています。. */
    var ME9011: String = MessagePropertiesName.ME9011,
    /** ご指定の条件では、現在お取扱いしていない商品です。. */
    var ME9012: String = MessagePropertiesName.ME9012,
    /** エラーとなっている商品があります。エラーを解決後、再度アップロードしてください。. */
    var ME9013: String = MessagePropertiesName.ME9013,
    /** マッピング情報に「未設定」もしくは「エラー」の項目があるため、登録できません。. */
    var ME9014: String = MessagePropertiesName.ME9014,
    /** ダウンロードする帳票の種類を選択してください。. */
    var ME9015: String = MessagePropertiesName.ME9015,
    /** 「法規制確認・確認」と「削除」のいずれかのみにチェックしてください。. */
    var ME9016: String = MessagePropertiesName.ME9016,
    /** 取り込まれていないファイルが残っています。[{0}]. */
    var ME9017: String = MessagePropertiesName.ME9017,
    /** 一時ディレクトリへファイルを移動できませんでした。[{0}]. */
    var ME9018: String = MessagePropertiesName.ME9018,
    /** 本番ディレクトリへファイルをコピーできませんでした。[{0}]. */
    var ME9019: String = MessagePropertiesName.ME9019,
    /** 指定してください。. */
    var ME9020: String = MessagePropertiesName.ME9020,
    /** 半角英数字で指定してください。. */
    var ME9021: String = MessagePropertiesName.ME9021,
    /** 数値で指定してください。. */
    var ME9022: String = MessagePropertiesName.ME9022,
    /** 注文カートに登録されている商品と条件が異なります。出荷先、輸送方法、通貨をご確認ください。. */
    var ME9023: String = MessagePropertiesName.ME9023,
    /** 検索条件に該当する{0}は１件もありませんでした。検索条件を変更し、再検索してください。. */
    var MI0001: String = MessagePropertiesName.MI0001,
    /** メールを送信しました。. */
    var MI0002: String = MessagePropertiesName.MI0002,
    /** {0}を更新しました。. */
    var MI0003: String = MessagePropertiesName.MI0003,
    /** {0}を登録しました。. */
    var MI0004: String = MessagePropertiesName.MI0004,
    /** {0}が完了しました。. */
    var MI0005: String = MessagePropertiesName.MI0005,
    /** {0}テーブルを更新しました。[登録：{1}件 更新：{2}件 削除：{3}件]. */
    var MI0006: String = MessagePropertiesName.MI0006,
    /** {0}の削除が完了しました。[{1}件]. */
    var MI0007: String = MessagePropertiesName.MI0007,
    /** 論理削除された{0}の削除が完了しました。[{1}件]. */
    var MI0008: String = MessagePropertiesName.MI0008,
    /** {0}より以前の{1}を削除します。. */
    var MI0009: String = MessagePropertiesName.MI0009,
    /** {0}より以前の論理削除された{1}を削除します。. */
    var MI0010: String = MessagePropertiesName.MI0010,
    /** {0}を作成しました。[{1}]. */
    var MI0011: String = MessagePropertiesName.MI0011,
    /** {0}を削除しました。[{1}]. */
    var MI0012: String = MessagePropertiesName.MI0012,
    /** {0}を登録しました。[{1}]. */
    var MI0013: String = MessagePropertiesName.MI0013,
    /** {0}を変更しました。[{1}]. */
    var MI0014: String = MessagePropertiesName.MI0014,
    /** {0}を開始します。. */
    var MI0015: String = MessagePropertiesName.MI0015,
    /** 起動引数[{0}]. */
    var MI0016: String = MessagePropertiesName.MI0016,
    /** ロールバックが成功しました。. */
    var MI0017: String = MessagePropertiesName.MI0017,
    /** {0}を終了します。リターンコード[{1}]. */
    var MI0018: String = MessagePropertiesName.MI0018,
    /** 検索条件に該当する{0}は１件もありませんでした。. */
    var MI0019: String = MessagePropertiesName.MI0019,
    /** {0}を削除しました。. */
    var MI0020: String = MessagePropertiesName.MI0020,
    /** メールを送信しました。[{0}]. */
    var MI0021: String = MessagePropertiesName.MI0021,
    /** 差分抽出の基準時刻[{0}]. */
    var MI9000: String = MessagePropertiesName.MI9000,
    /** 次の実行まで{0}秒間待機します。. */
    var MI9001: String = MessagePropertiesName.MI9001,
    /** 前回との差分がありませんでした。処理を終了します。. */
    var MI9002: String = MessagePropertiesName.MI9002,
    /** 一時ディレクトリへファイルを移動しました。[{0}]. */
    var MI9003: String = MessagePropertiesName.MI9003,
    /** 本番ディレクトリへファイルをコピーしました。[{0}]. */
    var MI9004: String = MessagePropertiesName.MI9004,
    /** ログアウトします。よろしいですか？. */
    var MC0001: String = MessagePropertiesName.MC0001,
    /** パスワードを初期化します。よろしいですか？. */
    var MC0002: String = MessagePropertiesName.MC0002,
    /** ご入力いただいた内容で{0}を行います。よろしいですか？. */
    var MC0003: String = MessagePropertiesName.MC0003,
    /** ご入力いただいた内容で{0}を登録します。よろしいですか？. */
    var MC0004: String = MessagePropertiesName.MC0004,
    /** ご入力いただいた内容で{0}を更新します。よろしいですか？. */
    var MC0005: String = MessagePropertiesName.MC0005,
    /** ご確認いただいた内容で注文を決定します。よろしいですか？. */
    var MC0006: String = MessagePropertiesName.MC0006,
    /** ご入力いただいた内容で注文を変更します。よろしいですか？. */
    var MC0007: String = MessagePropertiesName.MC0007,
    /** 「{0}」にテストメールを送信します。よろしいですか？. */
    var MC0008: String = MessagePropertiesName.MC0008,
    /** このユーザーIDは現在ログイン中です。ログインを続行しますか？. */
    var MC0009: String = MessagePropertiesName.MC0009,
    /** 別ページで入力した内容も削除されます。よろしいですか？. */
    var MC0010: String = MessagePropertiesName.MC0010,
    /** ご入力いただいた内容で注文を決定します。よろしいですか？. */
    var MC0011: String = MessagePropertiesName.MC0011,
    /** ご注文をキャンセルします。よろしいですか？. */
    var MC0012: String = MessagePropertiesName.MC0012,
    /** マイリストより解除します。よろしいですか？. */
    var MC0013: String = MessagePropertiesName.MC0013,
    /** {0}を登録します。よろしいですか？. */
    var MC0014: String = MessagePropertiesName.MC0014,
    /** {0}を変更します。よろしいですか？. */
    var MC0015: String = MessagePropertiesName.MC0015,
    /** {0}を削除します。よろしいですか？. */
    var MC0016: String = MessagePropertiesName.MC0016,
    /** {0}を有効にします。よろしいですか？. */
    var MC0017: String = MessagePropertiesName.MC0017,
    /** {0}を無効にします。よろしいですか？. */
    var MC0018: String = MessagePropertiesName.MC0018,
    /** 希望納期を標準納期より前にご指定されている商品があります。ご希望に添えない場合がございますが処理を続けますか？. */
    var MC9000: String = MessagePropertiesName.MC9000,
    /** 現在ログインされています。代理ログインを続行しますか？. */
    var MC9001: String = MessagePropertiesName.MC9001,
    /** 「個数、希望納期、P/O No.」が同一の商品が既にカートに登録されています。カートへ登録しますか？. */
    var MC9002: String = MessagePropertiesName.MC9002,
    /** この得意先のマッピング情報は既に登録されています。上書きしてよろしいですか？. */
    var MC9003: String = MessagePropertiesName.MC9003,
    /** 「法規制確認」「確認」のいずれかのみチェックされている場合は確認完了にはなりません。処理を続けますか？. */
    var MC9004: String = MessagePropertiesName.MC9004,
    /** 「削除」をチェックしたOC帳票はファイルが削除されます。処理を続けますか？. */
    var MC9005: String = MessagePropertiesName.MC9005,
    /** システムエラーが発生しました。申し訳ございませんが、時間を置いて再度実行頂くか、ログインより再度操作をお願いします。. */
    var MA0001: String = MessagePropertiesName.MA0001,
    /** 初期パスワードが設定されています。パスワードを変更してください。. */
    var MW0001: String = MessagePropertiesName.MW0001,
    /** ご注文が正常に完了していない恐れがあります。申し訳ございませんが、注文履歴明細よりご確認ください。. */
    var MW0002: String = MessagePropertiesName.MW0002,
    /** 注文完了メールの送信に失敗しました。申し訳ございませんが、注文履歴ページよりご確認ください。. */
    var MW0003: String = MessagePropertiesName.MW0003,
    /** ログインされてから一定時間操作されていなかったためログアウトしました。お手数ですが、再度ログインをお願いします。. */
    var MW0004: String = MessagePropertiesName.MW0004,
    /** 本システムではブラウザの戻るなどの画面操作以外での遷移はできません。\nお手数ですが、ログインより操作を行ってください。. */
    var MW0005: String = MessagePropertiesName.MW0005,
    /** 標準納期より前の納期はご希望に添えない場合がございます。. */
    var MW9000: String = MessagePropertiesName.MW9000
)

/**
 * メッセージプロパティ名.
 */
object MessagePropertiesName {

  /** {0}を入力してください。. */
  const val ME0001 = "ME0001"
  /** {0}を指定してください。. */
  const val ME0002 = "ME0002"
  /** 無効な{0}です。. */
  const val ME0003 = "ME0003"
  /** {0}を選択してください。. */
  const val ME0004 = "ME0004"
  /** {0}は半角英数字で入力してください。. */
  const val ME0005 = "ME0005"
  /** {0}は半角数字で入力してください。. */
  const val ME0006 = "ME0006"
  /** {0}は半角英字で入力してください。. */
  const val ME0007 = "ME0007"
  /** {0}は半角文字で入力してください。. */
  const val ME0008 = "ME0008"
  /** {0}は半角文字、半角カナで入力してください。 . */
  const val ME0009 = "ME0009"
  /** {0}は全角文字で入力してください。. */
  const val ME0010 = "ME0010"
  /** {0}は数値で入力してください。. */
  const val ME0011 = "ME0011"
  /** {0}に負数はご指定いただけません。. */
  const val ME0012 = "ME0012"
  /** {0}に小数はご指定いただけません。. */
  const val ME0013 = "ME0013"
  /** {0}は{1}桁で入力してください。. */
  const val ME0014 = "ME0014"
  /** {0}は{1}桁以内で入力してください。. */
  const val ME0015 = "ME0015"
  /** {0}は{1}文字で入力してください。. */
  const val ME0016 = "ME0016"
  /** {0}は{1}文字以内で入力してください。. */
  const val ME0017 = "ME0017"
  /** {0}には正しい{1}を入力してください。. */
  const val ME0018 = "ME0018"
  /** {0}は{1}バイトで入力してください。. */
  const val ME0019 = "ME0019"
  /** 正しい{0}を入力してください。. */
  const val ME0020 = "ME0020"
  /** {0}が正しくありません。. */
  const val ME0021 = "ME0021"
  /** 有効な{0}を入力してください。. */
  const val ME0022 = "ME0022"
  /** {0}には有効な{1}を入力してください。. */
  const val ME0023 = "ME0023"
  /** {0}には本日から{1}年以内の日付を入力してください。. */
  const val ME0024 = "ME0024"
  /** {0}には本日から{1}ヶ月以内の日付を入力してください。. */
  const val ME0025 = "ME0025"
  /** {0}には本日から{1}日以内の日付を入力してください。. */
  const val ME0026 = "ME0026"
  /** 不正な引数です。引数[{0}]. */
  const val ME0027 = "ME0027"
  /** {0}がありません。. */
  const val ME0028 = "ME0028"
  /** {0}が見つかりませんでした。. */
  const val ME0029 = "ME0029"
  /** {0}が見つかりません[{1}]. */
  const val ME0030 = "ME0030"
  /** {0}の作成に失敗しました。[{1}]. */
  const val ME0031 = "ME0031"
  /** {0}の削除に失敗しました。[{1}]. */
  const val ME0032 = "ME0032"
  /** {0}の登録に失敗しました。[{1}]. */
  const val ME0033 = "ME0033"
  /** {0}の変更に失敗しました。[{1}]. */
  const val ME0034 = "ME0034"
  /** 規定の形式ではありません。[{0}]. */
  const val ME0035 = "ME0035"
  /** ユーザーID、もしくはパスワードが一致しません。. */
  const val ME0036 = "ME0036"
  /** パスワードは「8文字以上、30文字以下、半角英数大文字小文字」で入力してください。. */
  const val ME0037 = "ME0037"
  /** 新パスワードと一致するように入力してください。. */
  const val ME0038 = "ME0038"
  /** 電話番号は半角数字、\"-（ハイフン）\"区切りでご指定ください。. */
  const val ME0039 = "ME0039"
  /** 携帯電話の電話番号はご指定いただけません。. */
  const val ME0040 = "ME0040"
  /** メールの送信に失敗しました。. */
  const val ME0041 = "ME0041"
  /** メールアドレスの確認のため、テストメールを送信してください。送信完了後、受信ができているか確認をしてください。. */
  const val ME0042 = "ME0042"
  /** {0}を変更された場合はテスト送信をしてください。. */
  const val ME0043 = "ME0043"
  /** ご注文いただいた情報が一部古くなっております。大変申し訳ございませんが、最初からご注文をお願い致します。. */
  const val ME0044 = "ME0044"
  /** ご注文のステータスが更新されています。お手数ではありますが、注文履歴よりステータスをご確認ください。. */
  const val ME0045 = "ME0045"
  /** ご注文される商品の個数を入力してください。. */
  const val ME0046 = "ME0046"
  /** ご変更される商品の個数を入力、もしくはキャンセルをチェックしてください。. */
  const val ME0047 = "ME0047"
  /** {0}に失敗しました。. */
  const val ME0048 = "ME0048"
  /** {0}には{1}から{2}年以内の日付を入力してください。. */
  const val ME0049 = "ME0049"
  /** {0}には{1}から{2}ヶ月以内の日付を入力してください。. */
  const val ME0050 = "ME0050"
  /** {0}には{1}から{2}日以内の日付を入力してください。. */
  const val ME0051 = "ME0051"
  /** ご注文のステータスが更新されています。お手数ではありますが、再度ご検索頂きステータスをご確認ください。. */
  const val ME0052 = "ME0052"
  /** 現在ご注文頂けない商品が含まれています。. */
  const val ME0053 = "ME0053"
  /** {0}には本日から{1}年前までの日付を入力してください。. */
  const val ME0054 = "ME0054"
  /** {0}には本日から{1}ヶ月前までの日付を入力してください。. */
  const val ME0055 = "ME0055"
  /** {0}には本日から{1}日前までの日付を入力してください。. */
  const val ME0056 = "ME0056"
  /** {0}に失敗しました。時間を置いて再実施して頂くか、担当営業へご連絡ください。. */
  const val ME0057 = "ME0057"
  /** 起動引数の数が不正です。このプログラムの起動引数の数[{0}]　指定された起動引数の数[{1}]. */
  const val ME0058 = "ME0058"
  /** エラーが発生しました。全件ロールバックを実施します。. */
  const val ME0059 = "ME0059"
  /** メールデータの読み込みに失敗しました。開始行[{0}]. */
  const val ME0060 = "ME0060"
  /** メール構築に失敗しました。開始行[{0}]. */
  const val ME0061 = "ME0061"
  /** メール送信に失敗しました。開始行[{0}]. */
  const val ME0062 = "ME0062"
  /** {0}は正の整数で入力してください。. */
  const val ME0063 = "ME0063"
  /** メールの送信に失敗しました。[{0}]. */
  const val ME0064 = "ME0064"
  /** {0}は全角{1}文字以内、半角{2}文字以内で入力してください。. */
  const val ME0065 = "ME0065"
  /** {0}に失敗しました。時間を置いて再実施してください。. */
  const val ME0066 = "ME0066"
  /** 該当する{0}が見つかりません。. */
  const val ME0067 = "ME0067"
  /** ご指定の条件では、登録がありません。. */
  const val ME0068 = "ME0068"
  /** {0}が登録されておりません。. */
  const val ME0069 = "ME0069"
  /** {0}は整数{1}桁以内、小数{2}桁以内で入力してください。. */
  const val ME0070 = "ME0070"
  /** 「出荷先（最終出荷先）、通貨、輸送方法」を指定してください。. */
  const val ME9000 = "ME9000"
  /** 一定期間使用されていなかったためユーザーIDを一時停止しております。お手数ですが、担当営業までお問い合わせください。. */
  const val ME9001 = "ME9001"
  /** カートへ登録される商品の個数を入力してください。. */
  const val ME9002 = "ME9002"
  /** 「出荷先、最終出荷先、通貨、輸送方法」の組み合わせが１組のみになるよう選択してください。. */
  const val ME9003 = "ME9003"
  /** アップロードするファイルを指定してください。. */
  const val ME9004 = "ME9004"
  /** アップロードするファイルが見つかりません。ファイルが存在するか確認してください。. */
  const val ME9005 = "ME9005"
  /** アップロードするファイルの中にデータがありません。ファイルを確認してください。. */
  const val ME9006 = "ME9006"
  /** CSVファイルを指定してください。. */
  const val ME9007 = "ME9007"
  /** 規定の形式のファイルではありません。ファイルを確認してください。. */
  const val ME9008 = "ME9008"
  /** 文字コードが？と異なります。ファイルを確認してください。. */
  const val ME9009 = "ME9009"
  /** 現在お取扱いしていない商品です。. */
  const val ME9010 = "ME9010"
  /** 入目が誤っています。. */
  const val ME9011 = "ME9011"
  /** ご指定の条件では、現在お取扱いしていない商品です。. */
  const val ME9012 = "ME9012"
  /** エラーとなっている商品があります。エラーを解決後、再度アップロードしてください。. */
  const val ME9013 = "ME9013"
  /** マッピング情報に「未設定」もしくは「エラー」の項目があるため、登録できません。. */
  const val ME9014 = "ME9014"
  /** ダウンロードする帳票の種類を選択してください。. */
  const val ME9015 = "ME9015"
  /** 「法規制確認・確認」と「削除」のいずれかのみにチェックしてください。. */
  const val ME9016 = "ME9016"
  /** 取り込まれていないファイルが残っています。[{0}]. */
  const val ME9017 = "ME9017"
  /** 一時ディレクトリへファイルを移動できませんでした。[{0}]. */
  const val ME9018 = "ME9018"
  /** 本番ディレクトリへファイルをコピーできませんでした。[{0}]. */
  const val ME9019 = "ME9019"
  /** 指定してください。. */
  const val ME9020 = "ME9020"
  /** 半角英数字で指定してください。. */
  const val ME9021 = "ME9021"
  /** 数値で指定してください。. */
  const val ME9022 = "ME9022"
  /** 注文カートに登録されている商品と条件が異なります。出荷先、輸送方法、通貨をご確認ください。. */
  const val ME9023 = "ME9023"
  /** 検索条件に該当する{0}は１件もありませんでした。検索条件を変更し、再検索してください。. */
  const val MI0001 = "MI0001"
  /** メールを送信しました。. */
  const val MI0002 = "MI0002"
  /** {0}を更新しました。. */
  const val MI0003 = "MI0003"
  /** {0}を登録しました。. */
  const val MI0004 = "MI0004"
  /** {0}が完了しました。. */
  const val MI0005 = "MI0005"
  /** {0}テーブルを更新しました。[登録：{1}件 更新：{2}件 削除：{3}件]. */
  const val MI0006 = "MI0006"
  /** {0}の削除が完了しました。[{1}件]. */
  const val MI0007 = "MI0007"
  /** 論理削除された{0}の削除が完了しました。[{1}件]. */
  const val MI0008 = "MI0008"
  /** {0}より以前の{1}を削除します。. */
  const val MI0009 = "MI0009"
  /** {0}より以前の論理削除された{1}を削除します。. */
  const val MI0010 = "MI0010"
  /** {0}を作成しました。[{1}]. */
  const val MI0011 = "MI0011"
  /** {0}を削除しました。[{1}]. */
  const val MI0012 = "MI0012"
  /** {0}を登録しました。[{1}]. */
  const val MI0013 = "MI0013"
  /** {0}を変更しました。[{1}]. */
  const val MI0014 = "MI0014"
  /** {0}を開始します。. */
  const val MI0015 = "MI0015"
  /** 起動引数[{0}]. */
  const val MI0016 = "MI0016"
  /** ロールバックが成功しました。. */
  const val MI0017 = "MI0017"
  /** {0}を終了します。リターンコード[{1}]. */
  const val MI0018 = "MI0018"
  /** 検索条件に該当する{0}は１件もありませんでした。. */
  const val MI0019 = "MI0019"
  /** {0}を削除しました。. */
  const val MI0020 = "MI0020"
  /** メールを送信しました。[{0}]. */
  const val MI0021 = "MI0021"
  /** 差分抽出の基準時刻[{0}]. */
  const val MI9000 = "MI9000"
  /** 次の実行まで{0}秒間待機します。. */
  const val MI9001 = "MI9001"
  /** 前回との差分がありませんでした。処理を終了します。. */
  const val MI9002 = "MI9002"
  /** 一時ディレクトリへファイルを移動しました。[{0}]. */
  const val MI9003 = "MI9003"
  /** 本番ディレクトリへファイルをコピーしました。[{0}]. */
  const val MI9004 = "MI9004"
  /** ログアウトします。よろしいですか？. */
  const val MC0001 = "MC0001"
  /** パスワードを初期化します。よろしいですか？. */
  const val MC0002 = "MC0002"
  /** ご入力いただいた内容で{0}を行います。よろしいですか？. */
  const val MC0003 = "MC0003"
  /** ご入力いただいた内容で{0}を登録します。よろしいですか？. */
  const val MC0004 = "MC0004"
  /** ご入力いただいた内容で{0}を更新します。よろしいですか？. */
  const val MC0005 = "MC0005"
  /** ご確認いただいた内容で注文を決定します。よろしいですか？. */
  const val MC0006 = "MC0006"
  /** ご入力いただいた内容で注文を変更します。よろしいですか？. */
  const val MC0007 = "MC0007"
  /** 「{0}」にテストメールを送信します。よろしいですか？. */
  const val MC0008 = "MC0008"
  /** このユーザーIDは現在ログイン中です。ログインを続行しますか？. */
  const val MC0009 = "MC0009"
  /** 別ページで入力した内容も削除されます。よろしいですか？. */
  const val MC0010 = "MC0010"
  /** ご入力いただいた内容で注文を決定します。よろしいですか？. */
  const val MC0011 = "MC0011"
  /** ご注文をキャンセルします。よろしいですか？. */
  const val MC0012 = "MC0012"
  /** マイリストより解除します。よろしいですか？. */
  const val MC0013 = "MC0013"
  /** {0}を登録します。よろしいですか？. */
  const val MC0014 = "MC0014"
  /** {0}を変更します。よろしいですか？. */
  const val MC0015 = "MC0015"
  /** {0}を削除します。よろしいですか？. */
  const val MC0016 = "MC0016"
  /** {0}を有効にします。よろしいですか？. */
  const val MC0017 = "MC0017"
  /** {0}を無効にします。よろしいですか？. */
  const val MC0018 = "MC0018"
  /** 希望納期を標準納期より前にご指定されている商品があります。ご希望に添えない場合がございますが処理を続けますか？. */
  const val MC9000 = "MC9000"
  /** 現在ログインされています。代理ログインを続行しますか？. */
  const val MC9001 = "MC9001"
  /** 「個数、希望納期、P/O No.」が同一の商品が既にカートに登録されています。カートへ登録しますか？. */
  const val MC9002 = "MC9002"
  /** この得意先のマッピング情報は既に登録されています。上書きしてよろしいですか？. */
  const val MC9003 = "MC9003"
  /** 「法規制確認」「確認」のいずれかのみチェックされている場合は確認完了にはなりません。処理を続けますか？. */
  const val MC9004 = "MC9004"
  /** 「削除」をチェックしたOC帳票はファイルが削除されます。処理を続けますか？. */
  const val MC9005 = "MC9005"
  /** システムエラーが発生しました。申し訳ございませんが、時間を置いて再度実行頂くか、ログインより再度操作をお願いします。. */
  const val MA0001 = "MA0001"
  /** 初期パスワードが設定されています。パスワードを変更してください。. */
  const val MW0001 = "MW0001"
  /** ご注文が正常に完了していない恐れがあります。申し訳ございませんが、注文履歴明細よりご確認ください。. */
  const val MW0002 = "MW0002"
  /** 注文完了メールの送信に失敗しました。申し訳ございませんが、注文履歴ページよりご確認ください。. */
  const val MW0003 = "MW0003"
  /** ログインされてから一定時間操作されていなかったためログアウトしました。お手数ですが、再度ログインをお願いします。. */
  const val MW0004 = "MW0004"
  /** 本システムではブラウザの戻るなどの画面操作以外での遷移はできません。\nお手数ですが、ログインより操作を行ってください。. */
  const val MW0005 = "MW0005"
  /** 標準納期より前の納期はご希望に添えない場合がございます。. */
  const val MW9000 = "MW9000"
}
