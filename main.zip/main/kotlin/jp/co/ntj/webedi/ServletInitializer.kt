package jp.co.ntj.webedi

import org.springframework.boot.builder.SpringApplicationBuilder
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer

/**
 * ServleInitializer.
 *
 * @author 日立システムズ
 */
class ServletInitializer : SpringBootServletInitializer() {

	override fun configure(application: SpringApplicationBuilder): SpringApplicationBuilder {
		return application.sources(NtjWebEdiApplication::class.java)
	}

}

