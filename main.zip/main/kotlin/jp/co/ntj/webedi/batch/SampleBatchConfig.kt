package jp.co.ntj.webedi.batch

import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import javax.sql.DataSource

@Configuration
@EnableBatchProcessing
class SampleBatchConfig() {

  // メタテーブルを作成しない
  inner class MyDefaultBatchConfigurer : DefaultBatchConfigurer() {
    override fun setDataSource(dataSource: DataSource) {
    }
  }

  @Bean
  fun batchConfigurer(): DefaultBatchConfigurer {
    return MyDefaultBatchConfigurer()
  }
}