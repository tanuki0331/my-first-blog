package jp.co.ntj.webedi.batch

import jp.co.ntj.webedi.batch.properties.BatchProperties
import jp.co.ntj.webedi.domain.entity.table.InvReport
import jp.co.ntj.webedi.domain.entity.table.OcReport
import jp.co.ntj.webedi.domain.entity.table.PinvReport
import jp.co.ntj.webedi.domain.service.DeleteInvalidDataService
import org.slf4j.Logger
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Service
import java.nio.file.Files
import java.nio.file.Paths
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

/**
 * 不要データ削除バッチ.
 *
 * @author 日立システムズ
 */
@Service
@ConditionalOnProperty(name = ["batch"], havingValue = "DeleteInvalidData")
class DeleteInvalidData(
    val deleteInvalidDataService: DeleteInvalidDataService,
    val batchProperties: BatchProperties,
    val batchLogger: Logger) : BaseCommandLineBatch() {

  override fun execute(): Int {

    // 得意先マスタに紐付くデータ削除
    updateForDelByInvalidTokui()

    // 得意先ユーザーに紐付くデータ削除
    updateForDelByInvalidCustomerUser()

    // 仕向先マスタ／最終仕向先マスタに紐付くデータ削除
    updateForDelByInvalidShimu()

    // プライスリスト情報に紐付くデータ削除
    updateForDelByInvalidPlist()

    // ファイルが存在しないOC帳票データ削除
    deleteFileNoExistOcReport()

    // ファイルが存在しないP/I帳票データ削除
    deleteFileNoExistPinvReport()

    // ファイルが存在しないINV帳票データ削除
    deleteFileNoExistInvReport()

    // 保管期間が終了したデータ削除
    deleteExpiredDate()

    // 論理削除されたデータ削除
    deleteDeletedDate()

    return 0
  }

  /**
   * 存在しないもしくは論理削除された得意先に紐付くデータを論理削除する
   */
  fun updateForDelByInvalidTokui() {
    deleteInvalidDataService.logicalDelCustomerUserByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelOrderDataMappingByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelOcReportByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelOcDownloadHistoryByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelOcConfirmationByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelPinvReportByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelPinvDownloadHistoryByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelPinvConfirmationByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelInvReportByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelInvDownloadHistoryByInvalidTokui(UPDATE_USER)
    deleteInvalidDataService.logicalDelShipToUserByInvalidTokui(UPDATE_USER)
  }

  /**
   * 存在しないもしくは論理削除された得意先ユーザーに紐付くデータを論理削除する
   */
  fun updateForDelByInvalidCustomerUser() {
    deleteInvalidDataService.logicalDelCustomerUserDlvyMailByInvalidCstmUser(UPDATE_USER)
    deleteInvalidDataService.logicalDelCustomerUserAccessInfoByInvalidCstmUser(UPDATE_USER)
    deleteInvalidDataService.logicalDelCustomerUserAuthorityByInvalidCstmUser(UPDATE_USER)
    deleteInvalidDataService.logicalDelSearchConditionByInvalidCstmUser(UPDATE_USER)
    deleteInvalidDataService.logicalDelOrderCartHeaderByInvalidCstmUser(UPDATE_USER)
    deleteInvalidDataService.logicalDelOrderCartDetailByInvalidCstmUser(UPDATE_USER)
    deleteInvalidDataService.logicalDelShipToUserByInvalidCstmUser(UPDATE_USER)
  }

  /**
   * 論理削除もしくは物理削除された仕向先／最終仕向先に紐付くデータを削除する
   */
  fun updateForDelByInvalidShimu() {
    deleteInvalidDataService.logicalDelSearchConditionByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelOrderCartHeaderByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelOrderCartDetailByHeader(UPDATE_USER)
    deleteInvalidDataService.logicalDelOcReportByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelOcDownloadHistoryByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelOcConfirmationByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelPinvReportByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelPinvDownloadHistoryByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelPinvConfirmationByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelInvReportByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelInvDownloadHistoryByInvalidShimu(UPDATE_USER)
    deleteInvalidDataService.logicalDelShipToUserByInvalidShimu(UPDATE_USER)
  }

  /**
   * 論理削除もしくは物理削除されたプライスリスト情報に紐付くデータを削除する
   */
  fun updateForDelByInvalidPlist() {
    deleteInvalidDataService.logicalDelOrderCartDetailByInvalidPlist(UPDATE_USER)
    deleteInvalidDataService.logicalDelOrderCartHeaderByDetail(UPDATE_USER)
  }

  /**
   * ファイルが存在しないOC帳票のデータを削除する
   */
  fun deleteFileNoExistOcReport() {

    // 削除対象のOC帳票リスト
    val delOcReports = mutableListOf<OcReport>()

    // 全OC帳票をチェック
    deleteInvalidDataService.getOcReports()
        .forEachIndexed { index, ocReport ->
          if (isExistFile(ocReport.filePath)) {
            delOcReports.add(ocReport)
          }

          // 1000件ごとに一括削除
          if (index % 1000 == 0 && delOcReports.isNotEmpty()) {
            deleteInvalidDataService.deleteOcReport(delOcReports)
            deleteInvalidDataService.deleteOcDownloadHistory(delOcReports)
            deleteInvalidDataService.deleteOcConfirmation(delOcReports)
            delOcReports.clear()
          }
        }

    // リストに残っていれば削除
    if (delOcReports.isNotEmpty()) {
      deleteInvalidDataService.deleteOcReport(delOcReports)
      deleteInvalidDataService.deleteOcDownloadHistory(delOcReports)
      deleteInvalidDataService.deleteOcConfirmation(delOcReports)
    }
  }

  /**
   * ファイルが存在しないP/I帳票のデータを削除する
   */
  fun deleteFileNoExistPinvReport() {

    // 削除対象のP/I帳票リスト
    val delPinvReports = mutableListOf<PinvReport>()

    // 全P/I帳票をチェック
    deleteInvalidDataService.getPinvReports()
        .forEachIndexed { index, pinvReport ->
          if (isExistFile(pinvReport.filePath)) {
            delPinvReports.add(pinvReport)
          }

          // 1000件ごとに一括削除
          if (index % 1000 == 0 && delPinvReports.isNotEmpty()) {
            deleteInvalidDataService.deletePinvReport(delPinvReports)
            deleteInvalidDataService.deletePinvDownloadHistory(delPinvReports)
            deleteInvalidDataService.deletePinvConfirmation(delPinvReports)
            delPinvReports.clear()
          }
        }

    // リストに残っていれば削除
    if (delPinvReports.isNotEmpty()) {
      deleteInvalidDataService.deletePinvReport(delPinvReports)
      deleteInvalidDataService.deletePinvDownloadHistory(delPinvReports)
      deleteInvalidDataService.deletePinvConfirmation(delPinvReports)
    }
  }

  /**
   * ファイルが存在しないINV帳票のデータを削除する
   */
  fun deleteFileNoExistInvReport() {

    // 削除対象のINV帳票リスト
    val delInvReports = mutableListOf<InvReport>()

    // 全INV帳票をチェック
    deleteInvalidDataService.getInvReports()
        .forEachIndexed { index, invReport ->
          if (isExistFile(invReport.filePath)) {
            delInvReports.add(invReport)
          }

          // 1000件ごとに一括削除
          if (index % 1000 == 0 && delInvReports.isNotEmpty()) {
            deleteInvalidDataService.deleteInvReport(delInvReports)
            deleteInvalidDataService.deleteInvDownloadHistory(delInvReports)
            delInvReports.clear()
          }
        }

    // リストに残っていれば削除
    if (delInvReports.isNotEmpty()) {
      deleteInvalidDataService.deleteInvReport(delInvReports)
      deleteInvalidDataService.deleteInvDownloadHistory(delInvReports)
    }
  }

  /**
   * 保管期間が終了したデータを削除する
   */
  fun deleteExpiredDate() {

    // 注文カートヘッダ
    calcExpiredDate(batchProperties.storagePeriod.orderCartHeader)?.let { exp ->
      deleteInvalidDataService.deleteExpiredOrderCart(exp)
    }
    // 注文カート明細
    calcExpiredDate(batchProperties.storagePeriod.orderCartDetail)?.let { exp ->
      deleteInvalidDataService.deleteExpiredOrderCartDetail(exp)
    }
    // OC帳票マスタ
    calcExpiredDate(batchProperties.storagePeriod.ocReport)?.let { exp ->
      deleteInvalidDataService.deleteExpiredOcReport(exp)
    }
    // OC帳票ダウンロード履歴
    calcExpiredDate(batchProperties.storagePeriod.ocDownloadHistory)?.let { exp ->
      deleteInvalidDataService.deleteExpiredOcDownloadHistory(exp)
    }
    // OC帳票確認
    calcExpiredDate(batchProperties.storagePeriod.ocConfirmation)?.let { exp ->
      deleteInvalidDataService.deleteExpiredOcConfirmation(exp)
    }
    // P/I帳票マスタ
    calcExpiredDate(batchProperties.storagePeriod.pinvReport)?.let { exp ->
      deleteInvalidDataService.deleteExpiredPinvReport(exp)
    }
    // P/I帳票ダウンロード履歴
    calcExpiredDate(batchProperties.storagePeriod.pinvDownloadHistory)?.let { exp ->
      deleteInvalidDataService.deleteExpiredPinvDownloadHistory(exp)
    }
    // P/I帳票確認
    calcExpiredDate(batchProperties.storagePeriod.pinvConfirmation)?.let { exp ->
      deleteInvalidDataService.deleteExpiredPinvConfirmation(exp)
    }
    // INV帳票マスタ
    calcExpiredDate(batchProperties.storagePeriod.invReport)?.let { exp ->
      deleteInvalidDataService.deleteExpiredInvReport(exp)
    }
    // INV帳票ダウンロード履歴
    calcExpiredDate(batchProperties.storagePeriod.invDownloadHistory)?.let { exp ->
      deleteInvalidDataService.deleteExpiredInvDownloadHistory(exp)
    }
  }

  /**
   * 保管期間が終了した論理削除ずみデータを削除する
   */
  fun deleteDeletedDate() {

    calcExpiredDate(batchProperties.storagePeriod.logicalDelete)?.let { exp ->
      deleteInvalidDataService.deleteDeletedCode(exp)
      deleteInvalidDataService.deleteDeletedCustomerUser(exp)
      deleteInvalidDataService.deleteDeletedCustomerUserAccessInfo(exp)
      deleteInvalidDataService.deleteDeletedCustomerUserAuthority(exp)
      deleteInvalidDataService.deleteDeletedCustomerUserDlvyMail(exp)
      deleteInvalidDataService.deleteDeletedEmployeeUser(exp)
      deleteInvalidDataService.deleteDeletedEmployeeUserAccessInfo(exp)
      deleteInvalidDataService.deleteDeletedEmployeeUserAuthority(exp)
      deleteInvalidDataService.deleteDeletedGeneralNews(exp)
      deleteInvalidDataService.deleteDeletedInvDownloadHistory(exp)
      deleteInvalidDataService.deleteDeletedInvReport(exp)
      deleteInvalidDataService.deleteDeletedOcConfirmation(exp)
      deleteInvalidDataService.deleteDeletedOcDownloadHistory(exp)
      deleteInvalidDataService.deleteDeletedOcReport(exp)
      deleteInvalidDataService.deleteDeletedOrderCartDetail(exp)
      deleteInvalidDataService.deleteDeletedOrderCartHeader(exp)
      deleteInvalidDataService.deleteDeletedOrderDataMapping(exp)
      deleteInvalidDataService.deleteDeletedPinvConfirmation(exp)
      deleteInvalidDataService.deleteDeletedPinvDownloadHistory(exp)
      deleteInvalidDataService.deleteDeletedPinvReport(exp)
      deleteInvalidDataService.deleteDeletedProcessExecuteTime(exp)
      deleteInvalidDataService.deleteDeletedSearchCondition(exp)
      deleteInvalidDataService.deleteDeletedShipToUser(exp)
    }
  }



  /**
   * 指定された期間日数から期限となる日付(時間は切り捨て)を取得する
   *
   * @param period 期限日数
   * @return 期限となる日付、ただし日数が空もしくは不正な数値の場合はnullが返却される
   */
  fun calcExpiredDate(period: String): LocalDateTime? {
    try {
      if (period.isBlank()) {
        return null
      }
      return LocalDateTime.now().truncatedTo(ChronoUnit.DAYS).minusDays(period.toLong())
    } catch (e: NumberFormatException) {
      return null
    }
  }

  /**
   * ファイルの存在チェック
   *
   * @param filePath ファイルのパス
   */
  fun isExistFile(filePath: String): Boolean {
    return try {
      Files.isRegularFile(Paths.get(filePath))
    } catch (e: Exception) {
      false
    }
  }

  companion object {
    const val UPDATE_USER = "SYSTEM"
  }
}

