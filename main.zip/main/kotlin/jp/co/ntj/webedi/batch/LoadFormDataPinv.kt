package jp.co.ntj.webedi.batch

import jp.co.ntj.webedi.batch.common.BatchMessages
import jp.co.ntj.webedi.batch.properties.BatchProperties
import jp.co.ntj.webedi.domain.entity.table.PinvReport
import jp.co.ntj.webedi.service.LoadFormDataPinvService
import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Service
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Paths
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * ProformaInvoice帳票データロードバッチ.
 *
 * @author 日立システムズ
 */
@Service
@ConditionalOnProperty(name = ["batch"], havingValue = "loadfrompinv")
class LoadFormDataPinv(
    val loadFormDataPinvService: LoadFormDataPinvService,
    val batchLogger: Logger,
    val batchProperties: BatchProperties) : BaseCommandLineBatch()
{

  // 連携ディレクトリ
  var loadDir: String = ""
  // 待機秒数
  var repeatSecond: String = ""
  // エラーフラグ
  var errorFlg = false
  // メッセージ定数
  var message: BatchMessages = BatchMessages();
  // 全て取得フラグ
  var allFileTarget = false
  // 繰り返しフラグ
  var loopFlg = false
  // 日時フォーマッタ
  val dateFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
  // 一時ディレクトリパス
  var tempDirectory = ""
  // 処理時刻
  var executeAt = ""
  // 実行ユーザ
  val createdUser = "SYSTEM";
  // 出荷先コードの社員マスタのMap<[出荷先コード],Map<社員名,メールアドレス>>
  var shipUserMap = LinkedHashMap<String, Map<String, String>>()
  // 出荷先コードごとのProformaInvoice番号のリストMap<出荷先コード,List<Invoice番号>>
  var pinvNumberMap = LinkedHashMap<String, ArrayList<String>>()


  override fun init(vararg args: String?) {
    super.init(*args)

    // 引数チェック
    checkArgs(*args)

    batchLogger.debug("start LoadFormDataInv [$args]")
  }

  override fun execute(): Int {

    if (!errorFlg) {
      do {
        // 前回処理時刻の取得
        executeAt = loadFormDataPinvService.getProcessExecuteTime()
        if (StringUtils.isEmpty(executeAt)) {
          allFileTarget = true
        }
        batchLogger.info(message.MI9000.replace("{0}", executeAt))

        // 一時ディレクトリの作成
        if (!createTemporalyDir()) {
          // エラー終了
          break
        }

        // 差分ファイルのファイル移動(一時ディレクトリへ)
        if (!copyTargetInvoiceFile()) {
          // エラー終了
          break
        }

        // データ登録処理(本番ディレクトリへファイルコピーして削除)
        if (!registInvoiceFile()) {
          // エラー終了
          break
        }

        // 一時ディレクトリの削除
        deleteTempDirectory()

        // メール送信
        sendMail()

        // 処理時刻の保存
        loadFormDataPinvService.saveProcessExecuteTime()

        // 繰り返し実行
        if (!org.apache.commons.lang3.StringUtils.isEmpty(repeatSecond)) {
          batchLogger.info(message.MI9001.replace("{0}", repeatSecond))

          // 指定秒数待つ
          var second = repeatSecond.toLong() * 1000
          Thread.sleep(second)
        }
      } while (loopFlg)

      if (errorFlg) {
        return -1 // 終了コード
      }

      batchLogger.info(message.MI0005.replace("{0}", "データ移行処理"))
      return 0 // 終了コード

    } else {
      return -1 // 終了コード
    }
  }

  /**
   * 引数チェック
   */
  fun checkArgs(vararg args: String?) {
    if (args.size >= 2) {
      if (args.size >= 3) {
        if (!org.apache.commons.lang3.math.NumberUtils.isDigits(args[2])) {
          // 正の数値でなければエラー
          batchLogger.error(message.ME0063.replace("{0}", "待機秒数"))
          errorFlg = true
        } else {
          repeatSecond = args[2].toString()
          loopFlg = true
        }
      }

      var file = File(args[1])
      if (file.exists() && file.isDirectory) {
        // 連携ディレクトリは有効
        loadDir = args[1].toString()
      } else {
        // 連携ディレクトリは無効
        batchLogger.error(message.ME0029.replace("{0}", "連携ディレクトリ"))
        errorFlg = true
      }

    } else {
      batchLogger.error(message.ME0029.replace("{0}", "引数"))
      errorFlg = true
    }
  }

  /**
   * 一時ディレクトリの作成
   */
  fun createTemporalyDir() : Boolean {
    val tempDir = getTemporaryDir()
    val now = LocalDateTime.now()
    val todayStr = now.format(dateFormatter) // 今日の日付
    tempDirectory = tempDir + "/" + todayStr

    val file: File = File(tempDir)
    if (file.exists() && file.isDirectory) {
      // 連携ディレクトリは有効

      // 一時フォルダを作成
      val createFile = File(tempDirectory)
      if (!createFile.mkdir()) {
        // 一時ディレクトリ作成失敗

      } else {
        var msg = message.MI0011
        msg = msg.replace("{0}", "一時ディレクトリ")
        msg = msg.replace("{1}", tempDirectory)
        batchLogger.info(msg)
      }

    }
    return !errorFlg
  }

  /**
   * 差分ファイルのファイル移動
   */
  fun copyTargetInvoiceFile() : Boolean {
    var loadDirFile = File(loadDir)
    var fileList = loadDirFile.listFiles()
    fileList.forEach {
      if (allFileTarget) {
        // 全てのファイルが対象
        var fromFileName = Paths.get(it.path)
        var from =  it.name
        var to = tempDirectory + "/" + from
        var toFilename = Paths.get(to)

        try {
          Files.copy(fromFileName, toFilename)
          var msg = message.MI9003
          msg = msg.replace("{0}", to)
          batchLogger.info(msg)

        } catch (e: IOException) {
          var msg = message.ME9018
          msg = msg.replace("{0}", to)
          batchLogger.error(msg)
        }

      } else {
        // 処理時刻以降のファイルが対象
        var updatetime = it.lastModified()
        val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        var updatetimeStr = simpleDateFormat.format(updatetime)
        if (updatetimeStr > executeAt) {
          var fromFileName = Paths.get(it.path)
          var from =  it.name
          var to = tempDirectory + "/" + from
          var toFilename = Paths.get(to)

          try {
            Files.copy(fromFileName, toFilename)

            var msg = message.MI9003
            msg = msg.replace("{0}", to)
            batchLogger.info(msg)

          } catch (e: IOException) {
            var msg = message.ME9018
            msg = msg.replace("{0}", to)
            batchLogger.error(msg)
          }
        }
      }
    }
    return true;
  }

  /**
   * データ登録処理(本番ディレクトリへファイルコピーして削除)
   */
  fun registInvoiceFile(): Boolean {
    var copyCount = 0

    var loadDirFile = File(tempDirectory)
    var fileList = loadDirFile.listFiles()

    if (fileList != null) {
      var fileListLoop = arrayOf(fileList)
      var masterCopyErrFlg = false;

      fileListLoop[0].forEach {
        copyCount++

        // 本番ディレクトリにファイルコピー
        var from = it.path
        var fromFileName = Paths.get(from)
        var to = getMasterDir() + "/" + it.name
        var toFilename = Paths.get(to)

        // 同名ファイルは上書き
        var toFIle = File(to)
        if (toFIle.exists()) {
          toFIle.delete()
        }
        try {
          Files.copy(fromFileName, toFilename)

          var msg = message.MI9004
          msg = msg.replace("{0}", to)
          batchLogger.info(msg)
          masterCopyErrFlg = false

        } catch (e: IOException) {
          var msg = message.ME9019
          msg = msg.replace("{0}", to)
          batchLogger.error(msg)
          masterCopyErrFlg = true
        }

        // マスタ登録
        // ファイル名から必要なデータを取得
        var kaisya_cd = "" // 会社コード
        var gengo_kbn = "" // 言語区分
        var customer_code = 0L // 得意先コード
        var destination_code = 0L // 出荷先コード
        var pinv_number = "" // ProformaInvoice番号

        var filename = it.name.split(".")
        var params = filename[0].split("_")
        if (params.size >= 7) {
          kaisya_cd = params[0]
          gengo_kbn = params[1]
          customer_code = params[4].toLong()
          destination_code = params[5].toLong()
          pinv_number = params[3]

          var datetime = LocalDateTime.now()
          var zoneDatetime = ZonedDateTime.of(datetime,  ZoneId.systemDefault())
          var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssXXX")
          var datetimestr = formatter.format(zoneDatetime)

          var pinvReport = loadFormDataPinvService.getPinvReport(kaisya_cd,gengo_kbn,customer_code,destination_code,pinv_number)
          if (pinvReport != null) {
            // 登録済み
            pinvReport.issueAt = toLocalDate(params[6], "yyyyMMdd")
            pinvReport.filePath = toFilename.toString()
            pinvReport.updatedAt = datetimestr
            pinvReport.updatedUser = createdUser

            var updateCount = loadFormDataPinvService.updatePinvRepoet(pinvReport)
            if (updateCount == 1) {
              var msg = message.MI0014
              msg = msg.replace("{0}", "P/I帳票")
              msg = msg.replace("{1}", toFilename.toString())
              batchLogger.info(msg)
            } else {
              // 更新に失敗した場合本番ディレクトリにコピーしたファイルを削除する
              toFIle.delete()
            }

            //TODO 帳票確認を削除する

          } else {
            // 新規登録
            pinvReport = PinvReport()
            pinvReport.kaisyaCd = kaisya_cd
            pinvReport.gengoKbn = gengo_kbn
            pinvReport.customerCode = customer_code
            pinvReport.destinationCode = destination_code
            pinvReport.pinvNumber = pinv_number
            pinvReport.issueAt = toLocalDate(params[6], "yyyyMMdd")
            pinvReport.filePath = toFilename.toString()
            pinvReport.isDeleted = 0
            pinvReport.createdAt = datetimestr
            pinvReport.createdUser = createdUser
            pinvReport.updatedAt = datetimestr
            pinvReport.updatedUser = createdUser

            var insertCount = loadFormDataPinvService.insertPinvRepoet(pinvReport)
            if (insertCount == 1) {
              var msg = message.MI0013
              msg = msg.replace("{0}", "P/I帳票")
              msg = msg.replace("{1}", toFilename.toString())
              batchLogger.info(msg)
            } else {
              // 登録に失敗した場合本番ディレクトリにコピーしたファイルを削除する
              toFIle.delete()
            }
          }

          // 帳票確認データは物理削除
          loadFormDataPinvService.deletePinvConfirmation(kaisya_cd,gengo_kbn,customer_code,destination_code,pinv_number)

          // メール送信
          createMailSendData(destination_code, pinv_number)

          // 一時ディレクトリのファイル削除
          if (!masterCopyErrFlg) {
            var fromFile = File(fromFileName.toString())
            fromFile.delete()

            // ログメッセージ出力
            var msg = message.MI0012
            msg = msg.replace("{0}", "P/I帳票ファイル")
            msg = msg.replace("{1}", fromFileName.toString())
            batchLogger.info(msg)
          }

        } else {
          // ファイル名の形式が想定と異なっている場合は削除する
          if (!masterCopyErrFlg) {
            toFIle.delete()
          }
        }
      }
    }

    if (copyCount == 0) {
      // 処理対象がなければメッセージ出力
      batchLogger.info(message.MI9002)
    }

    return true
  }

  /**
   * メール送信用の情報を取得する
   */
  fun createMailSendData(destination_code: Long, inv_number: String) {
    // 社員ユーザー情報
    if (!shipUserMap.containsKey(destination_code.toString())) {
      var userMap = loadFormDataPinvService.getUserMap(destination_code)
      shipUserMap.put(destination_code.toString(), userMap)
    }
    // 会社ごとのInvoice番号
    if (!pinvNumberMap.containsKey(destination_code.toString())) {
      pinvNumberMap.put(destination_code.toString(), arrayListOf())
    }
    var invList = pinvNumberMap.get(destination_code.toString())
    if (invList != null) {
      invList.add(inv_number)
    }
  }

  /**
   * 一時ディレクトリの削除
   */
  fun deleteTempDirectory(): Boolean {
    var tempDir = File(tempDirectory)
    if (tempDir.exists()) {
      if (tempDir.isDirectory) {
        if (tempDir.listFiles().isEmpty()) {
          tempDir.delete()

          var msg = message.MI0012
          msg = msg.replace("{0}", "一時ディレクトリ")
          msg = msg.replace("{1}", tempDirectory)
          batchLogger.info(msg)

        } else {
          // 一時ファイルが残っていれば残してエラー出力
          var msg = message.ME9017
          msg = msg.replace("{0}", tempDirectory)
          batchLogger.error(msg)
        }
      }
    }
    return true
  }

  /**
   * メール送信
   */
  fun sendMail(): Boolean {
    // 「INV発行メール」を送信する。
    // 宛先は「担当営業」とする。
    // 宛先ごとにメールをマージする。（参照：共通仕様[メール宛先マージ]）
    // メールにはP/I帳票の情報「Invoice番号」を含める。

    for ((key, value) in shipUserMap) {
      var pinvNumbers = pinvNumberMap.get(key) // Inv番号のリスト
      for ((name, email) in value) {

        //TODO:テンプレートを使用してメール送信する
        batchLogger.debug("name[$name]")
        batchLogger.debug("email[$email]")

        for (pinvNumber in arrayOf(pinvNumbers)) {
          batchLogger.debug("pinvNumber[$pinvNumber]")
        }

        var msg = message.MI0021
        msg = msg.replace("{0}", email)
        batchLogger.info(msg)
      }
    }

    return true
  }

  /**
   * 一時ディレクトリ名を取得する
   */
  fun getTemporaryDir(): String {
    return batchProperties.invloadtemporarydir
  }

  /**
   * 本番ディレクトリ名を取得する
   */
  fun getMasterDir(): String {
    return batchProperties.invloadmasterdir
  }

  /**
   * 日付文字列をLocalDate型に変換する
   */
  fun toLocalDate(date: String,  pattern: String = "yyyy/MM/dd HH:mm:ss"): LocalDate? {
    return LocalDate.parse(date, DateTimeFormatter.ofPattern(pattern))
  }
}