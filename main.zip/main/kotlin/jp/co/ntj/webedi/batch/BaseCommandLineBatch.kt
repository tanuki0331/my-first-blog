package jp.co.ntj.webedi.batch

import org.springframework.boot.CommandLineRunner

/**
 * コマンドラインバッチ基底クラス.
 *
 * @author 日立システムズ
 */
abstract class BaseCommandLineBatch : CommandLineRunner {

  /**
   * アプリ実行メソッド.
   *
   * Springより呼ばれるがアプリケーション起動前に呼ばれる
   * @param args 引数
   */
  override fun run(vararg args: String?) {
    // 初期化
    init(*args)
  }

  /**
   * 初期化.
   *
   * @param args 引数
   */
  open fun init(vararg args: String?) {
    // 必要であればサブクラスで実装
  }

  /**
   * 実行.
   */
  abstract fun execute(): Int
}