package jp.co.ntj.webedi.batch.properties

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Configuration
import org.springframework.stereotype.Component
import java.math.BigDecimal

/**
 * プロパティファイル設定値読み込みクラス
 * (resources/config/application.yml)
 */
@Component
@Configuration
@ConfigurationProperties(prefix = "batchsetting")
class BatchProperties {
  // OC帳票データロード
  lateinit var ocloadtemporarydir: String //OC帳票データロード：一時ディレクトリ
  lateinit var ocloadmasterdir: String //OC帳票データロード：本番ディレクトリ

  // Invoice帳票データロード
  lateinit var invloadtemporarydir: String //Invoice帳票データロード：一時ディレクトリ
  lateinit var invloadmasterdir: String //Invoice帳票データロード：本番ディレクトリ

  // ProformaInvoice帳票データロード
  lateinit var pinvloadtemporarydir: String //ProformaInvoice帳票データロード：一時ディレクトリ
  lateinit var pinvloadmasterdir: String //ProformaInvoice帳票データロード：本番ディレクトリ

  // 保管期間
  var storagePeriod: StoragePeriod = StoragePeriod()

  class StoragePeriod {
    // テーブルデータ
    lateinit var orderCartHeader: String      // 注文カートヘッダ
    lateinit var orderCartDetail: String      // 注文カート明細
    lateinit var ocReport: String             // OC帳票マスタ
    lateinit var ocDownloadHistory: String    // OC帳票ダウンロード履歴
    lateinit var ocConfirmation: String       // OC帳票確認
    lateinit var pinvReport: String           // P/I帳票マスタ
    lateinit var pinvDownloadHistory: String  // P/I帳票ダウンロード履歴
    lateinit var pinvConfirmation: String     // P/I帳票確認
    lateinit var invReport: String            // INV帳票マスタ
    lateinit var invDownloadHistory: String   // INV帳票ダウンロード履歴
    lateinit var logicalDelete: String        // 論理削除データ
    // ファイル
    lateinit var webServerLog: String         // Webサーバーログ
    lateinit var apServerLog: String          // APサーバーログ
    lateinit var webAppLog: String            // Webアプリログ
    lateinit var batchLog: String             // バッチログ
    lateinit var dbBackup: String             // DBバックアップ
    lateinit var ocReportFile: String         // OC帳票ファイル
    lateinit var invReportFile: String        // Invoice帳票ファイル
    lateinit var pinvReportFile: String       // Proforma Invoice帳票ファイル
  }
}
