package jp.co.ntj.webedi.batch

import jp.co.ntj.webedi.batch.common.BatchMessages
import jp.co.ntj.webedi.batch.properties.BatchProperties
import jp.co.ntj.webedi.domain.entity.table.OcReport
import jp.co.ntj.webedi.service.LoadFormDataOCService
import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Service
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Paths
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.collections.ArrayList
import kotlin.collections.LinkedHashMap


/**
 * OC帳票データロードバッチ.
 *
 * @author 日立システムズ
 */
@Service
@ConditionalOnProperty(name = ["batch"], havingValue = "loadfromoc")
class LoadFormDataOC(
  val loadFormDataOCService: LoadFormDataOCService,
  val batchLogger: Logger,
  val batchProperties: BatchProperties) : BaseCommandLineBatch()
{

  // 連携ディレクトリ
  var loadDir: String = ""
  // 待機秒数
  var repeatSecond: String = ""
  // エラーフラグ
  var errorFlg = false
  // メッセージ定数
  var message: BatchMessages = BatchMessages();
  // 全て取得フラグ
  var allFileTarget = false
  // 繰り返しフラグ
  var loopFlg = false
  // 日時フォーマッタ
  val dateFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
  // 一時ディレクトリパス
  var tempDirectory = ""
  // 処理時刻
  var executeAt = ""
  // 実行ユーザ
  val createdUser = "SYSTEM";
  // 出荷先コードの社員マスタのMap<[出荷先コード],Map<社員名,メールアドレス>>
  var shipUserMap = LinkedHashMap<String, Map<String, String>>()
  // 出荷先コードごとのOC番号のリストMap<出荷先コード,List<OC番号>>
  var ocNumberMap = LinkedHashMap<String, ArrayList<String>>()


  override fun init(vararg args: String?) {
    super.init(*args)

    // 引数チェック
    checkArgs(*args)

    batchLogger.debug("start LoadFormDataOC [$args]")
  }

  override fun execute(): Int {

    if (!errorFlg) {
      do {
        // 前回処理時刻の取得
        executeAt = loadFormDataOCService.getProcessExecuteTime()
        if (StringUtils.isEmpty(executeAt)) {
          allFileTarget = true
        }
        batchLogger.info(message.MI9000.replace("{0}", executeAt))

        // 一時ディレクトリの作成
        if (!createTemporalyDir()) {
          // エラー終了
          break
        }

        // 差分ファイルのファイル移動(一時ディレクトリへ)
        if (!copyTargetOCFile()) {
          // エラー終了
          break
        }

        // データ登録処理(本番ディレクトリへファイルコピーして削除)
        if (!registOCFile()) {
          // エラー終了
          break
        }

        // 一時ディレクトリの削除
        deleteTempDirectory()

        // メール送信
        sendMail()

        // 処理時刻の保存
        loadFormDataOCService.saveProcessExecuteTime()

        // 繰り返し実行
        if (!org.apache.commons.lang3.StringUtils.isEmpty(repeatSecond)) {
          batchLogger.info(message.MI9001.replace("{0}", repeatSecond))

          // 指定秒数待つ
          var second = repeatSecond.toLong() * 1000
          Thread.sleep(second)
        }
      } while (loopFlg)

      if (errorFlg) {
        return -1 // 終了コード
      }

      batchLogger.info(message.MI0005.replace("{0}", "データ移行処理"))
      return 0 // 終了コード

    } else {
      return -1 // 終了コード
    }
  }

  /**
   * 引数チェック
   */
  fun checkArgs(vararg args: String?) {
    if (args.size >= 2) {
      if (args.size >= 3) {
        if (!org.apache.commons.lang3.math.NumberUtils.isDigits(args[2])) {
          // 正の数値でなければエラー
          batchLogger.error(message.ME0063.replace("{0}", "待機秒数"))
          errorFlg = true
        } else {
          repeatSecond = args[2].toString()
          loopFlg = true
        }
      }

      var file : File = File(args[1])
      if (file.exists() && file.isDirectory) {
        // 連携ディレクトリは有効
        loadDir = args[1].toString()
      } else {
        // 連携ディレクトリは無効
        batchLogger.error(message.ME0029.replace("{0}", "連携ディレクトリ"))
        errorFlg = true
      }

    } else {
      batchLogger.error(message.ME0029.replace("{0}", "引数"))
      errorFlg = true
    }
  }

  /**
   * 一時ディレクトリの作成
   */
  fun createTemporalyDir() : Boolean {
    val tempDir = getTemporaryDir()
    val now = LocalDateTime.now()
    val todayStr = now.format(dateFormatter) // 今日の日付
    tempDirectory = tempDir + "/" + todayStr

    val file: File = File(tempDir)
    if (file.exists() && file.isDirectory) {
      // 連携ディレクトリは有効

      // 一時フォルダを作成
      val createFile = File(tempDirectory)
      if (!createFile.mkdir()) {
        // 一時ディレクトリ作成失敗

      } else {
        var msg = message.MI0011
        msg = msg.replace("{0}", "一時ディレクトリ")
        msg = msg.replace("{1}", tempDirectory)
        batchLogger.info(msg)
      }

    }
    return !errorFlg
  }

  /**
   * 差分ファイルのファイル移動
   */
  fun copyTargetOCFile() : Boolean {
    var loadDirFile = File(loadDir)
    var fileList = loadDirFile.listFiles()
    fileList.forEach {
      if (allFileTarget) {
        // 全てのファイルが対象
        var fromFileName = Paths.get(it.path)
        var from =  it.name
        var to = tempDirectory + "/" + from
        var toFilename = Paths.get(to)

        try {
          Files.copy(fromFileName, toFilename)
          var msg = message.MI9003
          msg = msg.replace("{0}", to)
          batchLogger.info(msg)

        } catch (e: IOException) {
          var msg = message.ME9018
          msg = msg.replace("{0}", to)
          batchLogger.info(msg)
        }

      } else {
        // 処理時刻以降のファイルが対象
        var updatetime = it.lastModified()
        val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        var updatetimeStr = simpleDateFormat.format(updatetime)
        if (updatetimeStr.compareTo(executeAt) > 0) {
          var fromFileName = Paths.get(it.path)
          var from =  it.name
          var to = tempDirectory + "/" + from
          var toFilename = Paths.get(to)

          try {
            Files.copy(fromFileName, toFilename)

            var msg = message.MI9003
            msg = msg.replace("{0}", to)
            batchLogger.info(msg)

          } catch (e: IOException) {
            var msg = message.ME9018
            msg = msg.replace("{0}", to)
            batchLogger.info(msg)
          }
        }
      }
    }
    return true;
  }

  /**
   * データ登録処理(本番ディレクトリへファイルコピーして削除)
   */
  fun registOCFile(): Boolean {
    var copyCount = 0

    var loadDirFile = File(tempDirectory)
    var fileList = loadDirFile.listFiles()

    if (fileList != null) {
      var fileListLoop = arrayOf(fileList)

      var masterCopyErrFlg = false;

      fileListLoop[0].forEach {
        copyCount++

        // 本番ディレクトリにファイルコピー
        var from = it.path
        var fromFileName = Paths.get(from)
        var to = getMasterDir() + "/" + it.name
        var toFilename = Paths.get(to)

        // 同名ファイルは上書き
        var toFIle = File(to)
        if (toFIle.exists()) {
          toFIle.delete()
        }
        try {
          Files.copy(fromFileName, toFilename)

          var msg = message.MI9004
          msg = msg.replace("{0}", to)
          batchLogger.info(msg)
          masterCopyErrFlg = false

        } catch (e: IOException) {
          var msg = message.ME9019
          msg = msg.replace("{0}", to)
          batchLogger.error(msg)
          masterCopyErrFlg = true
        }

        // マスタ登録
        // ファイル名から必要なデータを取得
        var kaisya_cd = "" // 会社コード
        var gengo_kbn = "" // 言語区分
        var customer_code = 0L // 得意先コード
        var destination_code = 0L // 出荷先コード
        var oc_number = "" // OC番号
        var filename = it.name.split(".")
        var params = filename[0].split("_")
        if (params.size >= 7) {
          kaisya_cd = params[0]
          gengo_kbn = params[1]
          customer_code = params[4].toLong()
          destination_code = params[5].toLong()
          oc_number = params[3]

          var datetime = LocalDateTime.now()
          var zoneDatetime = ZonedDateTime.of(datetime,  ZoneId.systemDefault())
          var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssXXX")
          var datetimestr = formatter.format(zoneDatetime)

          var ocReport = loadFormDataOCService.getOCReport(kaisya_cd,gengo_kbn,customer_code,destination_code,oc_number)
          if (ocReport != null) {
            // 登録済み
            ocReport.issueAt = toLocalDate(params[6], "yyyyMMdd")
            ocReport.filePath = toFilename.toString()
            ocReport.updatedAt = datetimestr
            ocReport.updatedUser = createdUser

            var updateCount = loadFormDataOCService.updateOCRepoet(ocReport)
            if (updateCount == 1) {
              var msg = message.MI0014
              msg = msg.replace("{0}", "OC帳票")
              msg = msg.replace("{1}", toFilename.toString())
              batchLogger.info(msg)
            } else {
              // 更新に失敗した場合本番ディレクトリにコピーしたファイルを削除する
              toFIle.delete()
            }

          } else {
            // 新規登録
            ocReport = OcReport()
            ocReport.kaisyaCd = kaisya_cd
            ocReport.gengoKbn = gengo_kbn
            ocReport.customerCode = customer_code
            ocReport.destinationCode = destination_code
            ocReport.ocNumber = oc_number
            ocReport.issueAt = toLocalDate(params[6], "yyyyMMdd")
            ocReport.filePath = toFilename.toString()
            ocReport.isDeleted = 0
            ocReport.createdAt = datetimestr
            ocReport.createdUser = createdUser
            ocReport.updatedAt = datetimestr
            ocReport.updatedUser = createdUser

            var insertCount = loadFormDataOCService.insertOCRepoet(ocReport)
            if (insertCount == 1) {
              var msg = message.MI0013
              msg = msg.replace("{0}", "OC帳票")
              msg = msg.replace("{1}", toFilename.toString())
              batchLogger.info(msg)
            } else {
              // 登録に失敗した場合本番ディレクトリにコピーしたファイルを削除する
              toFIle.delete()
            }
          }

          // 帳票確認データは物理削除
          loadFormDataOCService.deleteOCConfirmation(kaisya_cd,gengo_kbn,customer_code,destination_code,oc_number)

          createMailSendData(destination_code, oc_number)

          // 一時ディレクトリのファイル削除
          if (!masterCopyErrFlg) {
            var fromFile = File(fromFileName.toString())
            fromFile.delete()

            // ログメッセージ出力
            var msg = message.MI0012
            msg = msg.replace("{0}", "OC帳票ファイル")
            msg = msg.replace("{1}", fromFileName.toString())
            batchLogger.info(msg)
          }

        } else {
          // ファイル名の形式が想定と異なっている場合は削除する
          if (!masterCopyErrFlg) {
            toFIle.delete()
          }
        }
      }
    }

    if (copyCount == 0) {
      // 処理対象がなければメッセージ出力
      batchLogger.info(message.MI9002)
    }

    return true
  }

  /**
   * メール送信用の情報を取得する
   */
  fun createMailSendData(destination_code: Long, oc_number: String) {
    // 社員ユーザー情報
    if (!shipUserMap.containsKey(destination_code.toString())) {
      var userMap = loadFormDataOCService.getUserMap(destination_code)
      shipUserMap.put(destination_code.toString(), userMap)
    }
    // 会社ごとのOC番号
    if (!ocNumberMap.containsKey(destination_code.toString())) {
      ocNumberMap.put(destination_code.toString(), arrayListOf())
    }
    var ocList = ocNumberMap.get(destination_code.toString())
    if (ocList != null) {
      ocList.add(oc_number)
    }
  }

  /**
   * 一時ディレクトリの削除
   */
  fun deleteTempDirectory(): Boolean {
    var tempDir = File(tempDirectory)
    if (tempDir.exists()) {
      if (tempDir.isDirectory) {
        if (tempDir.listFiles().size == 0) {
          tempDir.delete()

          var msg = message.MI0012
          msg = msg.replace("{0}", "一時ディレクトリ")
          msg = msg.replace("{1}", tempDirectory)
          batchLogger.info(msg)

        } else {
          // 一時ファイルが残っていれば残してエラー出力
          var msg = message.ME9017
          msg = msg.replace("{0}", tempDirectory)
          batchLogger.error(msg)
        }
      }
    }
    return true
  }

  /**
   * メール送信
   */
  fun sendMail(): Boolean {
    // 「OC帳票確認依頼メール」を送信する。
    // 宛先は「担当営業」とする。
    // 宛先ごとにメールをマージする。（参照：共通仕様[メール宛先マージ]）
    // メールにはOC帳票の情報「OC番号」を含める。

    for ((key, value) in shipUserMap) {
      var ocNumbers = ocNumberMap.get(key) // OC番号のリスト
      for ((name, email) in value) {

        //TODO:テンプレートを使用してメール送信する
        batchLogger.debug("name[" + name + "]")
        batchLogger.debug("email[" + email + "]")

        var msg = message.MI0021
        msg = msg.replace("{0}", email)
        batchLogger.info(msg)
      }
    }

    return true
  }

  /**
   * 一時ディレクトリ名を取得する
   */
  fun getTemporaryDir(): String {
    return batchProperties.ocloadtemporarydir
  }

  /**
   * 本番ディレクトリ名を取得する
   */
  fun getMasterDir(): String {
    return batchProperties.ocloadmasterdir
  }

  /**
   * 日付文字列をLocalDate型に変換する
   */
  fun toLocalDate(date: String,  pattern: String = "yyyy/MM/dd HH:mm:ss"): LocalDate? {
    return LocalDate.parse(date, DateTimeFormatter.ofPattern(pattern))
  }
}