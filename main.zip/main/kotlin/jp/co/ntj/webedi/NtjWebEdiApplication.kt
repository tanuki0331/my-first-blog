package jp.co.ntj.webedi

import jp.co.ntj.webedi.batch.BaseCommandLineBatch
import org.springframework.boot.SpringApplication
import org.springframework.boot.WebApplicationType
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration

/**
 * Springアプリケーション.
 *
 * @author 日立システムズ
 *
 */
@SpringBootApplication
@Configuration
class NtjWebEdiApplication

/**
 * メイン
 *
 * @param
 */
fun main(args: Array<String>) {
  if (args.any { it.matches("--batch=.+".toRegex()) }) {
    val app = SpringApplication(NtjWebEdiApplication::class.java)
    app.webApplicationType = WebApplicationType.NONE
    System.exit(app.run(*args).getBean(BaseCommandLineBatch::class.java).execute())
  } else {
    runApplication<NtjWebEdiApplication>(*args)
  }
}
