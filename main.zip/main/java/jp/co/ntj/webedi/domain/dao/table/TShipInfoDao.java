package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.TShipInfo;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface TShipInfoDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param invNo
     * @param orderno
     * @param orderLine
     * @return the TShipInfo entity
     */
    @Select
    TShipInfo selectById(String kaisyaCd, String gengoKbn, String invNo, Long orderno, Short orderLine);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(TShipInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(TShipInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(TShipInfo entity);
}