package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class GeneralNewsListener implements EntityListener<GeneralNews> {

    @Override
    public void preInsert(GeneralNews entity, PreInsertContext<GeneralNews> context) {
    }

    @Override
    public void preUpdate(GeneralNews entity, PreUpdateContext<GeneralNews> context) {
    }

    @Override
    public void preDelete(GeneralNews entity, PreDeleteContext<GeneralNews> context) {
    }

    @Override
    public void postInsert(GeneralNews entity, PostInsertContext<GeneralNews> context) {
    }

    @Override
    public void postUpdate(GeneralNews entity, PostUpdateContext<GeneralNews> context) {
    }

    @Override
    public void postDelete(GeneralNews entity, PostDeleteContext<GeneralNews> context) {
    }
}