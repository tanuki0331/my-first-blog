package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MTokuiCodeListener implements EntityListener<MTokuiCode> {

    @Override
    public void preInsert(MTokuiCode entity, PreInsertContext<MTokuiCode> context) {
    }

    @Override
    public void preUpdate(MTokuiCode entity, PreUpdateContext<MTokuiCode> context) {
    }

    @Override
    public void preDelete(MTokuiCode entity, PreDeleteContext<MTokuiCode> context) {
    }

    @Override
    public void postInsert(MTokuiCode entity, PostInsertContext<MTokuiCode> context) {
    }

    @Override
    public void postUpdate(MTokuiCode entity, PostUpdateContext<MTokuiCode> context) {
    }

    @Override
    public void postDelete(MTokuiCode entity, PostDeleteContext<MTokuiCode> context) {
    }
}