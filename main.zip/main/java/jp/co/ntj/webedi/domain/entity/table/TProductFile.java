package jp.co.ntj.webedi.domain.entity.table;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 商品関連ファイル情報
 */
@Entity(listener = TProductFileListener.class)
@Table(name = "T_PRODUCT_FILE")
public class TProductFile {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** ファイルコード */
    @Id
    @Column(name = "FILE_CODE")
    Long fileCode;

    /** 商品コード */
    @Column(name = "SHOHINCD")
    String shohincd;

    /** 商品略名コード */
    @Column(name = "SHOHIN_RYAK_CD")
    String shohinRyakCd;

    /** 商品名英語 */
    @Column(name = "SHOHIN_NM")
    String shohinNm;

    /** 商品分類－大分類コード */
    @Column(name = "LAG_BUNCD")
    String lagBuncd;

    /** 商品分類－中分類コード */
    @Column(name = "MID_BUNCD")
    String midBuncd;

    /** 商品分類－小分類コード１ */
    @Column(name = "SML_BUNCD1")
    String smlBuncd1;

    /** 入目重量 */
    @Column(name = "IRIME_JURYO")
    BigDecimal irimeJuryo;

    /** 入目単位コード */
    @Column(name = "RIME_TANICD")
    Short rimeTanicd;

    /** 入目単位名 */
    @Column(name = "IRIME_TANINM")
    String irimeTaninm;

    /** 梱包単位コード */
    @Column(name = "KONPO_TANICD")
    String konpoTanicd;

    /** 梱包単位名 */
    @Column(name = "KONPO_TANINM")
    String konpoTaninm;

    /** ユニット単価 */
    @Column(name = "UNIT_TANKA")
    BigDecimal unitTanka;

    /** ユニット単位コード */
    @Column(name = "UNIT_TANICD")
    Short unitTanicd;

    /** ユニット単位名 */
    @Column(name = "UNIT_TANINM")
    String unitTaninm;

    /** 建値コード */
    @Column(name = "TATENECD")
    String tatenecd;

    /** 建値名 */
    @Column(name = "TATENENM")
    String tatenenm;

    /** 単価 */
    @Column(name = "TANKA")
    BigDecimal tanka;

    /** 表示ファイル名 */
    @Column(name = "FILE_NAME1")
    String fileName1;

    /** 物理ファイル名 */
    @Column(name = "FILE_NAME2")
    String fileName2;

    /** ファイル区分 */
    @Column(name = "FILE_KIND")
    Short fileKind;

    /** 表示開始日 */
    @Column(name = "START_DATE")
    LocalDate startDate;

    /** 表示終了日 */
    @Column(name = "END_DATE")
    LocalDate endDate;

    /** 登録日付時刻 */
    @Column(name = "ENTRY_DATE")
    LocalDate entryDate;

    /** 更新日付時刻 */
    @Column(name = "UPDATE_DATE")
    LocalDate updateDate;

    /** 国コード */
    @Column(name = "KUNICD")
    Short kunicd;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the fileCode.
     * 
     * @return the fileCode
     */
    public Long getFileCode() {
        return fileCode;
    }

    /** 
     * Sets the fileCode.
     * 
     * @param fileCode the fileCode
     */
    public void setFileCode(Long fileCode) {
        this.fileCode = fileCode;
    }

    /** 
     * Returns the shohincd.
     * 
     * @return the shohincd
     */
    public String getShohincd() {
        return shohincd;
    }

    /** 
     * Sets the shohincd.
     * 
     * @param shohincd the shohincd
     */
    public void setShohincd(String shohincd) {
        this.shohincd = shohincd;
    }

    /** 
     * Returns the shohinRyakCd.
     * 
     * @return the shohinRyakCd
     */
    public String getShohinRyakCd() {
        return shohinRyakCd;
    }

    /** 
     * Sets the shohinRyakCd.
     * 
     * @param shohinRyakCd the shohinRyakCd
     */
    public void setShohinRyakCd(String shohinRyakCd) {
        this.shohinRyakCd = shohinRyakCd;
    }

    /** 
     * Returns the shohinNm.
     * 
     * @return the shohinNm
     */
    public String getShohinNm() {
        return shohinNm;
    }

    /** 
     * Sets the shohinNm.
     * 
     * @param shohinNm the shohinNm
     */
    public void setShohinNm(String shohinNm) {
        this.shohinNm = shohinNm;
    }

    /** 
     * Returns the lagBuncd.
     * 
     * @return the lagBuncd
     */
    public String getLagBuncd() {
        return lagBuncd;
    }

    /** 
     * Sets the lagBuncd.
     * 
     * @param lagBuncd the lagBuncd
     */
    public void setLagBuncd(String lagBuncd) {
        this.lagBuncd = lagBuncd;
    }

    /** 
     * Returns the midBuncd.
     * 
     * @return the midBuncd
     */
    public String getMidBuncd() {
        return midBuncd;
    }

    /** 
     * Sets the midBuncd.
     * 
     * @param midBuncd the midBuncd
     */
    public void setMidBuncd(String midBuncd) {
        this.midBuncd = midBuncd;
    }

    /** 
     * Returns the smlBuncd1.
     * 
     * @return the smlBuncd1
     */
    public String getSmlBuncd1() {
        return smlBuncd1;
    }

    /** 
     * Sets the smlBuncd1.
     * 
     * @param smlBuncd1 the smlBuncd1
     */
    public void setSmlBuncd1(String smlBuncd1) {
        this.smlBuncd1 = smlBuncd1;
    }

    /** 
     * Returns the irimeJuryo.
     * 
     * @return the irimeJuryo
     */
    public BigDecimal getIrimeJuryo() {
        return irimeJuryo;
    }

    /** 
     * Sets the irimeJuryo.
     * 
     * @param irimeJuryo the irimeJuryo
     */
    public void setIrimeJuryo(BigDecimal irimeJuryo) {
        this.irimeJuryo = irimeJuryo;
    }

    /** 
     * Returns the rimeTanicd.
     * 
     * @return the rimeTanicd
     */
    public Short getRimeTanicd() {
        return rimeTanicd;
    }

    /** 
     * Sets the rimeTanicd.
     * 
     * @param rimeTanicd the rimeTanicd
     */
    public void setRimeTanicd(Short rimeTanicd) {
        this.rimeTanicd = rimeTanicd;
    }

    /** 
     * Returns the irimeTaninm.
     * 
     * @return the irimeTaninm
     */
    public String getIrimeTaninm() {
        return irimeTaninm;
    }

    /** 
     * Sets the irimeTaninm.
     * 
     * @param irimeTaninm the irimeTaninm
     */
    public void setIrimeTaninm(String irimeTaninm) {
        this.irimeTaninm = irimeTaninm;
    }

    /** 
     * Returns the konpoTanicd.
     * 
     * @return the konpoTanicd
     */
    public String getKonpoTanicd() {
        return konpoTanicd;
    }

    /** 
     * Sets the konpoTanicd.
     * 
     * @param konpoTanicd the konpoTanicd
     */
    public void setKonpoTanicd(String konpoTanicd) {
        this.konpoTanicd = konpoTanicd;
    }

    /** 
     * Returns the konpoTaninm.
     * 
     * @return the konpoTaninm
     */
    public String getKonpoTaninm() {
        return konpoTaninm;
    }

    /** 
     * Sets the konpoTaninm.
     * 
     * @param konpoTaninm the konpoTaninm
     */
    public void setKonpoTaninm(String konpoTaninm) {
        this.konpoTaninm = konpoTaninm;
    }

    /** 
     * Returns the unitTanka.
     * 
     * @return the unitTanka
     */
    public BigDecimal getUnitTanka() {
        return unitTanka;
    }

    /** 
     * Sets the unitTanka.
     * 
     * @param unitTanka the unitTanka
     */
    public void setUnitTanka(BigDecimal unitTanka) {
        this.unitTanka = unitTanka;
    }

    /** 
     * Returns the unitTanicd.
     * 
     * @return the unitTanicd
     */
    public Short getUnitTanicd() {
        return unitTanicd;
    }

    /** 
     * Sets the unitTanicd.
     * 
     * @param unitTanicd the unitTanicd
     */
    public void setUnitTanicd(Short unitTanicd) {
        this.unitTanicd = unitTanicd;
    }

    /** 
     * Returns the unitTaninm.
     * 
     * @return the unitTaninm
     */
    public String getUnitTaninm() {
        return unitTaninm;
    }

    /** 
     * Sets the unitTaninm.
     * 
     * @param unitTaninm the unitTaninm
     */
    public void setUnitTaninm(String unitTaninm) {
        this.unitTaninm = unitTaninm;
    }

    /** 
     * Returns the tatenecd.
     * 
     * @return the tatenecd
     */
    public String getTatenecd() {
        return tatenecd;
    }

    /** 
     * Sets the tatenecd.
     * 
     * @param tatenecd the tatenecd
     */
    public void setTatenecd(String tatenecd) {
        this.tatenecd = tatenecd;
    }

    /** 
     * Returns the tatenenm.
     * 
     * @return the tatenenm
     */
    public String getTatenenm() {
        return tatenenm;
    }

    /** 
     * Sets the tatenenm.
     * 
     * @param tatenenm the tatenenm
     */
    public void setTatenenm(String tatenenm) {
        this.tatenenm = tatenenm;
    }

    /** 
     * Returns the tanka.
     * 
     * @return the tanka
     */
    public BigDecimal getTanka() {
        return tanka;
    }

    /** 
     * Sets the tanka.
     * 
     * @param tanka the tanka
     */
    public void setTanka(BigDecimal tanka) {
        this.tanka = tanka;
    }

    /** 
     * Returns the fileName1.
     * 
     * @return the fileName1
     */
    public String getFileName1() {
        return fileName1;
    }

    /** 
     * Sets the fileName1.
     * 
     * @param fileName1 the fileName1
     */
    public void setFileName1(String fileName1) {
        this.fileName1 = fileName1;
    }

    /** 
     * Returns the fileName2.
     * 
     * @return the fileName2
     */
    public String getFileName2() {
        return fileName2;
    }

    /** 
     * Sets the fileName2.
     * 
     * @param fileName2 the fileName2
     */
    public void setFileName2(String fileName2) {
        this.fileName2 = fileName2;
    }

    /** 
     * Returns the fileKind.
     * 
     * @return the fileKind
     */
    public Short getFileKind() {
        return fileKind;
    }

    /** 
     * Sets the fileKind.
     * 
     * @param fileKind the fileKind
     */
    public void setFileKind(Short fileKind) {
        this.fileKind = fileKind;
    }

    /** 
     * Returns the startDate.
     * 
     * @return the startDate
     */
    public LocalDate getStartDate() {
        return startDate;
    }

    /** 
     * Sets the startDate.
     * 
     * @param startDate the startDate
     */
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    /** 
     * Returns the endDate.
     * 
     * @return the endDate
     */
    public LocalDate getEndDate() {
        return endDate;
    }

    /** 
     * Sets the endDate.
     * 
     * @param endDate the endDate
     */
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    /** 
     * Returns the entryDate.
     * 
     * @return the entryDate
     */
    public LocalDate getEntryDate() {
        return entryDate;
    }

    /** 
     * Sets the entryDate.
     * 
     * @param entryDate the entryDate
     */
    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    /** 
     * Returns the updateDate.
     * 
     * @return the updateDate
     */
    public LocalDate getUpdateDate() {
        return updateDate;
    }

    /** 
     * Sets the updateDate.
     * 
     * @param updateDate the updateDate
     */
    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    /** 
     * Returns the kunicd.
     * 
     * @return the kunicd
     */
    public Short getKunicd() {
        return kunicd;
    }

    /** 
     * Sets the kunicd.
     * 
     * @param kunicd the kunicd
     */
    public void setKunicd(Short kunicd) {
        this.kunicd = kunicd;
    }
}