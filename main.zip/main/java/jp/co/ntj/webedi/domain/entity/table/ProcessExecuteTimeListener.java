package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class ProcessExecuteTimeListener implements EntityListener<ProcessExecuteTime> {

    @Override
    public void preInsert(ProcessExecuteTime entity, PreInsertContext<ProcessExecuteTime> context) {
    }

    @Override
    public void preUpdate(ProcessExecuteTime entity, PreUpdateContext<ProcessExecuteTime> context) {
    }

    @Override
    public void preDelete(ProcessExecuteTime entity, PreDeleteContext<ProcessExecuteTime> context) {
    }

    @Override
    public void postInsert(ProcessExecuteTime entity, PostInsertContext<ProcessExecuteTime> context) {
    }

    @Override
    public void postUpdate(ProcessExecuteTime entity, PostUpdateContext<ProcessExecuteTime> context) {
    }

    @Override
    public void postDelete(ProcessExecuteTime entity, PostDeleteContext<ProcessExecuteTime> context) {
    }
}