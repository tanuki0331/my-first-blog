package jp.co.ntj.webedi.domain.entity.table;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 発注ヘッダ情報
 */
@Entity(listener = TOrderHListener.class)
@Table(name = "T_ORDER_H")
public class TOrderH {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** Web注文番号 */
    @Id
    @Column(name = "ORDERNO")
    Long orderno;

    /** 得意先識別コード */
    @Column(name = "TOKU_SHIKICD")
    String tokuShikicd;

    /** 得意先コード */
    @Column(name = "TOKUCD")
    Long tokucd;

    /** 得意先社名１ */
    @Column(name = "TOKUI_NM1")
    String tokuiNm1;

    /** 得意先社名２ */
    @Column(name = "TOKUI_NM2")
    String tokuiNm2;

    /** 仕向先識別コード */
    @Column(name = "SHIMUKE_SHIKICD")
    String shimukeShikicd;

    /** 仕向先コード */
    @Column(name = "SHIMUKECD")
    Long shimukecd;

    /** 仕向先社名１ */
    @Column(name = "SHIMUKE_NM1")
    String shimukeNm1;

    /** 仕向先社名２ */
    @Column(name = "SHIMUKE_NM2")
    String shimukeNm2;

    /** 最終仕向先識別コード */
    @Column(name = "LAST_SHIMUKE_SHIKICD")
    String lastShimukeShikicd;

    /** 最終仕向先コード */
    @Column(name = "LAST_SHIMUKECD")
    Long lastShimukecd;

    /** 最終仕向先社名１ */
    @Column(name = "LAST_SHIMUKE_NM1")
    String lastShimukeNm1;

    /** 最終仕向先社名２ */
    @Column(name = "LAST_SHIMUKE_NM2")
    String lastShimukeNm2;

    /** 最終仕向先住所１ */
    @Column(name = "LAST_SHIMUKE_ADR1")
    String lastShimukeAdr1;

    /** 最終仕向先住所２ */
    @Column(name = "LAST_SHIMUKE_ADR2")
    String lastShimukeAdr2;

    /** 最終仕向先住所３ */
    @Column(name = "LAST_SHIMUKE_ADR3")
    String lastShimukeAdr3;

    /** 最終仕向先仕向地港コード */
    @Column(name = "LAST_SHIMUKE_PORTCD")
    Short lastShimukePortcd;

    /** 最終仕向先仕向地港名 */
    @Column(name = "LAST_SHIMUKE_PORTNM")
    String lastShimukePortnm;

    /** 発注者ログイン名 */
    @Column(name = "ORDER_LOGIN_NAME")
    String orderLoginName;

    /** 発注者名 */
    @Column(name = "ORDER_MAN_NM")
    String orderManNm;

    /** 発注日 */
    @Column(name = "ORDER_DATE")
    String orderDate;

    /** PONO */
    @Column(name = "PONO")
    String pono;

    /** 建値コード */
    @Column(name = "TATENECD")
    String tatenecd;

    /** 契約条件コード */
    @Column(name = "KEI_JYOKENCD")
    Short keiJyokencd;

    /** 価格条件コード */
    @Column(name = "KAK_JYOKENCD")
    Short kakJyokencd;

    /** 輸送方法コード */
    @Column(name = "YUSO_HOHOCD")
    Short yusoHohocd;

    /** 支払条件コード */
    @Column(name = "SHI_JYOKENCD")
    Short shiJyokencd;

    /** メールフラグ */
    @Column(name = "MAIL_FLG")
    Short mailFlg;

    /** メールアドレス(TO) */
    @Column(name = "TO_MAIL_ADR")
    String toMailAdr;

    /** 承認フラグ */
    @Column(name = "SYONIN_FLG")
    Short syoninFlg;

    /** 承認日 */
    @Column(name = "SYONIN_DATE")
    String syoninDate;

    /** 承認者ログイン名 */
    @Column(name = "SYONIN_LOGIN_NAME")
    String syoninLoginName;

    /** ダウンロードフラグ */
    @Column(name = "DOWNLOAD_FLG")
    Short downloadFlg;

    /** コメント */
    @Column(name = "COMMENT_STR")
    String commentStr;

    /** 登録日付時刻 */
    @Column(name = "ENTRY_DATE")
    LocalDate entryDate;

    /** 登録者ログイン名 */
    @Column(name = "ENTRY_USER")
    String entryUser;

    /** 更新日付時刻 */
    @Column(name = "UPDATE_DATE")
    LocalDate updateDate;

    /** 更新者ログイン名 */
    @Column(name = "UPDATE_LOGIN_NAME")
    String updateLoginName;

    /** 基幹受付日 */
    @Column(name = "K_RECEIPT_DATE")
    String kReceiptDate;

    /** 基幹受注年月 */
    @Column(name = "K_JUC_YM")
    Short kJucYm;

    /** 基幹受注連番 */
    @Column(name = "K_JUC_RENBAN")
    Short kJucRenban;

    /** 基幹取消フラグ */
    @Column(name = "K_DELETE_FLG")
    Short kDeleteFlg;

    /** 基幹取消日 */
    @Column(name = "K_DELETE_DATE")
    String kDeleteDate;

    /** 排他フラグ */
    @Column(name = "EXCLUSIVE_FLG")
    Short exclusiveFlg;

    /** 基幹修正後契約条件コード */
    @Column(name = "K_KEI_JYOKENCD")
    Short kKeiJyokencd;

    /** 基幹修正後価格条件コード */
    @Column(name = "K_KAK_JYOKENCD")
    Short kKakJyokencd;

    /** 基幹修正後輸送方法コード */
    @Column(name = "K_YUSO_HOHOCD")
    Short kYusoHohocd;

    /** WEBキャンセルフラグ */
    @Column(name = "WEB_CANSEL_FLG")
    Short webCanselFlg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the orderno.
     * 
     * @return the orderno
     */
    public Long getOrderno() {
        return orderno;
    }

    /** 
     * Sets the orderno.
     * 
     * @param orderno the orderno
     */
    public void setOrderno(Long orderno) {
        this.orderno = orderno;
    }

    /** 
     * Returns the tokuShikicd.
     * 
     * @return the tokuShikicd
     */
    public String getTokuShikicd() {
        return tokuShikicd;
    }

    /** 
     * Sets the tokuShikicd.
     * 
     * @param tokuShikicd the tokuShikicd
     */
    public void setTokuShikicd(String tokuShikicd) {
        this.tokuShikicd = tokuShikicd;
    }

    /** 
     * Returns the tokucd.
     * 
     * @return the tokucd
     */
    public Long getTokucd() {
        return tokucd;
    }

    /** 
     * Sets the tokucd.
     * 
     * @param tokucd the tokucd
     */
    public void setTokucd(Long tokucd) {
        this.tokucd = tokucd;
    }

    /** 
     * Returns the tokuiNm1.
     * 
     * @return the tokuiNm1
     */
    public String getTokuiNm1() {
        return tokuiNm1;
    }

    /** 
     * Sets the tokuiNm1.
     * 
     * @param tokuiNm1 the tokuiNm1
     */
    public void setTokuiNm1(String tokuiNm1) {
        this.tokuiNm1 = tokuiNm1;
    }

    /** 
     * Returns the tokuiNm2.
     * 
     * @return the tokuiNm2
     */
    public String getTokuiNm2() {
        return tokuiNm2;
    }

    /** 
     * Sets the tokuiNm2.
     * 
     * @param tokuiNm2 the tokuiNm2
     */
    public void setTokuiNm2(String tokuiNm2) {
        this.tokuiNm2 = tokuiNm2;
    }

    /** 
     * Returns the shimukeShikicd.
     * 
     * @return the shimukeShikicd
     */
    public String getShimukeShikicd() {
        return shimukeShikicd;
    }

    /** 
     * Sets the shimukeShikicd.
     * 
     * @param shimukeShikicd the shimukeShikicd
     */
    public void setShimukeShikicd(String shimukeShikicd) {
        this.shimukeShikicd = shimukeShikicd;
    }

    /** 
     * Returns the shimukecd.
     * 
     * @return the shimukecd
     */
    public Long getShimukecd() {
        return shimukecd;
    }

    /** 
     * Sets the shimukecd.
     * 
     * @param shimukecd the shimukecd
     */
    public void setShimukecd(Long shimukecd) {
        this.shimukecd = shimukecd;
    }

    /** 
     * Returns the shimukeNm1.
     * 
     * @return the shimukeNm1
     */
    public String getShimukeNm1() {
        return shimukeNm1;
    }

    /** 
     * Sets the shimukeNm1.
     * 
     * @param shimukeNm1 the shimukeNm1
     */
    public void setShimukeNm1(String shimukeNm1) {
        this.shimukeNm1 = shimukeNm1;
    }

    /** 
     * Returns the shimukeNm2.
     * 
     * @return the shimukeNm2
     */
    public String getShimukeNm2() {
        return shimukeNm2;
    }

    /** 
     * Sets the shimukeNm2.
     * 
     * @param shimukeNm2 the shimukeNm2
     */
    public void setShimukeNm2(String shimukeNm2) {
        this.shimukeNm2 = shimukeNm2;
    }

    /** 
     * Returns the lastShimukeShikicd.
     * 
     * @return the lastShimukeShikicd
     */
    public String getLastShimukeShikicd() {
        return lastShimukeShikicd;
    }

    /** 
     * Sets the lastShimukeShikicd.
     * 
     * @param lastShimukeShikicd the lastShimukeShikicd
     */
    public void setLastShimukeShikicd(String lastShimukeShikicd) {
        this.lastShimukeShikicd = lastShimukeShikicd;
    }

    /** 
     * Returns the lastShimukecd.
     * 
     * @return the lastShimukecd
     */
    public Long getLastShimukecd() {
        return lastShimukecd;
    }

    /** 
     * Sets the lastShimukecd.
     * 
     * @param lastShimukecd the lastShimukecd
     */
    public void setLastShimukecd(Long lastShimukecd) {
        this.lastShimukecd = lastShimukecd;
    }

    /** 
     * Returns the lastShimukeNm1.
     * 
     * @return the lastShimukeNm1
     */
    public String getLastShimukeNm1() {
        return lastShimukeNm1;
    }

    /** 
     * Sets the lastShimukeNm1.
     * 
     * @param lastShimukeNm1 the lastShimukeNm1
     */
    public void setLastShimukeNm1(String lastShimukeNm1) {
        this.lastShimukeNm1 = lastShimukeNm1;
    }

    /** 
     * Returns the lastShimukeNm2.
     * 
     * @return the lastShimukeNm2
     */
    public String getLastShimukeNm2() {
        return lastShimukeNm2;
    }

    /** 
     * Sets the lastShimukeNm2.
     * 
     * @param lastShimukeNm2 the lastShimukeNm2
     */
    public void setLastShimukeNm2(String lastShimukeNm2) {
        this.lastShimukeNm2 = lastShimukeNm2;
    }

    /** 
     * Returns the lastShimukeAdr1.
     * 
     * @return the lastShimukeAdr1
     */
    public String getLastShimukeAdr1() {
        return lastShimukeAdr1;
    }

    /** 
     * Sets the lastShimukeAdr1.
     * 
     * @param lastShimukeAdr1 the lastShimukeAdr1
     */
    public void setLastShimukeAdr1(String lastShimukeAdr1) {
        this.lastShimukeAdr1 = lastShimukeAdr1;
    }

    /** 
     * Returns the lastShimukeAdr2.
     * 
     * @return the lastShimukeAdr2
     */
    public String getLastShimukeAdr2() {
        return lastShimukeAdr2;
    }

    /** 
     * Sets the lastShimukeAdr2.
     * 
     * @param lastShimukeAdr2 the lastShimukeAdr2
     */
    public void setLastShimukeAdr2(String lastShimukeAdr2) {
        this.lastShimukeAdr2 = lastShimukeAdr2;
    }

    /** 
     * Returns the lastShimukeAdr3.
     * 
     * @return the lastShimukeAdr3
     */
    public String getLastShimukeAdr3() {
        return lastShimukeAdr3;
    }

    /** 
     * Sets the lastShimukeAdr3.
     * 
     * @param lastShimukeAdr3 the lastShimukeAdr3
     */
    public void setLastShimukeAdr3(String lastShimukeAdr3) {
        this.lastShimukeAdr3 = lastShimukeAdr3;
    }

    /** 
     * Returns the lastShimukePortcd.
     * 
     * @return the lastShimukePortcd
     */
    public Short getLastShimukePortcd() {
        return lastShimukePortcd;
    }

    /** 
     * Sets the lastShimukePortcd.
     * 
     * @param lastShimukePortcd the lastShimukePortcd
     */
    public void setLastShimukePortcd(Short lastShimukePortcd) {
        this.lastShimukePortcd = lastShimukePortcd;
    }

    /** 
     * Returns the lastShimukePortnm.
     * 
     * @return the lastShimukePortnm
     */
    public String getLastShimukePortnm() {
        return lastShimukePortnm;
    }

    /** 
     * Sets the lastShimukePortnm.
     * 
     * @param lastShimukePortnm the lastShimukePortnm
     */
    public void setLastShimukePortnm(String lastShimukePortnm) {
        this.lastShimukePortnm = lastShimukePortnm;
    }

    /** 
     * Returns the orderLoginName.
     * 
     * @return the orderLoginName
     */
    public String getOrderLoginName() {
        return orderLoginName;
    }

    /** 
     * Sets the orderLoginName.
     * 
     * @param orderLoginName the orderLoginName
     */
    public void setOrderLoginName(String orderLoginName) {
        this.orderLoginName = orderLoginName;
    }

    /** 
     * Returns the orderManNm.
     * 
     * @return the orderManNm
     */
    public String getOrderManNm() {
        return orderManNm;
    }

    /** 
     * Sets the orderManNm.
     * 
     * @param orderManNm the orderManNm
     */
    public void setOrderManNm(String orderManNm) {
        this.orderManNm = orderManNm;
    }

    /** 
     * Returns the orderDate.
     * 
     * @return the orderDate
     */
    public String getOrderDate() {
        return orderDate;
    }

    /** 
     * Sets the orderDate.
     * 
     * @param orderDate the orderDate
     */
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    /** 
     * Returns the pono.
     * 
     * @return the pono
     */
    public String getPono() {
        return pono;
    }

    /** 
     * Sets the pono.
     * 
     * @param pono the pono
     */
    public void setPono(String pono) {
        this.pono = pono;
    }

    /** 
     * Returns the tatenecd.
     * 
     * @return the tatenecd
     */
    public String getTatenecd() {
        return tatenecd;
    }

    /** 
     * Sets the tatenecd.
     * 
     * @param tatenecd the tatenecd
     */
    public void setTatenecd(String tatenecd) {
        this.tatenecd = tatenecd;
    }

    /** 
     * Returns the keiJyokencd.
     * 
     * @return the keiJyokencd
     */
    public Short getKeiJyokencd() {
        return keiJyokencd;
    }

    /** 
     * Sets the keiJyokencd.
     * 
     * @param keiJyokencd the keiJyokencd
     */
    public void setKeiJyokencd(Short keiJyokencd) {
        this.keiJyokencd = keiJyokencd;
    }

    /** 
     * Returns the kakJyokencd.
     * 
     * @return the kakJyokencd
     */
    public Short getKakJyokencd() {
        return kakJyokencd;
    }

    /** 
     * Sets the kakJyokencd.
     * 
     * @param kakJyokencd the kakJyokencd
     */
    public void setKakJyokencd(Short kakJyokencd) {
        this.kakJyokencd = kakJyokencd;
    }

    /** 
     * Returns the yusoHohocd.
     * 
     * @return the yusoHohocd
     */
    public Short getYusoHohocd() {
        return yusoHohocd;
    }

    /** 
     * Sets the yusoHohocd.
     * 
     * @param yusoHohocd the yusoHohocd
     */
    public void setYusoHohocd(Short yusoHohocd) {
        this.yusoHohocd = yusoHohocd;
    }

    /** 
     * Returns the shiJyokencd.
     * 
     * @return the shiJyokencd
     */
    public Short getShiJyokencd() {
        return shiJyokencd;
    }

    /** 
     * Sets the shiJyokencd.
     * 
     * @param shiJyokencd the shiJyokencd
     */
    public void setShiJyokencd(Short shiJyokencd) {
        this.shiJyokencd = shiJyokencd;
    }

    /** 
     * Returns the mailFlg.
     * 
     * @return the mailFlg
     */
    public Short getMailFlg() {
        return mailFlg;
    }

    /** 
     * Sets the mailFlg.
     * 
     * @param mailFlg the mailFlg
     */
    public void setMailFlg(Short mailFlg) {
        this.mailFlg = mailFlg;
    }

    /** 
     * Returns the toMailAdr.
     * 
     * @return the toMailAdr
     */
    public String getToMailAdr() {
        return toMailAdr;
    }

    /** 
     * Sets the toMailAdr.
     * 
     * @param toMailAdr the toMailAdr
     */
    public void setToMailAdr(String toMailAdr) {
        this.toMailAdr = toMailAdr;
    }

    /** 
     * Returns the syoninFlg.
     * 
     * @return the syoninFlg
     */
    public Short getSyoninFlg() {
        return syoninFlg;
    }

    /** 
     * Sets the syoninFlg.
     * 
     * @param syoninFlg the syoninFlg
     */
    public void setSyoninFlg(Short syoninFlg) {
        this.syoninFlg = syoninFlg;
    }

    /** 
     * Returns the syoninDate.
     * 
     * @return the syoninDate
     */
    public String getSyoninDate() {
        return syoninDate;
    }

    /** 
     * Sets the syoninDate.
     * 
     * @param syoninDate the syoninDate
     */
    public void setSyoninDate(String syoninDate) {
        this.syoninDate = syoninDate;
    }

    /** 
     * Returns the syoninLoginName.
     * 
     * @return the syoninLoginName
     */
    public String getSyoninLoginName() {
        return syoninLoginName;
    }

    /** 
     * Sets the syoninLoginName.
     * 
     * @param syoninLoginName the syoninLoginName
     */
    public void setSyoninLoginName(String syoninLoginName) {
        this.syoninLoginName = syoninLoginName;
    }

    /** 
     * Returns the downloadFlg.
     * 
     * @return the downloadFlg
     */
    public Short getDownloadFlg() {
        return downloadFlg;
    }

    /** 
     * Sets the downloadFlg.
     * 
     * @param downloadFlg the downloadFlg
     */
    public void setDownloadFlg(Short downloadFlg) {
        this.downloadFlg = downloadFlg;
    }

    /** 
     * Returns the commentStr.
     * 
     * @return the commentStr
     */
    public String getCommentStr() {
        return commentStr;
    }

    /** 
     * Sets the commentStr.
     * 
     * @param commentStr the commentStr
     */
    public void setCommentStr(String commentStr) {
        this.commentStr = commentStr;
    }

    /** 
     * Returns the entryDate.
     * 
     * @return the entryDate
     */
    public LocalDate getEntryDate() {
        return entryDate;
    }

    /** 
     * Sets the entryDate.
     * 
     * @param entryDate the entryDate
     */
    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    /** 
     * Returns the entryUser.
     * 
     * @return the entryUser
     */
    public String getEntryUser() {
        return entryUser;
    }

    /** 
     * Sets the entryUser.
     * 
     * @param entryUser the entryUser
     */
    public void setEntryUser(String entryUser) {
        this.entryUser = entryUser;
    }

    /** 
     * Returns the updateDate.
     * 
     * @return the updateDate
     */
    public LocalDate getUpdateDate() {
        return updateDate;
    }

    /** 
     * Sets the updateDate.
     * 
     * @param updateDate the updateDate
     */
    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    /** 
     * Returns the updateLoginName.
     * 
     * @return the updateLoginName
     */
    public String getUpdateLoginName() {
        return updateLoginName;
    }

    /** 
     * Sets the updateLoginName.
     * 
     * @param updateLoginName the updateLoginName
     */
    public void setUpdateLoginName(String updateLoginName) {
        this.updateLoginName = updateLoginName;
    }

    /** 
     * Returns the kReceiptDate.
     * 
     * @return the kReceiptDate
     */
    public String getKReceiptDate() {
        return kReceiptDate;
    }

    /** 
     * Sets the kReceiptDate.
     * 
     * @param kReceiptDate the kReceiptDate
     */
    public void setKReceiptDate(String kReceiptDate) {
        this.kReceiptDate = kReceiptDate;
    }

    /** 
     * Returns the kJucYm.
     * 
     * @return the kJucYm
     */
    public Short getKJucYm() {
        return kJucYm;
    }

    /** 
     * Sets the kJucYm.
     * 
     * @param kJucYm the kJucYm
     */
    public void setKJucYm(Short kJucYm) {
        this.kJucYm = kJucYm;
    }

    /** 
     * Returns the kJucRenban.
     * 
     * @return the kJucRenban
     */
    public Short getKJucRenban() {
        return kJucRenban;
    }

    /** 
     * Sets the kJucRenban.
     * 
     * @param kJucRenban the kJucRenban
     */
    public void setKJucRenban(Short kJucRenban) {
        this.kJucRenban = kJucRenban;
    }

    /** 
     * Returns the kDeleteFlg.
     * 
     * @return the kDeleteFlg
     */
    public Short getKDeleteFlg() {
        return kDeleteFlg;
    }

    /** 
     * Sets the kDeleteFlg.
     * 
     * @param kDeleteFlg the kDeleteFlg
     */
    public void setKDeleteFlg(Short kDeleteFlg) {
        this.kDeleteFlg = kDeleteFlg;
    }

    /** 
     * Returns the kDeleteDate.
     * 
     * @return the kDeleteDate
     */
    public String getKDeleteDate() {
        return kDeleteDate;
    }

    /** 
     * Sets the kDeleteDate.
     * 
     * @param kDeleteDate the kDeleteDate
     */
    public void setKDeleteDate(String kDeleteDate) {
        this.kDeleteDate = kDeleteDate;
    }

    /** 
     * Returns the exclusiveFlg.
     * 
     * @return the exclusiveFlg
     */
    public Short getExclusiveFlg() {
        return exclusiveFlg;
    }

    /** 
     * Sets the exclusiveFlg.
     * 
     * @param exclusiveFlg the exclusiveFlg
     */
    public void setExclusiveFlg(Short exclusiveFlg) {
        this.exclusiveFlg = exclusiveFlg;
    }

    /** 
     * Returns the kKeiJyokencd.
     * 
     * @return the kKeiJyokencd
     */
    public Short getKKeiJyokencd() {
        return kKeiJyokencd;
    }

    /** 
     * Sets the kKeiJyokencd.
     * 
     * @param kKeiJyokencd the kKeiJyokencd
     */
    public void setKKeiJyokencd(Short kKeiJyokencd) {
        this.kKeiJyokencd = kKeiJyokencd;
    }

    /** 
     * Returns the kKakJyokencd.
     * 
     * @return the kKakJyokencd
     */
    public Short getKKakJyokencd() {
        return kKakJyokencd;
    }

    /** 
     * Sets the kKakJyokencd.
     * 
     * @param kKakJyokencd the kKakJyokencd
     */
    public void setKKakJyokencd(Short kKakJyokencd) {
        this.kKakJyokencd = kKakJyokencd;
    }

    /** 
     * Returns the kYusoHohocd.
     * 
     * @return the kYusoHohocd
     */
    public Short getKYusoHohocd() {
        return kYusoHohocd;
    }

    /** 
     * Sets the kYusoHohocd.
     * 
     * @param kYusoHohocd the kYusoHohocd
     */
    public void setKYusoHohocd(Short kYusoHohocd) {
        this.kYusoHohocd = kYusoHohocd;
    }

    /** 
     * Returns the webCanselFlg.
     * 
     * @return the webCanselFlg
     */
    public Short getWebCanselFlg() {
        return webCanselFlg;
    }

    /** 
     * Sets the webCanselFlg.
     * 
     * @param webCanselFlg the webCanselFlg
     */
    public void setWebCanselFlg(Short webCanselFlg) {
        this.webCanselFlg = webCanselFlg;
    }
}