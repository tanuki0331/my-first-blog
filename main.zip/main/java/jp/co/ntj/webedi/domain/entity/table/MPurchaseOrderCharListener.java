package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MPurchaseOrderCharListener implements EntityListener<MPurchaseOrderChar> {

    @Override
    public void preInsert(MPurchaseOrderChar entity, PreInsertContext<MPurchaseOrderChar> context) {
    }

    @Override
    public void preUpdate(MPurchaseOrderChar entity, PreUpdateContext<MPurchaseOrderChar> context) {
    }

    @Override
    public void preDelete(MPurchaseOrderChar entity, PreDeleteContext<MPurchaseOrderChar> context) {
    }

    @Override
    public void postInsert(MPurchaseOrderChar entity, PostInsertContext<MPurchaseOrderChar> context) {
    }

    @Override
    public void postUpdate(MPurchaseOrderChar entity, PostUpdateContext<MPurchaseOrderChar> context) {
    }

    @Override
    public void postDelete(MPurchaseOrderChar entity, PostDeleteContext<MPurchaseOrderChar> context) {
    }
}