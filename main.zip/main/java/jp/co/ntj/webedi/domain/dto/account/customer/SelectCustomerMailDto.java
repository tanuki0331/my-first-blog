package jp.co.ntj.webedi.domain.dto.account.customer;

import jp.co.ntj.webedi.domain.domain.Bool;
import org.seasar.doma.Entity;

/**
 * メール検索DTO.
 *
 * @author 日立システムズ
 */
@Entity
public class SelectCustomerMailDto {

  /**
   * 連番
   */
  public Short sequenceNumber;

  /**
   * メールアドレス
   */
  public String mailAddress;

  /**
   * 注文登録メール有効フラグ
   */
  public Bool useOrderMail;

  /**
   * OC発行メール有効フラグ
   */
  public Bool isValidatedOcIssueMail;

  /**
   * INV発行メール有効フラグ
   */
  public Bool isValidatedInvIssueMail;

  /**
   * P/I発行メール有効フラグ
   */
  public Bool isValidatedPinvIssueMail;
}
