package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class TOrderFileListener implements EntityListener<TOrderFile> {

    @Override
    public void preInsert(TOrderFile entity, PreInsertContext<TOrderFile> context) {
    }

    @Override
    public void preUpdate(TOrderFile entity, PreUpdateContext<TOrderFile> context) {
    }

    @Override
    public void preDelete(TOrderFile entity, PreDeleteContext<TOrderFile> context) {
    }

    @Override
    public void postInsert(TOrderFile entity, PostInsertContext<TOrderFile> context) {
    }

    @Override
    public void postUpdate(TOrderFile entity, PostUpdateContext<TOrderFile> context) {
    }

    @Override
    public void postDelete(TOrderFile entity, PostDeleteContext<TOrderFile> context) {
    }
}