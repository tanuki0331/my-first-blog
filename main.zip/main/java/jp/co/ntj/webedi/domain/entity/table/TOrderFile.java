package jp.co.ntj.webedi.domain.entity.table;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 発注関連ファイル情報
 */
@Entity(listener = TOrderFileListener.class)
@Table(name = "T_ORDER_FILE")
public class TOrderFile {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** ファイルコード */
    @Id
    @Column(name = "FILE_CODE")
    Long fileCode;

    /** Web注文番号 */
    @Column(name = "ORDERNO")
    Long orderno;

    /** Web注文行番号 */
    @Column(name = "ORDER_LINE")
    Short orderLine;

    /** 得意先コード */
    @Column(name = "TOKUCD")
    Long tokucd;

    /** PONO */
    @Column(name = "PONO")
    String pono;

    /** インボイス番号 */
    @Column(name = "INVOICE_NO")
    String invoiceNo;

    /** オーダーコンファメーション番号 */
    @Column(name = "ORDER_CONF_NO")
    String orderConfNo;

    /** プロフォーマインボイス番号 */
    @Column(name = "PROFOMA_INVICE_NO")
    String profomaInviceNo;

    /** 表示ファイル名 */
    @Column(name = "FILE_NAME1")
    String fileName1;

    /** 物理ファイル名 */
    @Column(name = "FILE_NAME2")
    String fileName2;

    /** ファイル区分 */
    @Column(name = "FILE_KIND")
    Short fileKind;

    /** 表示開始日 */
    @Column(name = "START_DATE")
    LocalDate startDate;

    /** 表示終了日 */
    @Column(name = "END_DATE")
    LocalDate endDate;

    /** 登録日付時刻 */
    @Column(name = "ENTRY_DATE")
    LocalDate entryDate;

    /** 更新日付時刻 */
    @Column(name = "UPDATE_DATE")
    LocalDate updateDate;

    /** 帳票コード */
    @Column(name = "DOCCD")
    String doccd;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the fileCode.
     * 
     * @return the fileCode
     */
    public Long getFileCode() {
        return fileCode;
    }

    /** 
     * Sets the fileCode.
     * 
     * @param fileCode the fileCode
     */
    public void setFileCode(Long fileCode) {
        this.fileCode = fileCode;
    }

    /** 
     * Returns the orderno.
     * 
     * @return the orderno
     */
    public Long getOrderno() {
        return orderno;
    }

    /** 
     * Sets the orderno.
     * 
     * @param orderno the orderno
     */
    public void setOrderno(Long orderno) {
        this.orderno = orderno;
    }

    /** 
     * Returns the orderLine.
     * 
     * @return the orderLine
     */
    public Short getOrderLine() {
        return orderLine;
    }

    /** 
     * Sets the orderLine.
     * 
     * @param orderLine the orderLine
     */
    public void setOrderLine(Short orderLine) {
        this.orderLine = orderLine;
    }

    /** 
     * Returns the tokucd.
     * 
     * @return the tokucd
     */
    public Long getTokucd() {
        return tokucd;
    }

    /** 
     * Sets the tokucd.
     * 
     * @param tokucd the tokucd
     */
    public void setTokucd(Long tokucd) {
        this.tokucd = tokucd;
    }

    /** 
     * Returns the pono.
     * 
     * @return the pono
     */
    public String getPono() {
        return pono;
    }

    /** 
     * Sets the pono.
     * 
     * @param pono the pono
     */
    public void setPono(String pono) {
        this.pono = pono;
    }

    /** 
     * Returns the invoiceNo.
     * 
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }

    /** 
     * Sets the invoiceNo.
     * 
     * @param invoiceNo the invoiceNo
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    /** 
     * Returns the orderConfNo.
     * 
     * @return the orderConfNo
     */
    public String getOrderConfNo() {
        return orderConfNo;
    }

    /** 
     * Sets the orderConfNo.
     * 
     * @param orderConfNo the orderConfNo
     */
    public void setOrderConfNo(String orderConfNo) {
        this.orderConfNo = orderConfNo;
    }

    /** 
     * Returns the profomaInviceNo.
     * 
     * @return the profomaInviceNo
     */
    public String getProfomaInviceNo() {
        return profomaInviceNo;
    }

    /** 
     * Sets the profomaInviceNo.
     * 
     * @param profomaInviceNo the profomaInviceNo
     */
    public void setProfomaInviceNo(String profomaInviceNo) {
        this.profomaInviceNo = profomaInviceNo;
    }

    /** 
     * Returns the fileName1.
     * 
     * @return the fileName1
     */
    public String getFileName1() {
        return fileName1;
    }

    /** 
     * Sets the fileName1.
     * 
     * @param fileName1 the fileName1
     */
    public void setFileName1(String fileName1) {
        this.fileName1 = fileName1;
    }

    /** 
     * Returns the fileName2.
     * 
     * @return the fileName2
     */
    public String getFileName2() {
        return fileName2;
    }

    /** 
     * Sets the fileName2.
     * 
     * @param fileName2 the fileName2
     */
    public void setFileName2(String fileName2) {
        this.fileName2 = fileName2;
    }

    /** 
     * Returns the fileKind.
     * 
     * @return the fileKind
     */
    public Short getFileKind() {
        return fileKind;
    }

    /** 
     * Sets the fileKind.
     * 
     * @param fileKind the fileKind
     */
    public void setFileKind(Short fileKind) {
        this.fileKind = fileKind;
    }

    /** 
     * Returns the startDate.
     * 
     * @return the startDate
     */
    public LocalDate getStartDate() {
        return startDate;
    }

    /** 
     * Sets the startDate.
     * 
     * @param startDate the startDate
     */
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    /** 
     * Returns the endDate.
     * 
     * @return the endDate
     */
    public LocalDate getEndDate() {
        return endDate;
    }

    /** 
     * Sets the endDate.
     * 
     * @param endDate the endDate
     */
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    /** 
     * Returns the entryDate.
     * 
     * @return the entryDate
     */
    public LocalDate getEntryDate() {
        return entryDate;
    }

    /** 
     * Sets the entryDate.
     * 
     * @param entryDate the entryDate
     */
    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    /** 
     * Returns the updateDate.
     * 
     * @return the updateDate
     */
    public LocalDate getUpdateDate() {
        return updateDate;
    }

    /** 
     * Sets the updateDate.
     * 
     * @param updateDate the updateDate
     */
    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    /** 
     * Returns the doccd.
     * 
     * @return the doccd
     */
    public String getDoccd() {
        return doccd;
    }

    /** 
     * Sets the doccd.
     * 
     * @param doccd the doccd
     */
    public void setDoccd(String doccd) {
        this.doccd = doccd;
    }
}