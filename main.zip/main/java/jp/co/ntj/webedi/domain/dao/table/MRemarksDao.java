package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.MRemarks;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MRemarksDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param shimukecd
     * @return the MRemarks entity
     */
    @Select
    MRemarks selectById(String kaisyaCd, String gengoKbn, Long shimukecd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MRemarks entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MRemarks entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MRemarks entity);
}