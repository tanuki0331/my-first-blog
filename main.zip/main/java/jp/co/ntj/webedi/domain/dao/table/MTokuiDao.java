package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.MTokui;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MTokuiDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param tokucd
     * @return the MTokui entity
     */
    @Select
    MTokui selectById(String kaisyaCd, String gengoKbn, Long tokucd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MTokui entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MTokui entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MTokui entity);
}