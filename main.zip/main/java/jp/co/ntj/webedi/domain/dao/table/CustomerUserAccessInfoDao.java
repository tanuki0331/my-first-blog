package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.CustomerUserAccessInfo;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

import java.time.LocalDateTime;

/**
 */
@ConfigAutowireable
@Dao
public interface CustomerUserAccessInfoDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @return the CustomerUserAccessInfo entity
     */
    @Select
    CustomerUserAccessInfo selectById(String kaisyaCd, String gengoKbn, Long customerUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(CustomerUserAccessInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(CustomerUserAccessInfo entity);

    /**
     * 論理削除もしくは存在しない得意先ユーザーに紐付くデータを論理削除する
     *
     * @param updateUser
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidCustomerUser(String updateUser);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(CustomerUserAccessInfo entity);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
