package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class InvReportListener implements EntityListener<InvReport> {

    @Override
    public void preInsert(InvReport entity, PreInsertContext<InvReport> context) {
    }

    @Override
    public void preUpdate(InvReport entity, PreUpdateContext<InvReport> context) {
    }

    @Override
    public void preDelete(InvReport entity, PreDeleteContext<InvReport> context) {
    }

    @Override
    public void postInsert(InvReport entity, PostInsertContext<InvReport> context) {
    }

    @Override
    public void postUpdate(InvReport entity, PostUpdateContext<InvReport> context) {
    }

    @Override
    public void postDelete(InvReport entity, PostDeleteContext<InvReport> context) {
    }
}