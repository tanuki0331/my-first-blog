package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class TOrderBListener implements EntityListener<TOrderB> {

    @Override
    public void preInsert(TOrderB entity, PreInsertContext<TOrderB> context) {
    }

    @Override
    public void preUpdate(TOrderB entity, PreUpdateContext<TOrderB> context) {
    }

    @Override
    public void preDelete(TOrderB entity, PreDeleteContext<TOrderB> context) {
    }

    @Override
    public void postInsert(TOrderB entity, PostInsertContext<TOrderB> context) {
    }

    @Override
    public void postUpdate(TOrderB entity, PostUpdateContext<TOrderB> context) {
    }

    @Override
    public void postDelete(TOrderB entity, PostDeleteContext<TOrderB> context) {
    }
}