package jp.co.ntj.webedi.domain.dto.account.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import jp.co.ntj.webedi.domain.domain.Bool;
import org.seasar.doma.Entity;

/**
 * ユーザー検索.
 *
 * @author 日立システムズ
 */
@Entity
public class SelectCustomerUserDto {

  /**
   * 会社コード
   */
  public String kaisyaCd;

  /**
   * 言語区分
   */
  public String gengoKbn;

  /**
   * ID
   */
  public BigDecimal id;

  /**
   * ユーザーID
   */
  public String userId;

  /**
   * 得意先コード
   */
  public Long customerCode;

  /**
   * 氏名
   */
  public String name;

  /**
   * パスワード
   */
  public String password;

  /**
   * パスワード変更フラグ
   */
  public Bool isInitPassword;

  /**
   * メールアドレス
   */
  public String mailAddress;

  /**
   * 注文登録メール有効フラグ
   */
  public Bool useOrderMail;

  /**
   * OC発行メール有効フラグ
   */
  public Bool isValidatedOcIssueMail;

  /**
   * INV発行メール有効フラグ
   */
  public Bool isValidatedInvIssueMail;

  /**
   * P/I発行メール有効フラグ
   */
  public Bool isValidatedPinvIssueMail;

  /**
   * 国内納入日表示有効フラグ
   */
  public Bool isValidatedDomesticDlvy;

  /**
   * 商品一覧表示有効フラグ
   */
  public Bool isValidatedProductList;

  /**
   * ユーザー有効フラグ
   */
  public Bool isValidatedUser;

  /**
   * セッションID
   */
  public String sessionId;

  /**
   * 最終操作日時
   */
  public Timestamp lastOperationAt;

  /**
   * ログイン日時
   */
  public Timestamp loginAt;

  /**
   * 前回ログイン日時
   */
  public Timestamp prevLoginAt;

  /**
   * ホスト名
   */
  public String hostName;

  /**
   * アクセスIP
   */
  public String accessIp;

  /**
   * ユーザーエージェント
   */
  public String userAgent;

  /**
   * カート件数.
   */
  public int cartItemCount;
}
