package jp.co.ntj.webedi.domain.entity.table;

import java.math.BigDecimal;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 社員ユーザー
 */
@Entity(listener = EmployeeUserListener.class)
@Table(name = "EMPLOYEE_USER")
public class EmployeeUser {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** ID */
    @Id
    @Column(name = "ID")
    BigDecimal id;

    /** 社員ID */
    @Column(name = "EMPLOYEE_ID")
    String employeeId;

    /** 氏名 */
    @Column(name = "NAME")
    String name;

    /** パスワード */
    @Column(name = "PASSWORD")
    String password;

    /** メールアドレス */
    @Column(name = "MAIL_ADDRESS")
    String mailAddress;

    /** ユーザー有効フラグ */
    @Column(name = "IS_VALIDATED_USER")
    Short isValidatedUser;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the id.
     * 
     * @return the id
     */
    public BigDecimal getId() {
        return id;
    }

    /** 
     * Sets the id.
     * 
     * @param id the id
     */
    public void setId(BigDecimal id) {
        this.id = id;
    }

    /** 
     * Returns the employeeId.
     * 
     * @return the employeeId
     */
    public String getEmployeeId() {
        return employeeId;
    }

    /** 
     * Sets the employeeId.
     * 
     * @param employeeId the employeeId
     */
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    /** 
     * Returns the name.
     * 
     * @return the name
     */
    public String getName() {
        return name;
    }

    /** 
     * Sets the name.
     * 
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
    }

    /** 
     * Returns the password.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /** 
     * Sets the password.
     * 
     * @param password the password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /** 
     * Returns the mailAddress.
     * 
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /** 
     * Sets the mailAddress.
     * 
     * @param mailAddress the mailAddress
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /** 
     * Returns the isValidatedUser.
     * 
     * @return the isValidatedUser
     */
    public Short getIsValidatedUser() {
        return isValidatedUser;
    }

    /** 
     * Sets the isValidatedUser.
     * 
     * @param isValidatedUser the isValidatedUser
     */
    public void setIsValidatedUser(Short isValidatedUser) {
        this.isValidatedUser = isValidatedUser;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}