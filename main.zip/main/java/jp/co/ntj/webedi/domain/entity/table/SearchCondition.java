package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 検索条件
 */
@Entity(listener = SearchConditionListener.class)
@Table(name = "SEARCH_CONDITION")
public class SearchCondition {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 得意先ユーザーID */
    @Id
    @Column(name = "CUSTOMER_USER_ID")
    Long customerUserId;

    /** 仕向先コード */
    @Column(name = "DESTINATION_CODE")
    Long destinationCode;

    /** 最終仕向先コード */
    @Column(name = "LAST_DESTINATION_CODE")
    Long lastDestinationCode;

    /** 通貨コード */
    @Column(name = "CURRENCY_CODE")
    String currencyCode;

    /** 輸送方法コード */
    @Column(name = "TRANSPORT_METHOD_CODE")
    Short transportMethodCode;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the customerUserId.
     * 
     * @return the customerUserId
     */
    public Long getCustomerUserId() {
        return customerUserId;
    }

    /** 
     * Sets the customerUserId.
     * 
     * @param customerUserId the customerUserId
     */
    public void setCustomerUserId(Long customerUserId) {
        this.customerUserId = customerUserId;
    }

    /** 
     * Returns the destinationCode.
     * 
     * @return the destinationCode
     */
    public Long getDestinationCode() {
        return destinationCode;
    }

    /** 
     * Sets the destinationCode.
     * 
     * @param destinationCode the destinationCode
     */
    public void setDestinationCode(Long destinationCode) {
        this.destinationCode = destinationCode;
    }

    /** 
     * Returns the lastDestinationCode.
     * 
     * @return the lastDestinationCode
     */
    public Long getLastDestinationCode() {
        return lastDestinationCode;
    }

    /** 
     * Sets the lastDestinationCode.
     * 
     * @param lastDestinationCode the lastDestinationCode
     */
    public void setLastDestinationCode(Long lastDestinationCode) {
        this.lastDestinationCode = lastDestinationCode;
    }

    /** 
     * Returns the currencyCode.
     * 
     * @return the currencyCode
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /** 
     * Sets the currencyCode.
     * 
     * @param currencyCode the currencyCode
     */
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    /** 
     * Returns the transportMethodCode.
     * 
     * @return the transportMethodCode
     */
    public Short getTransportMethodCode() {
        return transportMethodCode;
    }

    /** 
     * Sets the transportMethodCode.
     * 
     * @param transportMethodCode the transportMethodCode
     */
    public void setTransportMethodCode(Short transportMethodCode) {
        this.transportMethodCode = transportMethodCode;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}