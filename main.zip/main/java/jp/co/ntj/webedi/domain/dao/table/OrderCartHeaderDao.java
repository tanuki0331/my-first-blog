package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.OrderCartHeader;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

import java.time.LocalDateTime;

/**
 */
@ConfigAutowireable
@Dao
public interface OrderCartHeaderDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @return the OrderCartHeader entity
     */
    @Select
    OrderCartHeader selectById(String kaisyaCd, String gengoKbn, Long customerUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(OrderCartHeader entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(OrderCartHeader entity);

    /**
     * 論理削除もしくは存在しない得意先ユーザーに紐付くデータを論理削除する
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidCustomerUser(String updateUser);

    /**
     * 論理削除もしくは存在しない仕向先／最終仕向け先に紐付くデータを論理削除する
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidShimu(String updateUser);

    /**
     * 注文カート明細が存在しないデータを論理削除する
     */
    @Update(sqlFile = true)
    int updateForDelByDetail(String updateUser);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(OrderCartHeader entity);

    /**
     * 指定日時以前に作成されたデータを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteBeforeByCreatedAt(LocalDateTime createdAt);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
