package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MShiharaiListener implements EntityListener<MShiharai> {

    @Override
    public void preInsert(MShiharai entity, PreInsertContext<MShiharai> context) {
    }

    @Override
    public void preUpdate(MShiharai entity, PreUpdateContext<MShiharai> context) {
    }

    @Override
    public void preDelete(MShiharai entity, PreDeleteContext<MShiharai> context) {
    }

    @Override
    public void postInsert(MShiharai entity, PostInsertContext<MShiharai> context) {
    }

    @Override
    public void postUpdate(MShiharai entity, PostUpdateContext<MShiharai> context) {
    }

    @Override
    public void postDelete(MShiharai entity, PostDeleteContext<MShiharai> context) {
    }
}