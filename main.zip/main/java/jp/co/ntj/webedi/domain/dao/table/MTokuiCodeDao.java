package jp.co.ntj.webedi.domain.dao.table;

import java.math.BigDecimal;
import jp.co.ntj.webedi.domain.entity.table.MTokuiCode;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MTokuiCodeDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param tokucd
     * @param shimukecd
     * @param tokuHinmokuCd
     * @param irimeJuryo
     * @return the MTokuiCode entity
     */
    @Select
    MTokuiCode selectById(String kaisyaCd, String gengoKbn, Long tokucd, Long shimukecd, String tokuHinmokuCd, BigDecimal irimeJuryo);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MTokuiCode entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MTokuiCode entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MTokuiCode entity);
}