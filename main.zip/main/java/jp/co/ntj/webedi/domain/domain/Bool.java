package jp.co.ntj.webedi.domain.domain;

import org.seasar.doma.Domain;

/**
 * 真偽値ドメイン.
 *
 * @author 日立システムズ
 */
@Domain(valueType = short.class)
public class Bool {

  /**
   * 値.
   */
  private short value;

  /**
   * コンストラクタ.
   *
   * @param value 1=true, 0=false
   */
  public Bool(short value) {
    this.value = value;
  }

  /**
   * コンストラクタ.
   *
   * @param isValid 1=true, 0=false
   */
  public Bool(boolean isValid) {
    this.value = isValid ? (short) 1 : (short) 0;
  }

  /**
   * 値取得.
   *
   * @return 1=true, 0=false
   */
  public short getValue() {
    return this.value;
  }

  /**
   * 真か.
   *
   * @return 真偽値、1以外はfalse
   */
  public boolean isValid() {
    return this.value == 1;
  }

}
