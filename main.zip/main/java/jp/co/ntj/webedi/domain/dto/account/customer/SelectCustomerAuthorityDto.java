package jp.co.ntj.webedi.domain.dto.account.customer;

import org.seasar.doma.Entity;

/**
 * 権限検索.
 *
 * @author 日立システムズ
 */
@Entity
public class SelectCustomerAuthorityDto {

  /**
   * 権限.
   */
  public String authority;
}
