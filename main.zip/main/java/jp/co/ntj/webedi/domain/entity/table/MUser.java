package jp.co.ntj.webedi.domain.entity.table;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 利用者マスタ
 */
@Entity(listener = MUserListener.class)
@Table(name = "M_USER")
public class MUser {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** ログイン名 */
    @Id
    @Column(name = "LOGIN_NAME")
    String loginName;

    /** パスワード */
    @Column(name = "PASSWD")
    String passwd;

    /** 管理区分 */
    @Column(name = "KANRI_KBN1")
    Short kanriKbn1;

    /** 英語氏名 */
    @Column(name = "ENAME")
    String ename;

    /** 得意先コード */
    @Column(name = "TOKUCD")
    Long tokucd;

    /** メールアドレス */
    @Column(name = "MAILADDRESS")
    String mailaddress;

    /** CARGOREADY表示区分 */
    @Column(name = "CARGO_READY_KBN")
    String cargoReadyKbn;

    /** パスワード有効期限 */
    @Column(name = "PASSWD_DATE")
    LocalDate passwdDate;

    /** 登録日付時刻 */
    @Column(name = "ENTRY_DATE")
    LocalDate entryDate;

    /** 更新日付時刻 */
    @Column(name = "UPDATE_DATE")
    LocalDate updateDate;

    /** 削除日付時刻 */
    @Column(name = "DELETE_DATE")
    LocalDate deleteDate;

    /** 削除フラグ */
    @Column(name = "DELETE_FLG")
    Short deleteFlg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the loginName.
     * 
     * @return the loginName
     */
    public String getLoginName() {
        return loginName;
    }

    /** 
     * Sets the loginName.
     * 
     * @param loginName the loginName
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    /** 
     * Returns the passwd.
     * 
     * @return the passwd
     */
    public String getPasswd() {
        return passwd;
    }

    /** 
     * Sets the passwd.
     * 
     * @param passwd the passwd
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    /** 
     * Returns the kanriKbn1.
     * 
     * @return the kanriKbn1
     */
    public Short getKanriKbn1() {
        return kanriKbn1;
    }

    /** 
     * Sets the kanriKbn1.
     * 
     * @param kanriKbn1 the kanriKbn1
     */
    public void setKanriKbn1(Short kanriKbn1) {
        this.kanriKbn1 = kanriKbn1;
    }

    /** 
     * Returns the ename.
     * 
     * @return the ename
     */
    public String getEname() {
        return ename;
    }

    /** 
     * Sets the ename.
     * 
     * @param ename the ename
     */
    public void setEname(String ename) {
        this.ename = ename;
    }

    /** 
     * Returns the tokucd.
     * 
     * @return the tokucd
     */
    public Long getTokucd() {
        return tokucd;
    }

    /** 
     * Sets the tokucd.
     * 
     * @param tokucd the tokucd
     */
    public void setTokucd(Long tokucd) {
        this.tokucd = tokucd;
    }

    /** 
     * Returns the mailaddress.
     * 
     * @return the mailaddress
     */
    public String getMailaddress() {
        return mailaddress;
    }

    /** 
     * Sets the mailaddress.
     * 
     * @param mailaddress the mailaddress
     */
    public void setMailaddress(String mailaddress) {
        this.mailaddress = mailaddress;
    }

    /** 
     * Returns the cargoReadyKbn.
     * 
     * @return the cargoReadyKbn
     */
    public String getCargoReadyKbn() {
        return cargoReadyKbn;
    }

    /** 
     * Sets the cargoReadyKbn.
     * 
     * @param cargoReadyKbn the cargoReadyKbn
     */
    public void setCargoReadyKbn(String cargoReadyKbn) {
        this.cargoReadyKbn = cargoReadyKbn;
    }

    /** 
     * Returns the passwdDate.
     * 
     * @return the passwdDate
     */
    public LocalDate getPasswdDate() {
        return passwdDate;
    }

    /** 
     * Sets the passwdDate.
     * 
     * @param passwdDate the passwdDate
     */
    public void setPasswdDate(LocalDate passwdDate) {
        this.passwdDate = passwdDate;
    }

    /** 
     * Returns the entryDate.
     * 
     * @return the entryDate
     */
    public LocalDate getEntryDate() {
        return entryDate;
    }

    /** 
     * Sets the entryDate.
     * 
     * @param entryDate the entryDate
     */
    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    /** 
     * Returns the updateDate.
     * 
     * @return the updateDate
     */
    public LocalDate getUpdateDate() {
        return updateDate;
    }

    /** 
     * Sets the updateDate.
     * 
     * @param updateDate the updateDate
     */
    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    /** 
     * Returns the deleteDate.
     * 
     * @return the deleteDate
     */
    public LocalDate getDeleteDate() {
        return deleteDate;
    }

    /** 
     * Sets the deleteDate.
     * 
     * @param deleteDate the deleteDate
     */
    public void setDeleteDate(LocalDate deleteDate) {
        this.deleteDate = deleteDate;
    }

    /** 
     * Returns the deleteFlg.
     * 
     * @return the deleteFlg
     */
    public Short getDeleteFlg() {
        return deleteFlg;
    }

    /** 
     * Sets the deleteFlg.
     * 
     * @param deleteFlg the deleteFlg
     */
    public void setDeleteFlg(Short deleteFlg) {
        this.deleteFlg = deleteFlg;
    }
}