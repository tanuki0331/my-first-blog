package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class TShipInfoListener implements EntityListener<TShipInfo> {

    @Override
    public void preInsert(TShipInfo entity, PreInsertContext<TShipInfo> context) {
    }

    @Override
    public void preUpdate(TShipInfo entity, PreUpdateContext<TShipInfo> context) {
    }

    @Override
    public void preDelete(TShipInfo entity, PreDeleteContext<TShipInfo> context) {
    }

    @Override
    public void postInsert(TShipInfo entity, PostInsertContext<TShipInfo> context) {
    }

    @Override
    public void postUpdate(TShipInfo entity, PostUpdateContext<TShipInfo> context) {
    }

    @Override
    public void postDelete(TShipInfo entity, PostDeleteContext<TShipInfo> context) {
    }
}