package jp.co.ntj.webedi.domain.entity.table;

import java.math.BigDecimal;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 得意先ユーザー
 */
@Entity(listener = CustomerUserListener.class)
@Table(name = "CUSTOMER_USER")
public class CustomerUser {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** ID */
    @Id
    @Column(name = "ID")
    BigDecimal id;

    /** ユーザーID */
    @Column(name = "USER_ID")
    String userId;

    /** 得意先コード */
    @Column(name = "CUSTOMER_CODE")
    Long customerCode;

    /** 氏名 */
    @Column(name = "NAME")
    String name;

    /** パスワード */
    @Column(name = "PASSWORD")
    String password;

    /** パスワード変更フラグ */
    @Column(name = "IS_INIT_PASSWORD")
    Short isInitPassword;

    /** メールアドレス */
    @Column(name = "MAIL_ADDRESS")
    String mailAddress;

    /** 注文登録メール有効フラグ */
    @Column(name = "USE_ORDER_MAIL")
    Short useOrderMail;

    /** OC発行メール有効フラグ */
    @Column(name = "IS_VALIDATED_OC_ISSUE_MAIL")
    Short isValidatedOcIssueMail;

    /** INV発行メール有効フラグ */
    @Column(name = "IS_VALIDATED_INV_ISSUE_MAIL")
    Short isValidatedInvIssueMail;

    /** P/I発行メール有効フラグ */
    @Column(name = "IS_VALIDATED_PINV_ISSUE_MAIL")
    Short isValidatedPinvIssueMail;

    /** 国内納入日表示有効フラグ */
    @Column(name = "IS_VALIDATED_DOMESTIC_DLVY")
    Short isValidatedDomesticDlvy;

    /** 商品一覧表示有効フラグ */
    @Column(name = "IS_VALIDATED_PRODUCT_LIST")
    Short isValidatedProductList;

    /** ユーザー有効フラグ */
    @Column(name = "IS_VALIDATED_USER")
    Short isValidatedUser;

    /** 削除フラグ */
    @Column(name = "IS_DELETED")
    Short isDeleted;

    /** 作成日時 */
    @Column(name = "CREATED_AT")
    String createdAt;

    /** 作成ユーザー */
    @Column(name = "CREATED_USER")
    String createdUser;

    /** 更新日時 */
    @Column(name = "UPDATED_AT")
    String updatedAt;

    /** 更新ユーザー */
    @Column(name = "UPDATED_USER")
    String updatedUser;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the id.
     * 
     * @return the id
     */
    public BigDecimal getId() {
        return id;
    }

    /** 
     * Sets the id.
     * 
     * @param id the id
     */
    public void setId(BigDecimal id) {
        this.id = id;
    }

    /** 
     * Returns the userId.
     * 
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /** 
     * Sets the userId.
     * 
     * @param userId the userId
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /** 
     * Returns the customerCode.
     * 
     * @return the customerCode
     */
    public Long getCustomerCode() {
        return customerCode;
    }

    /** 
     * Sets the customerCode.
     * 
     * @param customerCode the customerCode
     */
    public void setCustomerCode(Long customerCode) {
        this.customerCode = customerCode;
    }

    /** 
     * Returns the name.
     * 
     * @return the name
     */
    public String getName() {
        return name;
    }

    /** 
     * Sets the name.
     * 
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
    }

    /** 
     * Returns the password.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /** 
     * Sets the password.
     * 
     * @param password the password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /** 
     * Returns the isInitPassword.
     * 
     * @return the isInitPassword
     */
    public Short getIsInitPassword() {
        return isInitPassword;
    }

    /** 
     * Sets the isInitPassword.
     * 
     * @param isInitPassword the isInitPassword
     */
    public void setIsInitPassword(Short isInitPassword) {
        this.isInitPassword = isInitPassword;
    }

    /** 
     * Returns the mailAddress.
     * 
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /** 
     * Sets the mailAddress.
     * 
     * @param mailAddress the mailAddress
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /** 
     * Returns the useOrderMail.
     * 
     * @return the useOrderMail
     */
    public Short getUseOrderMail() {
        return useOrderMail;
    }

    /** 
     * Sets the useOrderMail.
     * 
     * @param useOrderMail the useOrderMail
     */
    public void setUseOrderMail(Short useOrderMail) {
        this.useOrderMail = useOrderMail;
    }

    /** 
     * Returns the isValidatedOcIssueMail.
     * 
     * @return the isValidatedOcIssueMail
     */
    public Short getIsValidatedOcIssueMail() {
        return isValidatedOcIssueMail;
    }

    /** 
     * Sets the isValidatedOcIssueMail.
     * 
     * @param isValidatedOcIssueMail the isValidatedOcIssueMail
     */
    public void setIsValidatedOcIssueMail(Short isValidatedOcIssueMail) {
        this.isValidatedOcIssueMail = isValidatedOcIssueMail;
    }

    /** 
     * Returns the isValidatedInvIssueMail.
     * 
     * @return the isValidatedInvIssueMail
     */
    public Short getIsValidatedInvIssueMail() {
        return isValidatedInvIssueMail;
    }

    /** 
     * Sets the isValidatedInvIssueMail.
     * 
     * @param isValidatedInvIssueMail the isValidatedInvIssueMail
     */
    public void setIsValidatedInvIssueMail(Short isValidatedInvIssueMail) {
        this.isValidatedInvIssueMail = isValidatedInvIssueMail;
    }

    /** 
     * Returns the isValidatedPinvIssueMail.
     * 
     * @return the isValidatedPinvIssueMail
     */
    public Short getIsValidatedPinvIssueMail() {
        return isValidatedPinvIssueMail;
    }

    /** 
     * Sets the isValidatedPinvIssueMail.
     * 
     * @param isValidatedPinvIssueMail the isValidatedPinvIssueMail
     */
    public void setIsValidatedPinvIssueMail(Short isValidatedPinvIssueMail) {
        this.isValidatedPinvIssueMail = isValidatedPinvIssueMail;
    }

    /** 
     * Returns the isValidatedDomesticDlvy.
     * 
     * @return the isValidatedDomesticDlvy
     */
    public Short getIsValidatedDomesticDlvy() {
        return isValidatedDomesticDlvy;
    }

    /** 
     * Sets the isValidatedDomesticDlvy.
     * 
     * @param isValidatedDomesticDlvy the isValidatedDomesticDlvy
     */
    public void setIsValidatedDomesticDlvy(Short isValidatedDomesticDlvy) {
        this.isValidatedDomesticDlvy = isValidatedDomesticDlvy;
    }

    /** 
     * Returns the isValidatedProductList.
     * 
     * @return the isValidatedProductList
     */
    public Short getIsValidatedProductList() {
        return isValidatedProductList;
    }

    /** 
     * Sets the isValidatedProductList.
     * 
     * @param isValidatedProductList the isValidatedProductList
     */
    public void setIsValidatedProductList(Short isValidatedProductList) {
        this.isValidatedProductList = isValidatedProductList;
    }

    /** 
     * Returns the isValidatedUser.
     * 
     * @return the isValidatedUser
     */
    public Short getIsValidatedUser() {
        return isValidatedUser;
    }

    /** 
     * Sets the isValidatedUser.
     * 
     * @param isValidatedUser the isValidatedUser
     */
    public void setIsValidatedUser(Short isValidatedUser) {
        this.isValidatedUser = isValidatedUser;
    }

    /** 
     * Returns the isDeleted.
     * 
     * @return the isDeleted
     */
    public Short getIsDeleted() {
        return isDeleted;
    }

    /** 
     * Sets the isDeleted.
     * 
     * @param isDeleted the isDeleted
     */
    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    /** 
     * Returns the createdAt.
     * 
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /** 
     * Sets the createdAt.
     * 
     * @param createdAt the createdAt
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** 
     * Returns the createdUser.
     * 
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /** 
     * Sets the createdUser.
     * 
     * @param createdUser the createdUser
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /** 
     * Returns the updatedAt.
     * 
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /** 
     * Sets the updatedAt.
     * 
     * @param updatedAt the updatedAt
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /** 
     * Returns the updatedUser.
     * 
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /** 
     * Sets the updatedUser.
     * 
     * @param updatedUser the updatedUser
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }
}