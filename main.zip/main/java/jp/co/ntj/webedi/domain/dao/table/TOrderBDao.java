package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.TOrderB;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface TOrderBDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param orderno
     * @param orderLine
     * @return the TOrderB entity
     */
    @Select
    TOrderB selectById(String kaisyaCd, String gengoKbn, Long orderno, Short orderLine);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(TOrderB entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(TOrderB entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(TOrderB entity);
}