package jp.co.ntj.webedi.domain.entity.table;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 名称マスタ
 */
@Entity(listener = MMeishoListener.class)
@Table(name = "M_MEISHO")
public class MMeisho {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 名称管理コード */
    @Id
    @Column(name = "MEIKANCD")
    String meikancd;

    /** 名称コード */
    @Id
    @Column(name = "MEISHOCD")
    String meishocd;

    /** 名称 */
    @Column(name = "MEISHONM")
    String meishonm;

    /** 略称 */
    @Column(name = "MEISHORYAK")
    String meishoryak;

    /** 文字項目１ */
    @Column(name = "STR_VALUE1")
    String strValue1;

    /** 文字項目２ */
    @Column(name = "STR_VALUE2")
    String strValue2;

    /** 文字項目３ */
    @Column(name = "STR_VALUE3")
    String strValue3;

    /** 文字項目４ */
    @Column(name = "STR_VALUE4")
    String strValue4;

    /** 文字項目５ */
    @Column(name = "STR_VALUE5")
    String strValue5;

    /** 数字項目１ */
    @Column(name = "NUM_VALUE1")
    BigDecimal numValue1;

    /** 数字項目２ */
    @Column(name = "NUM_VALUE2")
    BigDecimal numValue2;

    /** 数字項目３ */
    @Column(name = "NUM_VALUE3")
    BigDecimal numValue3;

    /** 数字項目４ */
    @Column(name = "NUM_VALUE4")
    BigDecimal numValue4;

    /** 数字項目５ */
    @Column(name = "NUM_VALUE5")
    BigDecimal numValue5;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Integer hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the meikancd.
     * 
     * @return the meikancd
     */
    public String getMeikancd() {
        return meikancd;
    }

    /** 
     * Sets the meikancd.
     * 
     * @param meikancd the meikancd
     */
    public void setMeikancd(String meikancd) {
        this.meikancd = meikancd;
    }

    /** 
     * Returns the meishocd.
     * 
     * @return the meishocd
     */
    public String getMeishocd() {
        return meishocd;
    }

    /** 
     * Sets the meishocd.
     * 
     * @param meishocd the meishocd
     */
    public void setMeishocd(String meishocd) {
        this.meishocd = meishocd;
    }

    /** 
     * Returns the meishonm.
     * 
     * @return the meishonm
     */
    public String getMeishonm() {
        return meishonm;
    }

    /** 
     * Sets the meishonm.
     * 
     * @param meishonm the meishonm
     */
    public void setMeishonm(String meishonm) {
        this.meishonm = meishonm;
    }

    /** 
     * Returns the meishoryak.
     * 
     * @return the meishoryak
     */
    public String getMeishoryak() {
        return meishoryak;
    }

    /** 
     * Sets the meishoryak.
     * 
     * @param meishoryak the meishoryak
     */
    public void setMeishoryak(String meishoryak) {
        this.meishoryak = meishoryak;
    }

    /** 
     * Returns the strValue1.
     * 
     * @return the strValue1
     */
    public String getStrValue1() {
        return strValue1;
    }

    /** 
     * Sets the strValue1.
     * 
     * @param strValue1 the strValue1
     */
    public void setStrValue1(String strValue1) {
        this.strValue1 = strValue1;
    }

    /** 
     * Returns the strValue2.
     * 
     * @return the strValue2
     */
    public String getStrValue2() {
        return strValue2;
    }

    /** 
     * Sets the strValue2.
     * 
     * @param strValue2 the strValue2
     */
    public void setStrValue2(String strValue2) {
        this.strValue2 = strValue2;
    }

    /** 
     * Returns the strValue3.
     * 
     * @return the strValue3
     */
    public String getStrValue3() {
        return strValue3;
    }

    /** 
     * Sets the strValue3.
     * 
     * @param strValue3 the strValue3
     */
    public void setStrValue3(String strValue3) {
        this.strValue3 = strValue3;
    }

    /** 
     * Returns the strValue4.
     * 
     * @return the strValue4
     */
    public String getStrValue4() {
        return strValue4;
    }

    /** 
     * Sets the strValue4.
     * 
     * @param strValue4 the strValue4
     */
    public void setStrValue4(String strValue4) {
        this.strValue4 = strValue4;
    }

    /** 
     * Returns the strValue5.
     * 
     * @return the strValue5
     */
    public String getStrValue5() {
        return strValue5;
    }

    /** 
     * Sets the strValue5.
     * 
     * @param strValue5 the strValue5
     */
    public void setStrValue5(String strValue5) {
        this.strValue5 = strValue5;
    }

    /** 
     * Returns the numValue1.
     * 
     * @return the numValue1
     */
    public BigDecimal getNumValue1() {
        return numValue1;
    }

    /** 
     * Sets the numValue1.
     * 
     * @param numValue1 the numValue1
     */
    public void setNumValue1(BigDecimal numValue1) {
        this.numValue1 = numValue1;
    }

    /** 
     * Returns the numValue2.
     * 
     * @return the numValue2
     */
    public BigDecimal getNumValue2() {
        return numValue2;
    }

    /** 
     * Sets the numValue2.
     * 
     * @param numValue2 the numValue2
     */
    public void setNumValue2(BigDecimal numValue2) {
        this.numValue2 = numValue2;
    }

    /** 
     * Returns the numValue3.
     * 
     * @return the numValue3
     */
    public BigDecimal getNumValue3() {
        return numValue3;
    }

    /** 
     * Sets the numValue3.
     * 
     * @param numValue3 the numValue3
     */
    public void setNumValue3(BigDecimal numValue3) {
        this.numValue3 = numValue3;
    }

    /** 
     * Returns the numValue4.
     * 
     * @return the numValue4
     */
    public BigDecimal getNumValue4() {
        return numValue4;
    }

    /** 
     * Sets the numValue4.
     * 
     * @param numValue4 the numValue4
     */
    public void setNumValue4(BigDecimal numValue4) {
        this.numValue4 = numValue4;
    }

    /** 
     * Returns the numValue5.
     * 
     * @return the numValue5
     */
    public BigDecimal getNumValue5() {
        return numValue5;
    }

    /** 
     * Sets the numValue5.
     * 
     * @param numValue5 the numValue5
     */
    public void setNumValue5(BigDecimal numValue5) {
        this.numValue5 = numValue5;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Integer getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Integer hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}