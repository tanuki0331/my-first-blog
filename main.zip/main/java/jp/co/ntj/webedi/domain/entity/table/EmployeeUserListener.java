package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class EmployeeUserListener implements EntityListener<EmployeeUser> {

    @Override
    public void preInsert(EmployeeUser entity, PreInsertContext<EmployeeUser> context) {
    }

    @Override
    public void preUpdate(EmployeeUser entity, PreUpdateContext<EmployeeUser> context) {
    }

    @Override
    public void preDelete(EmployeeUser entity, PreDeleteContext<EmployeeUser> context) {
    }

    @Override
    public void postInsert(EmployeeUser entity, PostInsertContext<EmployeeUser> context) {
    }

    @Override
    public void postUpdate(EmployeeUser entity, PostUpdateContext<EmployeeUser> context) {
    }

    @Override
    public void postDelete(EmployeeUser entity, PostDeleteContext<EmployeeUser> context) {
    }
}