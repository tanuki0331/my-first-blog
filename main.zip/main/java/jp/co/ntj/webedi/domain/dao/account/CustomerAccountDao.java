package jp.co.ntj.webedi.domain.dao.account;

import java.math.BigDecimal;
import java.util.List;
import jp.co.ntj.webedi.domain.dto.account.customer.SelectCustomerAuthorityDto;
import jp.co.ntj.webedi.domain.dto.account.customer.SelectCustomerMailDto;
import jp.co.ntj.webedi.domain.dto.account.customer.SelectCustomerUserDto;
import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * 得意先アカウントDao.
 *
 * @author 日立システムズ
 */
@ConfigAutowireable
@Dao
public interface CustomerAccountDao {

  /**
   * ユーザー検索.
   *
   * @param userId ユーザーID
   * @return SelectCustomerUserDto
   */
  @Select
  SelectCustomerUserDto selectCustomerUserByUserId(String userId);


  /**
   * ユーザー検索.
   *
   * @param kaisyaCd 会社コード
   * @param gengoKbn 言語区分
   * @param id id
   * @return SelectCustomerUserDto
   */
  @Select
  SelectCustomerUserDto selectCustomerUserById(String kaisyaCd, String gengoKbn, BigDecimal id);

  /**
   * 権限検索.
   *
   * @param kaisyaCd 会社コード
   * @param gengoKbn 言語区分
   * @param customerUserId id
   * @return SelectCustomerAuthorityDto
   */
  @Select
  List<SelectCustomerAuthorityDto> selectCustomerAuthority(String kaisyaCd, String gengoKbn,
      BigDecimal customerUserId);

  /**
   * メール検索.
   *
   * @param kaisyaCd 会社コード
   * @param gengoKbn 言語区分
   * @param customerUserId id
   * @return SelectCustomerMailDto
   */
  @Select
  List<SelectCustomerMailDto> selectCustomerMail(String kaisyaCd, String gengoKbn,
      BigDecimal customerUserId);
}
