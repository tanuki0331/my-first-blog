package jp.co.ntj.webedi.domain.entity.table;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * PurchaseOrder文言マスタ
 */
@Entity(listener = MPurchaseOrderCharListener.class)
@Table(name = "M_PURCHASE_ORDER_CHAR")
public class MPurchaseOrderChar {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 仕向先コード */
    @Id
    @Column(name = "SHIMUKECD")
    Long shimukecd;

    /** 社名識別コード */
    @Column(name = "SHA_SIKIBETCD")
    String shaSikibetcd;

    /** ロゴファイル名 */
    @Column(name = "LOGO_FILE")
    String logoFile;

    /** タイトル */
    @Column(name = "TITLE")
    String title;

    /** 得意先電話番号 */
    @Column(name = "TOKU_TEL")
    String tokuTel;

    /** 得意先FAX番号 */
    @Column(name = "TOKU_FAX")
    String tokuFax;

    /** サプライヤー名 */
    @Column(name = "SUPPLIER")
    String supplier;

    /** サプライヤー名_値 */
    @Column(name = "SUPPLIER_DATA")
    String supplierData;

    /** サプライヤー住所 */
    @Column(name = "SUPPLIER_ADDRESS")
    String supplierAddress;

    /** サプライヤー住所_値 */
    @Column(name = "SUPPLIER_ADDRESS_DATA")
    String supplierAddressData;

    /** サプライヤー電話番号 */
    @Column(name = "SUPPLIER_TEL")
    String supplierTel;

    /** サプライヤー電話番号_値 */
    @Column(name = "SUPPLIER_TEL_DATA")
    String supplierTelData;

    /** サプライヤーFAX番号 */
    @Column(name = "SUPPLIER_FAX")
    String supplierFax;

    /** サプライヤーFAX番号_値 */
    @Column(name = "SUPPLIER_FAX_DATA")
    String supplierFaxData;

    /** Po№ */
    @Column(name = "PONO")
    String pono;

    /** 発注日付 */
    @Column(name = "ORDER_DATE")
    String orderDate;

    /** 建値 */
    @Column(name = "CURRENCY")
    String currency;

    /** 現ページ/全ページ */
    @Column(name = "PAGE")
    String page;

    /** S/N */
    @Column(name = "SN")
    String sn;

    /** 商品名 */
    @Column(name = "DESCRIPTION")
    String description;

    /** 発注数量 */
    @Column(name = "QUANTITY")
    String quantity;

    /** 入目重量 */
    @Column(name = "WEIGHT")
    String weight;

    /** 単価 */
    @Column(name = "PRICE")
    String price;

    /** 金額 */
    @Column(name = "AMOUNT")
    String amount;

    /** 希望納期 */
    @Column(name = "ETA_DATE")
    String etaDate;

    /** 発注金額合計 */
    @Column(name = "TOTAL")
    String total;

    /** 輸送方法 */
    @Column(name = "DELIVERY_FORM")
    String deliveryForm;

    /** 仕向地港名 */
    @Column(name = "PORT")
    String port;

    /** 支払条件 */
    @Column(name = "PAYMENT")
    String payment;

    /** サプライヤー_フッター */
    @Column(name = "FOOT_SUPPLIER")
    String footSupplier;

    /** PurchaseManager */
    @Column(name = "PURCHASE_MANAGER")
    String purchaseManager;

    /** Signature */
    @Column(name = "SIGNATURE")
    String signature;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 電子署名ファイル名１ */
    @Column(name = "SIGN_FILE1")
    String signFile1;

    /** 電子署名ファイル名２ */
    @Column(name = "SIGN_FILE2")
    String signFile2;

    /** 契約条件 */
    @Column(name = "TRADE")
    String trade;

    /** ISO# */
    @Column(name = "ISONO")
    String isono;

    /** ISO#の内容文言 */
    @Column(name = "ISONO_DATA")
    String isonoData;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the shimukecd.
     * 
     * @return the shimukecd
     */
    public Long getShimukecd() {
        return shimukecd;
    }

    /** 
     * Sets the shimukecd.
     * 
     * @param shimukecd the shimukecd
     */
    public void setShimukecd(Long shimukecd) {
        this.shimukecd = shimukecd;
    }

    /** 
     * Returns the shaSikibetcd.
     * 
     * @return the shaSikibetcd
     */
    public String getShaSikibetcd() {
        return shaSikibetcd;
    }

    /** 
     * Sets the shaSikibetcd.
     * 
     * @param shaSikibetcd the shaSikibetcd
     */
    public void setShaSikibetcd(String shaSikibetcd) {
        this.shaSikibetcd = shaSikibetcd;
    }

    /** 
     * Returns the logoFile.
     * 
     * @return the logoFile
     */
    public String getLogoFile() {
        return logoFile;
    }

    /** 
     * Sets the logoFile.
     * 
     * @param logoFile the logoFile
     */
    public void setLogoFile(String logoFile) {
        this.logoFile = logoFile;
    }

    /** 
     * Returns the title.
     * 
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /** 
     * Sets the title.
     * 
     * @param title the title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /** 
     * Returns the tokuTel.
     * 
     * @return the tokuTel
     */
    public String getTokuTel() {
        return tokuTel;
    }

    /** 
     * Sets the tokuTel.
     * 
     * @param tokuTel the tokuTel
     */
    public void setTokuTel(String tokuTel) {
        this.tokuTel = tokuTel;
    }

    /** 
     * Returns the tokuFax.
     * 
     * @return the tokuFax
     */
    public String getTokuFax() {
        return tokuFax;
    }

    /** 
     * Sets the tokuFax.
     * 
     * @param tokuFax the tokuFax
     */
    public void setTokuFax(String tokuFax) {
        this.tokuFax = tokuFax;
    }

    /** 
     * Returns the supplier.
     * 
     * @return the supplier
     */
    public String getSupplier() {
        return supplier;
    }

    /** 
     * Sets the supplier.
     * 
     * @param supplier the supplier
     */
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    /** 
     * Returns the supplierData.
     * 
     * @return the supplierData
     */
    public String getSupplierData() {
        return supplierData;
    }

    /** 
     * Sets the supplierData.
     * 
     * @param supplierData the supplierData
     */
    public void setSupplierData(String supplierData) {
        this.supplierData = supplierData;
    }

    /** 
     * Returns the supplierAddress.
     * 
     * @return the supplierAddress
     */
    public String getSupplierAddress() {
        return supplierAddress;
    }

    /** 
     * Sets the supplierAddress.
     * 
     * @param supplierAddress the supplierAddress
     */
    public void setSupplierAddress(String supplierAddress) {
        this.supplierAddress = supplierAddress;
    }

    /** 
     * Returns the supplierAddressData.
     * 
     * @return the supplierAddressData
     */
    public String getSupplierAddressData() {
        return supplierAddressData;
    }

    /** 
     * Sets the supplierAddressData.
     * 
     * @param supplierAddressData the supplierAddressData
     */
    public void setSupplierAddressData(String supplierAddressData) {
        this.supplierAddressData = supplierAddressData;
    }

    /** 
     * Returns the supplierTel.
     * 
     * @return the supplierTel
     */
    public String getSupplierTel() {
        return supplierTel;
    }

    /** 
     * Sets the supplierTel.
     * 
     * @param supplierTel the supplierTel
     */
    public void setSupplierTel(String supplierTel) {
        this.supplierTel = supplierTel;
    }

    /** 
     * Returns the supplierTelData.
     * 
     * @return the supplierTelData
     */
    public String getSupplierTelData() {
        return supplierTelData;
    }

    /** 
     * Sets the supplierTelData.
     * 
     * @param supplierTelData the supplierTelData
     */
    public void setSupplierTelData(String supplierTelData) {
        this.supplierTelData = supplierTelData;
    }

    /** 
     * Returns the supplierFax.
     * 
     * @return the supplierFax
     */
    public String getSupplierFax() {
        return supplierFax;
    }

    /** 
     * Sets the supplierFax.
     * 
     * @param supplierFax the supplierFax
     */
    public void setSupplierFax(String supplierFax) {
        this.supplierFax = supplierFax;
    }

    /** 
     * Returns the supplierFaxData.
     * 
     * @return the supplierFaxData
     */
    public String getSupplierFaxData() {
        return supplierFaxData;
    }

    /** 
     * Sets the supplierFaxData.
     * 
     * @param supplierFaxData the supplierFaxData
     */
    public void setSupplierFaxData(String supplierFaxData) {
        this.supplierFaxData = supplierFaxData;
    }

    /** 
     * Returns the pono.
     * 
     * @return the pono
     */
    public String getPono() {
        return pono;
    }

    /** 
     * Sets the pono.
     * 
     * @param pono the pono
     */
    public void setPono(String pono) {
        this.pono = pono;
    }

    /** 
     * Returns the orderDate.
     * 
     * @return the orderDate
     */
    public String getOrderDate() {
        return orderDate;
    }

    /** 
     * Sets the orderDate.
     * 
     * @param orderDate the orderDate
     */
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    /** 
     * Returns the currency.
     * 
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /** 
     * Sets the currency.
     * 
     * @param currency the currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /** 
     * Returns the page.
     * 
     * @return the page
     */
    public String getPage() {
        return page;
    }

    /** 
     * Sets the page.
     * 
     * @param page the page
     */
    public void setPage(String page) {
        this.page = page;
    }

    /** 
     * Returns the sn.
     * 
     * @return the sn
     */
    public String getSn() {
        return sn;
    }

    /** 
     * Sets the sn.
     * 
     * @param sn the sn
     */
    public void setSn(String sn) {
        this.sn = sn;
    }

    /** 
     * Returns the description.
     * 
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /** 
     * Sets the description.
     * 
     * @param description the description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /** 
     * Returns the quantity.
     * 
     * @return the quantity
     */
    public String getQuantity() {
        return quantity;
    }

    /** 
     * Sets the quantity.
     * 
     * @param quantity the quantity
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /** 
     * Returns the weight.
     * 
     * @return the weight
     */
    public String getWeight() {
        return weight;
    }

    /** 
     * Sets the weight.
     * 
     * @param weight the weight
     */
    public void setWeight(String weight) {
        this.weight = weight;
    }

    /** 
     * Returns the price.
     * 
     * @return the price
     */
    public String getPrice() {
        return price;
    }

    /** 
     * Sets the price.
     * 
     * @param price the price
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /** 
     * Returns the amount.
     * 
     * @return the amount
     */
    public String getAmount() {
        return amount;
    }

    /** 
     * Sets the amount.
     * 
     * @param amount the amount
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /** 
     * Returns the etaDate.
     * 
     * @return the etaDate
     */
    public String getEtaDate() {
        return etaDate;
    }

    /** 
     * Sets the etaDate.
     * 
     * @param etaDate the etaDate
     */
    public void setEtaDate(String etaDate) {
        this.etaDate = etaDate;
    }

    /** 
     * Returns the total.
     * 
     * @return the total
     */
    public String getTotal() {
        return total;
    }

    /** 
     * Sets the total.
     * 
     * @param total the total
     */
    public void setTotal(String total) {
        this.total = total;
    }

    /** 
     * Returns the deliveryForm.
     * 
     * @return the deliveryForm
     */
    public String getDeliveryForm() {
        return deliveryForm;
    }

    /** 
     * Sets the deliveryForm.
     * 
     * @param deliveryForm the deliveryForm
     */
    public void setDeliveryForm(String deliveryForm) {
        this.deliveryForm = deliveryForm;
    }

    /** 
     * Returns the port.
     * 
     * @return the port
     */
    public String getPort() {
        return port;
    }

    /** 
     * Sets the port.
     * 
     * @param port the port
     */
    public void setPort(String port) {
        this.port = port;
    }

    /** 
     * Returns the payment.
     * 
     * @return the payment
     */
    public String getPayment() {
        return payment;
    }

    /** 
     * Sets the payment.
     * 
     * @param payment the payment
     */
    public void setPayment(String payment) {
        this.payment = payment;
    }

    /** 
     * Returns the footSupplier.
     * 
     * @return the footSupplier
     */
    public String getFootSupplier() {
        return footSupplier;
    }

    /** 
     * Sets the footSupplier.
     * 
     * @param footSupplier the footSupplier
     */
    public void setFootSupplier(String footSupplier) {
        this.footSupplier = footSupplier;
    }

    /** 
     * Returns the purchaseManager.
     * 
     * @return the purchaseManager
     */
    public String getPurchaseManager() {
        return purchaseManager;
    }

    /** 
     * Sets the purchaseManager.
     * 
     * @param purchaseManager the purchaseManager
     */
    public void setPurchaseManager(String purchaseManager) {
        this.purchaseManager = purchaseManager;
    }

    /** 
     * Returns the signature.
     * 
     * @return the signature
     */
    public String getSignature() {
        return signature;
    }

    /** 
     * Sets the signature.
     * 
     * @param signature the signature
     */
    public void setSignature(String signature) {
        this.signature = signature;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }

    /** 
     * Returns the signFile1.
     * 
     * @return the signFile1
     */
    public String getSignFile1() {
        return signFile1;
    }

    /** 
     * Sets the signFile1.
     * 
     * @param signFile1 the signFile1
     */
    public void setSignFile1(String signFile1) {
        this.signFile1 = signFile1;
    }

    /** 
     * Returns the signFile2.
     * 
     * @return the signFile2
     */
    public String getSignFile2() {
        return signFile2;
    }

    /** 
     * Sets the signFile2.
     * 
     * @param signFile2 the signFile2
     */
    public void setSignFile2(String signFile2) {
        this.signFile2 = signFile2;
    }

    /** 
     * Returns the trade.
     * 
     * @return the trade
     */
    public String getTrade() {
        return trade;
    }

    /** 
     * Sets the trade.
     * 
     * @param trade the trade
     */
    public void setTrade(String trade) {
        this.trade = trade;
    }

    /** 
     * Returns the isono.
     * 
     * @return the isono
     */
    public String getIsono() {
        return isono;
    }

    /** 
     * Sets the isono.
     * 
     * @param isono the isono
     */
    public void setIsono(String isono) {
        this.isono = isono;
    }

    /** 
     * Returns the isonoData.
     * 
     * @return the isonoData
     */
    public String getIsonoData() {
        return isonoData;
    }

    /** 
     * Sets the isonoData.
     * 
     * @param isonoData the isonoData
     */
    public void setIsonoData(String isonoData) {
        this.isonoData = isonoData;
    }
}