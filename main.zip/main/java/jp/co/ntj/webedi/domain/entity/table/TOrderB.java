package jp.co.ntj.webedi.domain.entity.table;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 発注ボディ情報
 */
@Entity(listener = TOrderBListener.class)
@Table(name = "T_ORDER_B")
public class TOrderB {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** Web注文番号 */
    @Id
    @Column(name = "ORDERNO")
    Long orderno;

    /** Web注文行番号 */
    @Id
    @Column(name = "ORDER_LINE")
    Short orderLine;

    /** 商品コード */
    @Column(name = "SHOHINCD")
    String shohincd;

    /** 商品略名コード */
    @Column(name = "SHOHIN_RYAK_CD")
    String shohinRyakCd;

    /** 商品名 */
    @Column(name = "SHOHIN_NM")
    String shohinNm;

    /** 商品分類－大分類コード */
    @Column(name = "LAG_BUNCD")
    String lagBuncd;

    /** 商品分類－中分類コード */
    @Column(name = "MID_BUNCD")
    String midBuncd;

    /** 商品分類－小分類コード１ */
    @Column(name = "SML_BUNCD1")
    String smlBuncd1;

    /** 入目重量 */
    @Column(name = "RIME_SURYO")
    BigDecimal rimeSuryo;

    /** 入目単位コード */
    @Column(name = "IRIME_TANI_CD")
    Short irimeTaniCd;

    /** 入目単位名 */
    @Column(name = "IRIME_TANI_NM")
    String irimeTaniNm;

    /** 梱包単位コード */
    @Column(name = "KONPO_NICD")
    String konpoNicd;

    /** 梱包単位名 */
    @Column(name = "KONPO_TANI_NM")
    String konpoTaniNm;

    /** ユニット単価 */
    @Column(name = "UNIT_TANKA")
    BigDecimal unitTanka;

    /** ユニット単位コード */
    @Column(name = "UNIT_TANICD")
    Short unitTanicd;

    /** ユニット単位名 */
    @Column(name = "UNIT_TANI_NM")
    String unitTaniNm;

    /** 売単価 */
    @Column(name = "SELL_TANKA")
    BigDecimal sellTanka;

    /** 入目売単価－ＫＧ売単価 */
    @Column(name = "IRIME_SELL_TANKA")
    BigDecimal irimeSellTanka;

    /** 数量 */
    @Column(name = "SURYO")
    BigDecimal suryo;

    /** 合計数量 */
    @Column(name = "SUM_SURYO")
    BigDecimal sumSuryo;

    /** 合計額 */
    @Column(name = "SUM_GAKU")
    BigDecimal sumGaku;

    /** 希望納期 */
    @Column(name = "NOUKI")
    String nouki;

    /** 登録日付時刻 */
    @Column(name = "ENTRY_DATE")
    LocalDate entryDate;

    /** 更新日付時刻 */
    @Column(name = "UPDATE_DATE")
    LocalDate updateDate;

    /** 基幹取消フラグ */
    @Column(name = "K_DELETE_FLG")
    Short kDeleteFlg;

    /** 基幹取消日 */
    @Column(name = "K_DELETE_DATE")
    String kDeleteDate;

    /** 基幹修正フラグ */
    @Column(name = "K_UPDATE_FLG")
    Short kUpdateFlg;

    /** 基幹修正日 */
    @Column(name = "K_UPDATE_DATE")
    String kUpdateDate;

    /** 基幹修正後売単価 */
    @Column(name = "K_SELL_TANKA")
    BigDecimal kSellTanka;

    /** 基幹修正後数量 */
    @Column(name = "K_SURYO")
    BigDecimal kSuryo;

    /** 基幹修正後合計数量 */
    @Column(name = "K_SUM_SURYO")
    BigDecimal kSumSuryo;

    /** 基幹修正後合計額 */
    @Column(name = "K_SUM_GAKU")
    BigDecimal kSumGaku;

    /** 基幹修正後希望納期 */
    @Column(name = "K_NOUKI")
    String kNouki;

    /** 回答納期 */
    @Column(name = "K_ANS_NOUKI")
    String kAnsNouki;

    /** 船積期限 */
    @Column(name = "SHIP_KIGEN")
    String shipKigen;

    /** 排他フラグ */
    @Column(name = "EXCLUSIVE_FLG")
    Short exclusiveFlg;

    /** 基幹修正後商品名 */
    @Column(name = "K_SHOHIN_NM")
    String kShohinNm;

    /** 基幹修正後梱包単位名 */
    @Column(name = "K_KONPO_TANI_NM")
    String kKonpoTaniNm;

    /** WEBキャンセルフラグ */
    @Column(name = "WEB_CANSEL_FLG")
    Short webCanselFlg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the orderno.
     * 
     * @return the orderno
     */
    public Long getOrderno() {
        return orderno;
    }

    /** 
     * Sets the orderno.
     * 
     * @param orderno the orderno
     */
    public void setOrderno(Long orderno) {
        this.orderno = orderno;
    }

    /** 
     * Returns the orderLine.
     * 
     * @return the orderLine
     */
    public Short getOrderLine() {
        return orderLine;
    }

    /** 
     * Sets the orderLine.
     * 
     * @param orderLine the orderLine
     */
    public void setOrderLine(Short orderLine) {
        this.orderLine = orderLine;
    }

    /** 
     * Returns the shohincd.
     * 
     * @return the shohincd
     */
    public String getShohincd() {
        return shohincd;
    }

    /** 
     * Sets the shohincd.
     * 
     * @param shohincd the shohincd
     */
    public void setShohincd(String shohincd) {
        this.shohincd = shohincd;
    }

    /** 
     * Returns the shohinRyakCd.
     * 
     * @return the shohinRyakCd
     */
    public String getShohinRyakCd() {
        return shohinRyakCd;
    }

    /** 
     * Sets the shohinRyakCd.
     * 
     * @param shohinRyakCd the shohinRyakCd
     */
    public void setShohinRyakCd(String shohinRyakCd) {
        this.shohinRyakCd = shohinRyakCd;
    }

    /** 
     * Returns the shohinNm.
     * 
     * @return the shohinNm
     */
    public String getShohinNm() {
        return shohinNm;
    }

    /** 
     * Sets the shohinNm.
     * 
     * @param shohinNm the shohinNm
     */
    public void setShohinNm(String shohinNm) {
        this.shohinNm = shohinNm;
    }

    /** 
     * Returns the lagBuncd.
     * 
     * @return the lagBuncd
     */
    public String getLagBuncd() {
        return lagBuncd;
    }

    /** 
     * Sets the lagBuncd.
     * 
     * @param lagBuncd the lagBuncd
     */
    public void setLagBuncd(String lagBuncd) {
        this.lagBuncd = lagBuncd;
    }

    /** 
     * Returns the midBuncd.
     * 
     * @return the midBuncd
     */
    public String getMidBuncd() {
        return midBuncd;
    }

    /** 
     * Sets the midBuncd.
     * 
     * @param midBuncd the midBuncd
     */
    public void setMidBuncd(String midBuncd) {
        this.midBuncd = midBuncd;
    }

    /** 
     * Returns the smlBuncd1.
     * 
     * @return the smlBuncd1
     */
    public String getSmlBuncd1() {
        return smlBuncd1;
    }

    /** 
     * Sets the smlBuncd1.
     * 
     * @param smlBuncd1 the smlBuncd1
     */
    public void setSmlBuncd1(String smlBuncd1) {
        this.smlBuncd1 = smlBuncd1;
    }

    /** 
     * Returns the rimeSuryo.
     * 
     * @return the rimeSuryo
     */
    public BigDecimal getRimeSuryo() {
        return rimeSuryo;
    }

    /** 
     * Sets the rimeSuryo.
     * 
     * @param rimeSuryo the rimeSuryo
     */
    public void setRimeSuryo(BigDecimal rimeSuryo) {
        this.rimeSuryo = rimeSuryo;
    }

    /** 
     * Returns the irimeTaniCd.
     * 
     * @return the irimeTaniCd
     */
    public Short getIrimeTaniCd() {
        return irimeTaniCd;
    }

    /** 
     * Sets the irimeTaniCd.
     * 
     * @param irimeTaniCd the irimeTaniCd
     */
    public void setIrimeTaniCd(Short irimeTaniCd) {
        this.irimeTaniCd = irimeTaniCd;
    }

    /** 
     * Returns the irimeTaniNm.
     * 
     * @return the irimeTaniNm
     */
    public String getIrimeTaniNm() {
        return irimeTaniNm;
    }

    /** 
     * Sets the irimeTaniNm.
     * 
     * @param irimeTaniNm the irimeTaniNm
     */
    public void setIrimeTaniNm(String irimeTaniNm) {
        this.irimeTaniNm = irimeTaniNm;
    }

    /** 
     * Returns the konpoNicd.
     * 
     * @return the konpoNicd
     */
    public String getKonpoNicd() {
        return konpoNicd;
    }

    /** 
     * Sets the konpoNicd.
     * 
     * @param konpoNicd the konpoNicd
     */
    public void setKonpoNicd(String konpoNicd) {
        this.konpoNicd = konpoNicd;
    }

    /** 
     * Returns the konpoTaniNm.
     * 
     * @return the konpoTaniNm
     */
    public String getKonpoTaniNm() {
        return konpoTaniNm;
    }

    /** 
     * Sets the konpoTaniNm.
     * 
     * @param konpoTaniNm the konpoTaniNm
     */
    public void setKonpoTaniNm(String konpoTaniNm) {
        this.konpoTaniNm = konpoTaniNm;
    }

    /** 
     * Returns the unitTanka.
     * 
     * @return the unitTanka
     */
    public BigDecimal getUnitTanka() {
        return unitTanka;
    }

    /** 
     * Sets the unitTanka.
     * 
     * @param unitTanka the unitTanka
     */
    public void setUnitTanka(BigDecimal unitTanka) {
        this.unitTanka = unitTanka;
    }

    /** 
     * Returns the unitTanicd.
     * 
     * @return the unitTanicd
     */
    public Short getUnitTanicd() {
        return unitTanicd;
    }

    /** 
     * Sets the unitTanicd.
     * 
     * @param unitTanicd the unitTanicd
     */
    public void setUnitTanicd(Short unitTanicd) {
        this.unitTanicd = unitTanicd;
    }

    /** 
     * Returns the unitTaniNm.
     * 
     * @return the unitTaniNm
     */
    public String getUnitTaniNm() {
        return unitTaniNm;
    }

    /** 
     * Sets the unitTaniNm.
     * 
     * @param unitTaniNm the unitTaniNm
     */
    public void setUnitTaniNm(String unitTaniNm) {
        this.unitTaniNm = unitTaniNm;
    }

    /** 
     * Returns the sellTanka.
     * 
     * @return the sellTanka
     */
    public BigDecimal getSellTanka() {
        return sellTanka;
    }

    /** 
     * Sets the sellTanka.
     * 
     * @param sellTanka the sellTanka
     */
    public void setSellTanka(BigDecimal sellTanka) {
        this.sellTanka = sellTanka;
    }

    /** 
     * Returns the irimeSellTanka.
     * 
     * @return the irimeSellTanka
     */
    public BigDecimal getIrimeSellTanka() {
        return irimeSellTanka;
    }

    /** 
     * Sets the irimeSellTanka.
     * 
     * @param irimeSellTanka the irimeSellTanka
     */
    public void setIrimeSellTanka(BigDecimal irimeSellTanka) {
        this.irimeSellTanka = irimeSellTanka;
    }

    /** 
     * Returns the suryo.
     * 
     * @return the suryo
     */
    public BigDecimal getSuryo() {
        return suryo;
    }

    /** 
     * Sets the suryo.
     * 
     * @param suryo the suryo
     */
    public void setSuryo(BigDecimal suryo) {
        this.suryo = suryo;
    }

    /** 
     * Returns the sumSuryo.
     * 
     * @return the sumSuryo
     */
    public BigDecimal getSumSuryo() {
        return sumSuryo;
    }

    /** 
     * Sets the sumSuryo.
     * 
     * @param sumSuryo the sumSuryo
     */
    public void setSumSuryo(BigDecimal sumSuryo) {
        this.sumSuryo = sumSuryo;
    }

    /** 
     * Returns the sumGaku.
     * 
     * @return the sumGaku
     */
    public BigDecimal getSumGaku() {
        return sumGaku;
    }

    /** 
     * Sets the sumGaku.
     * 
     * @param sumGaku the sumGaku
     */
    public void setSumGaku(BigDecimal sumGaku) {
        this.sumGaku = sumGaku;
    }

    /** 
     * Returns the nouki.
     * 
     * @return the nouki
     */
    public String getNouki() {
        return nouki;
    }

    /** 
     * Sets the nouki.
     * 
     * @param nouki the nouki
     */
    public void setNouki(String nouki) {
        this.nouki = nouki;
    }

    /** 
     * Returns the entryDate.
     * 
     * @return the entryDate
     */
    public LocalDate getEntryDate() {
        return entryDate;
    }

    /** 
     * Sets the entryDate.
     * 
     * @param entryDate the entryDate
     */
    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    /** 
     * Returns the updateDate.
     * 
     * @return the updateDate
     */
    public LocalDate getUpdateDate() {
        return updateDate;
    }

    /** 
     * Sets the updateDate.
     * 
     * @param updateDate the updateDate
     */
    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    /** 
     * Returns the kDeleteFlg.
     * 
     * @return the kDeleteFlg
     */
    public Short getKDeleteFlg() {
        return kDeleteFlg;
    }

    /** 
     * Sets the kDeleteFlg.
     * 
     * @param kDeleteFlg the kDeleteFlg
     */
    public void setKDeleteFlg(Short kDeleteFlg) {
        this.kDeleteFlg = kDeleteFlg;
    }

    /** 
     * Returns the kDeleteDate.
     * 
     * @return the kDeleteDate
     */
    public String getKDeleteDate() {
        return kDeleteDate;
    }

    /** 
     * Sets the kDeleteDate.
     * 
     * @param kDeleteDate the kDeleteDate
     */
    public void setKDeleteDate(String kDeleteDate) {
        this.kDeleteDate = kDeleteDate;
    }

    /** 
     * Returns the kUpdateFlg.
     * 
     * @return the kUpdateFlg
     */
    public Short getKUpdateFlg() {
        return kUpdateFlg;
    }

    /** 
     * Sets the kUpdateFlg.
     * 
     * @param kUpdateFlg the kUpdateFlg
     */
    public void setKUpdateFlg(Short kUpdateFlg) {
        this.kUpdateFlg = kUpdateFlg;
    }

    /** 
     * Returns the kUpdateDate.
     * 
     * @return the kUpdateDate
     */
    public String getKUpdateDate() {
        return kUpdateDate;
    }

    /** 
     * Sets the kUpdateDate.
     * 
     * @param kUpdateDate the kUpdateDate
     */
    public void setKUpdateDate(String kUpdateDate) {
        this.kUpdateDate = kUpdateDate;
    }

    /** 
     * Returns the kSellTanka.
     * 
     * @return the kSellTanka
     */
    public BigDecimal getKSellTanka() {
        return kSellTanka;
    }

    /** 
     * Sets the kSellTanka.
     * 
     * @param kSellTanka the kSellTanka
     */
    public void setKSellTanka(BigDecimal kSellTanka) {
        this.kSellTanka = kSellTanka;
    }

    /** 
     * Returns the kSuryo.
     * 
     * @return the kSuryo
     */
    public BigDecimal getKSuryo() {
        return kSuryo;
    }

    /** 
     * Sets the kSuryo.
     * 
     * @param kSuryo the kSuryo
     */
    public void setKSuryo(BigDecimal kSuryo) {
        this.kSuryo = kSuryo;
    }

    /** 
     * Returns the kSumSuryo.
     * 
     * @return the kSumSuryo
     */
    public BigDecimal getKSumSuryo() {
        return kSumSuryo;
    }

    /** 
     * Sets the kSumSuryo.
     * 
     * @param kSumSuryo the kSumSuryo
     */
    public void setKSumSuryo(BigDecimal kSumSuryo) {
        this.kSumSuryo = kSumSuryo;
    }

    /** 
     * Returns the kSumGaku.
     * 
     * @return the kSumGaku
     */
    public BigDecimal getKSumGaku() {
        return kSumGaku;
    }

    /** 
     * Sets the kSumGaku.
     * 
     * @param kSumGaku the kSumGaku
     */
    public void setKSumGaku(BigDecimal kSumGaku) {
        this.kSumGaku = kSumGaku;
    }

    /** 
     * Returns the kNouki.
     * 
     * @return the kNouki
     */
    public String getKNouki() {
        return kNouki;
    }

    /** 
     * Sets the kNouki.
     * 
     * @param kNouki the kNouki
     */
    public void setKNouki(String kNouki) {
        this.kNouki = kNouki;
    }

    /** 
     * Returns the kAnsNouki.
     * 
     * @return the kAnsNouki
     */
    public String getKAnsNouki() {
        return kAnsNouki;
    }

    /** 
     * Sets the kAnsNouki.
     * 
     * @param kAnsNouki the kAnsNouki
     */
    public void setKAnsNouki(String kAnsNouki) {
        this.kAnsNouki = kAnsNouki;
    }

    /** 
     * Returns the shipKigen.
     * 
     * @return the shipKigen
     */
    public String getShipKigen() {
        return shipKigen;
    }

    /** 
     * Sets the shipKigen.
     * 
     * @param shipKigen the shipKigen
     */
    public void setShipKigen(String shipKigen) {
        this.shipKigen = shipKigen;
    }

    /** 
     * Returns the exclusiveFlg.
     * 
     * @return the exclusiveFlg
     */
    public Short getExclusiveFlg() {
        return exclusiveFlg;
    }

    /** 
     * Sets the exclusiveFlg.
     * 
     * @param exclusiveFlg the exclusiveFlg
     */
    public void setExclusiveFlg(Short exclusiveFlg) {
        this.exclusiveFlg = exclusiveFlg;
    }

    /** 
     * Returns the kShohinNm.
     * 
     * @return the kShohinNm
     */
    public String getKShohinNm() {
        return kShohinNm;
    }

    /** 
     * Sets the kShohinNm.
     * 
     * @param kShohinNm the kShohinNm
     */
    public void setKShohinNm(String kShohinNm) {
        this.kShohinNm = kShohinNm;
    }

    /** 
     * Returns the kKonpoTaniNm.
     * 
     * @return the kKonpoTaniNm
     */
    public String getKKonpoTaniNm() {
        return kKonpoTaniNm;
    }

    /** 
     * Sets the kKonpoTaniNm.
     * 
     * @param kKonpoTaniNm the kKonpoTaniNm
     */
    public void setKKonpoTaniNm(String kKonpoTaniNm) {
        this.kKonpoTaniNm = kKonpoTaniNm;
    }

    /** 
     * Returns the webCanselFlg.
     * 
     * @return the webCanselFlg
     */
    public Short getWebCanselFlg() {
        return webCanselFlg;
    }

    /** 
     * Sets the webCanselFlg.
     * 
     * @param webCanselFlg the webCanselFlg
     */
    public void setWebCanselFlg(Short webCanselFlg) {
        this.webCanselFlg = webCanselFlg;
    }
}