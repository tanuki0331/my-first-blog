package jp.co.ntj.webedi.domain.entity.table;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 仕向先マスタ
 */
@Entity(listener = MShimuListener.class)
@Table(name = "M_SHIMU")
public class MShimu {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 仕向先コード */
    @Id
    @Column(name = "SHIMUKECD")
    Long shimukecd;

    /** 得意先コード */
    @Id
    @Column(name = "TOKUCD")
    Long tokucd;

    /** 商社コード */
    @Column(name = "SHOSHACD")
    Integer shoshacd;

    /** 社名識別コード */
    @Column(name = "SHA_SIKIBETCD")
    String shaSikibetcd;

    /** 社名略称 */
    @Column(name = "SHA_RYAK")
    String shaRyak;

    /** 社名カナ */
    @Column(name = "SHA_KANA")
    String shaKana;

    /** 電話番号 */
    @Column(name = "TELNO")
    String telno;

    /** ＦＡＸ番号 */
    @Column(name = "FAXNO")
    String faxno;

    /** 郵便番号 */
    @Column(name = "YUBIN_NO")
    String yubinNo;

    /** 社名１ */
    @Column(name = "SHA_NM1")
    String shaNm1;

    /** 社名２ */
    @Column(name = "SHA_NM2")
    String shaNm2;

    /** 住所１ */
    @Column(name = "ADR1")
    String adr1;

    /** 住所２ */
    @Column(name = "ADR2")
    String adr2;

    /** 住所３ */
    @Column(name = "ADR3")
    String adr3;

    /** 部署名 */
    @Column(name = "BUSHO_NM")
    String bushoNm;

    /** 代表者名 */
    @Column(name = "DAIHYO_NM")
    String daihyoNm;

    /** 国籍コード */
    @Column(name = "KUNICD")
    Short kunicd;

    /** 都道府県コード */
    @Column(name = "KENCD")
    Short kencd;

    /** 仕向先マージン率 */
    @Column(name = "SHIM_MARGIN")
    BigDecimal shimMargin;

    /** 標準契約条件コード */
    @Column(name = "HYJN_KEI_JYOKENCD")
    Short hyjnKeiJyokencd;

    /** 標準価格条件コード */
    @Column(name = "HYJN_KAK_JYOKENCD")
    Short hyjnKakJyokencd;

    /** 輸送期間 */
    @Column(name = "YUSO_KIKAN")
    Short yusoKikan;

    /** 円換算レート */
    @Column(name = "EN_RATE")
    BigDecimal enRate;

    /** 取引関連コード */
    @Column(name = "TORI_KANRNCD")
    Short toriKanrncd;

    /** ＨＫ経由区分 */
    @Column(name = "HK_KEYU_KBN")
    Short hkKeyuKbn;

    /** 需要家コード */
    @Column(name = "JUYOKACD")
    String juyokacd;

    /** 最終取引年月日 */
    @Column(name = "LAST_TORI_DATE")
    String lastToriDate;

    /** 標準支払条件コード */
    @Column(name = "HYJN_SHI_JYOKENCD")
    Short hyjnShiJyokencd;

    /** 標準建値コード */
    @Column(name = "HYJN_TATENECD")
    String hyjnTatenecd;

    /** 金利基準値 */
    @Column(name = "KINRI_KIJUN")
    BigDecimal kinriKijun;

    /** ＳＰＭＫパターンコード */
    @Column(name = "SPMK_PATRNCD")
    BigDecimal spmkPatrncd;

    /** 保険アップ率 */
    @Column(name = "HOKEN_UPRITU")
    Short hokenUpritu;

    /** 仕向地港コード */
    @Column(name = "SHIM_PORTCD")
    Short shimPortcd;

    /** 仕向地空港コード */
    @Column(name = "SHIM_AIRPORTCD")
    Short shimAirportcd;

    /** 商社仕向先コード */
    @Column(name = "SHOSHA_SHIMCD")
    Integer shoshaShimcd;

    /** 商社仕向先枝番 */
    @Column(name = "SHOSHA_SHIM_SEQ")
    Integer shoshaShimSeq;

    /** ＵＮＮＯ区分 */
    @Column(name = "UNNO_KBN")
    Short unnoKbn;

    /** ＨＳＮＯ区分 */
    @Column(name = "HSNO_KBN")
    Short hsnoKbn;

    /** ＬＯＴＮＯ区分 */
    @Column(name = "LOTNO_KBN")
    Short lotnoKbn;

    /** オーダＮＯ区分 */
    @Column(name = "ORDERNO_KBN")
    Short ordernoKbn;

    /** ＰＰＧコード区分 */
    @Column(name = "PPGCD_KBN")
    Short ppgcdKbn;

    /** フラッシュＰＮＴ区分 */
    @Column(name = "FLASH_PNT_KBN")
    Short flashPntKbn;

    /** 管理分類コード１ */
    @Column(name = "KANR_BUNCD1")
    Long kanrBuncd1;

    /** 管理分類コード２ */
    @Column(name = "KANR_BUNCD2")
    Long kanrBuncd2;

    /** 管理分類コード３ */
    @Column(name = "KANR_BUNCD3")
    Long kanrBuncd3;

    /** 管理分類コード４ */
    @Column(name = "KANR_BUNCD4")
    Long kanrBuncd4;

    /** 管理分類コード５ */
    @Column(name = "KANR_BUNCD5")
    Long kanrBuncd5;

    /** 営業担当者コード */
    @Column(name = "EIGYO_TANTOCD")
    Long eigyoTantocd;

    /** 業務担当者コード */
    @Column(name = "GYOMU_TANTOCD")
    Long gyomuTantocd;

    /** 単価改定番号 */
    @Column(name = "TAN_KAITEI_NO")
    Integer tanKaiteiNo;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Long hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the shimukecd.
     * 
     * @return the shimukecd
     */
    public Long getShimukecd() {
        return shimukecd;
    }

    /** 
     * Sets the shimukecd.
     * 
     * @param shimukecd the shimukecd
     */
    public void setShimukecd(Long shimukecd) {
        this.shimukecd = shimukecd;
    }

    /** 
     * Returns the tokucd.
     * 
     * @return the tokucd
     */
    public Long getTokucd() {
        return tokucd;
    }

    /** 
     * Sets the tokucd.
     * 
     * @param tokucd the tokucd
     */
    public void setTokucd(Long tokucd) {
        this.tokucd = tokucd;
    }

    /** 
     * Returns the shoshacd.
     * 
     * @return the shoshacd
     */
    public Integer getShoshacd() {
        return shoshacd;
    }

    /** 
     * Sets the shoshacd.
     * 
     * @param shoshacd the shoshacd
     */
    public void setShoshacd(Integer shoshacd) {
        this.shoshacd = shoshacd;
    }

    /** 
     * Returns the shaSikibetcd.
     * 
     * @return the shaSikibetcd
     */
    public String getShaSikibetcd() {
        return shaSikibetcd;
    }

    /** 
     * Sets the shaSikibetcd.
     * 
     * @param shaSikibetcd the shaSikibetcd
     */
    public void setShaSikibetcd(String shaSikibetcd) {
        this.shaSikibetcd = shaSikibetcd;
    }

    /** 
     * Returns the shaRyak.
     * 
     * @return the shaRyak
     */
    public String getShaRyak() {
        return shaRyak;
    }

    /** 
     * Sets the shaRyak.
     * 
     * @param shaRyak the shaRyak
     */
    public void setShaRyak(String shaRyak) {
        this.shaRyak = shaRyak;
    }

    /** 
     * Returns the shaKana.
     * 
     * @return the shaKana
     */
    public String getShaKana() {
        return shaKana;
    }

    /** 
     * Sets the shaKana.
     * 
     * @param shaKana the shaKana
     */
    public void setShaKana(String shaKana) {
        this.shaKana = shaKana;
    }

    /** 
     * Returns the telno.
     * 
     * @return the telno
     */
    public String getTelno() {
        return telno;
    }

    /** 
     * Sets the telno.
     * 
     * @param telno the telno
     */
    public void setTelno(String telno) {
        this.telno = telno;
    }

    /** 
     * Returns the faxno.
     * 
     * @return the faxno
     */
    public String getFaxno() {
        return faxno;
    }

    /** 
     * Sets the faxno.
     * 
     * @param faxno the faxno
     */
    public void setFaxno(String faxno) {
        this.faxno = faxno;
    }

    /** 
     * Returns the yubinNo.
     * 
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /** 
     * Sets the yubinNo.
     * 
     * @param yubinNo the yubinNo
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /** 
     * Returns the shaNm1.
     * 
     * @return the shaNm1
     */
    public String getShaNm1() {
        return shaNm1;
    }

    /** 
     * Sets the shaNm1.
     * 
     * @param shaNm1 the shaNm1
     */
    public void setShaNm1(String shaNm1) {
        this.shaNm1 = shaNm1;
    }

    /** 
     * Returns the shaNm2.
     * 
     * @return the shaNm2
     */
    public String getShaNm2() {
        return shaNm2;
    }

    /** 
     * Sets the shaNm2.
     * 
     * @param shaNm2 the shaNm2
     */
    public void setShaNm2(String shaNm2) {
        this.shaNm2 = shaNm2;
    }

    /** 
     * Returns the adr1.
     * 
     * @return the adr1
     */
    public String getAdr1() {
        return adr1;
    }

    /** 
     * Sets the adr1.
     * 
     * @param adr1 the adr1
     */
    public void setAdr1(String adr1) {
        this.adr1 = adr1;
    }

    /** 
     * Returns the adr2.
     * 
     * @return the adr2
     */
    public String getAdr2() {
        return adr2;
    }

    /** 
     * Sets the adr2.
     * 
     * @param adr2 the adr2
     */
    public void setAdr2(String adr2) {
        this.adr2 = adr2;
    }

    /** 
     * Returns the adr3.
     * 
     * @return the adr3
     */
    public String getAdr3() {
        return adr3;
    }

    /** 
     * Sets the adr3.
     * 
     * @param adr3 the adr3
     */
    public void setAdr3(String adr3) {
        this.adr3 = adr3;
    }

    /** 
     * Returns the bushoNm.
     * 
     * @return the bushoNm
     */
    public String getBushoNm() {
        return bushoNm;
    }

    /** 
     * Sets the bushoNm.
     * 
     * @param bushoNm the bushoNm
     */
    public void setBushoNm(String bushoNm) {
        this.bushoNm = bushoNm;
    }

    /** 
     * Returns the daihyoNm.
     * 
     * @return the daihyoNm
     */
    public String getDaihyoNm() {
        return daihyoNm;
    }

    /** 
     * Sets the daihyoNm.
     * 
     * @param daihyoNm the daihyoNm
     */
    public void setDaihyoNm(String daihyoNm) {
        this.daihyoNm = daihyoNm;
    }

    /** 
     * Returns the kunicd.
     * 
     * @return the kunicd
     */
    public Short getKunicd() {
        return kunicd;
    }

    /** 
     * Sets the kunicd.
     * 
     * @param kunicd the kunicd
     */
    public void setKunicd(Short kunicd) {
        this.kunicd = kunicd;
    }

    /** 
     * Returns the kencd.
     * 
     * @return the kencd
     */
    public Short getKencd() {
        return kencd;
    }

    /** 
     * Sets the kencd.
     * 
     * @param kencd the kencd
     */
    public void setKencd(Short kencd) {
        this.kencd = kencd;
    }

    /** 
     * Returns the shimMargin.
     * 
     * @return the shimMargin
     */
    public BigDecimal getShimMargin() {
        return shimMargin;
    }

    /** 
     * Sets the shimMargin.
     * 
     * @param shimMargin the shimMargin
     */
    public void setShimMargin(BigDecimal shimMargin) {
        this.shimMargin = shimMargin;
    }

    /** 
     * Returns the hyjnKeiJyokencd.
     * 
     * @return the hyjnKeiJyokencd
     */
    public Short getHyjnKeiJyokencd() {
        return hyjnKeiJyokencd;
    }

    /** 
     * Sets the hyjnKeiJyokencd.
     * 
     * @param hyjnKeiJyokencd the hyjnKeiJyokencd
     */
    public void setHyjnKeiJyokencd(Short hyjnKeiJyokencd) {
        this.hyjnKeiJyokencd = hyjnKeiJyokencd;
    }

    /** 
     * Returns the hyjnKakJyokencd.
     * 
     * @return the hyjnKakJyokencd
     */
    public Short getHyjnKakJyokencd() {
        return hyjnKakJyokencd;
    }

    /** 
     * Sets the hyjnKakJyokencd.
     * 
     * @param hyjnKakJyokencd the hyjnKakJyokencd
     */
    public void setHyjnKakJyokencd(Short hyjnKakJyokencd) {
        this.hyjnKakJyokencd = hyjnKakJyokencd;
    }

    /** 
     * Returns the yusoKikan.
     * 
     * @return the yusoKikan
     */
    public Short getYusoKikan() {
        return yusoKikan;
    }

    /** 
     * Sets the yusoKikan.
     * 
     * @param yusoKikan the yusoKikan
     */
    public void setYusoKikan(Short yusoKikan) {
        this.yusoKikan = yusoKikan;
    }

    /** 
     * Returns the enRate.
     * 
     * @return the enRate
     */
    public BigDecimal getEnRate() {
        return enRate;
    }

    /** 
     * Sets the enRate.
     * 
     * @param enRate the enRate
     */
    public void setEnRate(BigDecimal enRate) {
        this.enRate = enRate;
    }

    /** 
     * Returns the toriKanrncd.
     * 
     * @return the toriKanrncd
     */
    public Short getToriKanrncd() {
        return toriKanrncd;
    }

    /** 
     * Sets the toriKanrncd.
     * 
     * @param toriKanrncd the toriKanrncd
     */
    public void setToriKanrncd(Short toriKanrncd) {
        this.toriKanrncd = toriKanrncd;
    }

    /** 
     * Returns the hkKeyuKbn.
     * 
     * @return the hkKeyuKbn
     */
    public Short getHkKeyuKbn() {
        return hkKeyuKbn;
    }

    /** 
     * Sets the hkKeyuKbn.
     * 
     * @param hkKeyuKbn the hkKeyuKbn
     */
    public void setHkKeyuKbn(Short hkKeyuKbn) {
        this.hkKeyuKbn = hkKeyuKbn;
    }

    /** 
     * Returns the juyokacd.
     * 
     * @return the juyokacd
     */
    public String getJuyokacd() {
        return juyokacd;
    }

    /** 
     * Sets the juyokacd.
     * 
     * @param juyokacd the juyokacd
     */
    public void setJuyokacd(String juyokacd) {
        this.juyokacd = juyokacd;
    }

    /** 
     * Returns the lastToriDate.
     * 
     * @return the lastToriDate
     */
    public String getLastToriDate() {
        return lastToriDate;
    }

    /** 
     * Sets the lastToriDate.
     * 
     * @param lastToriDate the lastToriDate
     */
    public void setLastToriDate(String lastToriDate) {
        this.lastToriDate = lastToriDate;
    }

    /** 
     * Returns the hyjnShiJyokencd.
     * 
     * @return the hyjnShiJyokencd
     */
    public Short getHyjnShiJyokencd() {
        return hyjnShiJyokencd;
    }

    /** 
     * Sets the hyjnShiJyokencd.
     * 
     * @param hyjnShiJyokencd the hyjnShiJyokencd
     */
    public void setHyjnShiJyokencd(Short hyjnShiJyokencd) {
        this.hyjnShiJyokencd = hyjnShiJyokencd;
    }

    /** 
     * Returns the hyjnTatenecd.
     * 
     * @return the hyjnTatenecd
     */
    public String getHyjnTatenecd() {
        return hyjnTatenecd;
    }

    /** 
     * Sets the hyjnTatenecd.
     * 
     * @param hyjnTatenecd the hyjnTatenecd
     */
    public void setHyjnTatenecd(String hyjnTatenecd) {
        this.hyjnTatenecd = hyjnTatenecd;
    }

    /** 
     * Returns the kinriKijun.
     * 
     * @return the kinriKijun
     */
    public BigDecimal getKinriKijun() {
        return kinriKijun;
    }

    /** 
     * Sets the kinriKijun.
     * 
     * @param kinriKijun the kinriKijun
     */
    public void setKinriKijun(BigDecimal kinriKijun) {
        this.kinriKijun = kinriKijun;
    }

    /** 
     * Returns the spmkPatrncd.
     * 
     * @return the spmkPatrncd
     */
    public BigDecimal getSpmkPatrncd() {
        return spmkPatrncd;
    }

    /** 
     * Sets the spmkPatrncd.
     * 
     * @param spmkPatrncd the spmkPatrncd
     */
    public void setSpmkPatrncd(BigDecimal spmkPatrncd) {
        this.spmkPatrncd = spmkPatrncd;
    }

    /** 
     * Returns the hokenUpritu.
     * 
     * @return the hokenUpritu
     */
    public Short getHokenUpritu() {
        return hokenUpritu;
    }

    /** 
     * Sets the hokenUpritu.
     * 
     * @param hokenUpritu the hokenUpritu
     */
    public void setHokenUpritu(Short hokenUpritu) {
        this.hokenUpritu = hokenUpritu;
    }

    /** 
     * Returns the shimPortcd.
     * 
     * @return the shimPortcd
     */
    public Short getShimPortcd() {
        return shimPortcd;
    }

    /** 
     * Sets the shimPortcd.
     * 
     * @param shimPortcd the shimPortcd
     */
    public void setShimPortcd(Short shimPortcd) {
        this.shimPortcd = shimPortcd;
    }

    /** 
     * Returns the shimAirportcd.
     * 
     * @return the shimAirportcd
     */
    public Short getShimAirportcd() {
        return shimAirportcd;
    }

    /** 
     * Sets the shimAirportcd.
     * 
     * @param shimAirportcd the shimAirportcd
     */
    public void setShimAirportcd(Short shimAirportcd) {
        this.shimAirportcd = shimAirportcd;
    }

    /** 
     * Returns the shoshaShimcd.
     * 
     * @return the shoshaShimcd
     */
    public Integer getShoshaShimcd() {
        return shoshaShimcd;
    }

    /** 
     * Sets the shoshaShimcd.
     * 
     * @param shoshaShimcd the shoshaShimcd
     */
    public void setShoshaShimcd(Integer shoshaShimcd) {
        this.shoshaShimcd = shoshaShimcd;
    }

    /** 
     * Returns the shoshaShimSeq.
     * 
     * @return the shoshaShimSeq
     */
    public Integer getShoshaShimSeq() {
        return shoshaShimSeq;
    }

    /** 
     * Sets the shoshaShimSeq.
     * 
     * @param shoshaShimSeq the shoshaShimSeq
     */
    public void setShoshaShimSeq(Integer shoshaShimSeq) {
        this.shoshaShimSeq = shoshaShimSeq;
    }

    /** 
     * Returns the unnoKbn.
     * 
     * @return the unnoKbn
     */
    public Short getUnnoKbn() {
        return unnoKbn;
    }

    /** 
     * Sets the unnoKbn.
     * 
     * @param unnoKbn the unnoKbn
     */
    public void setUnnoKbn(Short unnoKbn) {
        this.unnoKbn = unnoKbn;
    }

    /** 
     * Returns the hsnoKbn.
     * 
     * @return the hsnoKbn
     */
    public Short getHsnoKbn() {
        return hsnoKbn;
    }

    /** 
     * Sets the hsnoKbn.
     * 
     * @param hsnoKbn the hsnoKbn
     */
    public void setHsnoKbn(Short hsnoKbn) {
        this.hsnoKbn = hsnoKbn;
    }

    /** 
     * Returns the lotnoKbn.
     * 
     * @return the lotnoKbn
     */
    public Short getLotnoKbn() {
        return lotnoKbn;
    }

    /** 
     * Sets the lotnoKbn.
     * 
     * @param lotnoKbn the lotnoKbn
     */
    public void setLotnoKbn(Short lotnoKbn) {
        this.lotnoKbn = lotnoKbn;
    }

    /** 
     * Returns the ordernoKbn.
     * 
     * @return the ordernoKbn
     */
    public Short getOrdernoKbn() {
        return ordernoKbn;
    }

    /** 
     * Sets the ordernoKbn.
     * 
     * @param ordernoKbn the ordernoKbn
     */
    public void setOrdernoKbn(Short ordernoKbn) {
        this.ordernoKbn = ordernoKbn;
    }

    /** 
     * Returns the ppgcdKbn.
     * 
     * @return the ppgcdKbn
     */
    public Short getPpgcdKbn() {
        return ppgcdKbn;
    }

    /** 
     * Sets the ppgcdKbn.
     * 
     * @param ppgcdKbn the ppgcdKbn
     */
    public void setPpgcdKbn(Short ppgcdKbn) {
        this.ppgcdKbn = ppgcdKbn;
    }

    /** 
     * Returns the flashPntKbn.
     * 
     * @return the flashPntKbn
     */
    public Short getFlashPntKbn() {
        return flashPntKbn;
    }

    /** 
     * Sets the flashPntKbn.
     * 
     * @param flashPntKbn the flashPntKbn
     */
    public void setFlashPntKbn(Short flashPntKbn) {
        this.flashPntKbn = flashPntKbn;
    }

    /** 
     * Returns the kanrBuncd1.
     * 
     * @return the kanrBuncd1
     */
    public Long getKanrBuncd1() {
        return kanrBuncd1;
    }

    /** 
     * Sets the kanrBuncd1.
     * 
     * @param kanrBuncd1 the kanrBuncd1
     */
    public void setKanrBuncd1(Long kanrBuncd1) {
        this.kanrBuncd1 = kanrBuncd1;
    }

    /** 
     * Returns the kanrBuncd2.
     * 
     * @return the kanrBuncd2
     */
    public Long getKanrBuncd2() {
        return kanrBuncd2;
    }

    /** 
     * Sets the kanrBuncd2.
     * 
     * @param kanrBuncd2 the kanrBuncd2
     */
    public void setKanrBuncd2(Long kanrBuncd2) {
        this.kanrBuncd2 = kanrBuncd2;
    }

    /** 
     * Returns the kanrBuncd3.
     * 
     * @return the kanrBuncd3
     */
    public Long getKanrBuncd3() {
        return kanrBuncd3;
    }

    /** 
     * Sets the kanrBuncd3.
     * 
     * @param kanrBuncd3 the kanrBuncd3
     */
    public void setKanrBuncd3(Long kanrBuncd3) {
        this.kanrBuncd3 = kanrBuncd3;
    }

    /** 
     * Returns the kanrBuncd4.
     * 
     * @return the kanrBuncd4
     */
    public Long getKanrBuncd4() {
        return kanrBuncd4;
    }

    /** 
     * Sets the kanrBuncd4.
     * 
     * @param kanrBuncd4 the kanrBuncd4
     */
    public void setKanrBuncd4(Long kanrBuncd4) {
        this.kanrBuncd4 = kanrBuncd4;
    }

    /** 
     * Returns the kanrBuncd5.
     * 
     * @return the kanrBuncd5
     */
    public Long getKanrBuncd5() {
        return kanrBuncd5;
    }

    /** 
     * Sets the kanrBuncd5.
     * 
     * @param kanrBuncd5 the kanrBuncd5
     */
    public void setKanrBuncd5(Long kanrBuncd5) {
        this.kanrBuncd5 = kanrBuncd5;
    }

    /** 
     * Returns the eigyoTantocd.
     * 
     * @return the eigyoTantocd
     */
    public Long getEigyoTantocd() {
        return eigyoTantocd;
    }

    /** 
     * Sets the eigyoTantocd.
     * 
     * @param eigyoTantocd the eigyoTantocd
     */
    public void setEigyoTantocd(Long eigyoTantocd) {
        this.eigyoTantocd = eigyoTantocd;
    }

    /** 
     * Returns the gyomuTantocd.
     * 
     * @return the gyomuTantocd
     */
    public Long getGyomuTantocd() {
        return gyomuTantocd;
    }

    /** 
     * Sets the gyomuTantocd.
     * 
     * @param gyomuTantocd the gyomuTantocd
     */
    public void setGyomuTantocd(Long gyomuTantocd) {
        this.gyomuTantocd = gyomuTantocd;
    }

    /** 
     * Returns the tanKaiteiNo.
     * 
     * @return the tanKaiteiNo
     */
    public Integer getTanKaiteiNo() {
        return tanKaiteiNo;
    }

    /** 
     * Sets the tanKaiteiNo.
     * 
     * @param tanKaiteiNo the tanKaiteiNo
     */
    public void setTanKaiteiNo(Integer tanKaiteiNo) {
        this.tanKaiteiNo = tanKaiteiNo;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Long getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Long hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}