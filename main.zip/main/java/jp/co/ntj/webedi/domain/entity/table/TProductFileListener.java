package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class TProductFileListener implements EntityListener<TProductFile> {

    @Override
    public void preInsert(TProductFile entity, PreInsertContext<TProductFile> context) {
    }

    @Override
    public void preUpdate(TProductFile entity, PreUpdateContext<TProductFile> context) {
    }

    @Override
    public void preDelete(TProductFile entity, PreDeleteContext<TProductFile> context) {
    }

    @Override
    public void postInsert(TProductFile entity, PostInsertContext<TProductFile> context) {
    }

    @Override
    public void postUpdate(TProductFile entity, PostUpdateContext<TProductFile> context) {
    }

    @Override
    public void postDelete(TProductFile entity, PostDeleteContext<TProductFile> context) {
    }
}