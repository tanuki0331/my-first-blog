package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.OcDownloadHistory;
import jp.co.ntj.webedi.domain.entity.table.OcReport;
import org.seasar.doma.*;
import org.seasar.doma.boot.ConfigAutowireable;

import java.time.LocalDateTime;
import java.util.List;

/**
 */
@ConfigAutowireable
@Dao
public interface OcDownloadHistoryDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param ocNumber
     * @return the OcDownloadHistory entity
     */
    @Select
    OcDownloadHistory selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String ocNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(OcDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(OcDownloadHistory entity);

    /**
     * 論理削除もしくは存在しない得意先に紐付くデータを論理削除する
     *
     * @param updateUser
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidTokui(String updateUser);

    /**
     * 論理削除もしくは存在しない仕向先／最終仕向け先に紐付くデータを論理削除する
     *
     * @param updateUser
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidShimu(String updateUser);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(OcDownloadHistory entity);

    /**
     * 指定日時以前に作成されたデータを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteBeforeByCreatedAt(LocalDateTime createdAt);

    /**
     * OC帳票に関連するデータについてバッチ削除を行う
     *
     * @param ocReports
     * @return affected rows
     */
    @BatchDelete(sqlFile = true)
    int[] deleteByOcReports(List<OcReport> ocReports);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
