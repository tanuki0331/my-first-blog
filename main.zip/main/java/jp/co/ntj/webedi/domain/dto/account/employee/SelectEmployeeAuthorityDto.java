package jp.co.ntj.webedi.domain.dto.account.employee;

import org.seasar.doma.Entity;

/**
 * 権限検索.
 *
 * @author 日立システムズ
 */
@Entity
public class SelectEmployeeAuthorityDto {

  /**
   * 権限.
   */
  public String authority;
}
