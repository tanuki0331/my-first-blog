package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MTokuiListener implements EntityListener<MTokui> {

    @Override
    public void preInsert(MTokui entity, PreInsertContext<MTokui> context) {
    }

    @Override
    public void preUpdate(MTokui entity, PreUpdateContext<MTokui> context) {
    }

    @Override
    public void preDelete(MTokui entity, PreDeleteContext<MTokui> context) {
    }

    @Override
    public void postInsert(MTokui entity, PostInsertContext<MTokui> context) {
    }

    @Override
    public void postUpdate(MTokui entity, PostUpdateContext<MTokui> context) {
    }

    @Override
    public void postDelete(MTokui entity, PostDeleteContext<MTokui> context) {
    }
}