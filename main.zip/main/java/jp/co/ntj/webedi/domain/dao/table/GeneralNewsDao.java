package jp.co.ntj.webedi.domain.dao.table;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jp.co.ntj.webedi.domain.entity.table.GeneralNews;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 */
@ConfigAutowireable
@Dao
public interface GeneralNewsDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param id
     * @return the GeneralNews entity
     */
    @Select
    GeneralNews selectById(String kaisyaCd, String gengoKbn, BigDecimal id);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(GeneralNews entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(GeneralNews entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(GeneralNews entity);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
