package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.InvReport;
import org.seasar.doma.*;
import org.seasar.doma.boot.ConfigAutowireable;

import java.time.LocalDateTime;
import java.util.List;

/**
 */
@ConfigAutowireable
@Dao
public interface InvReportDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param invNumber
     * @param reportCategory
     * @return the InvReport entity
     */
    @Select
    InvReport selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String invNumber, String reportCategory);

    /**
     * 全件を取得する
     */
    @Select
    List<InvReport> selectAll();

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(InvReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(InvReport entity);

    /**
     * 論理削除もしくは存在しない得意先に紐付くデータを論理削除する
     *
     * @param updateUser
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidTokui(String updateUser);

    /**
     * 論理削除もしくは存在しない仕向先／最終仕向け先に紐付くデータを論理削除する
     *
     * @param updateUser
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidShimu(String updateUser);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(InvReport entity);

    /**
     * 指定日時以前に作成されたデータを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteBeforeByCreatedAt(LocalDateTime createdAt);

    /**
     * バッチ削除を行う
     *
     * @param invReports
     * @return affected rows
     */
    @BatchDelete
    int[] delete(List<InvReport> invReports);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
