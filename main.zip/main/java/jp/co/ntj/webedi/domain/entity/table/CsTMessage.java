package jp.co.ntj.webedi.domain.entity.table;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * メッセージマスタ
 */
@Entity(listener = CsTMessageListener.class)
@Table(name = "CS_T_MESSAGE")
public class CsTMessage {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** メッセージＩＤ */
    @Id
    @Column(name = "MSGID")
    String msgid;

    /** メッセージ区分 */
    @Column(name = "MSGKBN")
    String msgkbn;

    /** メッセージ番号 */
    @Column(name = "MSGNO")
    String msgno;

    /** メッセージ内容 */
    @Column(name = "MSGNIYU")
    String msgniyu;

    /** 使用用途 */
    @Column(name = "SHYUYUT")
    String shyuyut;

    /** レコード削除フラグ */
    @Column(name = "RCDSKJFLG")
    String rcdskjflg;

    /** 初期登録日時 */
    @Column(name = "SHKTURKDT")
    LocalDate shkturkdt;

    /** 登録プログラムＩＤ */
    @Column(name = "TURKPGMID")
    String turkpgmid;

    /** 初回登録ユーザＩＤ */
    @Column(name = "SYKITRUKUSERID")
    String sykitrukuserid;

    /** 最終更新日時 */
    @Column(name = "SISHUKUSHNDT")
    LocalDate sishukushndt;

    /** 更新プログラムＩＤ */
    @Column(name = "KUSHNPGMID")
    String kushnpgmid;

    /** 最終更新団体コード */
    @Column(name = "SISHUKUSHNDNTICD")
    String sishukushndnticd;

    /** 最終更新ユーザＩＤ */
    @Column(name = "SISHUKUSHNUSERID")
    String sishukushnuserid;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the msgid.
     * 
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }

    /** 
     * Sets the msgid.
     * 
     * @param msgid the msgid
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }

    /** 
     * Returns the msgkbn.
     * 
     * @return the msgkbn
     */
    public String getMsgkbn() {
        return msgkbn;
    }

    /** 
     * Sets the msgkbn.
     * 
     * @param msgkbn the msgkbn
     */
    public void setMsgkbn(String msgkbn) {
        this.msgkbn = msgkbn;
    }

    /** 
     * Returns the msgno.
     * 
     * @return the msgno
     */
    public String getMsgno() {
        return msgno;
    }

    /** 
     * Sets the msgno.
     * 
     * @param msgno the msgno
     */
    public void setMsgno(String msgno) {
        this.msgno = msgno;
    }

    /** 
     * Returns the msgniyu.
     * 
     * @return the msgniyu
     */
    public String getMsgniyu() {
        return msgniyu;
    }

    /** 
     * Sets the msgniyu.
     * 
     * @param msgniyu the msgniyu
     */
    public void setMsgniyu(String msgniyu) {
        this.msgniyu = msgniyu;
    }

    /** 
     * Returns the shyuyut.
     * 
     * @return the shyuyut
     */
    public String getShyuyut() {
        return shyuyut;
    }

    /** 
     * Sets the shyuyut.
     * 
     * @param shyuyut the shyuyut
     */
    public void setShyuyut(String shyuyut) {
        this.shyuyut = shyuyut;
    }

    /** 
     * Returns the rcdskjflg.
     * 
     * @return the rcdskjflg
     */
    public String getRcdskjflg() {
        return rcdskjflg;
    }

    /** 
     * Sets the rcdskjflg.
     * 
     * @param rcdskjflg the rcdskjflg
     */
    public void setRcdskjflg(String rcdskjflg) {
        this.rcdskjflg = rcdskjflg;
    }

    /** 
     * Returns the shkturkdt.
     * 
     * @return the shkturkdt
     */
    public LocalDate getShkturkdt() {
        return shkturkdt;
    }

    /** 
     * Sets the shkturkdt.
     * 
     * @param shkturkdt the shkturkdt
     */
    public void setShkturkdt(LocalDate shkturkdt) {
        this.shkturkdt = shkturkdt;
    }

    /** 
     * Returns the turkpgmid.
     * 
     * @return the turkpgmid
     */
    public String getTurkpgmid() {
        return turkpgmid;
    }

    /** 
     * Sets the turkpgmid.
     * 
     * @param turkpgmid the turkpgmid
     */
    public void setTurkpgmid(String turkpgmid) {
        this.turkpgmid = turkpgmid;
    }

    /** 
     * Returns the sykitrukuserid.
     * 
     * @return the sykitrukuserid
     */
    public String getSykitrukuserid() {
        return sykitrukuserid;
    }

    /** 
     * Sets the sykitrukuserid.
     * 
     * @param sykitrukuserid the sykitrukuserid
     */
    public void setSykitrukuserid(String sykitrukuserid) {
        this.sykitrukuserid = sykitrukuserid;
    }

    /** 
     * Returns the sishukushndt.
     * 
     * @return the sishukushndt
     */
    public LocalDate getSishukushndt() {
        return sishukushndt;
    }

    /** 
     * Sets the sishukushndt.
     * 
     * @param sishukushndt the sishukushndt
     */
    public void setSishukushndt(LocalDate sishukushndt) {
        this.sishukushndt = sishukushndt;
    }

    /** 
     * Returns the kushnpgmid.
     * 
     * @return the kushnpgmid
     */
    public String getKushnpgmid() {
        return kushnpgmid;
    }

    /** 
     * Sets the kushnpgmid.
     * 
     * @param kushnpgmid the kushnpgmid
     */
    public void setKushnpgmid(String kushnpgmid) {
        this.kushnpgmid = kushnpgmid;
    }

    /** 
     * Returns the sishukushndnticd.
     * 
     * @return the sishukushndnticd
     */
    public String getSishukushndnticd() {
        return sishukushndnticd;
    }

    /** 
     * Sets the sishukushndnticd.
     * 
     * @param sishukushndnticd the sishukushndnticd
     */
    public void setSishukushndnticd(String sishukushndnticd) {
        this.sishukushndnticd = sishukushndnticd;
    }

    /** 
     * Returns the sishukushnuserid.
     * 
     * @return the sishukushnuserid
     */
    public String getSishukushnuserid() {
        return sishukushnuserid;
    }

    /** 
     * Sets the sishukushnuserid.
     * 
     * @param sishukushnuserid the sishukushnuserid
     */
    public void setSishukushnuserid(String sishukushnuserid) {
        this.sishukushnuserid = sishukushnuserid;
    }
}