package jp.co.ntj.webedi.domain.entity.table;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 商品分類マスタ
 */
@Entity(listener = MShobunListener.class)
@Table(name = "M_SHOBUN")
public class MShobun {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 大分類コード */
    @Id
    @Column(name = "LAG_BUNCD")
    String lagBuncd;

    /** 中分類コード */
    @Id
    @Column(name = "MID_BUNCD")
    String midBuncd;

    /** 小分類コード１ */
    @Id
    @Column(name = "SML_BUNCD1")
    String smlBuncd1;

    /** 分類名 */
    @Column(name = "BUN_NM")
    String bunNm;

    /** 分類名英 */
    @Column(name = "BUN_ENM")
    String bunEnm;

    /** 管理分類コード１ */
    @Column(name = "KANR_BUNCD1")
    Long kanrBuncd1;

    /** 管理分類コード２ */
    @Column(name = "KANR_BUNCD2")
    Long kanrBuncd2;

    /** 管理分類コード３ */
    @Column(name = "KANR_BUNCD3")
    Long kanrBuncd3;

    /** 管理分類コード４ */
    @Column(name = "KANR_BUNCD4")
    Long kanrBuncd4;

    /** 管理分類コード５ */
    @Column(name = "KANR_BUNCD5")
    Long kanrBuncd5;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Integer hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the lagBuncd.
     * 
     * @return the lagBuncd
     */
    public String getLagBuncd() {
        return lagBuncd;
    }

    /** 
     * Sets the lagBuncd.
     * 
     * @param lagBuncd the lagBuncd
     */
    public void setLagBuncd(String lagBuncd) {
        this.lagBuncd = lagBuncd;
    }

    /** 
     * Returns the midBuncd.
     * 
     * @return the midBuncd
     */
    public String getMidBuncd() {
        return midBuncd;
    }

    /** 
     * Sets the midBuncd.
     * 
     * @param midBuncd the midBuncd
     */
    public void setMidBuncd(String midBuncd) {
        this.midBuncd = midBuncd;
    }

    /** 
     * Returns the smlBuncd1.
     * 
     * @return the smlBuncd1
     */
    public String getSmlBuncd1() {
        return smlBuncd1;
    }

    /** 
     * Sets the smlBuncd1.
     * 
     * @param smlBuncd1 the smlBuncd1
     */
    public void setSmlBuncd1(String smlBuncd1) {
        this.smlBuncd1 = smlBuncd1;
    }

    /** 
     * Returns the bunNm.
     * 
     * @return the bunNm
     */
    public String getBunNm() {
        return bunNm;
    }

    /** 
     * Sets the bunNm.
     * 
     * @param bunNm the bunNm
     */
    public void setBunNm(String bunNm) {
        this.bunNm = bunNm;
    }

    /** 
     * Returns the bunEnm.
     * 
     * @return the bunEnm
     */
    public String getBunEnm() {
        return bunEnm;
    }

    /** 
     * Sets the bunEnm.
     * 
     * @param bunEnm the bunEnm
     */
    public void setBunEnm(String bunEnm) {
        this.bunEnm = bunEnm;
    }

    /** 
     * Returns the kanrBuncd1.
     * 
     * @return the kanrBuncd1
     */
    public Long getKanrBuncd1() {
        return kanrBuncd1;
    }

    /** 
     * Sets the kanrBuncd1.
     * 
     * @param kanrBuncd1 the kanrBuncd1
     */
    public void setKanrBuncd1(Long kanrBuncd1) {
        this.kanrBuncd1 = kanrBuncd1;
    }

    /** 
     * Returns the kanrBuncd2.
     * 
     * @return the kanrBuncd2
     */
    public Long getKanrBuncd2() {
        return kanrBuncd2;
    }

    /** 
     * Sets the kanrBuncd2.
     * 
     * @param kanrBuncd2 the kanrBuncd2
     */
    public void setKanrBuncd2(Long kanrBuncd2) {
        this.kanrBuncd2 = kanrBuncd2;
    }

    /** 
     * Returns the kanrBuncd3.
     * 
     * @return the kanrBuncd3
     */
    public Long getKanrBuncd3() {
        return kanrBuncd3;
    }

    /** 
     * Sets the kanrBuncd3.
     * 
     * @param kanrBuncd3 the kanrBuncd3
     */
    public void setKanrBuncd3(Long kanrBuncd3) {
        this.kanrBuncd3 = kanrBuncd3;
    }

    /** 
     * Returns the kanrBuncd4.
     * 
     * @return the kanrBuncd4
     */
    public Long getKanrBuncd4() {
        return kanrBuncd4;
    }

    /** 
     * Sets the kanrBuncd4.
     * 
     * @param kanrBuncd4 the kanrBuncd4
     */
    public void setKanrBuncd4(Long kanrBuncd4) {
        this.kanrBuncd4 = kanrBuncd4;
    }

    /** 
     * Returns the kanrBuncd5.
     * 
     * @return the kanrBuncd5
     */
    public Long getKanrBuncd5() {
        return kanrBuncd5;
    }

    /** 
     * Sets the kanrBuncd5.
     * 
     * @param kanrBuncd5 the kanrBuncd5
     */
    public void setKanrBuncd5(Long kanrBuncd5) {
        this.kanrBuncd5 = kanrBuncd5;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Integer getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Integer hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}