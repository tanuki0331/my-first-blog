package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class OcConfirmationListener implements EntityListener<OcConfirmation> {

    @Override
    public void preInsert(OcConfirmation entity, PreInsertContext<OcConfirmation> context) {
    }

    @Override
    public void preUpdate(OcConfirmation entity, PreUpdateContext<OcConfirmation> context) {
    }

    @Override
    public void preDelete(OcConfirmation entity, PreDeleteContext<OcConfirmation> context) {
    }

    @Override
    public void postInsert(OcConfirmation entity, PostInsertContext<OcConfirmation> context) {
    }

    @Override
    public void postUpdate(OcConfirmation entity, PostUpdateContext<OcConfirmation> context) {
    }

    @Override
    public void postDelete(OcConfirmation entity, PostDeleteContext<OcConfirmation> context) {
    }
}