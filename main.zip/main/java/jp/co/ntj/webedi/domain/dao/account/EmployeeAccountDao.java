package jp.co.ntj.webedi.domain.dao.account;

import java.math.BigDecimal;
import java.util.List;
import jp.co.ntj.webedi.domain.dto.account.employee.SelectEmployeeAuthorityDto;
import jp.co.ntj.webedi.domain.dto.account.employee.SelectEmployeeUserDto;
import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * 社員アカウントDao.
 *
 * @author 日立システムズ
 */
@ConfigAutowireable
@Dao
public interface EmployeeAccountDao {

  /**
   * ユーザー検索.
   *
   * @param employeeId 社員ID
   * @return SelectEmployeeUserDto
   */
  @Select
  SelectEmployeeUserDto selectEmployeeUserByEmployeeId(String employeeId);

  /**
   * ユーザー検索.
   *
   * @param kaisyaCd 会社コード
   * @param gengoKbn 言語区分
   * @param id id
   * @return SelectEmployeeUserDto
   */
  @Select
  SelectEmployeeUserDto selectEmployeeUserById(String kaisyaCd, String gengoKbn, BigDecimal id);

  /**
   * 権限検索.
   *
   * @param kaisyaCd 会社コード
   * @param gengoKbn 言語区分
   * @param employeeUserId id
   * @return SelectEmployeeAuthorityDto
   */
  @Select
  List<SelectEmployeeAuthorityDto> selectEmployeeAuthority(String kaisyaCd, String gengoKbn,
      BigDecimal employeeUserId);
}
