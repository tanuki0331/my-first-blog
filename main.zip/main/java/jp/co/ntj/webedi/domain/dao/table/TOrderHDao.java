package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.TOrderH;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface TOrderHDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param orderno
     * @return the TOrderH entity
     */
    @Select
    TOrderH selectById(String kaisyaCd, String gengoKbn, Long orderno);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(TOrderH entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(TOrderH entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(TOrderH entity);
}