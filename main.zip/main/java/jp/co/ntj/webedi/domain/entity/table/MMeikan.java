package jp.co.ntj.webedi.domain.entity.table;

import java.time.LocalDate;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

/**
 * 名称管理マスタ
 */
@Entity(listener = MMeikanListener.class)
@Table(name = "M_MEIKAN")
public class MMeikan {

    /** 会社コード */
    @Id
    @Column(name = "KAISYA_CD")
    String kaisyaCd;

    /** 言語区分 */
    @Id
    @Column(name = "GENGO_KBN")
    String gengoKbn;

    /** 名称管理コード */
    @Id
    @Column(name = "MEIKANCD")
    String meikancd;

    /** 名称管理名 */
    @Column(name = "MEIKANNM")
    String meikannm;

    /** 名称管理略称 */
    @Column(name = "MEIKANRYAK")
    String meikanryak;

    /** コード属性 */
    @Column(name = "CD_TYPE")
    String cdType;

    /** コード桁数 */
    @Column(name = "CD_KETA")
    Short cdKeta;

    /** 名称属性 */
    @Column(name = "NM_TYPE")
    String nmType;

    /** 名称桁数 */
    @Column(name = "NM_KETA")
    Short nmKeta;

    /** 名称ＩＭＥ制御 */
    @Column(name = "NM_IME")
    Short nmIme;

    /** 文字項目見出し１ */
    @Column(name = "STR_TITLE1")
    String strTitle1;

    /** 文字項目見出し２ */
    @Column(name = "STR_TITLE2")
    String strTitle2;

    /** 文字項目見出し３ */
    @Column(name = "STR_TITLE3")
    String strTitle3;

    /** 文字項目見出し４ */
    @Column(name = "STR_TITLE4")
    String strTitle4;

    /** 文字項目見出し５ */
    @Column(name = "STR_TITLE5")
    String strTitle5;

    /** 文字項目名称管理コード１ */
    @Column(name = "STR_MEIKANCD1")
    String strMeikancd1;

    /** 文字項目名称管理コード２ */
    @Column(name = "STR_MEIKANCD2")
    String strMeikancd2;

    /** 文字項目名称管理コード３ */
    @Column(name = "STR_MEIKANCD3")
    String strMeikancd3;

    /** 文字項目名称管理コード４ */
    @Column(name = "STR_MEIKANCD4")
    String strMeikancd4;

    /** 文字項目名称管理コード５ */
    @Column(name = "STR_MEIKANCD5")
    String strMeikancd5;

    /** 文字項目入力必須区分１ */
    @Column(name = "STR_INPUT1")
    Short strInput1;

    /** 文字項目入力必須区分２ */
    @Column(name = "STR_INPUT2")
    Short strInput2;

    /** 文字項目入力必須区分３ */
    @Column(name = "STR_INPUT3")
    Short strInput3;

    /** 文字項目入力必須区分４ */
    @Column(name = "STR_INPUT4")
    Short strInput4;

    /** 文字項目入力必須区分５ */
    @Column(name = "STR_INPUT5")
    Short strInput5;

    /** 数字項目見出し１ */
    @Column(name = "NUM_TITLE1")
    String numTitle1;

    /** 数字項目見出し２ */
    @Column(name = "NUM_TITLE2")
    String numTitle2;

    /** 数字項目見出し３ */
    @Column(name = "NUM_TITLE3")
    String numTitle3;

    /** 数字項目見出し４ */
    @Column(name = "NUM_TITLE4")
    String numTitle4;

    /** 数字項目見出し５ */
    @Column(name = "NUM_TITLE5")
    String numTitle5;

    /** 旧システムテーブル名 */
    @Column(name = "OLD_TABLENAME")
    String oldTablename;

    /** 入力可能オペレータレベル */
    @Column(name = "INPUT_LEVEL")
    Short inputLevel;

    /** 表示順 */
    @Column(name = "HYOJI_SEQ")
    Integer hyojiSeq;

    /** 更新日時 */
    @Column(name = "REC_TIMESTAMP")
    LocalDate recTimestamp;

    /** 更新担当者コード */
    @Column(name = "REC_TANTOCD")
    Integer recTantocd;

    /** レコード削除フラグ */
    @Column(name = "REC_DLTFLG")
    Short recDltflg;

    /** 
     * Returns the kaisyaCd.
     * 
     * @return the kaisyaCd
     */
    public String getKaisyaCd() {
        return kaisyaCd;
    }

    /** 
     * Sets the kaisyaCd.
     * 
     * @param kaisyaCd the kaisyaCd
     */
    public void setKaisyaCd(String kaisyaCd) {
        this.kaisyaCd = kaisyaCd;
    }

    /** 
     * Returns the gengoKbn.
     * 
     * @return the gengoKbn
     */
    public String getGengoKbn() {
        return gengoKbn;
    }

    /** 
     * Sets the gengoKbn.
     * 
     * @param gengoKbn the gengoKbn
     */
    public void setGengoKbn(String gengoKbn) {
        this.gengoKbn = gengoKbn;
    }

    /** 
     * Returns the meikancd.
     * 
     * @return the meikancd
     */
    public String getMeikancd() {
        return meikancd;
    }

    /** 
     * Sets the meikancd.
     * 
     * @param meikancd the meikancd
     */
    public void setMeikancd(String meikancd) {
        this.meikancd = meikancd;
    }

    /** 
     * Returns the meikannm.
     * 
     * @return the meikannm
     */
    public String getMeikannm() {
        return meikannm;
    }

    /** 
     * Sets the meikannm.
     * 
     * @param meikannm the meikannm
     */
    public void setMeikannm(String meikannm) {
        this.meikannm = meikannm;
    }

    /** 
     * Returns the meikanryak.
     * 
     * @return the meikanryak
     */
    public String getMeikanryak() {
        return meikanryak;
    }

    /** 
     * Sets the meikanryak.
     * 
     * @param meikanryak the meikanryak
     */
    public void setMeikanryak(String meikanryak) {
        this.meikanryak = meikanryak;
    }

    /** 
     * Returns the cdType.
     * 
     * @return the cdType
     */
    public String getCdType() {
        return cdType;
    }

    /** 
     * Sets the cdType.
     * 
     * @param cdType the cdType
     */
    public void setCdType(String cdType) {
        this.cdType = cdType;
    }

    /** 
     * Returns the cdKeta.
     * 
     * @return the cdKeta
     */
    public Short getCdKeta() {
        return cdKeta;
    }

    /** 
     * Sets the cdKeta.
     * 
     * @param cdKeta the cdKeta
     */
    public void setCdKeta(Short cdKeta) {
        this.cdKeta = cdKeta;
    }

    /** 
     * Returns the nmType.
     * 
     * @return the nmType
     */
    public String getNmType() {
        return nmType;
    }

    /** 
     * Sets the nmType.
     * 
     * @param nmType the nmType
     */
    public void setNmType(String nmType) {
        this.nmType = nmType;
    }

    /** 
     * Returns the nmKeta.
     * 
     * @return the nmKeta
     */
    public Short getNmKeta() {
        return nmKeta;
    }

    /** 
     * Sets the nmKeta.
     * 
     * @param nmKeta the nmKeta
     */
    public void setNmKeta(Short nmKeta) {
        this.nmKeta = nmKeta;
    }

    /** 
     * Returns the nmIme.
     * 
     * @return the nmIme
     */
    public Short getNmIme() {
        return nmIme;
    }

    /** 
     * Sets the nmIme.
     * 
     * @param nmIme the nmIme
     */
    public void setNmIme(Short nmIme) {
        this.nmIme = nmIme;
    }

    /** 
     * Returns the strTitle1.
     * 
     * @return the strTitle1
     */
    public String getStrTitle1() {
        return strTitle1;
    }

    /** 
     * Sets the strTitle1.
     * 
     * @param strTitle1 the strTitle1
     */
    public void setStrTitle1(String strTitle1) {
        this.strTitle1 = strTitle1;
    }

    /** 
     * Returns the strTitle2.
     * 
     * @return the strTitle2
     */
    public String getStrTitle2() {
        return strTitle2;
    }

    /** 
     * Sets the strTitle2.
     * 
     * @param strTitle2 the strTitle2
     */
    public void setStrTitle2(String strTitle2) {
        this.strTitle2 = strTitle2;
    }

    /** 
     * Returns the strTitle3.
     * 
     * @return the strTitle3
     */
    public String getStrTitle3() {
        return strTitle3;
    }

    /** 
     * Sets the strTitle3.
     * 
     * @param strTitle3 the strTitle3
     */
    public void setStrTitle3(String strTitle3) {
        this.strTitle3 = strTitle3;
    }

    /** 
     * Returns the strTitle4.
     * 
     * @return the strTitle4
     */
    public String getStrTitle4() {
        return strTitle4;
    }

    /** 
     * Sets the strTitle4.
     * 
     * @param strTitle4 the strTitle4
     */
    public void setStrTitle4(String strTitle4) {
        this.strTitle4 = strTitle4;
    }

    /** 
     * Returns the strTitle5.
     * 
     * @return the strTitle5
     */
    public String getStrTitle5() {
        return strTitle5;
    }

    /** 
     * Sets the strTitle5.
     * 
     * @param strTitle5 the strTitle5
     */
    public void setStrTitle5(String strTitle5) {
        this.strTitle5 = strTitle5;
    }

    /** 
     * Returns the strMeikancd1.
     * 
     * @return the strMeikancd1
     */
    public String getStrMeikancd1() {
        return strMeikancd1;
    }

    /** 
     * Sets the strMeikancd1.
     * 
     * @param strMeikancd1 the strMeikancd1
     */
    public void setStrMeikancd1(String strMeikancd1) {
        this.strMeikancd1 = strMeikancd1;
    }

    /** 
     * Returns the strMeikancd2.
     * 
     * @return the strMeikancd2
     */
    public String getStrMeikancd2() {
        return strMeikancd2;
    }

    /** 
     * Sets the strMeikancd2.
     * 
     * @param strMeikancd2 the strMeikancd2
     */
    public void setStrMeikancd2(String strMeikancd2) {
        this.strMeikancd2 = strMeikancd2;
    }

    /** 
     * Returns the strMeikancd3.
     * 
     * @return the strMeikancd3
     */
    public String getStrMeikancd3() {
        return strMeikancd3;
    }

    /** 
     * Sets the strMeikancd3.
     * 
     * @param strMeikancd3 the strMeikancd3
     */
    public void setStrMeikancd3(String strMeikancd3) {
        this.strMeikancd3 = strMeikancd3;
    }

    /** 
     * Returns the strMeikancd4.
     * 
     * @return the strMeikancd4
     */
    public String getStrMeikancd4() {
        return strMeikancd4;
    }

    /** 
     * Sets the strMeikancd4.
     * 
     * @param strMeikancd4 the strMeikancd4
     */
    public void setStrMeikancd4(String strMeikancd4) {
        this.strMeikancd4 = strMeikancd4;
    }

    /** 
     * Returns the strMeikancd5.
     * 
     * @return the strMeikancd5
     */
    public String getStrMeikancd5() {
        return strMeikancd5;
    }

    /** 
     * Sets the strMeikancd5.
     * 
     * @param strMeikancd5 the strMeikancd5
     */
    public void setStrMeikancd5(String strMeikancd5) {
        this.strMeikancd5 = strMeikancd5;
    }

    /** 
     * Returns the strInput1.
     * 
     * @return the strInput1
     */
    public Short getStrInput1() {
        return strInput1;
    }

    /** 
     * Sets the strInput1.
     * 
     * @param strInput1 the strInput1
     */
    public void setStrInput1(Short strInput1) {
        this.strInput1 = strInput1;
    }

    /** 
     * Returns the strInput2.
     * 
     * @return the strInput2
     */
    public Short getStrInput2() {
        return strInput2;
    }

    /** 
     * Sets the strInput2.
     * 
     * @param strInput2 the strInput2
     */
    public void setStrInput2(Short strInput2) {
        this.strInput2 = strInput2;
    }

    /** 
     * Returns the strInput3.
     * 
     * @return the strInput3
     */
    public Short getStrInput3() {
        return strInput3;
    }

    /** 
     * Sets the strInput3.
     * 
     * @param strInput3 the strInput3
     */
    public void setStrInput3(Short strInput3) {
        this.strInput3 = strInput3;
    }

    /** 
     * Returns the strInput4.
     * 
     * @return the strInput4
     */
    public Short getStrInput4() {
        return strInput4;
    }

    /** 
     * Sets the strInput4.
     * 
     * @param strInput4 the strInput4
     */
    public void setStrInput4(Short strInput4) {
        this.strInput4 = strInput4;
    }

    /** 
     * Returns the strInput5.
     * 
     * @return the strInput5
     */
    public Short getStrInput5() {
        return strInput5;
    }

    /** 
     * Sets the strInput5.
     * 
     * @param strInput5 the strInput5
     */
    public void setStrInput5(Short strInput5) {
        this.strInput5 = strInput5;
    }

    /** 
     * Returns the numTitle1.
     * 
     * @return the numTitle1
     */
    public String getNumTitle1() {
        return numTitle1;
    }

    /** 
     * Sets the numTitle1.
     * 
     * @param numTitle1 the numTitle1
     */
    public void setNumTitle1(String numTitle1) {
        this.numTitle1 = numTitle1;
    }

    /** 
     * Returns the numTitle2.
     * 
     * @return the numTitle2
     */
    public String getNumTitle2() {
        return numTitle2;
    }

    /** 
     * Sets the numTitle2.
     * 
     * @param numTitle2 the numTitle2
     */
    public void setNumTitle2(String numTitle2) {
        this.numTitle2 = numTitle2;
    }

    /** 
     * Returns the numTitle3.
     * 
     * @return the numTitle3
     */
    public String getNumTitle3() {
        return numTitle3;
    }

    /** 
     * Sets the numTitle3.
     * 
     * @param numTitle3 the numTitle3
     */
    public void setNumTitle3(String numTitle3) {
        this.numTitle3 = numTitle3;
    }

    /** 
     * Returns the numTitle4.
     * 
     * @return the numTitle4
     */
    public String getNumTitle4() {
        return numTitle4;
    }

    /** 
     * Sets the numTitle4.
     * 
     * @param numTitle4 the numTitle4
     */
    public void setNumTitle4(String numTitle4) {
        this.numTitle4 = numTitle4;
    }

    /** 
     * Returns the numTitle5.
     * 
     * @return the numTitle5
     */
    public String getNumTitle5() {
        return numTitle5;
    }

    /** 
     * Sets the numTitle5.
     * 
     * @param numTitle5 the numTitle5
     */
    public void setNumTitle5(String numTitle5) {
        this.numTitle5 = numTitle5;
    }

    /** 
     * Returns the oldTablename.
     * 
     * @return the oldTablename
     */
    public String getOldTablename() {
        return oldTablename;
    }

    /** 
     * Sets the oldTablename.
     * 
     * @param oldTablename the oldTablename
     */
    public void setOldTablename(String oldTablename) {
        this.oldTablename = oldTablename;
    }

    /** 
     * Returns the inputLevel.
     * 
     * @return the inputLevel
     */
    public Short getInputLevel() {
        return inputLevel;
    }

    /** 
     * Sets the inputLevel.
     * 
     * @param inputLevel the inputLevel
     */
    public void setInputLevel(Short inputLevel) {
        this.inputLevel = inputLevel;
    }

    /** 
     * Returns the hyojiSeq.
     * 
     * @return the hyojiSeq
     */
    public Integer getHyojiSeq() {
        return hyojiSeq;
    }

    /** 
     * Sets the hyojiSeq.
     * 
     * @param hyojiSeq the hyojiSeq
     */
    public void setHyojiSeq(Integer hyojiSeq) {
        this.hyojiSeq = hyojiSeq;
    }

    /** 
     * Returns the recTimestamp.
     * 
     * @return the recTimestamp
     */
    public LocalDate getRecTimestamp() {
        return recTimestamp;
    }

    /** 
     * Sets the recTimestamp.
     * 
     * @param recTimestamp the recTimestamp
     */
    public void setRecTimestamp(LocalDate recTimestamp) {
        this.recTimestamp = recTimestamp;
    }

    /** 
     * Returns the recTantocd.
     * 
     * @return the recTantocd
     */
    public Integer getRecTantocd() {
        return recTantocd;
    }

    /** 
     * Sets the recTantocd.
     * 
     * @param recTantocd the recTantocd
     */
    public void setRecTantocd(Integer recTantocd) {
        this.recTantocd = recTantocd;
    }

    /** 
     * Returns the recDltflg.
     * 
     * @return the recDltflg
     */
    public Short getRecDltflg() {
        return recDltflg;
    }

    /** 
     * Sets the recDltflg.
     * 
     * @param recDltflg the recDltflg
     */
    public void setRecDltflg(Short recDltflg) {
        this.recDltflg = recDltflg;
    }
}