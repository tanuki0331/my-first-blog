package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.MPurchaseOrderChar;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

/**
 */
@Dao
public interface MPurchaseOrderCharDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param shimukecd
     * @return the MPurchaseOrderChar entity
     */
    @Select
    MPurchaseOrderChar selectById(String kaisyaCd, String gengoKbn, Long shimukecd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(MPurchaseOrderChar entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(MPurchaseOrderChar entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(MPurchaseOrderChar entity);
}