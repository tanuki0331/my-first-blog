package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.EmployeeUserAccessInfo;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

import java.time.LocalDateTime;

/**
 */
@ConfigAutowireable
@Dao
public interface EmployeeUserAccessInfoDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param employeeUserId
     * @return the EmployeeUserAccessInfo entity
     */
    @Select
    EmployeeUserAccessInfo selectById(String kaisyaCd, String gengoKbn, Long employeeUserId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(EmployeeUserAccessInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(EmployeeUserAccessInfo entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(EmployeeUserAccessInfo entity);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
