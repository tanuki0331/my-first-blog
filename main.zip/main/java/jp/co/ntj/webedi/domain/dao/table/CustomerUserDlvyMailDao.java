package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.CustomerUserDlvyMail;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

import java.time.LocalDateTime;

/**
 */
@ConfigAutowireable
@Dao
public interface CustomerUserDlvyMailDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerUserId
     * @param sequenceNumber
     * @return the CustomerUserDlvyMail entity
     */
    @Select
    CustomerUserDlvyMail selectById(String kaisyaCd, String gengoKbn, Long customerUserId, Short sequenceNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(CustomerUserDlvyMail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(CustomerUserDlvyMail entity);

    /**
     * 論理削除もしくは存在しない得意先ユーザーに紐付くデータを論理削除する
     *
     * @param updateUser
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidCustomerUser(String updateUser);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(CustomerUserDlvyMail entity);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
