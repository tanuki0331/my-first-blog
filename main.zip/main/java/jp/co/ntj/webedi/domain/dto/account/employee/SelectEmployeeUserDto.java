package jp.co.ntj.webedi.domain.dto.account.employee;

import java.math.BigDecimal;
import java.sql.Timestamp;
import jp.co.ntj.webedi.domain.domain.Bool;
import org.seasar.doma.Entity;

/**
 * 社員ユーザー検索.
 *
 * @author 日立システムズ
 */
@Entity
public class SelectEmployeeUserDto {

  /**
   * 会社コード
   */
  public String kaisyaCd;

  /**
   * 言語区分
   */
  public String gengoKbn;

  /**
   * ID
   */
  public BigDecimal id;

  /**
   * 社員ID
   */
  public String employeeId;

  /**
   * 氏名
   */
  public String name;

  /**
   * パスワード
   */
  public String password;

  /**
   * メールアドレス
   */
  public String mailAddress;

  /**
   * ユーザー有効フラグ
   */
  public Bool isValidatedUser;

  /**
   * セッションID
   */
  public String sessionId;

  /**
   * 最終操作日時
   */
  public Timestamp lastOperationAt;

  /**
   * ログイン日時
   */
  public Timestamp loginAt;

  /**
   * 前回ログイン日時
   */
  public Timestamp prevLoginAt;

  /**
   * ホスト名
   */
  public String hostName;

  /**
   * アクセスIP
   */
  public String accessIp;

  /**
   * ユーザーエージェント
   */
  public String userAgent;
}
