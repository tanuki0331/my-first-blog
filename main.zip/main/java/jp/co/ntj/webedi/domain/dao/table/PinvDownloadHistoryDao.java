package jp.co.ntj.webedi.domain.dao.table;

import jp.co.ntj.webedi.domain.entity.table.PinvDownloadHistory;
import jp.co.ntj.webedi.domain.entity.table.PinvReport;
import org.seasar.doma.*;
import org.seasar.doma.boot.ConfigAutowireable;

import java.time.LocalDateTime;
import java.util.List;

/**
 */
@ConfigAutowireable
@Dao
public interface PinvDownloadHistoryDao {

    /**
     * @param kaisyaCd
     * @param gengoKbn
     * @param customerCode
     * @param destinationCode
     * @param pinvNumber
     * @return the PinvDownloadHistory entity
     */
    @Select
    PinvDownloadHistory selectById(String kaisyaCd, String gengoKbn, Long customerCode, Long destinationCode, String pinvNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(PinvDownloadHistory entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(PinvDownloadHistory entity);

    /**
     * 論理削除もしくは存在しない得意先に紐付くデータを論理削除する
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidTokui(String updateUser);

    /**
     * 論理削除もしくは存在しない仕向先／最終仕向け先に紐付くデータを論理削除する
     *
     * @param updateUser
     */
    @Update(sqlFile = true)
    int updateForDelByInvalidShimu(String updateUser);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(PinvDownloadHistory entity);

    /**
     * 指定日時以前に作成されたデータを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteBeforeByCreatedAt(LocalDateTime createdAt);

    /**
     * ProformaInvoice帳票に関連するデータについてバッチ削除を行う
     *
     * @param pinvReports
     * @return affected rows
     */
    @BatchDelete(sqlFile = true)
    int[] deleteByPinvReports(List<PinvReport> pinvReports);

    /**
     * 指定日時以前に作成された論理削除データを削除する
     *
     * @param createdAt
     * @return affected rows
     */
    @Delete(sqlFile = true)
    int deleteDeletedData(LocalDateTime createdAt);
}
