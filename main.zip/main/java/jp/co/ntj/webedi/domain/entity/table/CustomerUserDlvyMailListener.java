package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class CustomerUserDlvyMailListener implements EntityListener<CustomerUserDlvyMail> {

    @Override
    public void preInsert(CustomerUserDlvyMail entity, PreInsertContext<CustomerUserDlvyMail> context) {
    }

    @Override
    public void preUpdate(CustomerUserDlvyMail entity, PreUpdateContext<CustomerUserDlvyMail> context) {
    }

    @Override
    public void preDelete(CustomerUserDlvyMail entity, PreDeleteContext<CustomerUserDlvyMail> context) {
    }

    @Override
    public void postInsert(CustomerUserDlvyMail entity, PostInsertContext<CustomerUserDlvyMail> context) {
    }

    @Override
    public void postUpdate(CustomerUserDlvyMail entity, PostUpdateContext<CustomerUserDlvyMail> context) {
    }

    @Override
    public void postDelete(CustomerUserDlvyMail entity, PostDeleteContext<CustomerUserDlvyMail> context) {
    }
}