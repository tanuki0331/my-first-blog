package jp.co.ntj.webedi.domain.entity.table;

import org.seasar.doma.jdbc.entity.EntityListener;
import org.seasar.doma.jdbc.entity.PostDeleteContext;
import org.seasar.doma.jdbc.entity.PostInsertContext;
import org.seasar.doma.jdbc.entity.PostUpdateContext;
import org.seasar.doma.jdbc.entity.PreDeleteContext;
import org.seasar.doma.jdbc.entity.PreInsertContext;
import org.seasar.doma.jdbc.entity.PreUpdateContext;

/**
 * 
 */
public class MPlistListener implements EntityListener<MPlist> {

    @Override
    public void preInsert(MPlist entity, PreInsertContext<MPlist> context) {
    }

    @Override
    public void preUpdate(MPlist entity, PreUpdateContext<MPlist> context) {
    }

    @Override
    public void preDelete(MPlist entity, PreDeleteContext<MPlist> context) {
    }

    @Override
    public void postInsert(MPlist entity, PostInsertContext<MPlist> context) {
    }

    @Override
    public void postUpdate(MPlist entity, PostUpdateContext<MPlist> context) {
    }

    @Override
    public void postDelete(MPlist entity, PostDeleteContext<MPlist> context) {
    }
}