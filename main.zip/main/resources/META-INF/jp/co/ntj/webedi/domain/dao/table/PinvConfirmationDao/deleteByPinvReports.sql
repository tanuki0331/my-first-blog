delete from
  PINV_CONFIRMATION
WHERE
  KAISYA_CD = /* pinvReports.kaisyaCd */'a'
and
  GENGO_KBN = /* pinvReports.gengoKbn */'b'
and
  CUSTOMER_CODE = /* pinvReports.customerCode */1
and
  DESTINATION_CODE = /* pinvReports.destinationCode */2
and
  PINV_NUMBER = /* pinvReports.pinvNumber */'c'
