select
    eu.KAISYA_CD                                     -- 会社コード
  , eu.GENGO_KBN                                     -- 言語区分
  , eu.ID                                            -- ID
  , eu.EMPLOYEE_ID                                   -- ユーザーID
  , eu.NAME                                          -- 氏名
  , eu.PASSWORD                                      -- パスワード
  , eu.MAIL_ADDRESS                                  -- メールアドレス
  , eu.IS_VALIDATED_USER                             -- ユーザー有効フラグ
 
  , euai.SESSION_ID                                  -- セッションID
  , euai.LAST_OPERATION_AT                           -- 最終操作日時
  , euai.LOGIN_AT                                    -- ログイン日時
  , euai.PREV_LOGIN_AT                               -- 前回ログイン日時
  , euai.HOST_NAME                                   -- ホスト名
  , euai.ACCESS_IP                                   -- アクセスIP
  , euai.USER_AGENT                                  -- ユーザーエージェント
from
  EMPLOYEE_USER eu
left join
  EMPLOYEE_USER_ACCESS_INFO euai
  on
    euai.KAISYA_CD = eu.KAISYA_CD 
  and
    euai.GENGO_KBN = eu.GENGO_KBN 
  and
    euai.EMPLOYEE_USER_ID = eu.ID
  and
    euai.IS_DELETED = 0
where
    eu.EMPLOYEE_ID = /* employeeId */'0000000000000'
  and
    eu.IS_DELETED = 0
