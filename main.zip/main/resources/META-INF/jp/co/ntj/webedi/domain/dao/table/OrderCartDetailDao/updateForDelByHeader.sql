update
  ORDER_CART_DETAIL ocd
set
  ocd.IS_DELETED = 1
  ,ocd.UPDATED_AT = SYSDATE
  ,ocd.UPDATED_USER = /* updateUser */'a'
where
  ocd.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      ORDER_CART_HEADER och
    where
      ocd.KAISYA_CD = och.KAISYA_CD
    and
      ocd.GENGO_KBN = och.GENGO_KBN
    and
      ocd.CUSTOMER_USER_ID = och.CUSTOMER_USER_ID
    and
      och.IS_DELETED = 0)
