select
  /*%expand*/*
from
  M_TOKUI_CODE
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  TOKUCD = /* tokucd */1
  and
  SHIMUKECD = /* shimukecd */1
  and
  TOKU_HINMOKU_CD = /* tokuHinmokuCd */'a'
  and
  IRIME_JURYO = /* irimeJuryo */1
