select
  /*%expand*/*
from
  GENERAL_NEWS
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  ID = /* id */1
