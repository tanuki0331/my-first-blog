select
  /*%expand*/*
from
  SHIP_TO_USER
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  CUSTOMER_CODE = /* customerCode */1
  and
  DESTINATION_CODE = /* destinationCode */1
  and
  CUSTOMER_USER_ID = /* customerUserId */1
