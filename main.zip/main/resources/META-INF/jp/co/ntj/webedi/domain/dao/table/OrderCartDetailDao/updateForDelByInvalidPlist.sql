update
  ORDER_CART_DETAIL ocd
set
  ocd.IS_DELETED = 1
  ,ocd.UPDATED_AT = SYSDATE
  ,ocd.UPDATED_USER = /* updateUser */'a'
where
  ocd.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      M_PLIST mp
    where
      ocd.KAISYA_CD = mp.KAISYA_CD
    and
      ocd.GENGO_KBN = mp.GENGO_KBN
    and
      ocd.PRODUCT_CODE = mp.SHOHINCD
    and
      mp.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_PLIST mp
    where
      ocd.KAISYA_CD = mp.KAISYA_CD
    and
      ocd.GENGO_KBN = mp.GENGO_KBN
    and
      ocd.PRODUCT_CODE = mp.SHOHINCD)
  )
