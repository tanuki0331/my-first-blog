select
    cu.KAISYA_CD                                     -- 会社コード
  , cu.GENGO_KBN                                     -- 言語区分
  , cu.ID                                            -- ID
  , cu.USER_ID                                       -- ユーザーID
  , cu.CUSTOMER_CODE                                 -- 得意先コード
  , cu.NAME                                          -- 氏名
  , cu.PASSWORD                                      -- パスワード
  , cu.IS_INIT_PASSWORD                              -- パスワード変更フラグ
  , cu.MAIL_ADDRESS                                  -- メールアドレス
  , cu.USE_ORDER_MAIL                                -- 注文登録メール有効フラグ
  , cu.IS_VALIDATED_OC_ISSUE_MAIL                    -- OC発行メール有効フラグ
  , cu.IS_VALIDATED_INV_ISSUE_MAIL                   -- INV発行メール有効フラグ
  , cu.IS_VALIDATED_PINV_ISSUE_MAIL                  -- P/I発行メール有効フラグ
  , cu.IS_VALIDATED_DOMESTIC_DLVY                    -- 国内納入日表示有効フラグ
  , cu.IS_VALIDATED_PRODUCT_LIST                     -- 商品一覧表示有効フラグ
  , cu.IS_VALIDATED_USER                             -- ユーザー有効フラグ
 
  , cuai.SESSION_ID                                  -- セッションID
  , cuai.LAST_OPERATION_AT                           -- 最終操作日時
  , cuai.LOGIN_AT                                    -- ログイン日時
  , cuai.PREV_LOGIN_AT                               -- 前回ログイン日時
  , cuai.HOST_NAME                                   -- ホスト名
  , cuai.ACCESS_IP                                   -- アクセスIP
  , cuai.USER_AGENT                                  -- ユーザーエージェント

  , count(ocd.SEQUENCE_NUMBER) as CART_ITEM_COUNT    -- カート件数
from
  CUSTOMER_USER cu
left join
  CUSTOMER_USER_ACCESS_INFO cuai
  on
    cuai.KAISYA_CD = cu.KAISYA_CD
  and
    cuai.GENGO_KBN = cu.GENGO_KBN
  and
    cuai.CUSTOMER_USER_ID = cu.ID
  and
    cuai.IS_DELETED = 0
left join
  ORDER_CART_DETAIL ocd
  on
    ocd.KAISYA_CD = cu.KAISYA_CD
  and
    ocd.GENGO_KBN = cu.GENGO_KBN
  and
    ocd.CUSTOMER_USER_ID = cu.ID
  and
    ocd.IS_DELETED = 0
where
    cu.KAISYA_CD = /* kaisyaCd */'1001'
  and
    cu.GENGO_KBN = /* gengoKbn */'EN'
  and
    cu.ID = /* id */'2'
  and
    cu.IS_DELETED = 0
group by
    cu.KAISYA_CD                                     -- 会社コード
  , cu.GENGO_KBN                                     -- 言語区分
  , cu.ID                                            -- ID
  , cu.USER_ID                                       -- ユーザーID
  , cu.CUSTOMER_CODE                                 -- 得意先コード
  , cu.NAME                                          -- 氏名
  , cu.PASSWORD                                      -- パスワード
  , cu.IS_INIT_PASSWORD                              -- パスワード変更フラグ
  , cu.MAIL_ADDRESS                                  -- メールアドレス
  , cu.USE_ORDER_MAIL                                -- 注文登録メール有効フラグ
  , cu.IS_VALIDATED_OC_ISSUE_MAIL                    -- OC発行メール有効フラグ
  , cu.IS_VALIDATED_INV_ISSUE_MAIL                   -- INV発行メール有効フラグ
  , cu.IS_VALIDATED_PINV_ISSUE_MAIL                  -- P/I発行メール有効フラグ
  , cu.IS_VALIDATED_DOMESTIC_DLVY                    -- 国内納入日表示有効フラグ
  , cu.IS_VALIDATED_PRODUCT_LIST                     -- 商品一覧表示有効フラグ
  , cu.IS_VALIDATED_USER                             -- ユーザー有効フラグ

  , cuai.SESSION_ID                                  -- セッションID
  , cuai.LAST_OPERATION_AT                           -- 最終操作日時
  , cuai.LOGIN_AT                                    -- ログイン日時
  , cuai.PREV_LOGIN_AT                               -- 前回ログイン日時
  , cuai.HOST_NAME                                   -- ホスト名
  , cuai.ACCESS_IP                                   -- アクセスIP
  , cuai.USER_AGENT                                  -- ユーザーエージェント
