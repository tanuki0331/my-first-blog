update
  ORDER_CART_HEADER och
set
  och.IS_DELETED = 1
  ,och.UPDATED_AT = SYSDATE
  ,och.UPDATED_USER = /* updateUser */'a'
where
  och.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      och.KAISYA_CD = cu.KAISYA_CD
    and
      och.GENGO_KBN = cu.GENGO_KBN
    and
      och.CUSTOMER_USER_ID = cu.ID
    and
      cu.IS_DELETED != 0) or
  not exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      och.KAISYA_CD = cu.KAISYA_CD
    and
      och.GENGO_KBN = cu.GENGO_KBN
    and
      och.CUSTOMER_USER_ID = cu.ID)
  )
