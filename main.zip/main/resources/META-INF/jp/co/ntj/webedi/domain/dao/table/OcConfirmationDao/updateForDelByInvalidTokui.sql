update
  OC_CONFIRMATION occ
set
  occ.IS_DELETED = 1
  ,occ.UPDATED_AT = SYSDATE
  ,occ.UPDATED_USER = /* updateUser */'a'
where
  occ.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      M_TOKUI mt
    where
      occ.KAISYA_CD = mt.KAISYA_CD
    and
      occ.GENGO_KBN = mt.GENGO_KBN
    and
      occ.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      occ.KAISYA_CD = mt.KAISYA_CD
    and
      occ.GENGO_KBN = mt.GENGO_KBN
    and
      occ.CUSTOMER_CODE = mt.TOKUCD)
  )
