select
  E.NAME as NAME
  ,E.MAIL_ADDRESS as MAIL_ADDRESS
from
  M_SHIMU S
inner join EMPLOYEE_USER E
on TO_CHAR(E.EMPLOYEE_ID) = S.EIGYO_TANTOCD
where
  S.SHIMUKECD = /* destinationCode */0
