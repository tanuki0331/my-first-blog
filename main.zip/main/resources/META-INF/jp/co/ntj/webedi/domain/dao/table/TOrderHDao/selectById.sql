select
  /*%expand*/*
from
  T_ORDER_H
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  ORDERNO = /* orderno */1
