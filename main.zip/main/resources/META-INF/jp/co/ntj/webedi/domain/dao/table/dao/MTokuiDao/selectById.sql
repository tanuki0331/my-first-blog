select
  /*%expand*/*
from
  M_TOKUI
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  TOKUCD = /* tokucd */1
