select
  /*%expand*/*
from
  CUSTOMER_USER_AUTHORITY
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  CUSTOMER_USER_ID = /* customerUserId */1
