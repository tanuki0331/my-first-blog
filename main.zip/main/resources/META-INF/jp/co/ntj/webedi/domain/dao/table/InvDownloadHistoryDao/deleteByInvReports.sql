delete from
  INV_DOWNLOAD_HISTORY
where
  KAISYA_CD = /* invReports.kaisyaCd */'a'
and
  GENGO_KBN = /* invReports.gengoKbn */'b'
and
  CUSTOMER_CODE = /* invReports.customerCode */1
and
  DESTINATION_CODE = /* invReports.destinationCode */2
and
  INV_NUMBER = /* invReports.invNumber */'c'
and
  REPORT_CATEGORY = /* invReports.reportCategory */'d'
