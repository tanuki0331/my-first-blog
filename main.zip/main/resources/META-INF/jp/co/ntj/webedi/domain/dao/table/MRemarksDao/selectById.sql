select
  /*%expand*/*
from
  M_REMARKS
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  SHIMUKECD = /* shimukecd */1
