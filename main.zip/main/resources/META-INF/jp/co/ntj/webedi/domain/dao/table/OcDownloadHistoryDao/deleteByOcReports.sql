delete from
  OC_DOWNLOAD_HISTORY
WHERE
  KAISYA_CD = /* ocReports.kaisyaCd */'a'
and
  GENGO_KBN = /* ocReports.gengoKbn */'b'
and
  CUSTOMER_CODE = /* ocReports.customerCode */1
and
  DESTINATION_CODE = /* ocReports.destinationCode */2
and
  OC_NUMBER = /* ocReports.ocNumber */'c'
