select
  /*%expand*/*
from
  M_LSHIMU
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  LSHIMUKECD = /* lshimukecd */1
