select
  /*%expand*/*
from
  M_PURCHASE_ORDER_CHAR
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  SHIMUKECD = /* shimukecd */1
