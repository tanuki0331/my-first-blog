delete from
  ORDER_CART_HEADER
WHERE
  created_at < /* createdAt */'2018-01-01 00:00:00'
