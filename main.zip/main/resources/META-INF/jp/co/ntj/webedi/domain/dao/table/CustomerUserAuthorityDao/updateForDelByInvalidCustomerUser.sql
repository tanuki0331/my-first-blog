update
  CUSTOMER_USER_AUTHORITY cua
set
  cua.IS_DELETED = 1
  ,cua.UPDATED_AT = SYSDATE
  ,cua.UPDATED_USER = /* updateUser */'a'
where
  cua.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      cua.KAISYA_CD = cu.KAISYA_CD
    and
      cua.GENGO_KBN = cu.GENGO_KBN
    and
      cua.CUSTOMER_USER_ID = cu.ID
    and
      cu.IS_DELETED != 0) or
  not exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      cua.KAISYA_CD = cu.KAISYA_CD
    and
      cua.GENGO_KBN = cu.GENGO_KBN
    and
      cua.CUSTOMER_USER_ID = cu.ID)
  )
