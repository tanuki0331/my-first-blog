select
  /*%expand*/*
from
  M_SHIMU
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  SHIMUKECD = /* shimukecd */1
  and
  TOKUCD = /* tokucd */1
