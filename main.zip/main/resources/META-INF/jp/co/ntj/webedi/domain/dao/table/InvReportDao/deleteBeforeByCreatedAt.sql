delete from
  INV_REPORT
WHERE
  created_at < /* createdAt */'2018-01-01 00:00:00'
