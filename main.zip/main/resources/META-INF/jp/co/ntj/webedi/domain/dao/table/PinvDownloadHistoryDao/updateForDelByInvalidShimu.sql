update
  PINV_DOWNLOAD_HISTORY pdh
set
  pdh.IS_DELETED = 1
  ,pdh.UPDATED_AT = SYSDATE
  ,pdh.UPDATED_USER = /* updateUser */'a'
where
  pdh.IS_DELETED != 1
and (
  -- 仕向け先マスタ
  exists (
    select
      1
    from
      M_SHIMU ms
    where
      pdh.KAISYA_CD = ms.KAISYA_CD
    and
      pdh.GENGO_KBN = ms.GENGO_KBN
    and
      pdh.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_SHIMU ms
    where
      pdh.KAISYA_CD = ms.KAISYA_CD
    and
      pdh.GENGO_KBN = ms.GENGO_KBN
    and
      pdh.DESTINATION_CODE = ms.SHIMUKECD) or
  -- 最終仕向け先マスタ
  exists (
    select
      1
    from
      M_LSHIMU mls
    where
      pdh.KAISYA_CD = mls.KAISYA_CD
    and
      pdh.GENGO_KBN = mls.GENGO_KBN
    and
      pdh.DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_LSHIMU mls
    where
      pdh.KAISYA_CD = mls.KAISYA_CD
    and
      pdh.GENGO_KBN = mls.GENGO_KBN
    and
      pdh.DESTINATION_CODE = mls.LSHIMUKECD)
  )
