select
  /*%expand*/*
from
  M_PLIST
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  TOKUCD = /* tokucd */1
  and
  SHIMUKECD = /* shimukecd */1
  and
  SHOHINCD = /* shohincd */'a'
  and
  YUSO_HOHOCD = /* yusoHohocd */1
