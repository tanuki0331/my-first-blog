select
  /*%expand*/*
from
  PROCESS_EXECUTE_TIME
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  PROCESS_CATEGORY = /* processCategory */'a'
