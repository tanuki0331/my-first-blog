select
  /*%expand*/*
from
  CUSTOMER_USER_DLVY_MAIL
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  CUSTOMER_USER_ID = /* customerUserId */1
  and
  SEQUENCE_NUMBER = /* sequenceNumber */1
