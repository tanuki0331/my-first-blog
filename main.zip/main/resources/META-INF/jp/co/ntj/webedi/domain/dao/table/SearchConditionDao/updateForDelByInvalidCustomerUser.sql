update
  SEARCH_CONDITION sc
set
  sc.IS_DELETED = 1
  ,sc.UPDATED_AT = SYSDATE
  ,sc.UPDATED_USER = /* updateUser */'a'
where
  sc.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      sc.KAISYA_CD = cu.KAISYA_CD
    and
      sc.GENGO_KBN = cu.GENGO_KBN
    and
      sc.CUSTOMER_USER_ID = cu.ID
    and
      cu.IS_DELETED != 0) or
  not exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      sc.KAISYA_CD = cu.KAISYA_CD
    and
      sc.GENGO_KBN = cu.GENGO_KBN
    and
      sc.CUSTOMER_USER_ID = cu.ID)
  )
