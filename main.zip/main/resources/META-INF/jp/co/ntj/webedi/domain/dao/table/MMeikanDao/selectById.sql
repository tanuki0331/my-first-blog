select
  /*%expand*/*
from
  M_MEIKAN
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  MEIKANCD = /* meikancd */'a'
