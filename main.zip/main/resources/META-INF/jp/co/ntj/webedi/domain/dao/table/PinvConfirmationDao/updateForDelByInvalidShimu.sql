update
  PINV_CONFIRMATION pic
set
  pic.IS_DELETED = 1
  ,pic.UPDATED_AT = SYSDATE
  ,pic.UPDATED_USER = /* updateUser */'a'
where
  pic.IS_DELETED != 1
and (
  -- 仕向け先マスタ
  exists (
    select
      1
    from
      M_SHIMU ms
    where
      pic.KAISYA_CD = ms.KAISYA_CD
    and
      pic.GENGO_KBN = ms.GENGO_KBN
    and
      pic.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_SHIMU ms
    where
      pic.KAISYA_CD = ms.KAISYA_CD
    and
      pic.GENGO_KBN = ms.GENGO_KBN
    and
      pic.DESTINATION_CODE = ms.SHIMUKECD) or
  -- 最終仕向け先マスタ
  exists (
    select
      1
    from
      M_LSHIMU mls
    where
      pic.KAISYA_CD = mls.KAISYA_CD
    and
      pic.GENGO_KBN = mls.GENGO_KBN
    and
      pic.DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_LSHIMU mls
    where
      pic.KAISYA_CD = mls.KAISYA_CD
    and
      pic.GENGO_KBN = mls.GENGO_KBN
    and
      pic.DESTINATION_CODE = mls.LSHIMUKECD)
  )
