update
  ORDER_CART_HEADER och
set
  och.IS_DELETED = 1
  ,och.UPDATED_AT = SYSDATE
  ,och.UPDATED_USER = /* updateUser */'a'
where
  och.IS_DELETED != 1
and
  not exists (
    select
      1
    from
      ORDER_CART_DETAIL ocd
    where
      och.KAISYA_CD = ocd.KAISYA_CD
    and
      och.GENGO_KBN = ocd.GENGO_KBN
    and
      och.CUSTOMER_USER_ID = ocd.CUSTOMER_USER_ID
    and
      ocd.IS_DELETED = 0)
