update
  INV_REPORT ir
set
  ir.IS_DELETED = 1
  ,ir.UPDATED_AT = SYSDATE
  ,ir.UPDATED_USER = /* updateUser */'a'
where
  ir.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      M_TOKUI mt
    where
      ir.KAISYA_CD = mt.KAISYA_CD
    and
      ir.GENGO_KBN = mt.GENGO_KBN
    and
      ir.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      ir.KAISYA_CD = mt.KAISYA_CD
    and
      ir.GENGO_KBN = mt.GENGO_KBN
    and
      ir.CUSTOMER_CODE = mt.TOKUCD)
  )
