select
  /*%expand*/*
from
  CODE
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  CODE_CATEGORY = /* codeCategory */'a'
  and
  CODE = /* code */'a'
