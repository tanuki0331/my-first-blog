delete from
  OC_DOWNLOAD_HISTORY
where
  IS_DELETED = '1'
and
  CREATED_AT < /* createdAt */'2018-01-01 00:00:00'
