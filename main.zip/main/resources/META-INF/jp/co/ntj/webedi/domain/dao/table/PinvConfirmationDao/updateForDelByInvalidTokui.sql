update
  PINV_CONFIRMATION pic
set
  pic.IS_DELETED = 1
  ,pic.UPDATED_AT = SYSDATE
  ,pic.UPDATED_USER = /* updateUser */'a'
where
  pic.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      M_TOKUI mt
    where
      pic.KAISYA_CD = mt.KAISYA_CD
    and
      pic.GENGO_KBN = mt.GENGO_KBN
    and
      pic.CUSTOMER_CODE = mt.TOKUCD
    and
      mt.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_TOKUI mt
    where
      pic.KAISYA_CD = mt.KAISYA_CD
    and
      pic.GENGO_KBN = mt.GENGO_KBN
    and
      pic.CUSTOMER_CODE = mt.TOKUCD)
  )
