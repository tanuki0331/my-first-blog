update
  CUSTOMER_USER_ACCESS_INFO cuai
set
  cuai.IS_DELETED = 1
  ,cuai.UPDATED_AT = SYSDATE
  ,cuai.UPDATED_USER = /* updateUser */'a'
where
  cuai.IS_DELETED != 1
and (
  exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      cuai.KAISYA_CD = cu.KAISYA_CD
    and
      cuai.GENGO_KBN = cu.GENGO_KBN
    and
      cuai.CUSTOMER_USER_ID = cu.ID
    and
      cu.IS_DELETED != 0) or
  not exists (
    select
      1
    from
      CUSTOMER_USER cu
    where
      cuai.KAISYA_CD = cu.KAISYA_CD
    and
      cuai.GENGO_KBN = cu.GENGO_KBN
    and
      cuai.CUSTOMER_USER_ID = cu.ID)
  )
