select
  /*%expand*/*
from
  M_USER
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  LOGIN_NAME = /* loginName */'a'
