select
    SEQUENCE_NUMBER                               -- 連番
  , MAIL_ADDRESS                                  -- メールアドレス
  , USE_ORDER_MAIL                                -- 注文登録メール有効フラグ
  , IS_VALIDATED_OC_ISSUE_MAIL                    -- OC発行メール有効フラグ
  , IS_VALIDATED_INV_ISSUE_MAIL                   -- INV発行メール有効フラグ
  , IS_VALIDATED_PINV_ISSUE_MAIL                  -- P/I発行メール有効フラグ
from
  CUSTOMER_USER_DLVY_MAIL
where
    KAISYA_CD = /* kaisyaCd */'1001'
  and
    GENGO_KBN = /* gengoKbn */'EN'
  and
    CUSTOMER_USER_ID = /* customerUserId */2
  and
    IS_DELETED = 0
order by
  SEQUENCE_NUMBER
