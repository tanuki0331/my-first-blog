select
  AUTHORITY                                     -- 権限
from
  EMPLOYEE_USER_AUTHORITY
where
    KAISYA_CD = /* kaisyaCd */'1001'
  and
    GENGO_KBN = /* gengoKbn */'EN'
  and
    EMPLOYEE_USER_ID = /* employeeUserId */1
  and
    IS_DELETED = 0
