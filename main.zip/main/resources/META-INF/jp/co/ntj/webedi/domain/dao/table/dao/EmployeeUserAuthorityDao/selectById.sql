select
  /*%expand*/*
from
  EMPLOYEE_USER_AUTHORITY
where
  KAISYA_CD = /* kaisyaCd */'a'
  and
  GENGO_KBN = /* gengoKbn */'a'
  and
  EMPLOYEE_USER_ID = /* employeeUserId */1
