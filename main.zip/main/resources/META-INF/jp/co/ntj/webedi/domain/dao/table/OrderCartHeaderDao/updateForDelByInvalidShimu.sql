update
  ORDER_CART_HEADER och
set
  och.IS_DELETED = 1
  ,och.UPDATED_AT = SYSDATE
  ,och.UPDATED_USER = /* updateUser */'a'
where
  och.IS_DELETED != 1
and (
  -- 仕向け先マスタ
  exists (
    select
      1
    from
      M_SHIMU ms
    where
      och.KAISYA_CD = ms.KAISYA_CD
    and
      och.GENGO_KBN = ms.GENGO_KBN
    and
      och.DESTINATION_CODE = ms.SHIMUKECD
    and
      ms.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_SHIMU ms
    where
      och.KAISYA_CD = ms.KAISYA_CD
    and
      och.GENGO_KBN = ms.GENGO_KBN
    and
      och.DESTINATION_CODE = ms.SHIMUKECD) or
  -- 最終仕向け先マスタ
  exists (
    select
      1
    from
      M_LSHIMU mls
    where
      och.KAISYA_CD = mls.KAISYA_CD
    and
      och.GENGO_KBN = mls.GENGO_KBN
    and
      och.LAST_DESTINATION_CODE = mls.LSHIMUKECD
    and
      mls.REC_DLTFLG != 0) or
  not exists (
    select
      1
    from
      M_LSHIMU mls
    where
      och.KAISYA_CD = mls.KAISYA_CD
    and
      och.GENGO_KBN = mls.GENGO_KBN
    and
      och.LAST_DESTINATION_CODE = mls.LSHIMUKECD)
  )
