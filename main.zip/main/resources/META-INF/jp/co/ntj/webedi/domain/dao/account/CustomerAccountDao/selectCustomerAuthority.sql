select
  AUTHORITY                                     -- 権限
from
  CUSTOMER_USER_AUTHORITY
where
    KAISYA_CD = /* kaisyaCd */'1001'
  and
    GENGO_KBN = /* gengoKbn */'EN'
  and
    CUSTOMER_USER_ID = /* customerUserId */2
  and
    IS_DELETED = 0
