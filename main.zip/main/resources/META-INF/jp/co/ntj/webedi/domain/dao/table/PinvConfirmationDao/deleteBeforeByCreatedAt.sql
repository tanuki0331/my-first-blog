delete from
  PINV_CONFIRMATION
WHERE
  created_at < /* createdAt */'2018-01-01 00:00:00'
